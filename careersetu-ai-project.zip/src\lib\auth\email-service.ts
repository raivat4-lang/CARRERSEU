// Professional Email Dispatch Service for CareerSetu AI MFA & Password Reset
// Generates and dispatches security codes via backend nodemailer SMTP transport.

import { dispatchEmailOtpServerFn } from "./auth.functions";

export interface EmailDispatchOptions {
  to: string;
  subject?: string;
  templateType: "STUDENT_LOGIN_MFA" | "STUDENT_SIGNUP_VERIFY" | "ADMIN_LOGIN_MFA" | "ADMIN_PASSWORD_RESET" | "ADMIN_FIRST_SETUP";
  recipientName?: string;
  otpCode?: string;
  expiresInMinutes?: number;
}

export interface EmailDispatchResult {
  success: boolean;
  message: string;
  isDevelopmentMode: boolean;
  maskedRecipient: string;
  challengeToken?: string;
  deliveryTimestamp: string;
  error?: string;
  /** Only present in dev mode (no SMTP). Never set in production. */
  devOtp?: string;
}

// Mask Email helper
export function maskEmailAddress(email: string): string {
  if (!email || !email.includes("@")) return "******@domain.com";
  const [user, domain] = email.split("@");
  if (!user || !domain) return "******@domain.com";
  if (user.length <= 2) return `${user[0]}*@${domain}`;
  const first = user[0];
  const last = user[user.length - 1];
  const stars = "*".repeat(Math.max(3, user.length - 2));
  return `${first}${stars}${last}@${domain}`;
}

// Dispatches Email via backend server function (never exposes OTP to client DOM/storage)
export async function sendAuthenticationEmail(options: EmailDispatchOptions): Promise<EmailDispatchResult> {
  const { to, recipientName = "User", templateType } = options;
  const timestamp = new Date().toISOString();
  const masked = maskEmailAddress(to);

  // Map to server function purpose
  let purpose: "STUDENT_LOGIN" | "STUDENT_VERIFY" | "ADMIN_LOGIN" | "ADMIN_FIRST_SETUP" | "ADMIN_RESET" = "STUDENT_LOGIN";
  if (templateType === "STUDENT_SIGNUP_VERIFY") purpose = "STUDENT_VERIFY";
  else if (templateType === "ADMIN_LOGIN_MFA") purpose = "ADMIN_LOGIN";
  else if (templateType === "ADMIN_FIRST_SETUP") purpose = "ADMIN_FIRST_SETUP";
  else if (templateType === "ADMIN_PASSWORD_RESET") purpose = "ADMIN_RESET";

  try {
    const res = await dispatchEmailOtpServerFn({
      data: {
        email: to,
        recipientName,
        purpose,
      },
    });

    if (res.success && res.challengeToken) {
      if (typeof sessionStorage !== "undefined") {
        sessionStorage.setItem("careersetu_auth_challenge_token", res.challengeToken);
        // Clear any old dev plain-text token
        sessionStorage.removeItem("careersetu_latest_dev_email");
      }

      return {
        success: true,
        message: `Security code sent to ${res.maskedEmail || masked}`,
        isDevelopmentMode: !res.sentViaSmtp,
        maskedRecipient: res.maskedEmail || masked,
        challengeToken: res.challengeToken,
        deliveryTimestamp: timestamp,
        devOtp: res.devOtp,
      };
    }

    return {
      success: false,
      message: res.error || "Failed to dispatch verification code.",
      isDevelopmentMode: false,
      maskedRecipient: masked,
      deliveryTimestamp: timestamp,
      error: res.error,
    };
  } catch (err: any) {
    console.error("Failed to execute dispatchEmailOtpServerFn:", err);
    return {
      success: false,
      message: err?.message || "An unexpected error occurred dispatching verification email.",
      isDevelopmentMode: false,
      maskedRecipient: masked,
      deliveryTimestamp: timestamp,
      error: err?.message,
    };
  }
}
