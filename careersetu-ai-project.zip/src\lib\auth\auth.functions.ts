// TanStack Start Server Functions for Email Security Code Generation, Dispatching & Verification
// Strictly runs on the server. Environment variables (SMTP credentials, SESSION_SECRET) are accessed securely.

import { createServerFn } from "@tanstack/react-start";
import { createHmac, createHash, randomBytes } from "crypto";
import { sendEmailViaSmtp, SendEmailPayload } from "./email.server";

export interface OtpChallengeData {
  email: string;
  codeHash: string;
  purpose: string;
  expiresAt: number; // Unix epoch ms
  attemptCount: number;
}

function getSecretKey(): string {
  const env = typeof process !== "undefined" && process.env ? process.env : ({} as Record<string, string | undefined>);
  return env.SESSION_SECRET || "careersetu_production_cryptographic_session_secret_2026_tier1";
}

function signChallenge(payload: OtpChallengeData): string {
  const secret = getSecretKey();
  const raw = Buffer.from(JSON.stringify(payload)).toString("base64url");
  const signature = createHmac("sha256", secret).update(raw).digest("base64url");
  return `${raw}.${signature}`;
}

function verifyAndDecodeChallenge(token: string): OtpChallengeData | null {
  try {
    const parts = token.split(".");
    if (parts.length !== 2) return null;
    const [raw, signature] = parts;
    if (!raw || !signature) return null;

    const secret = getSecretKey();
    const expectedSignature = createHmac("sha256", secret).update(raw).digest("base64url");

    if (signature !== expectedSignature) {
      return null;
    }

    const json = Buffer.from(raw, "base64url").toString("utf8");
    return JSON.parse(json) as OtpChallengeData;
  } catch {
    return null;
  }
}

function hashOtp(otp: string): string {
  return createHash("sha256").update(otp.trim()).digest("hex");
}

function maskEmail(email: string): string {
  if (!email || !email.includes("@")) return "******@domain.com";
  const [user, domain] = email.split("@");
  if (!user || !domain) return "******@domain.com";
  if (user.length <= 2) return `${user[0]}*@${domain}`;
  const first = user[0];
  const last = user[user.length - 1];
  const stars = "*".repeat(Math.max(3, user.length - 2));
  return `${first}${stars}${last}@${domain}`;
}

// Server in-memory rate limiting store for resend protection (cooldown enforcement)
const resendRateLimitMap = new Map<string, number>();

// 1. Dispatch OTP via Email Server Function
export const dispatchEmailOtpServerFn = createServerFn({ method: "POST" })
  .validator((data: {
    email: string;
    purpose?: "STUDENT_LOGIN" | "STUDENT_VERIFY" | "ADMIN_LOGIN" | "ADMIN_FIRST_SETUP" | "ADMIN_RESET";
    recipientName?: string;
  }) => data)
  .handler(async ({ data }) => {
    const cleanEmail = (data.email || "").trim().toLowerCase();
    const purpose = data.purpose || "STUDENT_LOGIN";
    const recipientName = data.recipientName || "Student";

    if (!cleanEmail || !cleanEmail.includes("@")) {
      return { success: false, error: "A valid email address is required." };
    }

    // Rate-limiting check: 15 second minimum between requests for same email
    const now = Date.now();
    const lastSent = resendRateLimitMap.get(cleanEmail);
    if (lastSent && now - lastSent < 15000) {
      const waitSec = Math.ceil((15000 - (now - lastSent)) / 1000);
      return {
        success: false,
        error: `Please wait ${waitSec} seconds before requesting another code.`,
      };
    }
    resendRateLimitMap.set(cleanEmail, now);

    // Cryptographically secure 6-digit numeric OTP
    // Generate buffer to avoid PRNG predictability
    const randomBuf = randomBytes(4);
    const num = randomBuf.readUInt32BE(0) % 900000;
    const otpCode = String(100000 + num);

    const codeHash = hashOtp(otpCode);
    const expiresInMinutes = 10;
    const expiresAt = now + expiresInMinutes * 60 * 1000;

    // Dispatch via backend nodemailer SMTP transporter
    const emailResult = await sendEmailViaSmtp({
      to: cleanEmail,
      subject: `CareerSetu Verification Code`,
      recipientName,
      otpCode,
      purpose,
      expiresInMinutes,
    });

    // Create signed challenge token (NEVER contains plaintext OTP)
    const challengePayload: OtpChallengeData = {
      email: cleanEmail,
      codeHash,
      purpose,
      expiresAt,
      attemptCount: 0,
    };
    const challengeToken = signChallenge(challengePayload);

    // In dev mode (no SMTP configured), return the OTP so the UI can show it as a dev helper.
    // In production (sentViaSmtp=true), devOtp is NEVER included.
    return {
      success: true,
      maskedEmail: maskEmail(cleanEmail),
      expiresInMinutes,
      challengeToken,
      sentViaSmtp: emailResult.sentViaSmtp,
      devOtp: emailResult.sentViaSmtp ? undefined : otpCode,
    };
  });

// 2. Verify OTP Server Function
export const verifyEmailOtpServerFn = createServerFn({ method: "POST" })
  .validator((data: {
    email: string;
    otp: string;
    challengeToken?: string;
  }) => data)
  .handler(async ({ data }) => {
    const cleanEmail = (data.email || "").trim().toLowerCase();
    const cleanOtp = (data.otp || "").trim();
    const token = data.challengeToken;

    if (!cleanOtp || cleanOtp.length !== 6) {
      return { valid: false, error: "Please enter the complete 6-digit verification code." };
    }

    if (!token) {
      // Fallback check if token wasn't passed directly
      return { valid: false, error: "Session challenge expired. Please request a new code." };
    }

    const challenge = verifyAndDecodeChallenge(token);
    if (!challenge) {
      return { valid: false, error: "Invalid security verification token. Please sign in again." };
    }

    if (challenge.email.toLowerCase() !== cleanEmail) {
      return { valid: false, error: "Email mismatch for verification token." };
    }

    if (Date.now() > challenge.expiresAt) {
      return { valid: false, error: "Verification code has expired. Please request a new code." };
    }

    if (challenge.attemptCount >= 5) {
      return { valid: false, error: "Too many failed attempts. Code locked for security. Please request a new code." };
    }

    const inputHash = hashOtp(cleanOtp);
    if (inputHash !== challenge.codeHash) {
      // Return updated challenge token with incremented attempt count
      challenge.attemptCount += 1;
      const updatedToken = signChallenge(challenge);
      const remaining = 5 - challenge.attemptCount;

      return {
        valid: false,
        updatedChallengeToken: updatedToken,
        error: `Incorrect verification code. ${remaining > 0 ? `${remaining} attempts remaining.` : "Code locked."}`,
      };
    }

    // Success! Verification validated on backend
    return {
      valid: true,
      email: cleanEmail,
      purpose: challenge.purpose,
    };
  });
