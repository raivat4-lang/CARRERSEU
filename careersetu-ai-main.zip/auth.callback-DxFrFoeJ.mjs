import { i as __toESM } from "../_runtime.mjs";
import { v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { k as setCurrentUser } from "./rbac-D_Rf6U5V.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { B as LoaderCircle, dt as CircleX, pt as CircleCheck } from "../_libs/lucide-react.mjs";
import { t as Logo } from "./Logo-CGI7av7x.mjs";
import { t as supabase } from "./client-DVcAC_2T.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth.callback-DxFrFoeJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AuthCallbackPage() {
	const navigate = useNavigate();
	const [status, setStatus] = (0, import_react.useState)("loading");
	const [message, setMessage] = (0, import_react.useState)("Completing Google sign-in…");
	(0, import_react.useEffect)(() => {
		async function handleCallback() {
			try {
				const { data, error } = await supabase.auth.getSession();
				if (error || !data.session) {
					const hash = window.location.hash;
					const search = window.location.search;
					if (hash || search.includes("code=")) {
						const { data: exchangeData, error: exchangeError } = await supabase.auth.exchangeCodeForSession(search || hash);
						if (exchangeError || !exchangeData.session) throw new Error(exchangeError?.message || "No session returned from Google.");
						await buildAndSaveUser(exchangeData.session.user, navigate);
						return;
					}
					throw new Error(error?.message || "Google sign-in was cancelled or failed.");
				}
				await buildAndSaveUser(data.session.user, navigate);
			} catch (err) {
				console.error("[Google OAuth callback error]", err);
				setStatus("error");
				setMessage(err?.message || "Sign-in failed. Please try again.");
				setTimeout(() => navigate({
					to: "/auth",
					search: { mode: "login" }
				}), 3e3);
			}
		}
		handleCallback();
	}, [navigate]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-dvh bg-gradient-to-br from-background via-background/95 to-primary/5 flex items-center justify-center p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center space-y-5 max-w-sm w-full",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center mb-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { size: "lg" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col items-center gap-4 p-8 rounded-3xl bg-card border border-border/80 shadow-elegant backdrop-blur-xl",
				children: [
					status === "loading" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-14 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-7 text-primary animate-spin" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-bold text-foreground font-display text-lg",
							children: "Google Sign-In"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground mt-1",
							children: message
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-full bg-muted rounded-full h-1.5 overflow-hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full bg-primary rounded-full animate-pulse w-3/4" })
						})
					] }),
					status === "success" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-7 text-emerald-500" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-bold text-foreground font-display text-lg",
						children: "Signed In!"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground mt-1",
						children: message
					})] })] }),
					status === "error" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-14 rounded-2xl bg-destructive/10 border border-destructive/20 flex items-center justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "size-7 text-destructive" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-bold text-foreground font-display text-lg",
							children: "Sign-In Failed"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground mt-1",
							children: message
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground/70 mt-2",
							children: "Redirecting back to login…"
						})
					] })] })
				]
			})]
		})
	});
}
async function buildAndSaveUser(supabaseUser, navigate) {
	const email = supabaseUser.email || "";
	const meta = supabaseUser.user_metadata || {};
	const name = meta.full_name || meta.name || meta.preferred_username || email.split("@")[0] || "Student";
	const googleUser = {
		id: `google-${supabaseUser.id}`,
		name,
		full_name: name,
		email,
		password_hash: null,
		phone: meta.phone || void 0,
		role: "STUDENT",
		is_active: true,
		status: "ACTIVE",
		email_verified: true,
		is_first_login: false,
		education: void 0,
		current_education: void 0,
		preferred_language: "english",
		created_at: (/* @__PURE__ */ new Date()).toISOString(),
		registeredAt: (/* @__PURE__ */ new Date()).toISOString(),
		updated_at: (/* @__PURE__ */ new Date()).toISOString(),
		lastActive: (/* @__PURE__ */ new Date()).toISOString()
	};
	setCurrentUser(googleUser);
	navigate({ to: "/dashboard" });
}
//#endregion
export { AuthCallbackPage as component };
