import { i as __toESM } from "../_runtime.mjs";
import { g as Link, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Card } from "./card-95-PmP7N.mjs";
import { t as Badge } from "./badge-BYEzUON3.mjs";
import { t as Button } from "./button-CdcMTBqt.mjs";
import { C as Search, G as Landmark, Ot as Bookmark, T as RotateCcw, g as Sparkles, it as ExternalLink, xt as Calendar, y as ShieldAlert } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, n as DialogContent, o as DialogTitle, t as Dialog } from "./dialog-d9GHmrLL.mjs";
import { t as Input } from "./input-D7UBWI0-.mjs";
import { o as getManagedExams } from "./admin-content-store-CcAL24zG.mjs";
import { _ as toggleBookmark, l as isBookmarked } from "./careersetu-store-CamG1tac.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-BfMpEmcB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/exams-AZSYYp2I.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var EXAM_CATEGORIES = [
	"All Categories",
	"Civil Services",
	"Engineering & Science",
	"Defense & Police",
	"Banking & Finance"
];
var STATUS_FILTERS = [
	"All Statuses",
	"Registration Open",
	"Upcoming",
	"Admit Card Released"
];
function ExamsFinderPage() {
	useNavigate();
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [selectedCategory, setSelectedCategory] = (0, import_react.useState)("All Categories");
	const [selectedStatus, setSelectedStatus] = (0, import_react.useState)("All Statuses");
	const [selectedExam, setSelectedExam] = (0, import_react.useState)(null);
	const [bookmarkedMap, setBookmarkedMap] = (0, import_react.useState)({});
	const [examsList, setExamsList] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		const live = getManagedExams().filter((e) => e.status !== "ARCHIVED");
		setExamsList(live);
		const bMap = {};
		live.forEach((e) => {
			bMap[e.id] = isBookmarked("exams", e.id);
		});
		setBookmarkedMap(bMap);
	}, []);
	const handleToggleBookmark = (examId) => {
		const isNow = toggleBookmark("exams", examId);
		setBookmarkedMap((prev) => ({
			...prev,
			[examId]: isNow
		}));
		toast.success(isNow ? "Exam added to bookmarks" : "Removed from bookmarks");
	};
	const filteredExams = (0, import_react.useMemo)(() => {
		return examsList.filter((e) => {
			const q = searchQuery.toLowerCase().trim();
			const matchesSearch = !q || e.name.toLowerCase().includes(q) || e.shortName && e.shortName.toLowerCase().includes(q) || e.conductingBody && e.conductingBody.toLowerCase().includes(q) || e.category && e.category.toLowerCase().includes(q);
			const matchesCat = selectedCategory === "All Categories" || e.category === selectedCategory;
			const matchesStatus = selectedStatus === "All Statuses" || e.status === selectedStatus;
			return matchesSearch && matchesCat && matchesStatus;
		});
	}, [
		examsList,
		searchQuery,
		selectedCategory,
		selectedStatus
	]);
	const resetFilters = () => {
		setSearchQuery("");
		setSelectedCategory("All Categories");
		setSelectedStatus("All Statuses");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 max-w-5xl mx-auto py-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-border",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-9 place-items-center rounded-xl bg-blue-500/10 text-blue-500",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-xl sm:text-2xl font-bold font-display text-foreground",
						children: "Government & National Exam Finder"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs sm:text-sm text-muted-foreground mt-1",
					children: "Track official timelines, eligibility, age limits, syllabus patterns, and salary scales."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/study-planner",
					className: "shrink-0 inline-flex items-center gap-1.5 gradient-brand text-primary-foreground font-bold text-xs py-2 px-3.5 rounded-2xl shadow-glow",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-4" }), " Create Study Plan"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "glass p-4 rounded-3xl border-border/80 shadow-xs space-y-3 bg-card/80",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 sm:grid-cols-3 gap-2.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-2.5 size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: searchQuery,
								onChange: (e) => setSearchQuery(e.target.value),
								placeholder: "Search UPSC, GATE, SSC, ISRO...",
								className: "pl-9 h-10 rounded-xl bg-background border-border text-xs sm:text-sm"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: selectedCategory,
							onValueChange: setSelectedCategory,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								className: "rounded-xl h-10 text-xs bg-background",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Category" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, {
								className: "rounded-2xl",
								children: EXAM_CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: c,
									className: "text-xs",
									children: c
								}, c))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: selectedStatus,
							onValueChange: setSelectedStatus,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								className: "rounded-xl h-10 text-xs bg-background",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Status" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, {
								className: "rounded-2xl",
								children: STATUS_FILTERS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: s,
									className: "text-xs",
									children: s
								}, s))
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between text-xs pt-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted-foreground font-semibold",
						children: [
							"Showing ",
							filteredExams.length,
							" Active National Exams"
						]
					}), (searchQuery || selectedCategory !== "All Categories" || selectedStatus !== "All Statuses") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: resetFilters,
						className: "text-[11px] text-primary hover:underline flex items-center gap-1 cursor-pointer font-medium",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-3" }), " Reset Filters"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 md:grid-cols-2 gap-4",
				children: filteredExams.map((exam) => {
					const isSaved = bookmarkedMap[exam.id];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "glass p-5 rounded-3xl border-border/80 hover:border-blue-500/40 transition-all shadow-xs hover:shadow-lg flex flex-col justify-between space-y-4 bg-card/90",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "outline",
										className: "text-[10px] border-blue-500/30 text-blue-500 bg-blue-500/5",
										children: exam.category
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `text-[10px] font-bold px-2 py-0.5 rounded-full border ${exam.status === "Registration Open" ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/30 animate-pulse" : exam.status === "Admit Card Released" ? "bg-amber-500/10 text-amber-500 border-amber-500/30" : "bg-accent text-foreground/80 border-border"}`,
											children: exam.status
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => handleToggleBookmark(exam.id),
											className: "p-1 rounded-lg text-muted-foreground hover:text-primary transition-colors cursor-pointer",
											title: "Bookmark exam",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: `size-3.5 ${isSaved ? "fill-primary text-primary" : ""}` })
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-bold text-base text-foreground leading-snug",
										children: exam.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[11px] font-semibold text-primary mt-0.5",
										children: [
											exam.conductingBody,
											" · ",
											exam.frequency
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground mt-1.5 line-clamp-2 leading-relaxed",
										children: exam.summary
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5 pt-2 border-t border-border/40 text-xs text-muted-foreground",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Age Limit:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "text-foreground",
												children: exam.ageLimit
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Starting Package:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "text-emerald-500",
												children: exam.salaryPayScale.split("->")[0]?.slice(0, 32)
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Last Updated:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[11px] font-mono text-muted-foreground",
												children: exam.lastUpdated
											})]
										})
									]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 pt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								size: "sm",
								onClick: () => setSelectedExam(exam),
								className: "flex-1 rounded-xl text-xs font-semibold hover:bg-accent cursor-pointer",
								children: "View Details & Pattern →"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: exam.officialWebsite,
								target: "_blank",
								rel: "noreferrer",
								className: "p-2 rounded-xl border border-border hover:bg-accent text-muted-foreground hover:text-foreground cursor-pointer",
								title: "Official Website",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-4" })
							})]
						})]
					}, exam.id);
				})
			}),
			selectedExam && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: !!selectedExam,
				onOpenChange: () => setSelectedExam(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-3xl max-h-[85vh] overflow-y-auto p-6 sm:p-8 rounded-3xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 mb-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							className: "bg-blue-500/10 text-blue-500 border-blue-500/20 text-xs",
							children: selectedExam.category
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs font-bold text-muted-foreground",
							children: ["Official Portal: ", selectedExam.conductingBody]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
						className: "text-xl sm:text-2xl font-bold font-display text-foreground",
						children: [
							selectedExam.name,
							" (",
							selectedExam.shortName,
							")"
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-6 text-xs sm:text-sm mt-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-foreground/90 leading-relaxed bg-accent/30 p-3.5 rounded-2xl border border-border/60",
								children: selectedExam.summary
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-3 gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3 rounded-2xl bg-card border border-border",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] text-muted-foreground block",
											children: "Eligibility Qualification"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-foreground text-xs",
											children: selectedExam.eligibility
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3 rounded-2xl bg-card border border-border",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] text-muted-foreground block",
											children: "Age Bracket"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-foreground text-xs",
											children: selectedExam.ageLimit
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3 rounded-2xl bg-card border border-border",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] text-muted-foreground block",
											children: "Pay Scale & Allowances"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-emerald-500 text-xs",
											children: selectedExam.salaryPayScale
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-4 rounded-2xl bg-accent/20 border border-border space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
									className: "font-bold text-xs uppercase tracking-wider text-muted-foreground flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3.5 text-primary" }), " Examination Structure & Pattern"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground block text-[10px]",
											children: "Total Marks:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: selectedExam.examPattern.totalMarks })] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground block text-[10px]",
											children: "Duration:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: selectedExam.examPattern.duration })] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground block text-[10px]",
											children: "Mode:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: selectedExam.examPattern.mode })] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground block text-[10px]",
											children: "Negative Marking:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: selectedExam.examPattern.negativeMarking })] })
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-bold text-xs uppercase tracking-wider text-muted-foreground",
									children: "Syllabus Highlights"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "space-y-1.5 text-xs text-foreground/90",
									children: selectedExam.syllabusHighlights.map((s, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-start gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-blue-500 shrink-0 mt-1.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: s })]
									}, idx))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3.5 rounded-2xl bg-card border border-border space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
										className: "font-bold text-xs text-foreground",
										children: "Previous Year Cutoff:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground font-mono",
										children: selectedExam.previousYearCutoff
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3.5 rounded-2xl bg-card border border-border space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
										className: "font-bold text-xs text-foreground",
										children: "Official Timeline:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: selectedExam.applicationTimeline
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-2 p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-[11px] text-amber-600 dark:text-amber-400",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-4 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"Official information last verified: ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: selectedExam.lastUpdated }),
									". Always confirm dates and updates on the official website:",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: selectedExam.officialWebsite,
										target: "_blank",
										rel: "noreferrer",
										className: "underline font-semibold",
										children: selectedExam.officialWebsite
									}),
									"."
								] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between gap-2 pt-4 border-t border-border",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									size: "sm",
									onClick: () => handleToggleBookmark(selectedExam.id),
									className: "rounded-xl cursor-pointer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: `size-3.5 mr-1 ${bookmarkedMap[selectedExam.id] ? "fill-primary text-primary" : ""}` }), bookmarkedMap[selectedExam.id] ? "Bookmarked" : "Bookmark Exam"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: selectedExam.officialWebsite,
										target: "_blank",
										rel: "noreferrer",
										className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-border hover:bg-accent text-xs font-semibold cursor-pointer",
										children: ["Official Portal ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3.5" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/study-planner",
										className: "gradient-brand text-primary-foreground font-bold text-xs py-2 px-4 rounded-xl shadow-xs",
										children: "Create Study Plan →"
									})]
								})]
							})
						]
					})]
				})
			})
		]
	});
}
//#endregion
export { ExamsFinderPage as component };
