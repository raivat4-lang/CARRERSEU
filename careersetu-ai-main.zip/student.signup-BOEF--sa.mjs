import { i as __toESM } from "../_runtime.mjs";
import { g as Link, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as registerStudentUser, N as evaluatePasswordStrength, O as resetUsersToTrialOnly } from "./rbac-D_Rf6U5V.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Card } from "./card-95-PmP7N.mjs";
import { t as Button } from "./button-CdcMTBqt.mjs";
import { B as LoaderCircle, E as RefreshCw, Mt as ArrowRight, s as UserPlus } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-D7UBWI0-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Logo } from "./Logo-CGI7av7x.mjs";
import { t as Label } from "./label-DiINKb2h.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-BfMpEmcB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/student.signup-BOEF--sa.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function StudentSignupPage() {
	const navigate = useNavigate();
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [duplicateEmail, setDuplicateEmail] = (0, import_react.useState)(null);
	const [formData, setFormData] = (0, import_react.useState)({
		name: "",
		email: "",
		password: "",
		confirmPassword: "",
		phone: "",
		age: "18",
		gender: "Male",
		state: "Maharashtra",
		city: "Pune",
		education: "Class 12 (Science)",
		preferred_language: "English"
	});
	const passwordStrength = evaluatePasswordStrength(formData.password);
	const handleClearTestData = () => {
		resetUsersToTrialOnly();
		setDuplicateEmail(null);
		toast.success("All test accounts removed. System reset to pre-seeded trial accounts.");
		window.location.reload();
	};
	const handleSubmit = async (e) => {
		e.preventDefault();
		if (!formData.name || !formData.email || !formData.password) {
			toast.error("Please fill in all required fields.");
			return;
		}
		if (formData.password !== formData.confirmPassword) {
			toast.error("Passwords do not match.");
			return;
		}
		if (!passwordStrength.isValid) {
			toast.error("Please create a stronger password (minimum 10 characters with uppercase, lowercase, and numbers).");
			return;
		}
		setLoading(true);
		try {
			const result = await registerStudentUser({
				name: formData.name.trim(),
				full_name: formData.name.trim(),
				email: formData.email.trim().toLowerCase(),
				password: formData.password,
				phone: formData.phone,
				age: formData.age,
				gender: formData.gender,
				state: formData.state,
				city: formData.city,
				education: formData.education,
				current_education: formData.education,
				preferred_language: formData.preferred_language
			});
			if (!result.success) {
				if (result.error?.includes("already exists")) setDuplicateEmail(formData.email.trim().toLowerCase());
				toast.error(result.error || "Registration failed. Please try again.");
				setLoading(false);
				return;
			}
			const cleanEmail = formData.email.trim().toLowerCase();
			if (typeof sessionStorage !== "undefined") {
				sessionStorage.setItem("careersetu_pending_student_email", cleanEmail);
				sessionStorage.setItem("careersetu_pending_student_masked", result.maskedEmail || "");
				if (result.devOtp) {
					sessionStorage.setItem("careersetu_dev_otp", result.devOtp);
					sessionStorage.setItem("careersetu_pending_dev_otp", result.devOtp);
				}
			}
			toast.success("Account created! Check your inbox for the 6-digit verification code.");
			navigate({ to: "/student/verify-mfa" });
		} catch (err) {
			toast.error("An unexpected error occurred. Please try again.");
		} finally {
			setLoading(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background text-foreground relative overflow-hidden flex flex-col justify-between p-4 sm:p-8 antialiased",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gradient-soft absolute inset-0 -z-10 opacity-70" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "blueprint-grid absolute inset-0 -z-10 opacity-40" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -top-32 left-1/2 -translate-x-1/2 -z-10 size-[32rem] rounded-full bg-primary/15 blur-[120px] pointer-events-none" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto w-full max-w-xl flex items-center justify-between pt-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "flex items-center gap-2 hover:opacity-90 transition-opacity",
					"aria-label": "CareerSetu home",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: handleClearTestData,
					title: "Remove all registered test accounts and reset to default trial state",
					className: "inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors px-2.5 py-1 rounded-lg border border-border/60 hover:bg-accent",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-3" }), "Reset Accounts"]
				})]
			}),
			duplicateEmail && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto w-full max-w-xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-amber-400/50 bg-amber-400/10 p-4 flex flex-col sm:flex-row sm:items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-bold text-amber-300 mb-0.5",
							children: "Account Already Exists"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-amber-200/80",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono font-bold",
								children: duplicateEmail
							}), " is already registered. If this is a test account, clear local data and try again."]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2 shrink-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => navigate({ to: "/student/login" }),
							className: "h-8 text-xs rounded-xl border-amber-400/50 text-amber-300 hover:bg-amber-400/10",
							children: "Sign In Instead"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							onClick: handleClearTestData,
							className: "h-8 text-xs rounded-xl bg-amber-500 hover:bg-amber-600 text-black font-bold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-3 mr-1" }), "Clear & Re-register"]
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto w-full max-w-xl py-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "rounded-3xl p-6 sm:p-8 bg-card/90 border border-border/80 shadow-elegant backdrop-blur-xl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3.5 pb-4 border-b border-border/70",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid size-12 place-items-center rounded-2xl gradient-brand text-primary-foreground shadow-glow shrink-0",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "size-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "text-xl font-bold font-display text-foreground tracking-tight",
									children: "Create Student Account"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground mt-0.5",
									children: "Join CareerSetu for personalized AI career guidance"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								onSubmit: handleSubmit,
								className: "space-y-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-xs text-foreground font-semibold mb-1.5 block",
											children: "Full Name *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											required: true,
											value: formData.name,
											onChange: (e) => setFormData({
												...formData,
												name: e.target.value
											}),
											placeholder: "e.g. Tanvi Deshmukh",
											className: "rounded-xl h-10 text-xs sm:text-sm"
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-xs text-foreground font-semibold mb-1.5 block",
											children: "Email Address *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "email",
											required: true,
											value: formData.email,
											onChange: (e) => setFormData({
												...formData,
												email: e.target.value
											}),
											placeholder: "student@example.com",
											className: "rounded-xl h-10 text-xs sm:text-sm"
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-xs text-foreground font-semibold mb-1.5 block",
											children: "Password *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "password",
											required: true,
											value: formData.password,
											onChange: (e) => setFormData({
												...formData,
												password: e.target.value
											}),
											placeholder: "••••••••••••",
											className: "rounded-xl h-10 text-xs sm:text-sm"
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-xs text-foreground font-semibold mb-1.5 block",
											children: "Confirm Password *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "password",
											required: true,
											value: formData.confirmPassword,
											onChange: (e) => setFormData({
												...formData,
												confirmPassword: e.target.value
											}),
											placeholder: "••••••••••••",
											className: "rounded-xl h-10 text-xs sm:text-sm"
										})] })]
									}),
									formData.password && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3.5 rounded-2xl bg-accent/40 border border-border/80 text-xs space-y-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-muted-foreground text-[11px] font-medium",
													children: "Password Security:"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: `text-[11px] font-bold ${passwordStrength.isValid ? "text-emerald-500" : "text-amber-500"}`,
													children: passwordStrength.isValid ? "✓ Strong Password" : "⚠ Needs Improvement"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "grid grid-cols-4 gap-1.5 h-1.5 bg-muted rounded-full overflow-hidden",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `h-full rounded-full transition-all ${passwordStrength.score >= 1 ? "bg-red-500" : "bg-transparent"}` }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `h-full rounded-full transition-all ${passwordStrength.score >= 2 ? "bg-amber-500" : "bg-transparent"}` }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `h-full rounded-full transition-all ${passwordStrength.score >= 3 ? "bg-blue-500" : "bg-transparent"}` }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `h-full rounded-full transition-all ${passwordStrength.score >= 4 ? "bg-emerald-500" : "bg-transparent"}` })
												]
											}),
											!passwordStrength.isValid && passwordStrength.feedback.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[11px] text-muted-foreground leading-tight",
												children: ["• ", passwordStrength.feedback[0]]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-1 sm:grid-cols-3 gap-4",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
												className: "text-xs text-foreground font-semibold mb-1.5 block",
												children: "Phone Number"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												type: "tel",
												value: formData.phone,
												onChange: (e) => setFormData({
													...formData,
													phone: e.target.value
												}),
												placeholder: "9876543210",
												className: "rounded-xl h-10 text-xs sm:text-sm"
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
												className: "text-xs text-foreground font-semibold mb-1.5 block",
												children: "Age"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												type: "number",
												min: 12,
												max: 60,
												value: formData.age,
												onChange: (e) => setFormData({
													...formData,
													age: e.target.value
												}),
												className: "rounded-xl h-10 text-xs sm:text-sm"
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
												className: "text-xs text-foreground font-semibold mb-1.5 block",
												children: "Gender"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
												value: formData.gender,
												onValueChange: (val) => setFormData({
													...formData,
													gender: val
												}),
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
													className: "rounded-xl h-10 text-xs sm:text-sm border-input bg-card/75",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Gender" })
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, {
													className: "rounded-xl border-border bg-card",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
															value: "Male",
															children: "Male"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
															value: "Female",
															children: "Female"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
															value: "Other",
															children: "Other"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
															value: "Prefer not to say",
															children: "Prefer not to say"
														})
													]
												})]
											})] })
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-xs text-foreground font-semibold mb-1.5 block",
											children: "State"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: formData.state,
											onChange: (e) => setFormData({
												...formData,
												state: e.target.value
											}),
											placeholder: "Maharashtra",
											className: "rounded-xl h-10 text-xs sm:text-sm"
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-xs text-foreground font-semibold mb-1.5 block",
											children: "City"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: formData.city,
											onChange: (e) => setFormData({
												...formData,
												city: e.target.value
											}),
											placeholder: "Pune",
											className: "rounded-xl h-10 text-xs sm:text-sm"
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-xs text-foreground font-semibold mb-1.5 block",
											children: "Current Education"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
											value: formData.education,
											onValueChange: (val) => setFormData({
												...formData,
												education: val
											}),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
												className: "rounded-xl h-10 text-xs sm:text-sm border-input bg-card/75",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Select Education" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, {
												className: "rounded-xl border-border bg-card",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
														value: "Class 10",
														children: "Class 10"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
														value: "Class 12 (Science)",
														children: "Class 12 (Science)"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
														value: "Class 12 (Commerce)",
														children: "Class 12 (Commerce)"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
														value: "Class 12 (Arts)",
														children: "Class 12 (Arts)"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
														value: "Diploma",
														children: "Diploma / Polytechnic"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
														value: "Graduate (B.Tech CS)",
														children: "Graduate (B.Tech / B.E.)"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
														value: "Graduate (B.Sc IT)",
														children: "Graduate (B.Sc / BCA)"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
														value: "Graduate (Commerce/B.Com)",
														children: "Graduate (Commerce)"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
														value: "Post Graduate",
														children: "Post Graduate"
													})
												]
											})]
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-xs text-foreground font-semibold mb-1.5 block",
											children: "Preferred Language"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
											value: formData.preferred_language,
											onValueChange: (val) => setFormData({
												...formData,
												preferred_language: val
											}),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
												className: "rounded-xl h-10 text-xs sm:text-sm border-input bg-card/75",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Language" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, {
												className: "rounded-xl border-border bg-card",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
														value: "English",
														children: "English"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
														value: "Hindi",
														children: "हिंदी (Hindi)"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
														value: "Marathi",
														children: "मराठी (Marathi)"
													})
												]
											})]
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "pt-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											type: "submit",
											disabled: loading,
											className: "w-full h-11 rounded-xl gradient-brand text-primary-foreground font-bold text-xs sm:text-sm shadow-glow hover:opacity-95 hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0 cursor-pointer transition-all group",
											children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin mr-2" }), "Creating Account & Generating MFA OTP..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Create Account & Verify Email", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 ml-2 transition-transform duration-200 group-hover:translate-x-1" })] })
										})
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "pt-2 text-center text-xs text-muted-foreground",
								children: [
									"Already have an account?",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/student/login",
										className: "text-primary font-semibold hover:underline underline-offset-2",
										children: "Sign In"
									})
								]
							})
						]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "text-center text-[11px] text-muted-foreground py-3",
				children: "CareerSetu AI Student Registration • Encrypted Credential Security"
			})
		]
	});
}
//#endregion
export { StudentSignupPage as component };
