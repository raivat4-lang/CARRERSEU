import { i as __toESM } from "../_runtime.mjs";
import { g as Link, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { h as getCurrentUser } from "./rbac-D_Rf6U5V.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Card } from "./card-95-PmP7N.mjs";
import { t as Badge } from "./badge-BYEzUON3.mjs";
import { t as Button } from "./button-CdcMTBqt.mjs";
import { Mt as ArrowRight, Nt as ArrowLeft, T as RotateCcw, g as Sparkles, p as Target, pt as CircleCheck } from "../_libs/lucide-react.mjs";
import { n as calculateAssessmentResults } from "./assessment-questions-ssXbMUdg.mjs";
import { s as getManagedQuestions } from "./admin-content-store-CcAL24zG.mjs";
import { f as saveAssessmentAnswers, p as saveAssessmentResults, s as getStoredAssessmentAnswers, u as recordAssessmentCompletion } from "./careersetu-store-CamG1tac.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Progress } from "./progress-CNflbst_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/assessment-D8AueDG3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SCALE_OPTIONS = [
	{
		value: 1,
		label: "Strongly Disagree",
		color: "hover:border-rose-500 hover:bg-rose-500/10"
	},
	{
		value: 2,
		label: "Disagree",
		color: "hover:border-amber-500 hover:bg-amber-500/10"
	},
	{
		value: 3,
		label: "Neutral",
		color: "hover:border-slate-500 hover:bg-slate-500/10"
	},
	{
		value: 4,
		label: "Agree",
		color: "hover:border-sky-500 hover:bg-sky-500/10"
	},
	{
		value: 5,
		label: "Strongly Agree",
		color: "hover:border-emerald-500 hover:bg-emerald-500/10"
	}
];
function AssessmentPage() {
	const navigate = useNavigate();
	const currentUser = getCurrentUser();
	const [answers, setAnswers] = (0, import_react.useState)({});
	const [currentIndex, setCurrentIndex] = (0, import_react.useState)(0);
	const [questionsList, setQuestionsList] = (0, import_react.useState)(() => {
		const live = getManagedQuestions().filter((q) => q.active !== false);
		return live.length > 0 ? live : [];
	});
	(0, import_react.useEffect)(() => {
		const live = getManagedQuestions().filter((q) => q.active !== false);
		setQuestionsList(live);
		const saved = getStoredAssessmentAnswers();
		if (Object.keys(saved).length > 0) {
			setAnswers(saved);
			const firstUnanswered = live.findIndex((q) => !saved[q.id]);
			if (firstUnanswered !== -1) setCurrentIndex(firstUnanswered);
		}
	}, []);
	const totalQuestions = questionsList.length || 50;
	const currentQuestion = questionsList[currentIndex] ?? questionsList[0] ?? {
		id: 1,
		text: "I enjoy solving problems and exploring structured solutions.",
		category: "Technology",
		weight: 1,
		traits: ["Analytical Thinking"],
		order: 1
	};
	const answeredCount = Object.keys(answers).length;
	const progressPercent = Math.round(answeredCount / totalQuestions * 100);
	const traitDisplay = Array.isArray(currentQuestion.traits) ? currentQuestion.traits.join(", ") : currentQuestion.traits || currentQuestion.trait || currentQuestion.category;
	const handleSelectAnswer = (value) => {
		const newAnswers = {
			...answers,
			[currentQuestion.id]: value
		};
		setAnswers(newAnswers);
		saveAssessmentAnswers(newAnswers);
		if (currentIndex < totalQuestions - 1) setCurrentIndex((prev) => prev + 1);
	};
	const handleComplete = () => {
		const results = calculateAssessmentResults(answers);
		saveAssessmentResults(results);
		recordAssessmentCompletion(currentUser.email, currentUser.full_name || "Student", results);
		toast.success("Assessment completed successfully! Generating your career blueprint...");
		navigate({ to: "/assessment-results" });
	};
	const handleReset = () => {
		if (window.confirm("Are you sure you want to reset all assessment answers?")) {
			setAnswers({});
			saveAssessmentAnswers({});
			setCurrentIndex(0);
			toast.info("Assessment answers reset");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 max-w-3xl mx-auto py-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-border/70",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-8 place-items-center rounded-xl bg-primary/10 text-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Target, { className: "size-4" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-xl sm:text-2xl font-bold font-display text-foreground",
						children: "AI Career Assessment"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground mt-1",
					children: "50 Adaptive questions evaluating logic, tech, healthcare, business, and leadership traits."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						size: "sm",
						onClick: handleReset,
						className: "h-8 rounded-xl text-xs text-muted-foreground hover:text-foreground cursor-pointer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-3.5 mr-1" }), " Reset"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/assessment-results",
						className: "inline-flex items-center text-xs font-semibold text-primary hover:underline",
						children: "View Latest Results →"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "glass p-4 rounded-2xl border-border/80 shadow-xs space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between text-xs font-semibold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-foreground flex items-center gap-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3.5 text-primary" }),
							"Question ",
							currentIndex + 1,
							" of ",
							totalQuestions
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-primary font-bold",
						children: [progressPercent, "% Completed"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
					value: progressPercent,
					className: "h-2 rounded-full"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "glass p-6 sm:p-8 rounded-3xl border-primary/20 shadow-xl bg-card/90 space-y-6 relative overflow-hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							variant: "outline",
							className: "text-xs border-primary/30 text-primary bg-primary/5",
							children: ["Category: ", currentQuestion.category]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-[11px] font-medium text-muted-foreground",
							children: ["Trait: ", traitDisplay]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "py-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "text-lg sm:text-2xl font-semibold leading-relaxed text-foreground text-center sm:text-left",
							children: [
								"\"",
								currentQuestion.text,
								"\""
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 sm:grid-cols-5 gap-2.5 pt-2",
						children: SCALE_OPTIONS.map((opt) => {
							const isSelected = answers[currentQuestion.id] === opt.value;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => handleSelectAnswer(opt.value),
								className: `flex sm:flex-col items-center justify-between sm:justify-center gap-2 p-3 sm:py-4 rounded-2xl border transition-all text-xs font-semibold cursor-pointer text-center ${isSelected ? "border-primary bg-primary text-primary-foreground shadow-glow scale-[1.02]" : `border-border/80 bg-background/80 text-foreground ${opt.color}`}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid size-6 sm:size-7 place-items-center rounded-full bg-black/10 text-xs font-bold",
									children: opt.value
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: opt.label })]
							}, opt.value);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between pt-6 border-t border-border/50",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							onClick: () => setCurrentIndex((prev) => Math.max(0, prev - 1)),
							disabled: currentIndex === 0,
							className: "rounded-xl cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4 mr-1" }), " Previous"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-center gap-2",
							children: currentIndex < totalQuestions - 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								size: "sm",
								onClick: () => setCurrentIndex((prev) => Math.min(totalQuestions - 1, prev + 1)),
								className: "rounded-xl cursor-pointer",
								children: ["Next ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 ml-1" })]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								onClick: handleComplete,
								className: "gradient-brand text-primary-foreground font-bold rounded-xl shadow-glow cursor-pointer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 mr-1.5" }), " Submit Assessment"]
							})
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "p-4 rounded-2xl border border-border/60 bg-accent/20 space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-semibold text-muted-foreground",
					children: "Jump to question:"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-1.5",
					children: questionsList.map((q, idx) => {
						const isAnswered = answers[q.id] !== void 0;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setCurrentIndex(idx),
							className: `size-6 rounded-lg text-[10px] font-semibold transition-all cursor-pointer ${currentIndex === idx ? "ring-2 ring-primary bg-primary text-primary-foreground font-bold" : isAnswered ? "bg-primary/20 text-primary border border-primary/30" : "bg-muted text-muted-foreground hover:bg-accent"}`,
							children: idx + 1
						}, q.id);
					})
				})]
			})
		]
	});
}
//#endregion
export { AssessmentPage as component };
