import { i as __toESM } from "../_runtime.mjs";
import { g as Link, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as initiateAdminLogin } from "./rbac-D_Rf6U5V.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Card } from "./card-95-PmP7N.mjs";
import { t as Button } from "./button-CdcMTBqt.mjs";
import { B as LoaderCircle, K as KeyRound, M as Moon, Mt as ArrowRight, m as Sun, nt as Eye, rt as EyeOff, v as ShieldCheck, y as ShieldAlert, z as Lock } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-D7UBWI0-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Logo } from "./Logo-CGI7av7x.mjs";
import { t as Label } from "./label-DiINKb2h.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.login-Fm9WthV9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminLoginPage() {
	const navigate = useNavigate();
	const [email, setEmail] = (0, import_react.useState)("raivats4@gmail.com");
	const [password, setPassword] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(false);
	const handleAdminLogin = async (e) => {
		e.preventDefault();
		if (!email) {
			toast.error("Please enter your administrator email.");
			return;
		}
		setLoading(true);
		try {
			const result = await initiateAdminLogin(email, password);
			if (!result.success) {
				toast.error(result.error || "Invalid email or password.");
				setLoading(false);
				return;
			}
			if (typeof sessionStorage !== "undefined") {
				sessionStorage.setItem("careersetu_pending_admin_email", email.trim().toLowerCase());
				sessionStorage.setItem("careersetu_pending_admin_masked", result.maskedEmail || "");
				if (result.devOtp) sessionStorage.setItem("careersetu_dev_otp", result.devOtp);
				else sessionStorage.removeItem("careersetu_dev_otp");
			}
			if (result.requiresFirstSetup) {
				toast.info("First-time setup detected. A security authorization code has been sent to your email.");
				navigate({ to: "/admin/first-setup" });
				return;
			}
			toast.success("Administrator 2FA security code dispatched to your registered email.");
			navigate({ to: "/admin/verify-mfa" });
		} catch (err) {
			toast.error("An unexpected error occurred during administrative verification.");
		} finally {
			setLoading(false);
		}
	};
	const [showPassword, setShowPassword] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background text-foreground relative overflow-hidden flex flex-col justify-between p-4 sm:p-8 antialiased",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gradient-soft absolute inset-0 -z-10 opacity-70" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "blueprint-grid absolute inset-0 -z-10 opacity-40" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -top-32 left-1/2 -translate-x-1/2 -z-10 size-[32rem] rounded-full bg-amber-500/10 blur-[120px] pointer-events-none" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto w-full max-w-md flex items-center justify-between pt-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "flex items-center gap-2 hover:opacity-90 transition-opacity",
					"aria-label": "CareerSetu home",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "ghost",
					size: "icon",
					"aria-label": "Toggle theme",
					onClick: () => {
						document.documentElement.classList.toggle("dark");
					},
					className: "rounded-xl size-9 text-muted-foreground hover:text-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0 text-amber-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "absolute size-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100 text-sky-400" })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto w-full max-w-md py-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 rounded-3xl bg-card/85 border border-border/80 p-4 space-y-2.5 backdrop-blur-xl shadow-soft",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between text-[11px] font-semibold text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5 text-amber-500 font-bold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4" }), " Tier-1 Administrator Gateway"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] uppercase tracking-wider font-mono bg-amber-500/10 text-amber-600 dark:text-amber-400 px-2 py-0.5 rounded-full",
								children: "Strict RBAC"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-3 gap-2 text-[10px]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-2.5 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-amber-600 dark:text-amber-300 font-bold text-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: "1. Credentials" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[9px] opacity-80 font-normal",
										children: "Admin Email & Pass"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-2.5 rounded-2xl bg-accent/40 border border-border/70 text-muted-foreground text-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: "2. Email 2FA" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[9px] opacity-80",
										children: "Security Code"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-2.5 rounded-2xl bg-accent/40 border border-border/70 text-muted-foreground text-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: "3. Session" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[9px] opacity-80",
										children: "RBAC Token"
									})]
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 rounded-2xl bg-amber-500/10 border border-amber-500/25 p-3.5 flex items-start gap-3 text-xs text-amber-600 dark:text-amber-300 backdrop-blur-md",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-4 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-bold",
							children: "Restricted Administration Gateway"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-0.5 text-muted-foreground leading-relaxed text-[11px]",
							children: "Access restricted to verified administrators. Protected by SQL RBAC, PBKDF2 encryption, and Email MFA."
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: "rounded-3xl p-6 sm:p-8 bg-card/90 border border-border/80 shadow-elegant backdrop-blur-xl",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3.5 pb-4 border-b border-border/70",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid size-12 place-items-center rounded-2xl bg-amber-500/20 text-amber-600 dark:text-amber-400 border border-amber-500/30 shadow-xs shrink-0",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-5" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
										className: "text-xl font-bold font-display text-foreground tracking-tight",
										children: "Administrator Sign In"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground mt-0.5",
										children: "Step 1 of 2: Provide credentials"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
									onSubmit: handleAdminLogin,
									className: "space-y-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-xs text-foreground font-semibold mb-1.5 block",
											children: "Administrator Email"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "email",
											required: true,
											value: email,
											onChange: (e) => setEmail(e.target.value),
											placeholder: "admin@careersetu.ai",
											className: "rounded-xl h-11 text-xs sm:text-sm font-mono"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between mb-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
												className: "text-xs text-foreground font-semibold",
												children: "Admin Password"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
												to: "/admin/forgot-password",
												className: "text-[11px] text-amber-600 dark:text-amber-400 hover:underline underline-offset-2 transition-colors",
												children: "Forgot Password?"
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												type: showPassword ? "text" : "password",
												value: password,
												onChange: (e) => setPassword(e.target.value),
												placeholder: "••••••••••••",
												className: "rounded-xl h-11 text-xs sm:text-sm pr-11"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setShowPassword(!showPassword),
												className: "absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground cursor-pointer p-1.5 rounded-lg hover:bg-accent/80 transition-colors",
												"aria-label": showPassword ? "Hide password" : "Show password",
												children: showPassword ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" })
											})]
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "pt-2",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												type: "submit",
												disabled: loading,
												className: "w-full h-11 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs sm:text-sm shadow-md shadow-amber-600/25 hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0 cursor-pointer transition-all group",
												children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin mr-2" }), "Verifying & Requesting 2FA Code..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Sign In & Request 2FA Code", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 ml-2 transition-transform duration-200 group-hover:translate-x-1" })] })
											})
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "pt-4 border-t border-border/70 text-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[11px] text-muted-foreground mb-2 font-medium",
										children: "Super Administrator Quick Fill:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex justify-center gap-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											type: "button",
											variant: "outline",
											size: "sm",
											onClick: () => {
												setEmail("raivats4@gmail.com");
												setPassword("admin1234");
												toast.info("Selected Super Admin (raivats4@gmail.com)");
											},
											className: "text-[11px] rounded-xl h-8 border-border text-foreground hover:bg-accent cursor-pointer",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "size-3 mr-1 text-amber-500" }), " raivats4@gmail.com (admin1234)"]
										})
									})]
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex flex-col items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/student/login",
							className: "text-xs text-muted-foreground hover:text-primary transition-colors",
							children: "← Back to Student Login"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/admin/signup",
							className: "text-xs text-amber-500 hover:text-amber-400 font-medium transition-colors flex items-center gap-1.5 py-1 px-3 rounded-lg hover:bg-amber-500/10 border border-amber-500/20",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-3.5" }), "Create Admin Account / Request Access"]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "text-center text-[11px] text-muted-foreground py-3",
				children: "CareerSetu AI Platform Security System • Multi-Factor Authentication & RBAC Tier 1"
			})
		]
	});
}
//#endregion
export { AdminLoginPage as component };
