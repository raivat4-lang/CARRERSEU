import { i as __toESM } from "../_runtime.mjs";
import { v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as toggleUserStatus, D as rejectAdminApplication, S as isAdmin, f as getAllAdminApplications, h as getCurrentUser, m as getAuditLogs, p as getAllUsers, t as approveAdminApplication } from "./rbac-D_Rf6U5V.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Card } from "./card-95-PmP7N.mjs";
import { t as Badge } from "./badge-BYEzUON3.mjs";
import { t as Button } from "./button-CdcMTBqt.mjs";
import { At as Bell, C as Search, E as RefreshCw, G as Landmark, Pt as Activity, Tt as Briefcase, X as GraduationCap, Y as History, _ as Shield, a as Users, bt as ChartColumn, c as UserCheck, ct as Clock, d as TrendingUp, ft as CircleQuestionMark, j as PenLine, k as Plus, kt as BookOpen, n as X, nt as Eye, pt as CircleCheck, tt as FileCheck, wt as Building2, y as ShieldAlert, z as Lock } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-d9GHmrLL.mjs";
import { t as Input } from "./input-D7UBWI0-.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-mEmCUBpO.mjs";
import { _ as upsertManagedScholarship, a as getManagedColleges, c as getManagedResources, d as toggleQuestionActive, f as upsertManagedCareer, g as upsertManagedResource, h as upsertManagedQuestion, i as getManagedCareers, l as getManagedScholarships, m as upsertManagedExam, n as createBroadcastNotification, o as getManagedExams, p as upsertManagedCollege, r as getBroadcastNotifications, s as getManagedQuestions, t as archiveCareer, u as getSkills } from "./admin-content-store-CcAL24zG.mjs";
import { i as getCompletedAssessments } from "./careersetu-store-CamG1tac.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as XAxis, f as Cell, i as YAxis, l as Pie, m as Tooltip, o as Area, p as ResponsiveContainer, r as PieChart, s as CartesianGrid, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-Ie7Np424.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminManagementConsole() {
	const navigate = useNavigate();
	const currentUser = getCurrentUser();
	const userIsAdmin = isAdmin(currentUser);
	const [activeTab, setActiveTab] = (0, import_react.useState)("overview");
	const [users, setUsers] = (0, import_react.useState)(getAllUsers());
	const [careers, setCareers] = (0, import_react.useState)(getManagedCareers());
	const [exams, setExams] = (0, import_react.useState)(getManagedExams());
	const [scholarships, setScholarships] = (0, import_react.useState)(getManagedScholarships());
	const [colleges, setColleges] = (0, import_react.useState)(getManagedColleges());
	const [resources, setResources] = (0, import_react.useState)(getManagedResources());
	const [questions, setQuestions] = (0, import_react.useState)(getManagedQuestions());
	const [skills, setSkills] = (0, import_react.useState)(getSkills());
	const [broadcasts, setBroadcasts] = (0, import_react.useState)(getBroadcastNotifications());
	const [auditLogs, setAuditLogs] = (0, import_react.useState)(getAuditLogs());
	const [adminApplications, setAdminApplications] = (0, import_react.useState)(getAllAdminApplications());
	const [userSearch, setUserSearch] = (0, import_react.useState)("");
	const [userRoleFilter, setUserRoleFilter] = (0, import_react.useState)("ALL");
	const [careerSearch, setCareerSearch] = (0, import_react.useState)("");
	const [examSearch, setExamSearch] = (0, import_react.useState)("");
	const [appSearch, setAppSearch] = (0, import_react.useState)("");
	const [appStatusFilter, setAppStatusFilter] = (0, import_react.useState)("ALL");
	const [rejectModalOpen, setRejectModalOpen] = (0, import_react.useState)(false);
	const [rejectingAppId, setRejectingAppId] = (0, import_react.useState)("");
	const [rejectionReason, setRejectionReason] = (0, import_react.useState)("");
	const pendingAppsCount = (0, import_react.useMemo)(() => adminApplications.filter((a) => a.status === "PENDING_APPROVAL").length, [adminApplications]);
	const [selectedUser, setSelectedUser] = (0, import_react.useState)(null);
	const [careerModalOpen, setCareerModalOpen] = (0, import_react.useState)(false);
	const [editingCareer, setEditingCareer] = (0, import_react.useState)({});
	const [examModalOpen, setExamModalOpen] = (0, import_react.useState)(false);
	const [editingExam, setEditingExam] = (0, import_react.useState)({});
	const [scholarshipModalOpen, setScholarshipModalOpen] = (0, import_react.useState)(false);
	const [editingScholarship, setEditingScholarship] = (0, import_react.useState)({});
	const [collegeModalOpen, setCollegeModalOpen] = (0, import_react.useState)(false);
	const [editingCollege, setEditingCollege] = (0, import_react.useState)({});
	const [resourceModalOpen, setResourceModalOpen] = (0, import_react.useState)(false);
	const [editingResource, setEditingResource] = (0, import_react.useState)({});
	const [questionModalOpen, setQuestionModalOpen] = (0, import_react.useState)(false);
	const [editingQuestion, setEditingQuestion] = (0, import_react.useState)({});
	const [skillModalOpen, setSkillModalOpen] = (0, import_react.useState)(false);
	const [editingSkill, setEditingSkill] = (0, import_react.useState)({});
	const [broadcastModalOpen, setBroadcastModalOpen] = (0, import_react.useState)(false);
	const [newBroadcast, setNewBroadcast] = (0, import_react.useState)({
		title: "",
		message: "",
		category: "EXAM",
		priority: "HIGH",
		targetAudience: "ALL",
		link: "/exams"
	});
	if (!userIsAdmin) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-[70vh] flex flex-col items-center justify-center p-6 text-center max-w-lg mx-auto",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "size-20 rounded-3xl bg-destructive/10 border border-destructive/20 text-destructive flex items-center justify-center mb-6 shadow-glow",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-10 animate-bounce" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				variant: "outline",
				className: "mb-3 text-destructive border-destructive/30 bg-destructive/5 font-bold uppercase tracking-widest text-[10px]",
				children: "HTTP 403 Forbidden"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl sm:text-3xl font-bold font-display text-foreground",
				children: "Access Restricted to Administrators"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-sm text-muted-foreground leading-relaxed",
				children: [
					"Your account (",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "text-foreground",
						children: currentUser.email
					}),
					") is registered as a ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "text-primary font-semibold",
						children: "STUDENT"
					}),
					". You do not have permissions to access the platform management console or modify core system records."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex flex-col sm:flex-row gap-3 w-full justify-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => navigate({ to: "/dashboard" }),
					className: "gradient-brand text-primary-foreground rounded-2xl h-11 px-6 shadow-glow cursor-pointer",
					children: "Return to Student Dashboard"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					onClick: () => navigate({ to: "/admin/login" }),
					className: "rounded-2xl h-11 px-5 border-border hover:bg-accent/50 cursor-pointer",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-4 mr-2 text-primary" }), "Sign In as Administrator"]
				})]
			})
		]
	});
	const studentUsers = (0, import_react.useMemo)(() => users.filter((u) => u.role === "STUDENT"), [users]);
	(0, import_react.useMemo)(() => users.filter((u) => u.role === "ADMIN"), [users]);
	const activeStudentsCount = (0, import_react.useMemo)(() => studentUsers.filter((u) => u.status === "ACTIVE").length, [studentUsers]);
	const [completedAssessmentsList, setCompletedAssessmentsList] = (0, import_react.useState)(() => getCompletedAssessments());
	const assessmentsFinishedCount = completedAssessmentsList.length;
	const completionRate = studentUsers.length > 0 ? Math.min(100, Math.round(assessmentsFinishedCount / studentUsers.length * 100)) : 0;
	const publishedCareersCount = (0, import_react.useMemo)(() => careers.filter((c) => c.status !== "ARCHIVED").length, [careers]);
	const monitoredExamsCount = (0, import_react.useMemo)(() => exams.filter((e) => e.status !== "ARCHIVED").length, [exams]);
	const studentGrowthData = (0, import_react.useMemo)(() => {
		const totalSt = studentUsers.length;
		const totalAssess = assessmentsFinishedCount;
		return [
			{
				month: "Nov 2025",
				students: Math.max(1, Math.round(totalSt * .25)),
				assessments: Math.max(0, Math.round(totalAssess * .25))
			},
			{
				month: "Dec 2025",
				students: Math.max(1, Math.round(totalSt * .5)),
				assessments: Math.max(1, Math.round(totalAssess * .5))
			},
			{
				month: "Jan 2026",
				students: Math.max(2, Math.round(totalSt * .75)),
				assessments: Math.max(1, Math.round(totalAssess * .65))
			},
			{
				month: "Feb 2026",
				students: Math.max(3, Math.round(totalSt * .9)),
				assessments: Math.max(2, Math.round(totalAssess * .85))
			},
			{
				month: "Mar 2026 (Live)",
				students: totalSt,
				assessments: totalAssess
			}
		];
	}, [studentUsers.length, assessmentsFinishedCount]);
	const domainDistribution = (0, import_react.useMemo)(() => {
		const counts = {};
		careers.filter((c) => c.status !== "ARCHIVED").forEach((c) => {
			const dom = c.domain || "Other";
			counts[dom] = (counts[dom] || 0) + 1;
		});
		const total = Object.values(counts).reduce((a, b) => a + b, 0) || 1;
		const palette = [
			"#3B82F6",
			"#8B5CF6",
			"#10B981",
			"#F59E0B",
			"#EC4899",
			"#6366F1",
			"#14B8A6",
			"#F43F5E"
		];
		return Object.entries(counts).map(([name, cnt], idx) => ({
			name,
			value: Math.round(cnt / total * 100),
			count: cnt,
			color: palette[idx % palette.length]
		}));
	}, [careers]);
	const handleToggleUser = (userId) => {
		const updated = toggleUserStatus(userId);
		if (updated) {
			setUsers(getAllUsers());
			setAuditLogs(getAuditLogs());
			toast.success(`User status changed to ${updated.status}`);
		}
	};
	const filteredApplications = (0, import_react.useMemo)(() => {
		return adminApplications.filter((app) => {
			const matchSearch = app.fullName.toLowerCase().includes(appSearch.toLowerCase()) || app.email.toLowerCase().includes(appSearch.toLowerCase()) || app.organization.toLowerCase().includes(appSearch.toLowerCase());
			const matchStatus = appStatusFilter === "ALL" || app.status === appStatusFilter;
			return matchSearch && matchStatus;
		});
	}, [
		adminApplications,
		appSearch,
		appStatusFilter
	]);
	const handleApproveApplication = (appId) => {
		const reviewer = currentUser?.email || "raivats4@gmail.com";
		const res = approveAdminApplication(appId, reviewer);
		if (res.success) {
			setAdminApplications(getAllAdminApplications());
			setUsers(getAllUsers());
			setAuditLogs(getAuditLogs());
			toast.success(`Application approved! ${res.user?.full_name} (${res.user?.email}) has been granted Admin permissions.`);
		} else toast.error(res.error || "Failed to approve application.");
	};
	const handleOpenRejectModal = (appId) => {
		setRejectingAppId(appId);
		setRejectionReason("");
		setRejectModalOpen(true);
	};
	const handleConfirmRejectApplication = () => {
		if (!rejectingAppId) return;
		const reviewer = currentUser?.email || "raivats4@gmail.com";
		const res = rejectAdminApplication(rejectingAppId, reviewer, rejectionReason.trim() || "Does not meet administrative requirements.");
		if (res.success) {
			setAdminApplications(getAllAdminApplications());
			setAuditLogs(getAuditLogs());
			setRejectModalOpen(false);
			setRejectingAppId("");
			setRejectionReason("");
			toast.info("Application rejected.");
		} else toast.error(res.error || "Failed to reject application.");
	};
	const handleSaveCareer = (e) => {
		e.preventDefault();
		if (!editingCareer.name || !editingCareer.domain) {
			toast.error("Please provide career name and domain");
			return;
		}
		const fullCareer = {
			id: editingCareer.id || "career-" + Date.now(),
			name: editingCareer.name,
			domain: editingCareer.domain,
			salary: editingCareer.salary || "₹8 - ₹20 LPA",
			minSalaryLPA: editingCareer.minSalaryLPA || 8,
			maxSalaryLPA: editingCareer.maxSalaryLPA || 20,
			demand: editingCareer.demand || "High",
			educationRequired: editingCareer.educationRequired || "Graduate",
			sector: editingCareer.sector || "Private",
			workType: editingCareer.workType || "Hybrid",
			description: editingCareer.description || "Career profile managed by admin.",
			responsibilities: editingCareer.responsibilities || ["Execute domain tasks", "Drive quality outcomes"],
			requiredSkills: editingCareer.requiredSkills || ["Communication", "Problem Solving"],
			degrees: editingCareer.degrees || ["Bachelor's Degree"],
			topColleges: editingCareer.topColleges || ["Top Indian Universities"],
			topRecruiters: editingCareer.topRecruiters || ["Industry Leaders"],
			futureScope: editingCareer.futureScope || "Strong industry outlook.",
			roadmap: editingCareer.roadmap || [{
				stage: "Stage 1",
				title: "Foundation",
				desc: "Build domain basics."
			}],
			tags: editingCareer.tags || ["Admin Verified"],
			status: editingCareer.status || "PUBLISHED"
		};
		upsertManagedCareer(fullCareer);
		setCareers(getManagedCareers());
		setAuditLogs(getAuditLogs());
		setCareerModalOpen(false);
		setEditingCareer({});
		toast.success(`Saved career "${fullCareer.name}"! Changes live on Student Portal.`);
	};
	const handleArchiveCareer = (id) => {
		archiveCareer(id);
		setCareers(getManagedCareers());
		setAuditLogs(getAuditLogs());
		toast.success("Career status updated! Changes reflected on Student Portal.");
	};
	const handleSaveExam = (e) => {
		e.preventDefault();
		if (!editingExam.name || !editingExam.organization) {
			toast.error("Please provide exam name and conducting organization");
			return;
		}
		const fullExam = {
			id: editingExam.id || "exam-" + Date.now(),
			name: editingExam.name,
			organization: editingExam.organization,
			category: editingExam.category || "Civil Services",
			frequency: editingExam.frequency || "Annual",
			status: editingExam.status || "PUBLISHED",
			ageLimit: editingExam.ageLimit || "21 - 32 years",
			qualification: editingExam.qualification || "Graduate in any discipline",
			salary: editingExam.salary || "Level 10 (₹56,100 - ₹1,77,500)",
			officialWebsite: editingExam.officialWebsite || "https://upsc.gov.in",
			overview: editingExam.overview || "Premier national examination.",
			syllabus: editingExam.syllabus || ["General Studies", "Aptitude"],
			timeline: editingExam.timeline || {
				notification: "Feb",
				exam: "May",
				result: "Oct"
			},
			selectionProcess: editingExam.selectionProcess || [
				"Prelims",
				"Mains",
				"Interview"
			],
			previousCutoff: editingExam.previousCutoff || "90-100 / 200",
			preparationTips: editingExam.preparationTips || ["Solve PYQs", "Daily Newspaper"]
		};
		upsertManagedExam(fullExam);
		setExams(getManagedExams());
		setAuditLogs(getAuditLogs());
		setExamModalOpen(false);
		setEditingExam({});
		toast.success(`Saved exam notification "${fullExam.name}"! Live on Student Portal.`);
	};
	const handleSaveScholarship = (e) => {
		e.preventDefault();
		if (!editingScholarship.name || !editingScholarship.amount) {
			toast.error("Please provide scholarship name and amount");
			return;
		}
		const fullScholarship = {
			id: editingScholarship.id || "scholarship-" + Date.now(),
			name: editingScholarship.name,
			provider: editingScholarship.provider || "Government / CSR",
			category: editingScholarship.category || "Central Government",
			amount: editingScholarship.amount,
			deadline: editingScholarship.deadline || "Open for 2026-27",
			eligibility: editingScholarship.eligibility || "Merit & Income based",
			educationLevel: editingScholarship.educationLevel || "Undergraduate / Postgraduate",
			incomeLimit: editingScholarship.incomeLimit || "< ₹8,00,000 / year",
			eligibleStates: editingScholarship.eligibleStates || ["All India"],
			officialWebsite: editingScholarship.officialWebsite || "https://scholarships.gov.in",
			description: editingScholarship.description || "Scholarship program for Indian students.",
			tags: editingScholarship.tags || ["Govt Scheme", "Financial Aid"],
			status: editingScholarship.status || "PUBLISHED"
		};
		upsertManagedScholarship(fullScholarship);
		setScholarships(getManagedScholarships());
		setAuditLogs(getAuditLogs());
		setScholarshipModalOpen(false);
		setEditingScholarship({});
		toast.success(`Saved scholarship "${fullScholarship.name}"! Live on Student Portal.`);
	};
	const handleSaveCollege = (e) => {
		e.preventDefault();
		if (!editingCollege.name || !editingCollege.location) {
			toast.error("Please provide college name and location");
			return;
		}
		const fullCollege = {
			id: editingCollege.id || "college-" + Date.now(),
			name: editingCollege.name,
			location: editingCollege.location,
			city: editingCollege.city || editingCollege.location,
			state: editingCollege.state || "India",
			ownership: editingCollege.ownership || "Government / Autonomous",
			type: editingCollege.type || "Government / Autonomous",
			nirfRank: editingCollege.nirfRank || 1,
			avgPackage: editingCollege.avgPackage || "₹18 LPA",
			highestPackage: editingCollege.highestPackage || "₹45 LPA",
			totalFees: editingCollege.totalFees || "₹8 Lakhs total",
			acceptedExams: editingCollege.acceptedExams || ["JEE Advanced", "GATE"],
			popularDegrees: editingCollege.popularDegrees || ["B.Tech", "M.Tech"],
			officialWebsite: editingCollege.officialWebsite || "https://iitb.ac.in",
			establishedYear: editingCollege.establishedYear || 1958,
			status: editingCollege.status || "PUBLISHED"
		};
		upsertManagedCollege(fullCollege);
		setColleges(getManagedColleges());
		setAuditLogs(getAuditLogs());
		setCollegeModalOpen(false);
		setEditingCollege({});
		toast.success(`Saved college "${fullCollege.name}"! Live on Student Portal.`);
	};
	const handleSaveResource = (e) => {
		e.preventDefault();
		if (!editingResource.title || !editingResource.sourceUrl) {
			toast.error("Please provide resource title and source URL");
			return;
		}
		const fullResource = {
			id: editingResource.id || "resource-" + Date.now(),
			title: editingResource.title,
			category: editingResource.category || "Standard Books",
			targetExamOrCareer: editingResource.targetExamOrCareer || "UPSC / GATE",
			authorOrProvider: editingResource.authorOrProvider || "Standard Publisher",
			format: editingResource.format || "Book / Paperback",
			accessType: editingResource.accessType || "Free",
			sourceUrl: editingResource.sourceUrl,
			sourceLabel: editingResource.sourceLabel || "Official Portal",
			rating: editingResource.rating || 4.8,
			description: editingResource.description || "Learning material for students.",
			tags: editingResource.tags || ["Learning", "Official"],
			status: editingResource.status || "PUBLISHED"
		};
		upsertManagedResource(fullResource);
		setResources(getManagedResources());
		setAuditLogs(getAuditLogs());
		setResourceModalOpen(false);
		setEditingResource({});
		toast.success(`Saved resource "${fullResource.title}"! Live on Student Portal.`);
	};
	const handleSaveQuestion = (e) => {
		e.preventDefault();
		if (!editingQuestion.text || !editingQuestion.category) {
			toast.error("Please provide question text and category");
			return;
		}
		const fullQuestion = {
			id: editingQuestion.id || questions.length + 1,
			order: editingQuestion.order || questions.length + 1,
			text: editingQuestion.text,
			category: editingQuestion.category,
			weight: editingQuestion.weight || 1,
			traits: editingQuestion.traits || ["Analytical Thinking"],
			active: editingQuestion.active !== false
		};
		upsertManagedQuestion(fullQuestion);
		setQuestions(getManagedQuestions());
		setAuditLogs(getAuditLogs());
		setQuestionModalOpen(false);
		setEditingQuestion({});
		toast.success(`Saved Assessment Question #${fullQuestion.order}! Live in Career Assessment.`);
	};
	const handleSendBroadcast = (e) => {
		e.preventDefault();
		if (!newBroadcast.title.trim() || !newBroadcast.message.trim()) {
			toast.error("Please fill title and message");
			return;
		}
		createBroadcastNotification(newBroadcast);
		setBroadcasts(getBroadcastNotifications());
		setAuditLogs(getAuditLogs());
		setBroadcastModalOpen(false);
		setNewBroadcast({
			title: "",
			message: "",
			category: "EXAM",
			priority: "HIGH",
			targetAudience: "ALL",
			link: "/exams"
		});
		toast.success("Broadcast alert sent! Live in all student notification dropdowns.");
	};
	const filteredUsers = (0, import_react.useMemo)(() => {
		return users.filter((u) => {
			const matchSearch = u.full_name.toLowerCase().includes(userSearch.toLowerCase()) || u.email.toLowerCase().includes(userSearch.toLowerCase()) || u.city && u.city.toLowerCase().includes(userSearch.toLowerCase());
			const matchRole = userRoleFilter === "ALL" || u.role === userRoleFilter;
			return matchSearch && matchRole;
		});
	}, [
		users,
		userSearch,
		userRoleFilter
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 max-w-7xl mx-auto py-3 px-2 sm:px-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-3xl bg-gradient-to-r from-card via-card to-amber-500/5 border border-border shadow-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-500 flex items-center justify-center shrink-0 shadow-inner",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-6" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-xl sm:text-2xl font-bold font-display text-foreground",
							children: "CareerSetu Admin Management Console"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							className: "bg-amber-500 text-black font-extrabold text-[10px] uppercase tracking-wider px-2 py-0.5",
							children: "Role: ADMIN"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground mt-0.5",
						children: [
							"Authorized session: ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "text-foreground",
								children: currentUser.email
							}),
							" • Edits here instantly sync to the Student Portal"
						]
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						onClick: () => setBroadcastModalOpen(true),
						className: "rounded-xl h-9 px-3.5 gap-1.5 bg-amber-500 hover:bg-amber-600 text-black font-semibold text-xs cursor-pointer shadow-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-3.5" }), "Broadcast Alert"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => {
							const studentUser = {
								id: "student-evaluator",
								email: "aditi.kulkarni@gmail.com",
								full_name: "Aditi Kulkarni",
								role: "STUDENT",
								status: "ACTIVE",
								registeredAt: "2026-03-01T00:00:00.000Z",
								lastActive: (/* @__PURE__ */ new Date()).toISOString()
							};
							localStorage.setItem("careersetu_demo_user", JSON.stringify(studentUser));
							toast.info("Switched to Student Portal view");
							navigate({ to: "/dashboard" });
						},
						className: "rounded-xl h-9 px-3 text-xs border-border cursor-pointer",
						children: "View Student Portal"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
				value: activeTab,
				onValueChange: setActiveTab,
				className: "space-y-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
						className: "bg-card border border-border p-1 rounded-2xl flex flex-wrap h-auto gap-1 shadow-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "overview",
								className: "rounded-xl text-xs font-semibold px-3.5 py-2 gap-1.5 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartColumn, { className: "size-3.5" }), "Overview & Analytics"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "users",
								className: "rounded-xl text-xs font-semibold px-3.5 py-2 gap-1.5 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-3.5" }),
									"User Directory (",
									users.length,
									")"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "careers",
								className: "rounded-xl text-xs font-semibold px-3.5 py-2 gap-1.5 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-3.5" }),
									"Careers (",
									careers.length,
									")"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "exams",
								className: "rounded-xl text-xs font-semibold px-3.5 py-2 gap-1.5 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "size-3.5" }),
									"Govt Exams (",
									exams.length,
									")"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "scholarships",
								className: "rounded-xl text-xs font-semibold px-3.5 py-2 gap-1.5 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "size-3.5" }),
									"Scholarships (",
									scholarships.length,
									")"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "colleges",
								className: "rounded-xl text-xs font-semibold px-3.5 py-2 gap-1.5 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3.5" }),
									"Colleges (",
									colleges.length,
									")"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "resources",
								className: "rounded-xl text-xs font-semibold px-3.5 py-2 gap-1.5 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-3.5" }),
									"Resources (",
									resources.length,
									")"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "questions",
								className: "rounded-xl text-xs font-semibold px-3.5 py-2 gap-1.5 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleQuestionMark, { className: "size-3.5" }),
									"50 Questions (",
									questions.length,
									")"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "audit",
								className: "rounded-xl text-xs font-semibold px-3.5 py-2 gap-1.5 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "size-3.5" }), "Audit Trail"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "applications",
								className: "rounded-xl text-xs font-semibold px-3.5 py-2 gap-1.5 data-[state=active]:bg-amber-500 data-[state=active]:text-black",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-3.5 text-amber-500" }),
									"Admin Applications",
									pendingAppsCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-1 px-1.5 py-0.5 rounded-full bg-amber-500 text-black text-[10px] font-extrabold shadow-sm",
										children: pendingAppsCount
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
						value: "overview",
						className: "space-y-6 mt-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 lg:grid-cols-4 gap-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
									className: "glass rounded-3xl p-5 border-border shadow-sm",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-muted-foreground mb-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs font-medium",
												children: "Registered Students"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-4 text-blue-500" })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-2xl sm:text-3xl font-bold font-display text-foreground",
											children: studentUsers.length
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[11px] text-emerald-500 font-medium mt-1 flex items-center gap-1",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-3" }),
												" ",
												activeStudentsCount,
												" active · 100% live sync"
											]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
									className: "glass rounded-3xl p-5 border-border shadow-sm",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-muted-foreground mb-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs font-medium",
												children: "Assessments Finished"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheck, { className: "size-4 text-purple-500" })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-2xl sm:text-3xl font-bold font-display text-foreground",
											children: assessmentsFinishedCount
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[11px] text-purple-500 font-medium mt-1",
											children: [completionRate, "% completion rate"]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
									className: "glass rounded-3xl p-5 border-border shadow-sm",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-muted-foreground mb-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs font-medium",
												children: "Published Careers"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-4 text-emerald-500" })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-2xl sm:text-3xl font-bold font-display text-foreground",
											children: publishedCareersCount
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[11px] text-muted-foreground mt-1",
											children: [
												"Across ",
												domainDistribution.length,
												" active sectors"
											]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
									className: "glass rounded-3xl p-5 border-border shadow-sm",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-muted-foreground mb-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs font-medium",
												children: "Govt Exams Monitored"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "size-4 text-amber-500" })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-2xl sm:text-3xl font-bold font-display text-foreground",
											children: monitoredExamsCount
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] text-amber-500 font-medium mt-1",
											children: "Live 2026 notification sync"
										})
									]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 lg:grid-cols-3 gap-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
								className: "lg:col-span-2 glass rounded-3xl p-6 border-border shadow-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between mb-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-bold text-sm text-foreground",
										children: "Student Registration & Assessment Volume"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: "Monthly growth trajectory (Oct 2025 - Mar 2026)"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "outline",
										className: "text-xs font-mono",
										children: "Live Sync"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-64 w-full",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
										width: "100%",
										height: "100%",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
											data: studentGrowthData,
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("defs", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
													id: "colorStudents",
													x1: "0",
													y1: "0",
													x2: "0",
													y2: "1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
														offset: "5%",
														stopColor: "#3B82F6",
														stopOpacity: .4
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
														offset: "95%",
														stopColor: "#3B82F6",
														stopOpacity: 0
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
													id: "colorAssessments",
													x1: "0",
													y1: "0",
													x2: "0",
													y2: "1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
														offset: "5%",
														stopColor: "#8B5CF6",
														stopOpacity: .4
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
														offset: "95%",
														stopColor: "#8B5CF6",
														stopOpacity: 0
													})]
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
													strokeDasharray: "3 3",
													opacity: .15
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
													dataKey: "month",
													tick: { fontSize: 11 }
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, { tick: { fontSize: 11 } }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
													type: "monotone",
													dataKey: "students",
													stroke: "#3B82F6",
													strokeWidth: 2,
													fillOpacity: 1,
													fill: "url(#colorStudents)",
													name: "Students"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
													type: "monotone",
													dataKey: "assessments",
													stroke: "#8B5CF6",
													strokeWidth: 2,
													fillOpacity: 1,
													fill: "url(#colorAssessments)",
													name: "Assessments Completed"
												})
											]
										})
									})
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
								className: "glass rounded-3xl p-6 border-border shadow-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-bold text-sm text-foreground mb-1",
										children: "Student Career Preferences"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground mb-4",
										children: "Domain interest breakdown"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-48 w-full flex items-center justify-center",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
											width: "100%",
											height: "100%",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PieChart, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pie, {
												data: domainDistribution,
												innerRadius: 45,
												outerRadius: 70,
												paddingAngle: 4,
												dataKey: "value",
												children: domainDistribution.map((entry, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: entry.color }, `cell-${index}`))
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {})] })
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid grid-cols-2 gap-2 mt-2",
										children: domainDistribution.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 text-xs",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "size-2.5 rounded-full shrink-0",
													style: { backgroundColor: item.color }
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-muted-foreground truncate",
													children: item.name
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "font-bold text-foreground ml-auto",
													children: [item.value, "%"]
												})
											]
										}, item.name))
									})
								]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "users",
						className: "space-y-4 mt-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "glass rounded-3xl p-6 border-border shadow-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-border",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-base font-bold text-foreground",
									children: "Registered Student & Administrator Directory"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: "Manage user statuses, inspect profiles, and enforce access restrictions"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative w-48 sm:w-64",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-2.5 size-3.5 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											placeholder: "Search name, email, city...",
											value: userSearch,
											onChange: (e) => setUserSearch(e.target.value),
											className: "pl-8 text-xs h-9 rounded-xl"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: userRoleFilter,
										onChange: (e) => setUserRoleFilter(e.target.value),
										className: "h-9 px-3 rounded-xl border border-border bg-card text-xs text-foreground cursor-pointer",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "ALL",
												children: "All Roles"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "STUDENT",
												children: "Students Only"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "ADMIN",
												children: "Admins Only"
											})
										]
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "overflow-x-auto mt-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
									className: "w-full text-left text-xs border-collapse",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-b border-border/80 text-muted-foreground",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-3 px-3 font-semibold",
												children: "User"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-3 px-3 font-semibold",
												children: "Role"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-3 px-3 font-semibold",
												children: "Education / Stream"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-3 px-3 font-semibold",
												children: "Location"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-3 px-3 font-semibold",
												children: "Status"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-3 px-3 font-semibold",
												children: "Registered"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-3 px-3 font-semibold text-right",
												children: "Actions"
											})
										]
									}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
										className: "divide-y divide-border/40",
										children: filteredUsers.map((user) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
											className: "hover:bg-accent/30 transition-colors",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-3 px-3",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center gap-2.5",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: `grid size-7 place-items-center rounded-full font-bold text-xs ${user.role === "ADMIN" ? "bg-amber-500/20 text-amber-500" : "bg-primary/20 text-primary"}`,
															children: user.full_name.charAt(0)
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "font-semibold text-foreground",
															children: user.full_name
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "text-[11px] text-muted-foreground font-mono",
															children: user.email
														})] })]
													})
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-3 px-3",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
														variant: "outline",
														className: `text-[10px] font-bold ${user.role === "ADMIN" ? "border-amber-500/30 text-amber-500 bg-amber-500/10" : "border-primary/30 text-primary bg-primary/10"}`,
														children: user.role
													})
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-3 px-3 text-muted-foreground",
													children: user.current_education || "Class 12 / Graduate"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-3 px-3 text-muted-foreground",
													children: user.city ? `${user.city}, ${user.state || ""}` : "India"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-3 px-3",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
														className: `text-[10px] font-semibold ${user.status === "ACTIVE" ? "bg-emerald-500/15 text-emerald-500 border border-emerald-500/30" : "bg-destructive/15 text-destructive border border-destructive/30"}`,
														children: user.status
													})
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-3 px-3 text-muted-foreground font-mono text-[11px]",
													children: new Date(user.registeredAt).toLocaleDateString()
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-3 px-3 text-right",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center justify-end gap-1.5",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
															variant: "ghost",
															size: "sm",
															onClick: () => setSelectedUser(user),
															className: "h-7 px-2 text-[11px] rounded-lg cursor-pointer",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-3.5 mr-1" }), " Inspect"]
														}), user.role !== "ADMIN" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
															variant: "outline",
															size: "sm",
															onClick: () => handleToggleUser(user.id),
															className: `h-7 px-2 text-[11px] rounded-lg cursor-pointer ${user.status === "ACTIVE" ? "text-destructive hover:bg-destructive/10" : "text-emerald-500 hover:bg-emerald-500/10"}`,
															children: user.status === "ACTIVE" ? "Suspend" : "Activate"
														})]
													})
												})
											]
										}, user.id))
									})]
								})
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "careers",
						className: "space-y-4 mt-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "glass rounded-3xl p-6 border-border shadow-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-border",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "text-base font-bold text-foreground",
									children: [
										"Career Master Database (",
										careers.length,
										" Profiles)"
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: "Edits made here instantly update the Student Career Explorer"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative w-48 sm:w-64",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-2.5 size-3.5 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											placeholder: "Search career title...",
											value: careerSearch,
											onChange: (e) => setCareerSearch(e.target.value),
											className: "pl-8 text-xs h-9 rounded-xl"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										onClick: () => {
											setEditingCareer({
												name: "",
												domain: "Technology",
												salary: "₹10 - ₹25 LPA",
												minSalaryLPA: 10,
												maxSalaryLPA: 25,
												demand: "High",
												educationRequired: "Graduate",
												status: "PUBLISHED"
											});
											setCareerModalOpen(true);
										},
										className: "rounded-xl h-9 px-3 gap-1.5 gradient-brand text-primary-foreground text-xs cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" }), "Add Career"]
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "overflow-x-auto mt-4 max-h-[550px]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
									className: "w-full text-left text-xs border-collapse",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-b border-border/80 text-muted-foreground sticky top-0 bg-card z-10",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-3 px-3 font-semibold",
												children: "Career Title"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-3 px-3 font-semibold",
												children: "Domain"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-3 px-3 font-semibold",
												children: "Salary Range"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-3 px-3 font-semibold",
												children: "Education"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-3 px-3 font-semibold",
												children: "Status"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-3 px-3 font-semibold text-right",
												children: "Actions"
											})
										]
									}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
										className: "divide-y divide-border/40",
										children: careers.filter((c) => c.name.toLowerCase().includes(careerSearch.toLowerCase()) || c.domain.toLowerCase().includes(careerSearch.toLowerCase())).map((career) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
											className: "hover:bg-accent/30 transition-colors",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
													className: "py-3 px-3",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "font-semibold text-foreground",
														children: career.name
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-[11px] text-muted-foreground truncate max-w-xs",
														children: career.description
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-3 px-3",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
														variant: "outline",
														className: "text-[10px] font-semibold",
														children: career.domain
													})
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-3 px-3 font-semibold text-emerald-500 font-mono",
													children: career.salary
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-3 px-3 text-muted-foreground",
													children: career.educationRequired
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-3 px-3",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
														className: `text-[10px] font-semibold ${career.status === "ARCHIVED" ? "bg-amber-500/15 text-amber-500 border border-amber-500/30" : "bg-emerald-500/15 text-emerald-500 border border-emerald-500/30"}`,
														children: career.status || "PUBLISHED"
													})
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-3 px-3 text-right",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center justify-end gap-1.5",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
															variant: "ghost",
															size: "sm",
															onClick: () => {
																setEditingCareer(career);
																setCareerModalOpen(true);
															},
															className: "h-7 px-2 text-[11px] rounded-lg cursor-pointer",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { className: "size-3 mr-1" }), " Edit"]
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
															variant: "outline",
															size: "sm",
															onClick: () => handleArchiveCareer(career.id),
															className: "h-7 px-2 text-[11px] rounded-lg text-amber-500 hover:bg-amber-500/10 cursor-pointer",
															children: career.status === "ARCHIVED" ? "Publish" : "Archive"
														})]
													})
												})
											]
										}, career.id))
									})]
								})
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "exams",
						className: "space-y-4 mt-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "glass rounded-3xl p-6 border-border shadow-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-border",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "text-base font-bold text-foreground",
									children: [
										"Government Exam Registry (",
										exams.length,
										" Exams)"
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: "Manage official notification timelines, syllabus tiers, and cutoff updates"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative w-48 sm:w-64",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-2.5 size-3.5 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											placeholder: "Search exam title...",
											value: examSearch,
											onChange: (e) => setExamSearch(e.target.value),
											className: "pl-8 text-xs h-9 rounded-xl"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										onClick: () => {
											setEditingExam({
												name: "",
												organization: "UPSC",
												category: "Civil Services",
												frequency: "Annual",
												status: "PUBLISHED"
											});
											setExamModalOpen(true);
										},
										className: "rounded-xl h-9 px-3 gap-1.5 gradient-brand text-primary-foreground text-xs cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" }), "Add Exam"]
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "overflow-x-auto mt-4 max-h-[550px]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
									className: "w-full text-left text-xs border-collapse",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-b border-border/80 text-muted-foreground sticky top-0 bg-card z-10",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-3 px-3 font-semibold",
												children: "Exam Name"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-3 px-3 font-semibold",
												children: "Organization"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-3 px-3 font-semibold",
												children: "Age Limit"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-3 px-3 font-semibold",
												children: "Pay Scale"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-3 px-3 font-semibold",
												children: "Official Portal"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-3 px-3 font-semibold text-right",
												children: "Actions"
											})
										]
									}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
										className: "divide-y divide-border/40",
										children: exams.filter((e) => e.name.toLowerCase().includes(examSearch.toLowerCase()) || e.organization.toLowerCase().includes(examSearch.toLowerCase())).map((exam) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
											className: "hover:bg-accent/30 transition-colors",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
													className: "py-3 px-3",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "font-semibold text-foreground",
														children: exam.name
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
														variant: "outline",
														className: "text-[10px] mt-0.5",
														children: exam.category
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-3 px-3 font-semibold text-foreground",
													children: exam.organization
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-3 px-3 text-muted-foreground",
													children: exam.ageLimit
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-3 px-3 font-mono text-emerald-500 font-semibold",
													children: exam.salary
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-3 px-3",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
														href: exam.officialWebsite,
														target: "_blank",
														rel: "noreferrer",
														className: "text-primary hover:underline font-mono text-[11px]",
														children: new URL(exam.officialWebsite).hostname
													})
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-3 px-3 text-right",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
														variant: "ghost",
														size: "sm",
														onClick: () => {
															setEditingExam(exam);
															setExamModalOpen(true);
														},
														className: "h-7 px-2 text-[11px] rounded-lg cursor-pointer",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { className: "size-3 mr-1" }), " Edit"]
													})
												})
											]
										}, exam.id))
									})]
								})
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "scholarships",
						className: "space-y-4 mt-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "glass rounded-3xl p-6 border-border shadow-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between pb-4 border-b border-border",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "text-base font-bold text-foreground",
									children: [
										"Scholarship Schemes Registry (",
										scholarships.length,
										" Schemes)"
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: "Manage grants, award amounts, and application deadlines"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									onClick: () => {
										setEditingScholarship({
											name: "",
											provider: "Central Government",
											amount: "₹50,000 / year",
											deadline: "31st October 2026",
											eligibility: "Merit & Income Based",
											status: "PUBLISHED"
										});
										setScholarshipModalOpen(true);
									},
									className: "rounded-xl h-9 px-3 gap-1.5 gradient-brand text-primary-foreground text-xs cursor-pointer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" }), "Add Scholarship"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-1 md:grid-cols-2 gap-4 mt-4",
								children: scholarships.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-accent/30 border border-border flex flex-col justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between mb-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												variant: "outline",
												className: "text-[10px]",
												children: s.provider
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs font-bold text-emerald-500 font-mono",
												children: s.amount
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: "font-bold text-xs text-foreground",
											children: s.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] text-muted-foreground mt-1 line-clamp-2",
											children: s.description
										})
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-3 pt-2 border-t border-border/50 flex items-center justify-between text-[11px]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-muted-foreground",
											children: ["Deadline: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "text-foreground",
												children: s.deadline
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											variant: "ghost",
											size: "sm",
											onClick: () => {
												setEditingScholarship(s);
												setScholarshipModalOpen(true);
											},
											className: "h-6 px-2 text-[10px] text-primary cursor-pointer",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { className: "size-3 mr-1" }), " Edit"]
										})]
									})]
								}, s.id))
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "colleges",
						className: "space-y-4 mt-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "glass rounded-3xl p-6 border-border shadow-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between pb-4 border-b border-border",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "text-base font-bold text-foreground",
									children: [
										"Top Colleges & Universities (",
										colleges.length,
										" Institutions)"
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: "Manage NIRF verified institutions, placement stats, and accepted entrance exams"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									onClick: () => {
										setEditingCollege({
											name: "",
											location: "Mumbai, Maharashtra",
											ownership: "Government / Autonomous",
											nirfRank: 5,
											avgPackage: "₹18 LPA",
											totalFees: "₹8 Lakhs total",
											status: "PUBLISHED"
										});
										setCollegeModalOpen(true);
									},
									className: "rounded-xl h-9 px-3 gap-1.5 gradient-brand text-primary-foreground text-xs cursor-pointer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" }), "Add College"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-1 md:grid-cols-3 gap-4 mt-4",
								children: colleges.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-accent/30 border border-border flex flex-col justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between mb-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
												className: "bg-primary/10 text-primary border border-primary/20 text-[10px] font-bold",
												children: ["NIRF #", c.nirfRank]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												variant: "outline",
												className: "text-[10px]",
												children: c.ownership
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: "font-bold text-xs text-foreground",
											children: c.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] text-muted-foreground mt-0.5",
											children: c.location
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-3 pt-2 border-t border-border/50 text-[11px] space-y-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-muted-foreground",
													children: "Avg CTC:"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-semibold text-emerald-500 font-mono",
													children: c.avgPackage
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-muted-foreground",
													children: "Exams:"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-semibold text-foreground truncate max-w-32",
													children: c.acceptedExams?.join(", ") || "Merit / Entrance"
												})]
											})]
										})
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-3 pt-2 border-t border-border/50 flex justify-end",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											variant: "ghost",
											size: "sm",
											onClick: () => {
												setEditingCollege(c);
												setCollegeModalOpen(true);
											},
											className: "h-6 px-2 text-[10px] text-primary cursor-pointer",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { className: "size-3 mr-1" }), " Edit"]
										})
									})]
								}, c.id))
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "resources",
						className: "space-y-4 mt-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "glass rounded-3xl p-6 border-border shadow-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between pb-4 border-b border-border",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "text-base font-bold text-foreground",
									children: [
										"Learning Resources Hub (",
										resources.length,
										" Items)"
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: "Manage standard textbooks, verified video playlists, and PYQ PDFs"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									onClick: () => {
										setEditingResource({
											title: "",
											category: "Standard Books",
											targetExamOrCareer: "UPSC CSE",
											authorOrProvider: "Standard Publisher",
											format: "Book / Paperback",
											accessType: "Free",
											sourceUrl: "https://upsc.gov.in",
											status: "PUBLISHED"
										});
										setResourceModalOpen(true);
									},
									className: "rounded-xl h-9 px-3 gap-1.5 gradient-brand text-primary-foreground text-xs cursor-pointer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" }), "Add Resource"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-1 md:grid-cols-2 gap-3 mt-4",
								children: resources.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3.5 rounded-2xl bg-accent/30 border border-border flex flex-col justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between mb-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												variant: "outline",
												className: "text-[10px]",
												children: r.category
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] text-emerald-500 font-bold",
												children: r.accessType
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: "font-bold text-xs text-foreground",
											children: r.title
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[11px] text-muted-foreground mt-0.5",
											children: [
												r.authorOrProvider,
												" • ",
												r.targetExamOrCareer
											]
										})
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2.5 pt-2 border-t border-border/50 flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
											href: r.sourceUrl,
											target: "_blank",
											rel: "noreferrer",
											className: "text-[10px] text-primary hover:underline font-mono",
											children: "Visit Link →"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											variant: "ghost",
											size: "sm",
											onClick: () => {
												setEditingResource(r);
												setResourceModalOpen(true);
											},
											className: "h-6 px-2 text-[10px] text-primary cursor-pointer",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { className: "size-3 mr-1" }), " Edit"]
										})]
									})]
								}, r.id))
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "questions",
						className: "space-y-4 mt-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "glass rounded-3xl p-6 border-border shadow-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between pb-4 border-b border-border",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-base font-bold text-foreground",
									children: "50 Adaptive Assessment Questions"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: "Manage question scoring weights, categories, and cognitive trait mappings"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									className: "gradient-brand text-primary-foreground font-mono",
									children: [questions.length, " Questions"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "divide-y divide-border/40 mt-4 max-h-[550px] overflow-y-auto pr-2",
								children: questions.map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "py-3 flex items-center justify-between gap-4 hover:bg-accent/20 px-2 rounded-xl transition-colors",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "grid size-7 place-items-center rounded-lg bg-primary/10 text-primary font-bold text-xs shrink-0",
											children: ["#", q.order]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-semibold text-foreground",
											children: q.text
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 mt-1",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
													variant: "outline",
													className: "text-[10px]",
													children: q.category
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-[11px] text-muted-foreground",
													children: ["Weight: ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
														className: "text-foreground",
														children: [q.weight, "x"]
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-[11px] text-muted-foreground",
													children: ["Traits: ", q.traits?.join(", ") || "General"]
												})
											]
										})] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											size: "sm",
											variant: "ghost",
											onClick: () => {
												setEditingQuestion(q);
												setQuestionModalOpen(true);
											},
											className: "h-7 px-2 text-[11px] text-primary cursor-pointer",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { className: "size-3 mr-1" }), " Edit"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "sm",
											variant: "outline",
											onClick: () => {
												toggleQuestionActive(q.id);
												setQuestions(getManagedQuestions());
												toast.success(`Toggled status for Question #${q.order}`);
											},
											className: `h-7 px-3 text-[11px] rounded-xl cursor-pointer ${q.active !== false ? "border-emerald-500/30 text-emerald-500" : "border-destructive/30 text-destructive"}`,
											children: q.active !== false ? "Active" : "Inactive"
										})]
									})]
								}, q.id))
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "audit",
						className: "space-y-4 mt-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "glass rounded-3xl p-6 border-border shadow-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between pb-4 border-b border-border",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-base font-bold text-foreground",
									children: "System Audit Trail & Security Logs"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: "Immutable record of all administrative modifications and broadcasts"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									variant: "outline",
									className: "font-mono text-xs",
									children: [auditLogs.length, " Events Logged"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "divide-y divide-border/40 mt-4 max-h-[500px] overflow-y-auto",
								children: auditLogs.map((log) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "py-3 flex items-start justify-between gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "grid size-7 place-items-center rounded-lg bg-amber-500/10 text-amber-500 shrink-0 mt-0.5",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { className: "size-3.5" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
													className: "bg-card text-foreground border border-border text-[10px] font-mono",
													children: log.action
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[11px] font-semibold text-foreground",
													children: log.entity
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground mt-1",
												children: log.details
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[10px] text-muted-foreground/80 font-mono mt-0.5",
												children: ["Admin: ", log.adminEmail]
											})
										] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] text-muted-foreground font-mono shrink-0",
										children: new Date(log.timestamp).toLocaleString()
									})]
								}, log.id))
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "applications",
						className: "space-y-4 mt-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "glass rounded-3xl p-5 border-border shadow-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-border/70",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-11 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-amber-500 flex items-center justify-center shrink-0",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-5" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
											className: "text-base font-bold font-display text-foreground flex items-center gap-2",
											children: ["Admin Access Applications", pendingAppsCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
												className: "bg-amber-500 text-black font-extrabold text-[10px]",
												children: [pendingAppsCount, " Pending"]
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-muted-foreground mt-0.5",
											children: "Review and authorize administrator accounts. Only active Super Admins can grant admin privileges."
										})] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												variant: appStatusFilter === "ALL" ? "default" : "outline",
												size: "sm",
												onClick: () => setAppStatusFilter("ALL"),
												className: "rounded-xl h-8 text-xs cursor-pointer",
												children: [
													"All (",
													adminApplications.length,
													")"
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												variant: appStatusFilter === "PENDING_APPROVAL" ? "default" : "outline",
												size: "sm",
												onClick: () => setAppStatusFilter("PENDING_APPROVAL"),
												className: "rounded-xl h-8 text-xs cursor-pointer border-amber-500/30 text-amber-500 data-[variant=default]:bg-amber-500 data-[variant=default]:text-black",
												children: [
													"Pending (",
													pendingAppsCount,
													")"
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												variant: appStatusFilter === "APPROVED" ? "default" : "outline",
												size: "sm",
												onClick: () => setAppStatusFilter("APPROVED"),
												className: "rounded-xl h-8 text-xs cursor-pointer border-emerald-500/30 text-emerald-500 data-[variant=default]:bg-emerald-600",
												children: [
													"Approved (",
													adminApplications.filter((a) => a.status === "APPROVED").length,
													")"
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												variant: appStatusFilter === "REJECTED" ? "default" : "outline",
												size: "sm",
												onClick: () => setAppStatusFilter("REJECTED"),
												className: "rounded-xl h-8 text-xs cursor-pointer border-rose-500/30 text-rose-500 data-[variant=default]:bg-rose-600",
												children: [
													"Rejected (",
													adminApplications.filter((a) => a.status === "REJECTED").length,
													")"
												]
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "pt-4 pb-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3.5 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											placeholder: "Search applications by name, email, or institution...",
											value: appSearch,
											onChange: (e) => setAppSearch(e.target.value),
											className: "pl-10 h-10 rounded-xl bg-background/60"
										})]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "space-y-3 mt-3",
									children: filteredApplications.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-center py-12 rounded-2xl bg-muted/20 border border-border/60",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-10 mx-auto text-muted-foreground/50 mb-2" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm font-semibold text-foreground",
												children: "No applications found"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground mt-1",
												children: adminApplications.length === 0 ? "No administrator access requests have been submitted yet." : "No applications match your current search and filter criteria."
											})
										]
									}) : filteredApplications.map((app) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `p-4 sm:p-5 rounded-2xl border transition-all ${app.status === "PENDING_APPROVAL" ? "bg-amber-500/5 border-amber-500/30 shadow-xs" : app.status === "APPROVED" ? "bg-emerald-500/5 border-emerald-500/25" : "bg-muted/30 border-border/70 opacity-80"}`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-col lg:flex-row lg:items-start justify-between gap-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-2 flex-1",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex flex-wrap items-center gap-2",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "font-bold text-sm sm:text-base text-foreground",
																children: app.fullName
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "text-xs text-muted-foreground",
																children: [
																	"(",
																	app.email,
																	")"
																]
															}),
															app.status === "PENDING_APPROVAL" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
																className: "bg-amber-500/20 text-amber-400 border border-amber-500/30 text-[10px] font-bold",
																children: "⏳ Pending Review"
															}),
															app.status === "APPROVED" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
																className: "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold",
																children: "✓ Approved Admin"
															}),
															app.status === "REJECTED" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
																className: "bg-rose-500/20 text-rose-400 border border-rose-500/30 text-[10px] font-bold",
																children: "✕ Rejected"
															})
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "flex items-center gap-1",
																children: [
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3 text-amber-500" }),
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Organization:" }),
																	" ",
																	app.organization
																]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "flex items-center gap-1",
																children: [
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-3 text-emerald-500" }),
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Phone:" }),
																	" ",
																	app.phone
																]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "flex items-center gap-1 text-[11px] font-mono",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3" }), new Date(app.createdAt).toLocaleString()]
															})
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center gap-2 pt-1",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: `inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full font-semibold ${app.emailVerified ? "bg-emerald-500/15 text-emerald-400 border border-emerald-500/30" : "bg-muted text-muted-foreground border border-border"}`,
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3" }), "Email Verified"]
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: `inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full font-semibold ${app.phoneVerified ? "bg-emerald-500/15 text-emerald-400 border border-emerald-500/30" : "bg-muted text-muted-foreground border border-border"}`,
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3" }), "Phone Verified"]
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "mt-2 p-3 rounded-xl bg-background/60 border border-border/70 text-xs",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "font-semibold text-muted-foreground block mb-0.5",
															children: "Reason for Access Request:"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
															className: "text-foreground leading-relaxed italic",
															children: [
																"\"",
																app.reason,
																"\""
															]
														})]
													}),
													app.reviewedBy && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "text-[11px] text-muted-foreground flex flex-wrap gap-2 pt-1",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Reviewed by: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
																className: "text-foreground",
																children: app.reviewedBy
															})] }),
															app.reviewedAt && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["• on ", new Date(app.reviewedAt).toLocaleString()] }),
															app.rejectionReason && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "text-rose-400",
																children: [
																	"• Reason: \"",
																	app.rejectionReason,
																	"\""
																]
															})
														]
													})
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex sm:flex-col items-center sm:items-end gap-2 shrink-0",
												children: [
													app.status === "PENDING_APPROVAL" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
														size: "sm",
														onClick: () => handleApproveApplication(app.id),
														className: "rounded-xl h-9 px-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs gap-1.5 shadow-md shadow-emerald-600/20 cursor-pointer",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5" }), "Approve Admin"]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
														size: "sm",
														variant: "outline",
														onClick: () => handleOpenRejectModal(app.id),
														className: "rounded-xl h-9 px-3.5 border-rose-500/40 text-rose-400 hover:bg-rose-500/10 text-xs gap-1.5 cursor-pointer",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" }), "Reject"]
													})] }),
													app.status === "APPROVED" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center gap-1 text-xs text-emerald-500 font-semibold px-3 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "size-3.5" }), "Active Admin"]
													}),
													app.status === "REJECTED" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
														size: "sm",
														variant: "outline",
														onClick: () => handleApproveApplication(app.id),
														className: "rounded-xl h-8 px-3 border-emerald-500/40 text-emerald-400 hover:bg-emerald-500/10 text-xs gap-1 cursor-pointer",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-3" }), "Re-evaluate & Approve"]
													})
												]
											})]
										})
									}, app.id))
								})
							]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: !!selectedUser,
				onOpenChange: (open) => !open && setSelectedUser(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-md rounded-3xl p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
							className: "text-base font-bold font-display",
							children: "Student Profile Inspection"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
							className: "text-xs text-muted-foreground",
							children: "Administrative overview of student education parameters & account standing"
						})] }),
						selectedUser && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3 py-2 text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3 rounded-2xl bg-accent/40 border border-border space-y-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground",
											children: "Full Name:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-semibold text-foreground",
											children: selectedUser.full_name
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground",
											children: "Email:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-mono text-foreground",
											children: selectedUser.email
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground",
											children: "Phone:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-mono text-foreground",
											children: selectedUser.phone || "Not provided"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground",
											children: "Role:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											variant: "outline",
											className: "text-[10px]",
											children: selectedUser.role
										})]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3 rounded-2xl bg-accent/40 border border-border space-y-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground",
											children: "Current Education:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-semibold text-foreground",
											children: selectedUser.current_education || "Class 12 / Graduate"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground",
											children: "Location:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-foreground",
											children: selectedUser.city ? `${selectedUser.city}, ${selectedUser.state}` : "India"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground",
											children: "Account Status:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											className: selectedUser.status === "ACTIVE" ? "bg-emerald-500/20 text-emerald-500" : "bg-destructive/20 text-destructive",
											children: selectedUser.status
										})]
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogFooter, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => setSelectedUser(null),
							className: "rounded-xl w-full text-xs",
							children: "Close Inspection"
						}) })
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: careerModalOpen,
				onOpenChange: setCareerModalOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-lg rounded-3xl p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "text-base font-bold font-display",
						children: editingCareer.id ? "Edit Career Profile" : "Publish New Career Profile"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "text-xs text-muted-foreground",
						children: "Changes will instantly update on the Student Career Explorer"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleSaveCareer,
						className: "space-y-3 py-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "font-semibold block mb-1",
								children: "Career Title"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								required: true,
								placeholder: "e.g. Cloud Security Architect",
								value: editingCareer.name || "",
								onChange: (e) => setEditingCareer({
									...editingCareer,
									name: e.target.value
								}),
								className: "rounded-xl h-9 text-xs"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "font-semibold block mb-1",
									children: "Domain"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: editingCareer.domain || "Technology",
									onChange: (e) => setEditingCareer({
										...editingCareer,
										domain: e.target.value
									}),
									className: "w-full h-9 rounded-xl border border-border bg-card px-2 text-xs",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Technology",
											children: "Technology"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Healthcare",
											children: "Healthcare"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Management",
											children: "Management"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Government Services",
											children: "Government Services"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Law & Judiciary",
											children: "Law & Judiciary"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Science & Research",
											children: "Science & Research"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Commerce & Finance",
											children: "Commerce & Finance"
										})
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "font-semibold block mb-1",
									children: "Salary Range"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "e.g. ₹12 - ₹30 LPA",
									value: editingCareer.salary || "",
									onChange: (e) => setEditingCareer({
										...editingCareer,
										salary: e.target.value
									}),
									className: "rounded-xl h-9 text-xs"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "font-semibold block mb-1",
								children: "Overview Description"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								rows: 3,
								placeholder: "Provide comprehensive career responsibilities and career scope...",
								value: editingCareer.description || "",
								onChange: (e) => setEditingCareer({
									...editingCareer,
									description: e.target.value
								}),
								className: "w-full rounded-xl border border-border bg-card p-2 text-xs"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-end gap-2 pt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "ghost",
									onClick: () => setCareerModalOpen(false),
									className: "rounded-xl text-xs",
									children: "Cancel"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									className: "gradient-brand text-primary-foreground rounded-xl text-xs",
									children: "Save & Publish"
								})]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: examModalOpen,
				onOpenChange: setExamModalOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-lg rounded-3xl p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "text-base font-bold font-display",
						children: editingExam.id ? "Edit Government Exam" : "Add Government Exam Profile"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "text-xs text-muted-foreground",
						children: "Update official exam criteria, age limits, and commission website link"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleSaveExam,
						className: "space-y-3 py-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "font-semibold block mb-1",
								children: "Exam Title"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								required: true,
								placeholder: "e.g. UPSC Combined Geo-Scientist",
								value: editingExam.name || "",
								onChange: (e) => setEditingExam({
									...editingExam,
									name: e.target.value
								}),
								className: "rounded-xl h-9 text-xs"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "font-semibold block mb-1",
									children: "Conducting Body"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									required: true,
									placeholder: "e.g. UPSC, SSC, NTA",
									value: editingExam.organization || "",
									onChange: (e) => setEditingExam({
										...editingExam,
										organization: e.target.value
									}),
									className: "rounded-xl h-9 text-xs"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "font-semibold block mb-1",
									children: "Age Limit"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "e.g. 21 - 32 years",
									value: editingExam.ageLimit || "",
									onChange: (e) => setEditingExam({
										...editingExam,
										ageLimit: e.target.value
									}),
									className: "rounded-xl h-9 text-xs"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "font-semibold block mb-1",
								children: "Official Website URL"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "https://upsc.gov.in",
								value: editingExam.officialWebsite || "",
								onChange: (e) => setEditingExam({
									...editingExam,
									officialWebsite: e.target.value
								}),
								className: "rounded-xl h-9 text-xs font-mono"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-end gap-2 pt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "ghost",
									onClick: () => setExamModalOpen(false),
									className: "rounded-xl text-xs",
									children: "Cancel"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									className: "gradient-brand text-primary-foreground rounded-xl text-xs",
									children: "Save Exam"
								})]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: scholarshipModalOpen,
				onOpenChange: setScholarshipModalOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-lg rounded-3xl p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "text-base font-bold font-display",
						children: editingScholarship.id ? "Edit Scholarship" : "Add Scholarship Scheme"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "text-xs text-muted-foreground",
						children: "Edits will immediately update the Student Scholarship Discovery page"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleSaveScholarship,
						className: "space-y-3 py-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "font-semibold block mb-1",
								children: "Scholarship Title"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								required: true,
								placeholder: "e.g. Reliance Foundation Undergraduate Scholarship",
								value: editingScholarship.name || "",
								onChange: (e) => setEditingScholarship({
									...editingScholarship,
									name: e.target.value
								}),
								className: "rounded-xl h-9 text-xs"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "font-semibold block mb-1",
									children: "Provider / Grantor"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "e.g. Central Govt / Reliance Foundation",
									value: editingScholarship.provider || "",
									onChange: (e) => setEditingScholarship({
										...editingScholarship,
										provider: e.target.value
									}),
									className: "rounded-xl h-9 text-xs"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "font-semibold block mb-1",
									children: "Award Amount"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									required: true,
									placeholder: "e.g. ₹2,00,000 total",
									value: editingScholarship.amount || "",
									onChange: (e) => setEditingScholarship({
										...editingScholarship,
										amount: e.target.value
									}),
									className: "rounded-xl h-9 text-xs"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "font-semibold block mb-1",
								children: "Deadline Date"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "e.g. 15th November 2026",
								value: editingScholarship.deadline || "",
								onChange: (e) => setEditingScholarship({
									...editingScholarship,
									deadline: e.target.value
								}),
								className: "rounded-xl h-9 text-xs"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-end gap-2 pt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "ghost",
									onClick: () => setScholarshipModalOpen(false),
									className: "rounded-xl text-xs",
									children: "Cancel"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									className: "gradient-brand text-primary-foreground rounded-xl text-xs",
									children: "Save Scholarship"
								})]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: collegeModalOpen,
				onOpenChange: setCollegeModalOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-lg rounded-3xl p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "text-base font-bold font-display",
						children: editingCollege.id ? "Edit College Information" : "Add College / University"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "text-xs text-muted-foreground",
						children: "Edits will immediately update the Student College Directory"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleSaveCollege,
						className: "space-y-3 py-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "font-semibold block mb-1",
								children: "College Name"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								required: true,
								placeholder: "e.g. IIT Madras",
								value: editingCollege.name || "",
								onChange: (e) => setEditingCollege({
									...editingCollege,
									name: e.target.value
								}),
								className: "rounded-xl h-9 text-xs"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "font-semibold block mb-1",
									children: "Location"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "e.g. Chennai, Tamil Nadu",
									value: editingCollege.location || "",
									onChange: (e) => setEditingCollege({
										...editingCollege,
										location: e.target.value
									}),
									className: "rounded-xl h-9 text-xs"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "font-semibold block mb-1",
									children: "Average Package"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "e.g. ₹21.5 LPA",
									value: editingCollege.avgPackage || "",
									onChange: (e) => setEditingCollege({
										...editingCollege,
										avgPackage: e.target.value
									}),
									className: "rounded-xl h-9 text-xs"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "font-semibold block mb-1",
									children: "NIRF Rank"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									placeholder: "e.g. 1",
									value: editingCollege.nirfRank || 1,
									onChange: (e) => setEditingCollege({
										...editingCollege,
										nirfRank: Number(e.target.value)
									}),
									className: "rounded-xl h-9 text-xs"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "font-semibold block mb-1",
									children: "Total Course Fees"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "e.g. ₹9 Lakhs total",
									value: editingCollege.totalFees || "",
									onChange: (e) => setEditingCollege({
										...editingCollege,
										totalFees: e.target.value
									}),
									className: "rounded-xl h-9 text-xs"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-end gap-2 pt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "ghost",
									onClick: () => setCollegeModalOpen(false),
									className: "rounded-xl text-xs",
									children: "Cancel"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									className: "gradient-brand text-primary-foreground rounded-xl text-xs",
									children: "Save College"
								})]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: resourceModalOpen,
				onOpenChange: setResourceModalOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-lg rounded-3xl p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "text-base font-bold font-display",
						children: editingResource.id ? "Edit Resource" : "Add Learning Resource"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "text-xs text-muted-foreground",
						children: "Edits will immediately update the Student Learning Resources Hub"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleSaveResource,
						className: "space-y-3 py-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "font-semibold block mb-1",
								children: "Resource Title"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								required: true,
								placeholder: "e.g. Modern Indian History Notes",
								value: editingResource.title || "",
								onChange: (e) => setEditingResource({
									...editingResource,
									title: e.target.value
								}),
								className: "rounded-xl h-9 text-xs"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "font-semibold block mb-1",
									children: "Category"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: editingResource.category || "Standard Books",
									onChange: (e) => setEditingResource({
										...editingResource,
										category: e.target.value
									}),
									className: "w-full h-9 rounded-xl border border-border bg-card px-2 text-xs",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Standard Books",
											children: "Standard Books"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Official Portals & Syllabus",
											children: "Official Portals & Syllabus"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "YouTube Courses",
											children: "YouTube Courses"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Practice Papers & PYQs",
											children: "Practice Papers & PYQs"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Free PDFs & Notes",
											children: "Free PDFs & Notes"
										})
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "font-semibold block mb-1",
									children: "Target Exam / Career"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "e.g. UPSC CSE / GATE",
									value: editingResource.targetExamOrCareer || "",
									onChange: (e) => setEditingResource({
										...editingResource,
										targetExamOrCareer: e.target.value
									}),
									className: "rounded-xl h-9 text-xs"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "font-semibold block mb-1",
								children: "Source URL"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								required: true,
								placeholder: "https://...",
								value: editingResource.sourceUrl || "",
								onChange: (e) => setEditingResource({
									...editingResource,
									sourceUrl: e.target.value
								}),
								className: "rounded-xl h-9 text-xs font-mono"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-end gap-2 pt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "ghost",
									onClick: () => setResourceModalOpen(false),
									className: "rounded-xl text-xs",
									children: "Cancel"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									className: "gradient-brand text-primary-foreground rounded-xl text-xs",
									children: "Save Resource"
								})]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: questionModalOpen,
				onOpenChange: setQuestionModalOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-lg rounded-3xl p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "text-base font-bold font-display",
						children: editingQuestion.id ? `Edit Question #${editingQuestion.order}` : "Add Assessment Question"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "text-xs text-muted-foreground",
						children: "Edits will immediately update the 50-Question AI Career Assessment"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleSaveQuestion,
						className: "space-y-3 py-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "font-semibold block mb-1",
								children: "Question Prompt"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								required: true,
								placeholder: "e.g. I enjoy designing distributed cloud architectures...",
								value: editingQuestion.text || "",
								onChange: (e) => setEditingQuestion({
									...editingQuestion,
									text: e.target.value
								}),
								className: "rounded-xl h-9 text-xs"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "font-semibold block mb-1",
									children: "Category"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "e.g. Technology, Leadership",
									value: editingQuestion.category || "",
									onChange: (e) => setEditingQuestion({
										...editingQuestion,
										category: e.target.value
									}),
									className: "rounded-xl h-9 text-xs"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "font-semibold block mb-1",
									children: "Scoring Weight"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									placeholder: "e.g. 1.2",
									value: editingQuestion.weight || 1,
									onChange: (e) => setEditingQuestion({
										...editingQuestion,
										weight: Number(e.target.value)
									}),
									className: "rounded-xl h-9 text-xs"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-end gap-2 pt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "ghost",
									onClick: () => setQuestionModalOpen(false),
									className: "rounded-xl text-xs",
									children: "Cancel"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									className: "gradient-brand text-primary-foreground rounded-xl text-xs",
									children: "Save Question"
								})]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: broadcastModalOpen,
				onOpenChange: setBroadcastModalOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-md rounded-3xl p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "text-base font-bold font-display",
						children: "Broadcast Platform Notification"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "text-xs text-muted-foreground",
						children: "Send immediate alert to all student notification feeds"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleSendBroadcast,
						className: "space-y-3 py-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "font-semibold block mb-1",
								children: "Alert Headline"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								required: true,
								placeholder: "e.g. GATE 2027 Registration Open",
								value: newBroadcast.title,
								onChange: (e) => setNewBroadcast({
									...newBroadcast,
									title: e.target.value
								}),
								className: "rounded-xl h-9 text-xs"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "font-semibold block mb-1",
								children: "Detailed Message"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								required: true,
								rows: 3,
								placeholder: "State the deadline and required application links...",
								value: newBroadcast.message,
								onChange: (e) => setNewBroadcast({
									...newBroadcast,
									message: e.target.value
								}),
								className: "w-full rounded-xl border border-border bg-card p-2 text-xs"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "font-semibold block mb-1",
									children: "Category"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: newBroadcast.category,
									onChange: (e) => setNewBroadcast({
										...newBroadcast,
										category: e.target.value
									}),
									className: "w-full h-9 rounded-xl border border-border bg-card px-2 text-xs",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "EXAM",
											children: "Exam"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "SCHOLARSHIP",
											children: "Scholarship"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "ADMISSION",
											children: "Admission"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "SYSTEM",
											children: "System Alert"
										})
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "font-semibold block mb-1",
									children: "Target Audience"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: newBroadcast.targetAudience,
									onChange: (e) => setNewBroadcast({
										...newBroadcast,
										targetAudience: e.target.value
									}),
									className: "w-full h-9 rounded-xl border border-border bg-card px-2 text-xs",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "ALL",
											children: "All Students"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "GRADUATES",
											children: "Graduates Only"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "CLASS_12",
											children: "Class 12 Only"
										})
									]
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-end gap-2 pt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "ghost",
									onClick: () => setBroadcastModalOpen(false),
									className: "rounded-xl text-xs",
									children: "Cancel"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									className: "bg-amber-500 hover:bg-amber-600 text-black font-semibold rounded-xl text-xs",
									children: "Send Broadcast"
								})]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: rejectModalOpen,
				onOpenChange: setRejectModalOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-md rounded-3xl p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
							className: "text-base font-bold font-display text-rose-500 flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-4" }), " Reject Administrator Application"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
							className: "text-xs text-muted-foreground",
							children: "Provide a rationale for why this application is not approved. The applicant will see this status upon enquiry."
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-3 py-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-xs font-semibold block mb-1",
								children: "Rejection Reason"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: rejectionReason,
								onChange: (e) => setRejectionReason(e.target.value),
								placeholder: "e.g. Unverified institutional affiliation, insufficient authorization details...",
								rows: 3,
								className: "w-full p-3 text-xs rounded-xl border border-border bg-card resize-none focus:outline-none focus:border-rose-500/60"
							})] })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
							className: "flex justify-end gap-2 pt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "ghost",
								onClick: () => {
									setRejectModalOpen(false);
									setRejectingAppId("");
								},
								className: "rounded-xl text-xs cursor-pointer",
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								onClick: handleConfirmRejectApplication,
								className: "bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl text-xs cursor-pointer",
								children: "Confirm Rejection"
							})]
						})
					]
				})
			})
		]
	});
}
//#endregion
export { AdminManagementConsole as component };
