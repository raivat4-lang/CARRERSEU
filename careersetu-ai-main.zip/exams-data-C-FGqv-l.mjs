//#region node_modules/.nitro/vite/services/ssr/assets/exams-data-C-FGqv-l.js
var EXAMS_DATA = [
	{
		id: "upsc-cse",
		name: "UPSC Civil Services Examination (CSE)",
		shortName: "UPSC CSE",
		category: "Civil Services",
		conductingBody: "Union Public Service Commission (UPSC)",
		frequency: "Annual (May Prelims, Sept Mains)",
		ageLimit: "21 - 32 years (Relaxations for OBC: 35, SC/ST: 37)",
		minAge: 21,
		maxAge: 32,
		eligibility: "Bachelor's Degree in ANY discipline from a recognized University.",
		qualifyingEducation: "Graduate",
		selectionProcess: [
			"Prelims (Objective - 400 Marks)",
			"Mains (Subjective 9 Papers - 1750 Marks)",
			"Personality Test / Interview (275 Marks)"
		],
		examPattern: {
			stages: "Prelims (GS 1 + CSAT) -> Mains (9 Papers) -> Interview",
			totalMarks: 2025,
			duration: "Prelims: 2 hours each | Mains: 3 hours per paper",
			negativeMarking: "1/3rd (0.33%) in Prelims GS 1",
			mode: "Offline Subjective"
		},
		salaryPayScale: "Level 10 (₹56,100) to Cabinet Secretary (₹2,50,000) + Free Housing & Perks",
		officialWebsite: "https://upsc.gov.in",
		lastUpdated: "September 2026",
		applicationTimeline: "February (Notification) -> May (Prelims) -> September (Mains)",
		status: "Registration Open",
		summary: "India's premier administrative exam to recruit IAS, IPS, IFS, IRS, and Central Group A leaders.",
		syllabusHighlights: [
			"GS 1: Indian Heritage, History, Geography, and Society",
			"GS 2: Governance, Constitution, Polity, Social Justice, and IR",
			"GS 3: Technology, Economic Development, Biodiversity, Environment, Security",
			"GS 4: Ethics, Integrity, and Aptitude",
			"Optional Subject: 2 Papers (500 Marks Total)"
		],
		preparationTips: [
			"Finish Class 6-12 NCERTs for conceptual baseline.",
			"Read The Hindu/Indian Express editorial daily and maintain issue-based notes.",
			"Practice daily 2 Mains answers and solve at least 40 Prelims mock tests."
		],
		previousYearCutoff: "Prelims GS-1: ~87.5 / 200 (General) | Mains: ~741 / 1750",
		relatedCareers: ["ias-officer", "ssc-cgl-officer"]
	},
	{
		id: "gate-engineering",
		name: "Graduate Aptitude Test in Engineering (GATE)",
		shortName: "GATE",
		category: "Engineering & Science",
		conductingBody: "IITs / IISc Bangalore",
		frequency: "Annual (February)",
		ageLimit: "No Age Limit",
		minAge: 20,
		maxAge: 65,
		eligibility: "Currently in 3rd year or completed B.Tech / B.E / B.Arch / M.Sc.",
		qualifyingEducation: "Graduate",
		selectionProcess: ["Single-stage Computer Based Test (CBT) covering 30 Disciplines"],
		examPattern: {
			stages: "1 Paper (65 Questions, 100 Marks)",
			totalMarks: 100,
			duration: "3 Hours (180 Minutes)",
			negativeMarking: "1/3rd for 1-mark MCQs, 2/3rd for 2-mark MCQs (No negative for NAT/MSQ)",
			mode: "CBT (Computer Based)"
		},
		salaryPayScale: "PSU Entry (IOCL, NTPC, ONGC, BHEL): ₹12 - ₹22 LPA CTC | M.Tech Stipend: ₹12,400/month",
		officialWebsite: "https://gate.iitk.ac.in",
		lastUpdated: "August 2026",
		applicationTimeline: "August - October (Application) -> February (Exam) -> March (Results)",
		status: "Upcoming",
		summary: "National benchmark test for M.Tech/Ph.D admissions in IITs/IISc and direct Executive Engineer recruitment in top Maharatna PSUs.",
		syllabusHighlights: [
			"General Aptitude (15 Marks): Verbal & Numerical Ability",
			"Engineering Mathematics (13 Marks): Calculus, Linear Algebra, Probability",
			"Core Subject Knowledge (72 Marks): Domain-specific engineering concepts"
		],
		preparationTips: ["Master high-weightage topics and solve 25 years of GATE previous year questions.", "Take standard virtual calculator practice tests to improve speed without calculation errors."],
		previousYearCutoff: "CSE Qualifying: ~28 Marks | IIT M.Tech CS Gate Score: 750+ | PSU Call: 820+",
		relatedCareers: [
			"isro-drdo-scientist",
			"ai-ml-engineer",
			"cloud-architect"
		]
	},
	{
		id: "ssc-cgl",
		name: "Staff Selection Commission Combined Graduate Level (SSC CGL)",
		shortName: "SSC CGL",
		category: "Civil Services",
		conductingBody: "Staff Selection Commission (SSC)",
		frequency: "Annual (September - October)",
		ageLimit: "18 - 30 years (Varies by post; relaxations for reserved categories)",
		minAge: 18,
		maxAge: 30,
		eligibility: "Bachelor's Degree from a recognized University in any discipline.",
		qualifyingEducation: "Graduate",
		selectionProcess: ["Tier 1 (CBT Qualifying)", "Tier 2 (CBT Merit Determining + DEST Typing Test)"],
		examPattern: {
			stages: "Tier 1 (100 Qs, 200 Marks) -> Tier 2 (Mathematical Abilities, English, Reasoning, GS, Computer)",
			totalMarks: 390,
			duration: "Tier 1: 60 Minutes | Tier 2: 2 Hours 15 Minutes",
			negativeMarking: "0.50 Marks in Tier 1 | 1 Mark in Tier 2",
			mode: "CBT (Computer Based)"
		},
		salaryPayScale: "Pay Level 4 (₹25,500) to Pay Level 8 (₹47,600 basic) -> Gross: ₹45,000 - ₹85,000/month",
		officialWebsite: "https://ssc.gov.in",
		lastUpdated: "September 2026",
		applicationTimeline: "June (Notification) -> September (Tier 1) -> December (Tier 2)",
		status: "Admit Card Released",
		summary: "Recruits 15,000+ Assistant Section Officers, Income Tax Inspectors, Central Excise Inspectors, and Auditors across Central Government Ministries.",
		syllabusHighlights: [
			"Quantitative Aptitude: Arithmetic, Advanced Maths, Geometry, Trigonometry",
			"English Comprehension: Grammar, Vocab, Reading Comprehension, Cloze Test",
			"Reasoning: Analogies, Coding-Decoding, Non-Verbal, Syllogisms",
			"General Awareness: Indian History, Polity, Geography, Current Affairs"
		],
		preparationTips: ["Practice 50 Quant questions daily with short calculation tricks.", "Achieve 30+ WPM typing speed for mandatory Data Entry Skill Test."],
		previousYearCutoff: "Tier 1 Cutoff: ~150 / 200 (General) | Final Inspector Cutoff: ~325 / 390",
		relatedCareers: ["ssc-cgl-officer", "ias-officer"]
	},
	{
		id: "rbi-grade-b",
		name: "Reserve Bank of India Grade B Officers Recruitment",
		shortName: "RBI Grade B",
		category: "Banking & Finance",
		conductingBody: "Reserve Bank of India (RBI)",
		frequency: "Annual",
		ageLimit: "21 - 30 years",
		minAge: 21,
		maxAge: 30,
		eligibility: "Minimum 60% marks in Graduation (50% for SC/ST/PwBD) or 55% in Post Graduation.",
		qualifyingEducation: "Graduate",
		selectionProcess: [
			"Phase 1 (Objective CBT - 200 Marks)",
			"Phase 2 (Descriptive + Objective - 300 Marks)",
			"Phase 3 (Interview - 75 Marks)"
		],
		examPattern: {
			stages: "Phase 1 -> Phase 2 (ESI + FM + English) -> Interview",
			totalMarks: 375,
			duration: "Phase 1: 120 Mins | Phase 2: 3 Papers (90 Mins each)",
			negativeMarking: "1/4th (0.25) in Objective Sections",
			mode: "CBT (Computer Based)"
		},
		salaryPayScale: "Starting Basic Pay: ₹55,200 | Gross Monthly Package: ~₹1,16,000 + Leased Accommodation",
		officialWebsite: "https://opportunities.rbi.org.in",
		lastUpdated: "September 2026",
		applicationTimeline: "July (Notification) -> September (Phase 1) -> October (Phase 2)",
		status: "Upcoming",
		summary: "Elite central banking entrance exam offering swift executive promotions and macroeconomic policy influence.",
		syllabusHighlights: [
			"Phase 1: General Awareness (80 Qs), Quant (30 Qs), Reasoning (60 Qs), English (30 Qs)",
			"Phase 2 Paper 1: Economic and Social Issues (ESI)",
			"Phase 2 Paper 2: Descriptive English Writing (Essay, Précis, Letter)",
			"Phase 2 Paper 3: Finance and Management (FM)"
		],
		preparationTips: ["Master RBI circulars, Union Budget, Economic Survey, and PIB updates.", "Practice keyboard typing for Phase 2 descriptive answer writing."],
		previousYearCutoff: "Phase 1 Cutoff: ~66.75 / 200 | Phase 2 + Interview Final Cutoff: ~235 / 375",
		relatedCareers: ["rbi-grade-b-officer", "investment-banker"]
	},
	{
		id: "isro-icrb",
		name: "ISRO Scientist/Engineer 'SC' Recruitment",
		shortName: "ISRO Scientist",
		category: "Engineering & Science",
		conductingBody: "ISRO Centralised Recruitment Board (ICRB)",
		frequency: "Annual / Biennial",
		ageLimit: "18 - 28 years",
		minAge: 18,
		maxAge: 28,
		eligibility: "B.E / B.Tech in Mechanical, Electronics, or Computer Science with minimum 65% aggregate or 6.84 CGPA.",
		qualifyingEducation: "Graduate",
		selectionProcess: ["Written Test (80 Domain Questions) -> Technical Subject Interview"],
		examPattern: {
			stages: "Written CBT (80 Qs) -> Interview (100 Marks, min 60% to qualify)",
			totalMarks: 180,
			duration: "120 Minutes",
			negativeMarking: "1/3rd (0.33) for incorrect answers",
			mode: "CBT (Computer Based)"
		},
		salaryPayScale: "Level 10 in Pay Matrix (₹56,100 basic) -> Gross: ~₹90,000/month + Space Center Housing",
		officialWebsite: "https://isro.gov.in",
		lastUpdated: "September 2026",
		applicationTimeline: "May (Notification) -> November (Written Test)",
		status: "Upcoming",
		summary: "Direct scientific appointment into India's space program working on launch vehicles, satellites, and interplanetary missions.",
		syllabusHighlights: ["Core Engineering Syllabus as per GATE standards", "Specialized Aerospace, Satellite Systems, and Controls electives"],
		preparationTips: ["Thoroughly revise standard undergraduate engineering textbooks (e.g. Ogata for Controls, Sedra Smith for Electronics).", "Be prepared to draw diagrams and derive equations on a whiteboard during the technical interview."],
		previousYearCutoff: "Written Score: ~120 / 240 for interview call",
		relatedCareers: ["isro-drdo-scientist", "ai-ml-engineer"]
	},
	{
		id: "upsc-nda",
		name: "UPSC National Defence Academy & Naval Academy (NDA & NA)",
		shortName: "UPSC NDA",
		category: "Defense & Police",
		conductingBody: "Union Public Service Commission",
		frequency: "Twice a Year (NDA I in April, NDA II in September)",
		ageLimit: "16.5 - 19.5 years (Unmarried Male & Female candidates)",
		minAge: 16.5,
		maxAge: 19.5,
		eligibility: "Passed or Appearing in Class 12 (Physics & Math required for Air Force & Navy wings).",
		qualifyingEducation: "Class 12",
		selectionProcess: ["Written Exam (900 Marks) -> 5-Day SSB Interview (900 Marks) -> Medicals"],
		examPattern: {
			stages: "Paper 1 (Mathematics: 300 Marks) + Paper 2 (GAT: 600 Marks)",
			totalMarks: 900,
			duration: "2.5 Hours per paper (5 Hours total)",
			negativeMarking: "0.83 Marks in Math | 1.33 Marks in GAT",
			mode: "Pen & Paper (OMR)"
		},
		salaryPayScale: "Stipend during training: ₹56,100/month | Commissioned Rank: Lieutenant (₹56,100 - ₹1,77,500 + MSP)",
		officialWebsite: "https://upsc.gov.in",
		lastUpdated: "September 2026",
		applicationTimeline: "December & May (Notifications) -> April & September (Exams)",
		status: "Registration Open",
		summary: "Premier tri-services academy entrance to become a commissioned officer in the Indian Army, Navy, or Air Force straight after 12th.",
		syllabusHighlights: [
			"Mathematics: Trigonometry, Calculus, Matrices, Coordinate Geometry, Probability",
			"GAT Part A (English): Grammar, Vocab, Comprehension (200 Marks)",
			"GAT Part B (General Science, History, Geography, Current Affairs - 400 Marks)"
		],
		preparationTips: ["Master Class 11 & 12 NCERT Mathematics with speed-solving techniques.", "Develop daily running, pushups, and leadership habits for SSB Officer Like Qualities (OLQ)."],
		previousYearCutoff: "Written Cutoff: ~340 - 360 / 900 | Final Recommended Cutoff: ~710 / 1800",
		relatedCareers: ["defense-officer-army-navy-airforce", "commercial-pilot"]
	},
	{
		id: "upsc-cds",
		name: "UPSC Combined Defence Services Examination (CDS)",
		shortName: "UPSC CDS",
		category: "Defense & Police",
		conductingBody: "Union Public Service Commission",
		frequency: "Twice a Year (CDS I in April, CDS II in September)",
		ageLimit: "19 - 25 years",
		minAge: 19,
		maxAge: 25,
		eligibility: "Graduation in any discipline (Engineering degree mandatory for INA/AFA).",
		qualifyingEducation: "Graduate",
		selectionProcess: ["Written Exam (300 Marks for IMA/INA/AFA; 200 Marks for OTA) -> 5-Day SSB -> Medicals"],
		examPattern: {
			stages: "English + General Knowledge + Elementary Mathematics (Maths not needed for OTA)",
			totalMarks: 300,
			duration: "2 Hours per paper",
			negativeMarking: "1/3rd (0.33) deduction",
			mode: "Pen & Paper (OMR)"
		},
		salaryPayScale: "Lieutenant / Flying Officer / Sub Lieutenant (₹56,100 - ₹1,77,500 + Military Service Pay)",
		officialWebsite: "https://upsc.gov.in",
		lastUpdated: "September 2026",
		applicationTimeline: "December & May (Notifications) -> April & September (Exams)",
		status: "Upcoming",
		summary: "Officer training entrance for graduates into IMA Dehradun, INA Ezhimala, AFA Dundigal, and OTA Chennai.",
		syllabusHighlights: [
			"English: Spotting Errors, Ordering of Sentences, Idioms",
			"GK: Physics, Chemistry, Biology, Indian History, Polity, Defense Current Affairs",
			"Maths: Arithmetic, Algebra, Geometry, Mensuration"
		],
		preparationTips: ["Focus heavily on GK and current affairs to easily cross sectional cutoff."],
		previousYearCutoff: "IMA: ~135 / 300 | AFA: ~145 / 300 | OTA: ~100 / 200",
		relatedCareers: ["defense-officer-army-navy-airforce"]
	},
	{
		id: "ibps-po",
		name: "IBPS Probationary Officer (PO) Recruitment",
		shortName: "IBPS PO",
		category: "Banking & Finance",
		conductingBody: "Institute of Banking Personnel Selection (IBPS)",
		frequency: "Annual",
		ageLimit: "20 - 30 years",
		minAge: 20,
		maxAge: 30,
		eligibility: "Bachelor's Degree in any discipline from a recognized University.",
		qualifyingEducation: "Graduate",
		selectionProcess: ["Prelims (100 Marks) -> Mains (225 Marks) -> Interview (100 Marks)"],
		examPattern: {
			stages: "Prelims (Speed CBT) -> Mains (Descriptive + Objective) -> Personal Interview",
			totalMarks: 325,
			duration: "Prelims: 60 Mins | Mains: 3.5 Hours",
			negativeMarking: "0.25 Marks per wrong answer",
			mode: "CBT (Computer Based)"
		},
		salaryPayScale: "Starting Basic Pay: ₹36,000 -> Gross Monthly Salary: ₹52,000 - ₹58,000",
		officialWebsite: "https://ibps.in",
		lastUpdated: "September 2026",
		applicationTimeline: "August (Notification) -> October (Prelims) -> November (Mains)",
		status: "Registration Open",
		summary: "Recruits Assistant Managers (PO) across 11 major Public Sector Banks including PNB, Bank of Baroda, and Canara Bank.",
		syllabusHighlights: [
			"Data Analysis & Interpretation",
			"Reasoning & Computer Aptitude",
			"General Economy & Banking Awareness",
			"English Language Comprehension & Essay Writing"
		],
		preparationTips: ["Practice high-level puzzle sets and DI bar charts with a stopwatch."],
		previousYearCutoff: "Prelims: ~55 / 100 | Mains: ~72 / 225",
		relatedCareers: ["rbi-grade-b-officer", "chartered-accountant"]
	}
];
//#endregion
export { EXAMS_DATA as t };
