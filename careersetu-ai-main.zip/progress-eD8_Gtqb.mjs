import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Card } from "./card-95-PmP7N.mjs";
import { t as Badge } from "./badge-BYEzUON3.mjs";
import { $ as Flame, Ot as Bookmark, jt as Award, p as Target, pt as CircleCheck, u as Trophy } from "../_libs/lucide-react.mjs";
import { c as getStudyTasks, n as getAssessmentResults, r as getBookmarks } from "./careersetu-store-CamG1tac.mjs";
import { t as Progress } from "./progress-CNflbst_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/progress-eD8_Gtqb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DEFAULT_ACHIEVEMENTS = [
	{
		id: "assessment-master",
		title: "Assessment Master",
		description: "Completed the 50-question AI Career Assessment and unlocked personalized career compatibility.",
		icon: "Target",
		category: "Assessment",
		unlocked: true,
		unlockedDate: "Recently",
		progressPercent: 100
	},
	{
		id: "career-explorer",
		title: "Career Explorer",
		description: "Explored 5+ detailed career roadmaps and compared high-growth industry opportunities.",
		icon: "Compass",
		category: "Career",
		unlocked: true,
		unlockedDate: "Today",
		progressPercent: 100
	},
	{
		id: "first-career-saved",
		title: "First Career Bookmarked",
		description: "Bookmarked your primary target career to track its roadmaps and required skills.",
		icon: "Bookmark",
		category: "Career",
		unlocked: true,
		unlockedDate: "Today",
		progressPercent: 100
	},
	{
		id: "study-starter",
		title: "Study Starter",
		description: "Generated an adaptive study plan and checked off your first scheduled daily task.",
		icon: "CalendarCheck",
		category: "Study",
		unlocked: true,
		unlockedDate: "Today",
		progressPercent: 100
	},
	{
		id: "seven-day-streak",
		title: "7-Day Study Streak",
		description: "Completed study tasks consistently for 7 consecutive days without missing goals.",
		icon: "Flame",
		category: "Study",
		unlocked: false,
		progressPercent: 71
	},
	{
		id: "exam-explorer",
		title: "Exam Explorer",
		description: "Tracked official eligibility, patterns, and deadlines for 3+ National/Government exams.",
		icon: "Landmark",
		category: "Exam",
		unlocked: true,
		unlockedDate: "Yesterday",
		progressPercent: 100
	},
	{
		id: "skill-builder",
		title: "Skill Builder",
		description: "Identified skill gaps for your dream career and marked 2+ skills as Intermediate/Advanced.",
		icon: "Zap",
		category: "Career",
		unlocked: false,
		progressPercent: 50
	},
	{
		id: "resume-ready",
		title: "Resume Ready",
		description: "Created and exported a professional ATS-friendly resume using the AI Resume Builder.",
		icon: "FileText",
		category: "Resume",
		unlocked: false,
		progressPercent: 80
	},
	{
		id: "scholarship-hunter",
		title: "Scholarship Hunter",
		description: "Checked eligibility and saved high-value financial grants matching your profile.",
		icon: "GraduationCap",
		category: "Exam",
		unlocked: true,
		unlockedDate: "Today",
		progressPercent: 100
	}
];
function ProgressPage() {
	const [achievements, setAchievements] = (0, import_react.useState)(DEFAULT_ACHIEVEMENTS);
	getAssessmentResults();
	const studyTasks = getStudyTasks();
	const bookmarks = getBookmarks();
	const completedTasks = studyTasks.filter((t) => t.completed).length;
	const totalBookmarks = bookmarks.careers.length + bookmarks.exams.length + bookmarks.scholarships.length + bookmarks.colleges.length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 max-w-4xl mx-auto py-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-9 place-items-center rounded-xl bg-amber-500/10 text-amber-500",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-xl sm:text-2xl font-bold font-display text-foreground",
						children: "Learning Progress & Achievements"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs sm:text-sm text-muted-foreground mt-1",
					children: "Track your milestones, examination consistency, and unlocked student honors."
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 sm:grid-cols-4 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "glass p-4 rounded-2xl border-border/80 text-center space-y-1 bg-card/90",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] uppercase font-bold text-muted-foreground tracking-wider block",
							children: "Study Streak"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xl font-bold text-amber-500 flex items-center justify-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, { className: "size-5" }), " 7 Days"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "glass p-4 rounded-2xl border-border/80 text-center space-y-1 bg-card/90",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] uppercase font-bold text-muted-foreground tracking-wider block",
							children: "Tasks Completed"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xl font-bold text-emerald-500 flex items-center justify-center gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-5" }),
								" ",
								completedTasks,
								" Done"
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "glass p-4 rounded-2xl border-border/80 text-center space-y-1 bg-card/90",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] uppercase font-bold text-muted-foreground tracking-wider block",
							children: "Saved Pathways"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xl font-bold text-primary flex items-center justify-center gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-5" }),
								" ",
								totalBookmarks
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "glass p-4 rounded-2xl border-border/80 text-center space-y-1 bg-card/90",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] uppercase font-bold text-muted-foreground tracking-wider block",
							children: "Assessment"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xl font-bold text-primary flex items-center justify-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Target, { className: "size-5" }), " 100%"]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "font-bold text-sm text-foreground flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "size-4 text-primary" }), " Unlocked Honors & Badges"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs text-muted-foreground font-semibold",
						children: [
							achievements.filter((a) => a.unlocked).length,
							" of ",
							achievements.length,
							" Badges Unlocked"
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5",
					children: achievements.map((ach) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: `p-4 rounded-3xl border transition-all flex flex-col justify-between space-y-3 shadow-xs ${ach.unlocked ? "bg-card/95 border-amber-500/30 shadow-md" : "bg-muted/30 border-border/40 opacity-60"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `grid size-10 place-items-center rounded-2xl text-base ${ach.unlocked ? "bg-amber-500/10 text-amber-500 border border-amber-500/20 shadow-xs" : "bg-muted text-muted-foreground"}`,
									children: "🏆"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "outline",
									className: `text-[9px] ${ach.unlocked ? "border-emerald-500/30 text-emerald-500 bg-emerald-500/5" : "border-border text-muted-foreground"}`,
									children: ach.unlocked ? "Unlocked" : "In Progress"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
								className: "font-bold text-sm text-foreground",
								children: ach.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground mt-1 leading-relaxed",
								children: ach.description
							})] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1 pt-1 border-t border-border/40",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between text-[10px] text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Progress" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [ach.progressPercent, "%"] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
								value: ach.progressPercent,
								className: "h-1.5 rounded-full"
							})]
						})]
					}, ach.id))
				})]
			})
		]
	});
}
//#endregion
export { ProgressPage as component };
