import { i as __toESM } from "../_runtime.mjs";
import { g as Link, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { I as maskEmail, a as completeAdminMfaLogin, g as getUserByEmail, l as createAndDispatchMfaCode } from "./rbac-D_Rf6U5V.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Card } from "./card-95-PmP7N.mjs";
import { t as Button } from "./button-CdcMTBqt.mjs";
import { B as LoaderCircle, E as RefreshCw, I as Mail, Nt as ArrowLeft, ht as CircleAlert, v as ShieldCheck } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Logo } from "./Logo-CGI7av7x.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.verify-mfa-D19HN0h6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminVerifyMfaPage() {
	const navigate = useNavigate();
	const [email, setEmail] = (0, import_react.useState)("");
	const [maskedDisplay, setMaskedDisplay] = (0, import_react.useState)("");
	const [otp, setOtp] = (0, import_react.useState)([
		"",
		"",
		"",
		"",
		"",
		""
	]);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [timeLeft, setTimeLeft] = (0, import_react.useState)(600);
	const [resendCooldown, setResendCooldown] = (0, import_react.useState)(45);
	const [errorMsg, setErrorMsg] = (0, import_react.useState)("");
	const [devOtp, setDevOtp] = (0, import_react.useState)(null);
	const inputRefs = (0, import_react.useRef)([]);
	(0, import_react.useEffect)(() => {
		let storedEmail = "";
		if (typeof sessionStorage !== "undefined") {
			storedEmail = sessionStorage.getItem("careersetu_pending_admin_email") || "";
			const storedDevOtp = sessionStorage.getItem("careersetu_dev_otp");
			if (storedDevOtp) setDevOtp(storedDevOtp);
		}
		if (!storedEmail) {
			navigate({ to: "/admin/login" });
			return;
		}
		setEmail(storedEmail);
		setMaskedDisplay(maskEmail(storedEmail));
		setTimeout(() => inputRefs.current[0]?.focus(), 100);
	}, [navigate]);
	(0, import_react.useEffect)(() => {
		if (timeLeft <= 0) return;
		const timer = setInterval(() => setTimeLeft((prev) => Math.max(0, prev - 1)), 1e3);
		return () => clearInterval(timer);
	}, [timeLeft]);
	(0, import_react.useEffect)(() => {
		if (resendCooldown <= 0) return;
		const timer = setInterval(() => setResendCooldown((prev) => Math.max(0, prev - 1)), 1e3);
		return () => clearInterval(timer);
	}, [resendCooldown]);
	const formatTimer = (seconds) => {
		const mins = Math.floor(seconds / 60);
		const secs = seconds % 60;
		return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
	};
	const otpValue = otp.join("");
	const handleOtpInput = (index, value) => {
		setErrorMsg("");
		if (value.length > 1) {
			const digits = value.replace(/\D/g, "").slice(0, 6).split("");
			const newOtp = Array.from({ length: 6 }, (_, i) => digits[i] || "");
			setOtp(newOtp);
			setTimeout(() => inputRefs.current[Math.min(digits.length, 5)]?.focus(), 20);
			return;
		}
		const digit = value.replace(/\D/g, "");
		const newOtp = [...otp];
		newOtp[index] = digit;
		setOtp(newOtp);
		if (digit && index < 5) setTimeout(() => inputRefs.current[index + 1]?.focus(), 20);
	};
	const handleOtpKeyDown = (index, e) => {
		if (e.key === "Backspace") if (!otp[index] && index > 0) {
			const newOtp = [...otp];
			newOtp[index - 1] = "";
			setOtp(newOtp);
			setTimeout(() => inputRefs.current[index - 1]?.focus(), 20);
		} else {
			const newOtp = [...otp];
			newOtp[index] = "";
			setOtp(newOtp);
		}
		else if (e.key === "ArrowLeft" && index > 0) inputRefs.current[index - 1]?.focus();
		else if (e.key === "ArrowRight" && index < 5) inputRefs.current[index + 1]?.focus();
		else if (e.key === "Enter" && otpValue.length === 6) handleVerifyOtp();
	};
	const handleOtpPaste = (e) => {
		e.preventDefault();
		const pasted = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, 6);
		if (!pasted) return;
		const digits = pasted.split("");
		const newOtp = Array.from({ length: 6 }, (_, i) => digits[i] || "");
		setOtp(newOtp);
		setTimeout(() => inputRefs.current[Math.min(pasted.length, 5)]?.focus(), 20);
	};
	const handleVerifyOtp = async () => {
		const code = otpValue.trim();
		if (code.length !== 6) {
			setErrorMsg("Please enter all 6 digits of the verification code.");
			const firstEmpty = otp.findIndex((d) => !d);
			if (firstEmpty >= 0) inputRefs.current[firstEmpty]?.focus();
			return;
		}
		if (timeLeft <= 0) {
			setErrorMsg("Verification code has expired. Please request a new one.");
			return;
		}
		setLoading(true);
		setErrorMsg("");
		try {
			const result = await completeAdminMfaLogin(email, code);
			if (!result.success) {
				setErrorMsg(result.error || "The verification code is incorrect or expired.");
				setOtp([
					"",
					"",
					"",
					"",
					"",
					""
				]);
				setTimeout(() => inputRefs.current[0]?.focus(), 50);
				setLoading(false);
				return;
			}
			if (typeof sessionStorage !== "undefined") {
				sessionStorage.removeItem("careersetu_pending_admin_email");
				sessionStorage.removeItem("careersetu_dev_otp");
			}
			toast.success("Administrator session authorized. Redirecting to console...");
			navigate({ to: "/admin" });
		} catch {
			setErrorMsg("An error occurred while validating security credentials.");
		} finally {
			setLoading(false);
		}
	};
	const handleResendCode = async () => {
		if (resendCooldown > 0) return;
		const user = getUserByEmail(email);
		if (!user) {
			toast.error("No administrator account found. Please return to login.");
			navigate({ to: "/admin/login" });
			return;
		}
		setLoading(true);
		setErrorMsg("");
		setOtp([
			"",
			"",
			"",
			"",
			"",
			""
		]);
		try {
			const dispatch = await createAndDispatchMfaCode(user, "ADMIN_LOGIN");
			if (dispatch.devOtp) {
				setDevOtp(dispatch.devOtp);
				if (typeof sessionStorage !== "undefined") sessionStorage.setItem("careersetu_dev_otp", dispatch.devOtp);
			}
			setResendCooldown(45);
			setTimeLeft(600);
			toast.success("A fresh 2FA code has been dispatched to your administrator email.");
			setTimeout(() => inputRefs.current[0]?.focus(), 100);
		} catch {
			toast.error("Failed to resend code.");
		} finally {
			setLoading(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background text-foreground relative overflow-hidden flex flex-col justify-between p-4 sm:p-8 antialiased",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gradient-soft absolute inset-0 -z-10 opacity-70" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "blueprint-grid absolute inset-0 -z-10 opacity-40" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -top-32 left-1/2 -translate-x-1/2 -z-10 size-[32rem] rounded-full bg-amber-500/10 blur-[120px] pointer-events-none" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto w-full max-w-md flex items-center justify-between pt-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "flex items-center gap-2 hover:opacity-90 transition-opacity",
					"aria-label": "CareerSetu home",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/admin/login",
					className: "flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors rounded-xl px-3 py-1.5 hover:bg-accent",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-3.5" }), "Back to Login"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto w-full max-w-md py-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 rounded-3xl bg-card/85 border border-border/80 p-4 space-y-2.5 backdrop-blur-xl shadow-soft",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between text-[11px] font-semibold text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1.5 text-amber-500 font-bold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4" }), " Secure Administrator Sign-In"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] uppercase tracking-wider font-mono bg-amber-500/10 text-amber-600 dark:text-amber-400 px-2 py-0.5 rounded-full",
							children: "Tier-1 RBAC"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-3 gap-2 text-[10px]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-2.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: "✓ 1. Credentials" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[9px] opacity-80",
									children: "Verified"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-2.5 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-amber-600 dark:text-amber-300 font-bold text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: "2. Email 2FA" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[9px] opacity-80 font-normal",
									children: "Enter Code"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-2.5 rounded-2xl bg-accent/40 border border-border/70 text-muted-foreground text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: "3. Session" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[9px] opacity-80",
									children: "Issue Token"
								})]
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "rounded-3xl p-6 sm:p-8 bg-card/85 border border-border/80 shadow-elegant backdrop-blur-xl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between pb-4 border-b border-border/70",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid size-11 place-items-center rounded-2xl bg-amber-500/20 text-amber-600 dark:text-amber-400 border border-amber-500/30 shadow-xs",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-5" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
										className: "text-lg font-bold font-display text-foreground",
										children: "Administrator Verification"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: "Step 2 of 2: Multi-Factor Authentication"
									})] })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "ghost",
									size: "sm",
									onClick: () => navigate({ to: "/admin/login" }),
									className: "h-8 px-2.5 text-xs text-muted-foreground hover:text-foreground rounded-xl",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-3.5 mr-1" }), " Back"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-4 rounded-2xl bg-primary/5 border border-primary/20 space-y-1.5 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-muted-foreground leading-relaxed",
									children: "A security code was generated on the backend and dispatched to the administrator's security email:"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono font-bold text-amber-600 dark:text-amber-400 text-sm tracking-wide",
									children: maskedDisplay || "t*********3@gmail.com"
								})]
							}),
							devOtp && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl border border-amber-500/40 bg-amber-500/10 p-4 flex items-start gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-amber-500 text-lg leading-none mt-0.5",
									children: "🔧"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1 min-w-0",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between mb-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-bold text-amber-500 dark:text-amber-400",
												children: "Dev Mode — Security Code Generated"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-600 dark:text-amber-300 font-semibold",
												children: "Local Testing"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-mono text-2xl font-black tracking-[0.35em] text-amber-600 dark:text-amber-300 select-all cursor-pointer hover:opacity-85 transition-opacity",
											onClick: () => {
												const digits = devOtp.slice(0, 6).split("");
												setOtp(Array.from({ length: 6 }, (_, i) => digits[i] || ""));
												toast.success("Security code auto-filled!");
												setTimeout(() => inputRefs.current[5]?.focus(), 50);
											},
											title: "Click to auto-fill",
											children: devOtp
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[11px] text-muted-foreground mt-1",
											children: [
												"Click code to auto-fill. To receive real emails in your inbox, configure SMTP in ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
													className: "font-mono text-[10px] bg-muted px-1 py-0.5 rounded",
													children: ".env"
												}),
												"."
											]
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between mb-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "text-xs text-foreground font-semibold",
										children: "6-Digit Security Code"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `text-[11px] font-mono font-medium tabular-nums ${timeLeft <= 60 ? "text-red-400" : "text-muted-foreground"}`,
										children: timeLeft > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Expires in ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: timeLeft <= 60 ? "text-red-400" : "text-amber-400",
											children: formatTimer(timeLeft)
										})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-red-400 font-semibold",
											children: "Code expired"
										})
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex gap-2 sm:gap-3 justify-center",
									onPaste: handleOtpPaste,
									children: otp.map((digit, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										ref: (el) => {
											inputRefs.current[index] = el;
										},
										type: "text",
										inputMode: "numeric",
										maxLength: 6,
										value: digit,
										disabled: loading || timeLeft <= 0,
										onChange: (e) => handleOtpInput(index, e.target.value),
										onKeyDown: (e) => handleOtpKeyDown(index, e),
										onFocus: (e) => e.target.select(),
										style: {
											width: "100%",
											maxWidth: "60px",
											aspectRatio: "1",
											borderRadius: "16px",
											border: `2px solid ${digit ? "hsl(38 92% 50%)" : errorMsg && !digit ? "rgba(239,68,68,0.6)" : "hsl(var(--border))"}`,
											background: digit ? "rgba(245,158,11,0.08)" : "hsl(var(--card) / 0.8)",
											color: "hsl(var(--foreground))",
											textAlign: "center",
											fontSize: "1.5rem",
											fontWeight: "900",
											fontFamily: "monospace",
											outline: "none",
											transition: "all 0.15s ease",
											opacity: loading || timeLeft <= 0 ? .5 : 1,
											cursor: loading || timeLeft <= 0 ? "not-allowed" : "text",
											boxShadow: digit ? "0 0 0 3px rgba(245,158,11,0.2)" : "none"
										},
										onFocusCapture: (e) => {
											e.currentTarget.style.borderColor = "hsl(38 92% 50%)";
											e.currentTarget.style.boxShadow = "0 0 0 3px rgba(245,158,11,0.25)";
										},
										onBlurCapture: (e) => {
											const hasValue = e.currentTarget.value;
											e.currentTarget.style.borderColor = hasValue ? "hsl(38 92% 50%)" : "hsl(var(--border))";
											e.currentTarget.style.boxShadow = hasValue ? "0 0 0 3px rgba(245,158,11,0.2)" : "none";
										},
										"aria-label": `Digit ${index + 1}`
									}, index))
								}),
								errorMsg && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 flex items-start gap-2 p-3 rounded-xl bg-red-500/10 border border-red-500/25 text-xs text-red-400",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "size-3.5 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: errorMsg })]
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								onClick: handleVerifyOtp,
								disabled: loading || otpValue.length !== 6 || timeLeft <= 0,
								className: "w-full h-12 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-sm shadow-md shadow-amber-600/20 cursor-pointer disabled:opacity-50 transition-all",
								children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin mr-2" }), "Authorizing Administrator Session..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 mr-2" }), "Verify Code & Enter Admin Console"] })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between text-xs text-muted-foreground pt-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Didn't receive the security code?" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: handleResendCode,
									disabled: resendCooldown > 0 || loading,
									className: `flex items-center gap-1.5 font-semibold transition-colors ${resendCooldown > 0 || loading ? "text-muted-foreground/50 cursor-not-allowed" : "text-amber-600 dark:text-amber-400 hover:underline underline-offset-2 cursor-pointer"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `size-3 ${loading ? "animate-spin" : ""}` }), resendCooldown > 0 ? `Resend in ${resendCooldown}s` : "Resend Security Code"]
								})]
							})
						]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "text-center text-[11px] text-muted-foreground py-3",
				children: "CareerSetu AI Platform Security System • Multi-Factor Authentication & RBAC Tier 1"
			})
		]
	});
}
//#endregion
export { AdminVerifyMfaPage as component };
