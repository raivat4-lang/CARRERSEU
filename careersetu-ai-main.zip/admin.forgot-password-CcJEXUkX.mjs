import { i as __toESM } from "../_runtime.mjs";
import { g as Link, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { I as maskEmail, N as evaluatePasswordStrength, o as completeAdminPasswordReset, y as initiateAdminForgotPassword } from "./rbac-D_Rf6U5V.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Card } from "./card-95-PmP7N.mjs";
import { t as Button } from "./button-CdcMTBqt.mjs";
import { B as LoaderCircle, I as Mail, K as KeyRound, Mt as ArrowRight, Nt as ArrowLeft, pt as CircleCheck, v as ShieldCheck, y as ShieldAlert } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-D7UBWI0-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Logo } from "./Logo-CGI7av7x.mjs";
import { t as Label } from "./label-DiINKb2h.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.forgot-password-CcJEXUkX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminForgotPasswordPage() {
	const navigate = useNavigate();
	const [step, setStep] = (0, import_react.useState)("REQUEST_CODE");
	const [email, setEmail] = (0, import_react.useState)("tysonfire13@gmail.com");
	const [maskedEmail, setMaskedEmail] = (0, import_react.useState)("");
	const [resetCode, setResetCode] = (0, import_react.useState)("");
	const [newPassword, setNewPassword] = (0, import_react.useState)("");
	const [confirmPassword, setConfirmPassword] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [devOtp, setDevOtp] = (0, import_react.useState)(null);
	const passwordStrength = evaluatePasswordStrength(newPassword);
	const handleRequestCode = async (e) => {
		e.preventDefault();
		if (!email) {
			toast.error("Please enter your administrator email address.");
			return;
		}
		setLoading(true);
		try {
			const result = await initiateAdminForgotPassword(email);
			setMaskedEmail(result.maskedEmail || email);
			if (result.devOtp) {
				setDevOtp(result.devOtp);
				if (typeof sessionStorage !== "undefined") sessionStorage.setItem("careersetu_dev_otp", result.devOtp);
			}
			toast.info("If an administrator account exists for this email, a security code has been sent.");
			setStep("VERIFY_AND_RESET");
		} catch (err) {
			toast.error("An error occurred while requesting password recovery.");
		} finally {
			setLoading(false);
		}
	};
	const handleResetPassword = async (e) => {
		e.preventDefault();
		if (!resetCode || resetCode.trim().length !== 6) {
			toast.error("Please enter the 6-digit password reset security code.");
			return;
		}
		if (!newPassword || newPassword !== confirmPassword) {
			toast.error("New passwords do not match.");
			return;
		}
		if (!passwordStrength.isValid) {
			toast.error("Please choose a stronger password meeting security guidelines.");
			return;
		}
		setLoading(true);
		try {
			const result = await completeAdminPasswordReset(email, resetCode.trim(), newPassword);
			if (!result.success) {
				toast.error(result.error || "Password reset verification failed.");
				setLoading(false);
				return;
			}
			toast.success("Administrator password updated! All previous sessions revoked.");
			setStep("SUCCESS");
		} catch (err) {
			toast.error("Failed to reset password.");
		} finally {
			setLoading(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background text-foreground relative overflow-hidden flex flex-col justify-between p-4 sm:p-8 antialiased",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gradient-soft absolute inset-0 -z-10 opacity-70" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "blueprint-grid absolute inset-0 -z-10 opacity-40" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -top-32 left-1/2 -translate-x-1/2 -z-10 size-[32rem] rounded-full bg-amber-500/10 blur-[120px] pointer-events-none" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto w-full max-w-md flex items-center justify-between pt-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "flex items-center gap-2 hover:opacity-90 transition-opacity",
					"aria-label": "CareerSetu home",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto w-full max-w-md py-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 rounded-2xl bg-amber-500/10 border border-amber-500/25 p-3.5 flex items-start gap-3 text-xs text-amber-600 dark:text-amber-300 backdrop-blur-md",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-5 text-amber-500 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-bold",
						children: "Administrator Password Recovery"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-0.5 text-muted-foreground leading-relaxed text-[11px]",
						children: "Requires single-use security code dispatched to your registered security email."
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "rounded-3xl p-6 sm:p-8 bg-card/85 border border-border/80 shadow-elegant backdrop-blur-xl",
					children: [
						step === "REQUEST_CODE" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between pb-4 border-b border-border/70",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid size-10 place-items-center rounded-2xl bg-amber-500/20 text-amber-600 dark:text-amber-400 border border-amber-500/30",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-5" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
										className: "text-lg font-bold font-display text-foreground",
										children: "Forgot Password"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: "Step 1: Enter registered admin email"
									})] })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "ghost",
									size: "sm",
									onClick: () => navigate({ to: "/admin/login" }),
									className: "h-8 px-2 text-xs text-muted-foreground hover:text-foreground rounded-xl",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-3.5 mr-1" }), " Back"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								onSubmit: handleRequestCode,
								className: "space-y-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-xs text-foreground font-semibold mb-1.5 block",
									children: "Administrator Email"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "email",
									required: true,
									value: email,
									onChange: (e) => setEmail(e.target.value),
									placeholder: "admin@careersetu.ai",
									className: "rounded-xl h-10 text-xs font-mono"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "pt-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "submit",
										disabled: loading,
										className: "w-full h-11 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-md shadow-amber-600/20 cursor-pointer transition-all",
										children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin mr-2" }), "Verifying & Generating Security Code..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Send Password Reset Security Code", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 ml-2" })] })
									})
								})]
							})]
						}),
						step === "VERIFY_AND_RESET" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between pb-4 border-b border-border/70",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "grid size-10 place-items-center rounded-2xl bg-amber-500/20 text-amber-600 dark:text-amber-400 border border-amber-500/30",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "size-5" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-lg font-bold font-display text-foreground",
											children: "Reset Password"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-muted-foreground",
											children: "Step 2: Enter code & new password"
										})] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										variant: "ghost",
										size: "sm",
										onClick: () => setStep("REQUEST_CODE"),
										className: "h-8 px-2 text-xs text-muted-foreground hover:text-foreground rounded-xl",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-3.5 mr-1" }), " Back"]
									})]
								}),
								devOtp && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-2xl border border-amber-400/50 bg-amber-400/10 p-3.5 flex items-start gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-amber-400 text-lg leading-none mt-0.5",
										children: "🔧"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex-1 min-w-0",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-bold text-amber-300 mb-1",
												children: "Dev Mode — No SMTP configured"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-mono text-2xl font-black tracking-[0.35em] text-amber-200 select-all cursor-pointer hover:text-amber-100 transition-colors",
												onClick: () => {
													setResetCode(devOtp);
													setDevOtp(null);
													if (typeof sessionStorage !== "undefined") sessionStorage.removeItem("careersetu_dev_otp");
												},
												title: "Click to auto-fill",
												children: devOtp
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px] text-amber-400/70 mt-1",
												children: "Click the code to auto-fill. Hidden when real email delivery is active."
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-primary/5 border border-primary/20 space-y-1.5 text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-muted-foreground leading-relaxed",
										children: "A 6-digit password reset security code was generated on the backend and sent to:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-mono font-bold text-amber-600 dark:text-amber-400 text-sm tracking-wide",
										children: maskEmail(email)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
									onSubmit: handleResetPassword,
									className: "space-y-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-xs text-foreground font-semibold mb-1.5 block",
											children: "6-Digit Password Reset Code"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "text",
											required: true,
											maxLength: 6,
											value: resetCode,
											onChange: (e) => setResetCode(e.target.value.replace(/[^0-9]/g, "")),
											placeholder: "• • • • • •",
											className: "rounded-xl h-11 text-center text-lg tracking-[0.4em] font-mono font-bold"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-xs text-foreground font-semibold mb-1.5 block",
											children: "New Password"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "password",
											required: true,
											value: newPassword,
											onChange: (e) => setNewPassword(e.target.value),
											placeholder: "••••••••••••",
											className: "rounded-xl h-10 text-xs"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-xs text-foreground font-semibold mb-1.5 block",
											children: "Confirm New Password"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "password",
											required: true,
											value: confirmPassword,
											onChange: (e) => setConfirmPassword(e.target.value),
											placeholder: "••••••••••••",
											className: "rounded-xl h-10 text-xs"
										})] }),
										newPassword && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-3 rounded-xl bg-accent/40 border border-border/80 text-xs space-y-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-muted-foreground text-[11px]",
													children: "Strength:"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: `text-[11px] font-bold ${passwordStrength.isValid ? "text-emerald-500" : "text-amber-500"}`,
													children: passwordStrength.isValid ? "Strong Password" : "Criteria Pending"
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "grid grid-cols-4 gap-1 h-1.5 bg-muted rounded-full overflow-hidden",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `h-full ${passwordStrength.score >= 1 ? "bg-red-500" : "bg-transparent"}` }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `h-full ${passwordStrength.score >= 2 ? "bg-amber-500" : "bg-transparent"}` }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `h-full ${passwordStrength.score >= 3 ? "bg-blue-500" : "bg-transparent"}` }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `h-full ${passwordStrength.score >= 4 ? "bg-emerald-500" : "bg-transparent"}` })
												]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "pt-2",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												type: "submit",
												disabled: loading || !passwordStrength.isValid || resetCode.length !== 6,
												className: "w-full h-11 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-md shadow-amber-600/20 cursor-pointer disabled:opacity-50 transition-all",
												children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin mr-2" }), "Updating Password & Revoking Sessions..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 mr-2" }), "Reset Password & Secure Account"] })
											})
										})
									]
								})
							]
						}),
						step === "SUCCESS" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "py-6 text-center space-y-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-16 rounded-3xl bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 flex items-center justify-center mx-auto shadow-glow",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-8" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-lg font-bold text-foreground",
										children: "Password Reset Successful"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: "Your administrator password has been updated and all previous sessions have been invalidated."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									onClick: () => navigate({ to: "/admin/login" }),
									className: "w-full h-11 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-md shadow-amber-600/20 cursor-pointer mt-4",
									children: "Proceed to Administrator Sign In"
								})
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "text-center text-[11px] text-muted-foreground py-3",
				children: "CareerSetu AI Platform Security System • Multi-Factor Authentication & RBAC Tier 1"
			})
		]
	});
}
//#endregion
export { AdminForgotPasswordPage as component };
