import { i as __toESM } from "../_runtime.mjs";
import { g as Link, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Card } from "./card-95-PmP7N.mjs";
import { t as Badge } from "./badge-BYEzUON3.mjs";
import { D as Redo, H as Lightbulb, Ot as Bookmark, d as TrendingUp, g as Sparkles, mt as CircleCheckBig, st as Compass } from "../_libs/lucide-react.mjs";
import { i as getManagedCareers } from "./admin-content-store-CcAL24zG.mjs";
import { _ as toggleBookmark, l as isBookmarked, n as getAssessmentResults } from "./careersetu-store-CamG1tac.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { c as Radar, d as PolarGrid, m as Tooltip, n as RadarChart, p as ResponsiveContainer, u as PolarAngleAxis } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/assessment-results-DlQcv1Et.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AssessmentResultsPage() {
	useNavigate();
	const [results, setResults] = (0, import_react.useState)(getAssessmentResults());
	const [bookmarkedMap, setBookmarkedMap] = (0, import_react.useState)({});
	const allCareers = getManagedCareers().filter((c) => c.status !== "ARCHIVED");
	(0, import_react.useEffect)(() => {
		const res = getAssessmentResults();
		setResults(res);
		const bMap = {};
		allCareers.forEach((c) => {
			bMap[c.id] = isBookmarked("careers", c.id);
		});
		setBookmarkedMap(bMap);
	}, []);
	const handleToggleBookmark = (careerId) => {
		const isNowBookmarked = toggleBookmark("careers", careerId);
		setBookmarkedMap((prev) => ({
			...prev,
			[careerId]: isNowBookmarked
		}));
		toast.success(isNowBookmarked ? "Career added to bookmarks" : "Career removed from bookmarks");
	};
	const topCareers = results.recommendedCareerIds.map((id) => allCareers.find((c) => c.id === id) || CAREERS_DATA.find((c) => c.id === id)).filter(Boolean);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 max-w-4xl mx-auto py-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "gradient-brand p-6 sm:p-8 rounded-3xl text-primary-foreground shadow-glow flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							className: "bg-white/20 text-white border-0 text-xs font-semibold backdrop-blur",
							children: "Verified AI Assessment Report"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-xl sm:text-3xl font-bold font-display leading-tight",
							children: "Your Personalized Career Blueprint 🎯"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs sm:text-sm opacity-90 max-w-xl leading-relaxed",
							children: "Based on your responses across 50 adaptive behavioral and domain questions, here is your multidimensional career compatibility profile."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/assessment",
					className: "shrink-0 inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-white text-primary font-bold text-xs shadow-md hover:bg-white/90 transition-all",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Redo, { className: "size-3.5" }), " Retake Test"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 md:grid-cols-2 gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "glass p-5 rounded-3xl border-border/80 shadow-md space-y-3 bg-card/90",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "font-bold text-sm text-foreground flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4 text-primary" }), " Career Interest Spectrum"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] text-muted-foreground font-mono",
							children: "Multidimensional Scale"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-64 w-full flex items-center justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(RadarChart, {
								data: results.radarData,
								margin: {
									top: 10,
									right: 20,
									bottom: 10,
									left: 20
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarGrid, {
										stroke: "hsl(var(--border))",
										strokeDasharray: "3 3"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarAngleAxis, {
										dataKey: "area",
										tick: {
											fill: "hsl(var(--foreground))",
											fontSize: 11
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radar, {
										name: "Interest Score",
										dataKey: "score",
										stroke: "hsl(var(--primary))",
										fill: "hsl(var(--primary))",
										fillOpacity: .4
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
										backgroundColor: "hsl(var(--card))",
										borderColor: "hsl(var(--border))",
										borderRadius: "0.75rem",
										fontSize: "12px"
									} })
								]
							})
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "glass p-5 rounded-3xl border-border/80 shadow-md space-y-4 bg-card/90 flex flex-col justify-between",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "font-bold text-sm text-foreground flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lightbulb, { className: "size-4 text-amber-500" }), " Cognitive & Personality Profile"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-foreground/90 leading-relaxed bg-accent/40 p-3 rounded-2xl border border-border/60",
								children: results.personalitySummary
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] font-semibold text-muted-foreground mb-1",
								children: "Top Signature Traits:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-1.5",
								children: results.topTraits.map((trait) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "secondary",
									className: "text-[11px] rounded-lg bg-primary/10 text-primary border border-primary/20 font-semibold",
									children: trait
								}, trait))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] font-semibold text-muted-foreground mb-1",
								children: "Optimal Learning Style:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-foreground/90 leading-relaxed",
								children: results.learningStyle
							})] })
						]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-5 rounded-3xl border-emerald-500/20 bg-emerald-500/5 shadow-xs space-y-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
						className: "font-bold text-xs sm:text-sm text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheckBig, { className: "size-4" }), " Core Key Strengths"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-1.5 text-xs text-foreground/90",
						children: results.strengths.map((s, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-start gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-emerald-500 shrink-0 mt-1.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: s })]
						}, idx))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-5 rounded-3xl border-amber-500/20 bg-amber-500/5 shadow-xs space-y-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
						className: "font-bold text-xs sm:text-sm text-amber-600 dark:text-amber-400 flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-4" }), " Strategic Growth Areas"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-1.5 text-xs text-foreground/90",
						children: results.growthAreas.map((g, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-start gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-amber-500 shrink-0 mt-1.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: g })]
						}, idx))
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4 pt-4 border-t border-border",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "text-lg sm:text-xl font-bold font-display text-foreground flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "size-5 text-primary" }), " Top Recommended Careers for You"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground mt-0.5",
						children: "Ranked by deterministic behavioral compatibility, stream prerequisites, and growth demand."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/careers",
						className: "text-xs font-semibold text-primary hover:underline",
						children: "Explore 100+ Careers →"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 md:grid-cols-2 gap-4",
					children: topCareers.map((c, index) => {
						if (!c) return null;
						const matchPercentage = 98 - index * 3;
						const isSaved = bookmarkedMap[c.id];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "glass p-5 rounded-3xl border-border/80 hover:border-primary/40 transition-all shadow-md hover:shadow-lg flex flex-col justify-between space-y-4 bg-card/90",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											variant: "outline",
											className: "text-[11px] border-primary/20 text-primary bg-primary/5",
											children: c.domain
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-xs font-bold text-emerald-500 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20",
												children: [matchPercentage, "% Match"]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: () => handleToggleBookmark(c.id),
												className: "p-1 rounded-lg text-muted-foreground hover:text-primary transition-colors cursor-pointer",
												title: "Bookmark career",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: `size-4 ${isSaved ? "fill-primary text-primary" : ""}` })
											})]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-bold text-base text-foreground leading-snug",
										children: c.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground mt-1 line-clamp-2 leading-relaxed",
										children: c.description
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between text-xs pt-1 border-t border-border/40 text-muted-foreground",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Salary: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-foreground",
											children: c.salary
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Demand: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-foreground",
											children: c.demand
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex flex-wrap gap-1 pt-1",
										children: c.requiredSkills.slice(0, 4).map((skill) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] px-2 py-0.5 rounded-md bg-accent text-foreground font-mono",
											children: skill
										}, skill))
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center gap-2 pt-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/careers",
									className: "flex-1 gradient-brand text-primary-foreground font-semibold text-xs py-2 px-3 rounded-xl text-center shadow-xs hover:opacity-95 transition-opacity",
									children: "View Roadmap & Details →"
								})
							})]
						}, c.id);
					})
				})]
			})
		]
	});
}
//#endregion
export { AssessmentResultsPage as component };
