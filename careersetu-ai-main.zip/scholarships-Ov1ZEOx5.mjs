import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Card } from "./card-95-PmP7N.mjs";
import { t as Badge } from "./badge-BYEzUON3.mjs";
import { C as Search, Ot as Bookmark, X as GraduationCap, it as ExternalLink } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-D7UBWI0-.mjs";
import { l as getManagedScholarships } from "./admin-content-store-CcAL24zG.mjs";
import { _ as toggleBookmark, l as isBookmarked } from "./careersetu-store-CamG1tac.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-BfMpEmcB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/scholarships-Ov1ZEOx5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SCHOLARSHIP_CATEGORIES = [
	"All Categories",
	"Central Government",
	"State Government",
	"Corporate CSR",
	"Women in STEM"
];
function ScholarshipsFinderPage() {
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [selectedCategory, setSelectedCategory] = (0, import_react.useState)("All Categories");
	const [bookmarkedMap, setBookmarkedMap] = (0, import_react.useState)({});
	const [scholarshipsList, setScholarshipsList] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		const live = getManagedScholarships().filter((s) => s.status !== "ARCHIVED");
		setScholarshipsList(live);
		const bMap = {};
		live.forEach((s) => {
			bMap[s.id] = isBookmarked("scholarships", s.id);
		});
		setBookmarkedMap(bMap);
	}, []);
	const handleToggleBookmark = (id) => {
		const isNow = toggleBookmark("scholarships", id);
		setBookmarkedMap((prev) => ({
			...prev,
			[id]: isNow
		}));
		toast.success(isNow ? "Scholarship added to bookmarks" : "Removed from bookmarks");
	};
	const filteredScholarships = (0, import_react.useMemo)(() => {
		return scholarshipsList.filter((s) => {
			const q = searchQuery.toLowerCase().trim();
			const matchesSearch = !q || s.name.toLowerCase().includes(q) || s.provider.toLowerCase().includes(q) || s.eligibleStates && s.eligibleStates.some((st) => st.toLowerCase().includes(q));
			const matchesCat = selectedCategory === "All Categories" || s.category === selectedCategory;
			return matchesSearch && matchesCat;
		});
	}, [
		scholarshipsList,
		searchQuery,
		selectedCategory
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 max-w-5xl mx-auto py-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-9 place-items-center rounded-xl bg-amber-500/10 text-amber-500",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-xl sm:text-2xl font-bold font-display text-foreground",
						children: "National & State Scholarship Finder"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs sm:text-sm text-muted-foreground mt-1",
					children: "Verified financial aid programs, income ceilings, official portals, and active deadlines."
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "glass p-4 rounded-3xl border-border/80 shadow-xs space-y-3 bg-card/80",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 gap-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-2.5 size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: searchQuery,
							onChange: (e) => setSearchQuery(e.target.value),
							placeholder: "Search by scholarship, state, provider...",
							className: "pl-9 h-10 rounded-xl bg-background border-border text-xs sm:text-sm"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: selectedCategory,
						onValueChange: setSelectedCategory,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "rounded-xl h-10 text-xs bg-background",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Category" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, {
							className: "rounded-2xl",
							children: SCHOLARSHIP_CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: c,
								className: "text-xs",
								children: c
							}, c))
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between text-xs pt-1 text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						"Showing ",
						filteredScholarships.length,
						" Active Scholarships"
					] }), (searchQuery || selectedCategory !== "All Categories") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							setSearchQuery("");
							setSelectedCategory("All Categories");
						},
						className: "text-primary hover:underline text-[11px] font-medium cursor-pointer",
						children: "Clear Filters"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 md:grid-cols-2 gap-4",
				children: filteredScholarships.map((s) => {
					const isSaved = bookmarkedMap[s.id];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "glass p-5 rounded-3xl border-border/80 hover:border-amber-500/40 transition-all shadow-xs hover:shadow-lg flex flex-col justify-between space-y-4 bg-card/90",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "outline",
										className: "text-[10px] border-amber-500/30 text-amber-500 bg-amber-500/5",
										children: s.category
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `text-[10px] font-bold px-2 py-0.5 rounded-full border ${s.status === "Closing Soon" ? "bg-rose-500/10 text-rose-500 border-rose-500/30 animate-pulse" : "bg-emerald-500/10 text-emerald-500 border-emerald-500/30"}`,
											children: s.status
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => handleToggleBookmark(s.id),
											className: "p-1 rounded-lg text-muted-foreground hover:text-primary transition-colors cursor-pointer",
											title: "Bookmark scholarship",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: `size-3.5 ${isSaved ? "fill-primary text-primary" : ""}` })
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-bold text-base text-foreground leading-snug",
										children: s.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[11px] font-semibold text-primary mt-0.5",
										children: s.provider
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground mt-1.5 line-clamp-2 leading-relaxed",
										children: s.description
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5 pt-2 border-t border-border/40 text-xs text-muted-foreground",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Grant Amount:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "text-emerald-500 font-bold",
												children: s.amount
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Application Deadline:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "text-foreground font-mono",
												children: s.deadline
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Family Income Limit:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-foreground",
												children: [
													"Below ₹",
													(s.annualFamilyIncomeLimitINR / 1e5).toFixed(1),
													" Lakhs / yr"
												]
											})]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-2.5 rounded-xl bg-accent/40 border border-border/60 text-[11px] text-foreground/90 space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "block text-muted-foreground font-semibold",
										children: "Eligibility Criteria:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: s.eligibility })]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2 pt-3 border-t border-border/40",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-[10px] text-muted-foreground",
								children: ["Verified: ", s.lastUpdated]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: s.officialUrl,
								target: "_blank",
								rel: "noreferrer",
								className: "inline-flex items-center gap-1.5 gradient-brand text-primary-foreground font-bold text-xs py-2 px-3.5 rounded-xl shadow-xs hover:opacity-95",
								children: ["Apply on Official Portal ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3.5" })]
							})]
						})]
					}, s.id);
				})
			})
		]
	});
}
//#endregion
export { ScholarshipsFinderPage as component };
