import { i as __toESM } from "../_runtime.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Card } from "./card-95-PmP7N.mjs";
import { t as Badge } from "./badge-BYEzUON3.mjs";
import { t as Button } from "./button-CdcMTBqt.mjs";
import { C as Search, Ot as Bookmark, T as RotateCcw, W as Layers, g as Sparkles, n as X, st as Compass, t as Zap } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, n as DialogContent, o as DialogTitle, t as Dialog } from "./dialog-d9GHmrLL.mjs";
import { t as Input } from "./input-D7UBWI0-.mjs";
import { i as getManagedCareers } from "./admin-content-store-CcAL24zG.mjs";
import { _ as toggleBookmark, l as isBookmarked } from "./careersetu-store-CamG1tac.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-BfMpEmcB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/careers-jJVDuGjG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DOMAINS = [
	"All Domains",
	"Technology",
	"Healthcare",
	"Management",
	"Business & Finance",
	"Commerce",
	"Arts & Design",
	"Law & Policy",
	"Agriculture & Environment",
	"Science & Research",
	"Government & Defense"
];
var SECTOR_OPTIONS = [
	"All Sectors",
	"Private",
	"Government",
	"Both"
];
function CareersExplorerPage() {
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [selectedDomain, setSelectedDomain] = (0, import_react.useState)("All Domains");
	const [selectedSector, setSelectedSector] = (0, import_react.useState)("All Sectors");
	const [selectedSalary, setSelectedSalary] = (0, import_react.useState)("All Salaries");
	const [sortBy, setSortBy] = (0, import_react.useState)("salary-high");
	const [careersList, setCareersList] = (0, import_react.useState)([]);
	const [selectedCareer, setSelectedCareer] = (0, import_react.useState)(null);
	const [compareList, setCompareList] = (0, import_react.useState)([]);
	const [isCompareOpen, setIsCompareOpen] = (0, import_react.useState)(false);
	const [bookmarkedMap, setBookmarkedMap] = (0, import_react.useState)({});
	(0, import_react.useEffect)(() => {
		const live = getManagedCareers().filter((c) => c.status !== "ARCHIVED");
		setCareersList(live);
		const bMap = {};
		live.forEach((c) => {
			bMap[c.id] = isBookmarked("careers", c.id);
		});
		setBookmarkedMap(bMap);
	}, []);
	const handleToggleBookmark = (careerId) => {
		const isNow = toggleBookmark("careers", careerId);
		setBookmarkedMap((prev) => ({
			...prev,
			[careerId]: isNow
		}));
		toast.success(isNow ? "Career bookmarked" : "Removed from bookmarks");
	};
	const handleToggleCompare = (career) => {
		if (compareList.some((c) => c.id === career.id)) setCompareList((prev) => prev.filter((c) => c.id !== career.id));
		else {
			if (compareList.length >= 3) {
				toast.info("You can compare up to 3 careers at once");
				return;
			}
			setCompareList((prev) => [...prev, career]);
			toast.success(`Added ${career.name} to comparison`);
		}
	};
	const filteredCareers = (0, import_react.useMemo)(() => {
		return careersList.filter((c) => {
			const q = searchQuery.toLowerCase().trim();
			const matchesSearch = !q || c.name.toLowerCase().includes(q) || c.domain.toLowerCase().includes(q) || c.tags.some((t) => t.toLowerCase().includes(q)) || c.requiredSkills.some((s) => s.toLowerCase().includes(q));
			const matchesDomain = selectedDomain === "All Domains" || c.domain === selectedDomain;
			const matchesSector = selectedSector === "All Sectors" || c.sector === selectedSector || c.sector === "Both";
			let matchesSalary = true;
			if (selectedSalary === "Above ₹10 LPA") matchesSalary = c.maxSalaryLPA >= 10;
			if (selectedSalary === "Above ₹15 LPA") matchesSalary = c.maxSalaryLPA >= 15;
			if (selectedSalary === "Above ₹20 LPA") matchesSalary = c.maxSalaryLPA >= 20;
			return matchesSearch && matchesDomain && matchesSector && matchesSalary;
		}).sort((a, b) => {
			if (sortBy === "salary-high") return b.maxSalaryLPA - a.maxSalaryLPA;
			if (sortBy === "name") return a.name.localeCompare(b.name);
			return 0;
		});
	}, [
		searchQuery,
		selectedDomain,
		selectedSector,
		selectedSalary,
		sortBy
	]);
	const resetFilters = () => {
		setSearchQuery("");
		setSelectedDomain("All Domains");
		setSelectedSector("All Sectors");
		setSelectedSalary("All Salaries");
		setSortBy("salary-high");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 max-w-5xl mx-auto py-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-border",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-9 place-items-center rounded-xl bg-primary/10 text-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-xl sm:text-2xl font-bold font-display text-foreground",
						children: "Career Explorer (100+ Pathways)"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs sm:text-sm text-muted-foreground mt-1",
					children: "Search, filter, compare, and build step-by-step roadmaps for modern Indian and global careers."
				})] }), compareList.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: () => setIsCompareOpen(true),
					className: "gradient-brand text-primary-foreground font-bold rounded-xl shadow-glow cursor-pointer gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "size-4" }),
						" Compare (",
						compareList.length,
						")"
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "glass p-4 rounded-3xl border-border/80 shadow-xs space-y-3 bg-card/80",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-2.5 size-4 text-muted-foreground" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: searchQuery,
									onChange: (e) => setSearchQuery(e.target.value),
									placeholder: "Search by title, skill, domain...",
									className: "pl-9 h-10 rounded-xl bg-background border-border text-xs sm:text-sm"
								}),
								searchQuery && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setSearchQuery(""),
									className: "absolute right-3 top-3 text-muted-foreground hover:text-foreground cursor-pointer",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: selectedDomain,
							onValueChange: setSelectedDomain,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								className: "rounded-xl h-10 text-xs bg-background",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Industry / Domain" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, {
								className: "rounded-2xl max-h-64",
								children: DOMAINS.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: d,
									className: "text-xs",
									children: d
								}, d))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: selectedSector,
							onValueChange: setSelectedSector,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								className: "rounded-xl h-10 text-xs bg-background",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Sector" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, {
								className: "rounded-2xl",
								children: SECTOR_OPTIONS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: s,
									className: "text-xs",
									children: s
								}, s))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: sortBy,
							onValueChange: (val) => setSortBy(val),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								className: "rounded-xl h-10 text-xs bg-background",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Sort by" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, {
								className: "rounded-2xl",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "salary-high",
									className: "text-xs",
									children: "💰 Highest Package First"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "name",
									className: "text-xs",
									children: "🔤 Alphabetical (A-Z)"
								})]
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-2 pt-1 text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] text-muted-foreground font-semibold",
								children: "Showing:"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
								variant: "secondary",
								className: "text-[11px] font-medium",
								children: [filteredCareers.length, " Careers Found"]
							}),
							selectedDomain !== "All Domains" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
								variant: "outline",
								className: "text-[11px] gap-1 bg-primary/5 text-primary border-primary/20",
								children: [selectedDomain, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setSelectedDomain("All Domains"),
									className: "cursor-pointer",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-2.5" })
								})]
							})
						]
					}), (searchQuery || selectedDomain !== "All Domains" || selectedSector !== "All Sectors") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: resetFilters,
						className: "text-[11px] text-primary hover:underline flex items-center gap-1 cursor-pointer font-medium",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-3" }), " Clear Filters"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4",
				children: filteredCareers.map((c) => {
					const isSaved = bookmarkedMap[c.id];
					const isCompared = compareList.some((item) => item.id === c.id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "glass p-5 rounded-3xl border-border/80 hover:border-primary/40 transition-all shadow-xs hover:shadow-lg flex flex-col justify-between space-y-4 bg-card/90 group",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "outline",
										className: "text-[10px] border-primary/20 text-primary bg-primary/5",
										children: c.domain
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => handleToggleCompare(c),
											className: `p-1 rounded-lg text-xs transition-colors cursor-pointer ${isCompared ? "text-primary font-bold bg-primary/10" : "text-muted-foreground hover:text-foreground"}`,
											title: "Add to comparison",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "size-3.5" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => handleToggleBookmark(c.id),
											className: "p-1 rounded-lg text-muted-foreground hover:text-primary transition-colors cursor-pointer",
											title: "Bookmark career",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: `size-3.5 ${isSaved ? "fill-primary text-primary" : ""}` })
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-bold text-sm sm:text-base text-foreground group-hover:text-primary transition-colors leading-snug",
									children: c.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground mt-1 line-clamp-2 leading-relaxed",
									children: c.description
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1 pt-2 border-t border-border/40 text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between text-muted-foreground",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Salary:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-foreground",
											children: c.salary
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between text-muted-foreground",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Work Type:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-foreground",
											children: c.workType
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap gap-1 pt-1",
									children: [c.requiredSkills.slice(0, 3).map((skill) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] px-2 py-0.5 rounded-md bg-accent text-foreground font-mono",
										children: skill
									}, skill)), c.requiredSkills.length > 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[10px] px-1.5 py-0.5 rounded-md text-muted-foreground font-mono",
										children: ["+", c.requiredSkills.length - 3]
									})]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "sm",
							onClick: () => setSelectedCareer(c),
							className: "w-full rounded-xl text-xs font-semibold hover:bg-primary hover:text-primary-foreground transition-all cursor-pointer",
							children: "View Full Roadmap & Scope →"
						})]
					}, c.id);
				})
			}),
			filteredCareers.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "glass p-12 text-center rounded-3xl border-border space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "size-10 mx-auto text-muted-foreground" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-bold text-base text-foreground",
						children: "No matching careers found"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground max-w-sm mx-auto",
						children: "Try adjusting your search terms or clearing industry domain filters."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						onClick: resetFilters,
						className: "rounded-xl gradient-brand text-primary-foreground font-bold",
						children: "Reset All Filters"
					})
				]
			}),
			selectedCareer && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: !!selectedCareer,
				onOpenChange: () => setSelectedCareer(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-3xl max-h-[85vh] overflow-y-auto p-6 sm:p-8 rounded-3xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 mb-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							className: "bg-primary/10 text-primary border-primary/20 text-xs",
							children: selectedCareer.domain
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							variant: "outline",
							className: "text-xs",
							children: [selectedCareer.sector, " Sector"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "text-xl sm:text-2xl font-bold font-display text-foreground",
						children: selectedCareer.name
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-6 text-xs sm:text-sm mt-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-foreground/90 leading-relaxed bg-accent/30 p-3.5 rounded-2xl border border-border/60",
								children: selectedCareer.description
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 sm:grid-cols-4 gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3 rounded-2xl bg-card border border-border",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] text-muted-foreground block",
											children: "Salary Range"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-foreground text-xs sm:text-sm",
											children: selectedCareer.salary
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3 rounded-2xl bg-card border border-border",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] text-muted-foreground block",
											children: "Demand Level"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-emerald-500 text-xs sm:text-sm",
											children: selectedCareer.demand
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3 rounded-2xl bg-card border border-border",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] text-muted-foreground block",
											children: "Education Req."
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-foreground text-xs sm:text-sm",
											children: selectedCareer.educationRequired
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3 rounded-2xl bg-card border border-border",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] text-muted-foreground block",
											children: "Work Model"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-foreground text-xs sm:text-sm",
											children: selectedCareer.workType
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-bold text-xs uppercase tracking-wider text-muted-foreground",
									children: "Required Skills"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-wrap gap-1.5",
									children: selectedCareer.requiredSkills.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "secondary",
										className: "text-xs px-2.5 py-1 rounded-xl bg-accent text-foreground font-mono",
										children: s
									}, s))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-accent/20 border border-border space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: "font-bold text-xs text-foreground",
										children: "Top Colleges in India:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "space-y-1 text-xs text-muted-foreground",
										children: selectedCareer.topColleges.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "flex items-center gap-1.5",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-primary" }),
												" ",
												c
											]
										}, c))
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-accent/20 border border-border space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: "font-bold text-xs text-foreground",
										children: "Top Recruiters & Employers:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "space-y-1 text-xs text-muted-foreground",
										children: selectedCareer.topRecruiters.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "flex items-center gap-1.5",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-emerald-500" }),
												" ",
												r
											]
										}, r))
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3 pt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
									className: "font-bold text-xs uppercase tracking-wider text-muted-foreground flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3.5 text-primary" }), " Step-by-Step Career Roadmap"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "space-y-2.5",
									children: selectedCareer.roadmap.map((step, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start gap-3 p-3 rounded-2xl bg-card border border-border/80",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "grid size-6 place-items-center rounded-full bg-primary text-primary-foreground text-xs font-bold shrink-0 mt-0.5",
											children: idx + 1
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-bold text-foreground text-xs sm:text-sm",
											children: step.title
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-muted-foreground mt-0.5",
											children: step.desc
										})] })]
									}, idx))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-2 justify-end pt-4 border-t border-border",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									size: "sm",
									onClick: () => handleToggleBookmark(selectedCareer.id),
									className: "rounded-xl cursor-pointer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: `size-3.5 mr-1 ${bookmarkedMap[selectedCareer.id] ? "fill-primary text-primary" : ""}` }), bookmarkedMap[selectedCareer.id] ? "Bookmarked" : "Bookmark Career"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/skill-gap",
									className: "inline-flex items-center gap-1.5 gradient-brand text-primary-foreground font-semibold text-xs py-2 px-4 rounded-xl shadow-xs hover:opacity-95",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-3.5" }), " Analyze Skill Gap"]
								})]
							})
						]
					})]
				})
			}),
			isCompareOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: isCompareOpen,
				onOpenChange: setIsCompareOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-4xl max-h-[85vh] overflow-y-auto p-6 rounded-3xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
							className: "text-lg font-bold font-display flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "size-5 text-primary" }), " Career Comparison Matrix"]
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overflow-x-auto mt-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "w-full text-xs text-left border-collapse",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-border bg-accent/40",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-3 font-bold text-foreground",
										children: "Criteria"
									}), compareList.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-3 font-bold text-primary",
										children: c.name
									}, c.id))]
								}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-b border-border/40",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3 font-semibold text-muted-foreground",
											children: "Domain"
										}), compareList.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3 font-medium text-foreground",
											children: c.domain
										}, c.id))]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-b border-border/40",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3 font-semibold text-muted-foreground",
											children: "Salary Range"
										}), compareList.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3 font-bold text-emerald-500",
											children: c.salary
										}, c.id))]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-b border-border/40",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3 font-semibold text-muted-foreground",
											children: "Demand Level"
										}), compareList.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3 text-foreground",
											children: c.demand
										}, c.id))]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-b border-border/40",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3 font-semibold text-muted-foreground",
											children: "Work Model"
										}), compareList.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3 text-foreground",
											children: c.workType
										}, c.id))]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-b border-border/40",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3 font-semibold text-muted-foreground",
											children: "Core Skills"
										}), compareList.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3 text-foreground",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "flex flex-wrap gap-1",
												children: c.requiredSkills.slice(0, 3).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "px-1.5 py-0.5 rounded bg-muted text-[10px]",
													children: s
												}, s))
											})
										}, c.id))]
									})
								] })]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-end gap-2 pt-4 border-t border-border",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								size: "sm",
								onClick: () => setCompareList([]),
								className: "rounded-xl cursor-pointer",
								children: "Clear Comparison"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								onClick: () => setIsCompareOpen(false),
								className: "gradient-brand text-primary-foreground font-bold rounded-xl",
								children: "Close"
							})]
						})
					]
				})
			})
		]
	});
}
//#endregion
export { CareersExplorerPage as component };
