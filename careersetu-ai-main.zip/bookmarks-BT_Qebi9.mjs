import { i as __toESM } from "../_runtime.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Card } from "./card-95-PmP7N.mjs";
import { t as Badge } from "./badge-BYEzUON3.mjs";
import { G as Landmark, Ot as Bookmark, Tt as Briefcase, X as GraduationCap, f as Trash2, wt as Building2 } from "../_libs/lucide-react.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-mEmCUBpO.mjs";
import { n as COLLEGES_DATA, r as SCHOLARSHIPS_DATA, t as CAREERS_DATA } from "./colleges-data-D-tQlA8g.mjs";
import { t as EXAMS_DATA } from "./exams-data-C-FGqv-l.mjs";
import { _ as toggleBookmark, r as getBookmarks } from "./careersetu-store-CamG1tac.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/bookmarks-BT_Qebi9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function BookmarksPage() {
	const [bookmarks, setBookmarks] = (0, import_react.useState)(getBookmarks());
	(0, import_react.useEffect)(() => {
		setBookmarks(getBookmarks());
	}, []);
	const handleRemove = (type, id) => {
		toggleBookmark(type, id);
		setBookmarks(getBookmarks());
		toast.info("Removed from bookmarks");
	};
	const savedCareers = CAREERS_DATA.filter((c) => bookmarks.careers.includes(c.id));
	const savedExams = EXAMS_DATA.filter((e) => bookmarks.exams.includes(e.id));
	const savedScholarships = SCHOLARSHIPS_DATA.filter((s) => bookmarks.scholarships.includes(s.id));
	const savedColleges = COLLEGES_DATA.filter((col) => bookmarks.colleges.includes(col.id));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 max-w-4xl mx-auto py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-9 place-items-center rounded-xl bg-primary/10 text-primary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-5 fill-primary" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl sm:text-2xl font-bold font-display text-foreground",
					children: "My Bookmarks Hub"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs sm:text-sm text-muted-foreground mt-1",
				children: "Easily manage and review your saved career roadmaps, exam notifications, grants, and colleges."
			})] })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
			defaultValue: "careers",
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
					className: "rounded-2xl p-1 bg-accent/60 w-full sm:w-auto flex-wrap",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
							value: "careers",
							className: "rounded-xl text-xs font-semibold gap-1.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-3.5" }),
								" Careers (",
								savedCareers.length,
								")"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
							value: "exams",
							className: "rounded-xl text-xs font-semibold gap-1.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "size-3.5" }),
								" Exams (",
								savedExams.length,
								")"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
							value: "scholarships",
							className: "rounded-xl text-xs font-semibold gap-1.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "size-3.5" }),
								" Scholarships (",
								savedScholarships.length,
								")"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
							value: "colleges",
							className: "rounded-xl text-xs font-semibold gap-1.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3.5" }),
								" Colleges (",
								savedColleges.length,
								")"
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
					value: "careers",
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 md:grid-cols-2 gap-3",
						children: savedCareers.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "glass p-4 rounded-2xl border-border/80 flex justify-between items-start gap-3 bg-card",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "outline",
									className: "text-[10px] mb-1 text-primary",
									children: c.domain
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-bold text-sm text-foreground",
									children: c.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground mt-0.5",
									children: [
										c.salary,
										" · ",
										c.demand,
										" Demand"
									]
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/careers",
									className: "p-1 text-primary hover:underline text-xs font-semibold",
									children: "View"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => handleRemove("careers", c.id),
									className: "p-1 text-muted-foreground hover:text-destructive",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
								})]
							})]
						}, c.id))
					}), savedCareers.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-8 text-center rounded-2xl text-muted-foreground text-xs",
						children: [
							"No careers bookmarked yet. Visit ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/careers",
								className: "text-primary underline",
								children: "Career Explorer"
							}),
							" to save favorites."
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
					value: "exams",
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 md:grid-cols-2 gap-3",
						children: savedExams.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "glass p-4 rounded-2xl border-border/80 flex justify-between items-start gap-3 bg-card",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "outline",
									className: "text-[10px] mb-1 text-blue-500",
									children: e.category
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-bold text-sm text-foreground",
									children: e.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground mt-0.5",
									children: [
										e.conductingBody,
										" · Status: ",
										e.status
									]
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/exams",
									className: "p-1 text-primary hover:underline text-xs font-semibold",
									children: "View"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => handleRemove("exams", e.id),
									className: "p-1 text-muted-foreground hover:text-destructive",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
								})]
							})]
						}, e.id))
					}), savedExams.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-8 text-center rounded-2xl text-muted-foreground text-xs",
						children: [
							"No exams bookmarked. Visit ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/exams",
								className: "text-primary underline",
								children: "Government Exams"
							}),
							" to save exams."
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
					value: "scholarships",
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 md:grid-cols-2 gap-3",
						children: savedScholarships.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "glass p-4 rounded-2xl border-border/80 flex justify-between items-start gap-3 bg-card",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "outline",
									className: "text-[10px] mb-1 text-amber-500",
									children: s.category
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-bold text-sm text-foreground",
									children: s.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-emerald-500 font-bold mt-0.5",
									children: [
										s.amount,
										" · Deadline: ",
										s.deadline
									]
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: s.officialUrl,
									target: "_blank",
									rel: "noreferrer",
									className: "p-1 text-primary hover:underline text-xs font-semibold",
									children: "Portal"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => handleRemove("scholarships", s.id),
									className: "p-1 text-muted-foreground hover:text-destructive",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
								})]
							})]
						}, s.id))
					}), savedScholarships.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-8 text-center rounded-2xl text-muted-foreground text-xs",
						children: [
							"No scholarships bookmarked. Visit ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/scholarships",
								className: "text-primary underline",
								children: "Scholarship Finder"
							}),
							" to save grants."
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
					value: "colleges",
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 md:grid-cols-2 gap-3",
						children: savedColleges.map((col) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "glass p-4 rounded-2xl border-border/80 flex justify-between items-start gap-3 bg-card",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									variant: "outline",
									className: "text-[10px] mb-1 text-emerald-500",
									children: ["NIRF #", col.nirfRank]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-bold text-sm text-foreground",
									children: col.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground mt-0.5",
									children: [
										col.city,
										", ",
										col.state,
										" · Avg: ₹",
										col.avgPlacementPackageLPA,
										" LPA"
									]
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: col.officialWebsite,
									target: "_blank",
									rel: "noreferrer",
									className: "p-1 text-primary hover:underline text-xs font-semibold",
									children: "Website"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => handleRemove("colleges", col.id),
									className: "p-1 text-muted-foreground hover:text-destructive",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
								})]
							})]
						}, col.id))
					}), savedColleges.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-8 text-center rounded-2xl text-muted-foreground text-xs",
						children: [
							"No colleges bookmarked. Visit ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/colleges",
								className: "text-primary underline",
								children: "College Directory"
							}),
							" to save institutions."
						]
					})]
				})
			]
		})]
	});
}
//#endregion
export { BookmarksPage as component };
