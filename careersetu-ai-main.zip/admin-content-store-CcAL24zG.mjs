import { C as logAuditEvent } from "./rbac-D_Rf6U5V.mjs";
import { n as COLLEGES_DATA, r as SCHOLARSHIPS_DATA, t as CAREERS_DATA } from "./colleges-data-D-tQlA8g.mjs";
import { t as EXAMS_DATA } from "./exams-data-C-FGqv-l.mjs";
import { t as ASSESSMENT_QUESTIONS } from "./assessment-questions-ssXbMUdg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-content-store-CcAL24zG.js
var RESOURCES_DATA = [
	{
		id: "upsc-laxmikanth-polity",
		title: "Indian Polity for Civil Services (6th/7th Edition)",
		category: "Standard Books",
		targetExamOrCareer: "UPSC CSE / State PSC",
		authorOrProvider: "M. Laxmikanth (McGraw Hill)",
		format: "Book / Paperback",
		accessType: "Paid / Library",
		sourceUrl: "https://www.mheducation.co.in",
		sourceLabel: "McGraw Hill India",
		rating: 4.9,
		description: "The undisputed 'Bible of Indian Polity' covering Constitution, Fundamental Rights, Parliament, and Judiciary.",
		tags: [
			"UPSC",
			"Polity",
			"Constitution",
			"Core Book"
		]
	},
	{
		id: "upsc-spectrum-history",
		title: "A Brief History of Modern India",
		category: "Standard Books",
		targetExamOrCareer: "UPSC CSE",
		authorOrProvider: "Rajiv Ahir (Spectrum Books)",
		format: "Book / Paperback",
		accessType: "Paid / Library",
		sourceUrl: "https://spectrumbooks.in",
		sourceLabel: "Spectrum Publications",
		rating: 4.8,
		description: "Chronological and point-by-point coverage of India's freedom struggle, Governor Generals, and reform movements.",
		tags: [
			"UPSC",
			"Modern History",
			"Prelims",
			"Mains"
		]
	},
	{
		id: "upsc-official-pyqs",
		title: "UPSC Official Previous Years' Question Papers (Prelims & Mains)",
		category: "Practice Papers & PYQs",
		targetExamOrCareer: "UPSC CSE",
		authorOrProvider: "Union Public Service Commission (Official)",
		format: "PDF Download",
		accessType: "Free",
		sourceUrl: "https://upsc.gov.in/examinations/previous-question-papers",
		sourceLabel: "Official UPSC Portal",
		rating: 5,
		description: "Official repository of past 15 years question papers for GS Paper 1, CSAT, and Mains Optional subjects.",
		tags: [
			"UPSC",
			"Official PYQs",
			"Free Download"
		]
	},
	{
		id: "gate-nptel-dsa",
		title: "Data Structures & Algorithms in C++ (NPTEL IIT Madras)",
		category: "YouTube Courses",
		targetExamOrCareer: "GATE CSE / Software Engineering",
		authorOrProvider: "Prof. Naveen Garg (IIT Delhi / NPTEL)",
		format: "Video Playlist",
		accessType: "Free",
		sourceUrl: "https://nptel.ac.in/courses/106102064",
		sourceLabel: "NPTEL / Swayam Govt Portal",
		rating: 4.9,
		description: "Comprehensive university-level lectures on asymptotic analysis, trees, graphs, dynamic programming, and greedy algorithms.",
		tags: [
			"GATE",
			"DSA",
			"NPTEL",
			"IIT Lectures",
			"Free"
		]
	},
	{
		id: "gate-overflow-pyqs",
		title: "GATE Overflow Comprehensive CSE Question Bank",
		category: "Practice Papers & PYQs",
		targetExamOrCareer: "GATE CSE",
		authorOrProvider: "GATE Overflow Community",
		format: "Web Portal",
		accessType: "Free",
		sourceUrl: "https://gateoverflow.in",
		sourceLabel: "GateOverflow.in",
		rating: 4.9,
		description: "Categorized, peer-reviewed solutions and discussion for every single GATE CS question asked since 1987.",
		tags: [
			"GATE CSE",
			"PYQ Solutions",
			"Free Community"
		]
	},
	{
		id: "striver-sde-sheet",
		title: "TakeUforward SDE Placement & DSA Roadmap (Striver Sheet)",
		category: "Practice Papers & PYQs",
		targetExamOrCareer: "Full Stack / SDE Career",
		authorOrProvider: "Raj Vikramaditya (takeUforward)",
		format: "Web Portal",
		accessType: "Free",
		sourceUrl: "https://takeuforward.org/strivers-a2z-dsa-course/strivers-a2z-dsa-course-sheet-2",
		sourceLabel: "TakeUforward Portal",
		rating: 4.9,
		description: "Structured A-to-Z DSA problem curriculum with step-by-step video editorials, C++, Java, and Python solutions.",
		tags: [
			"DSA",
			"LeetCode",
			"Placement",
			"SDE Sheet",
			"Free"
		]
	},
	{
		id: "full-stack-open",
		title: "Full Stack Open (University of Helsinki Deep Dive)",
		category: "YouTube Courses",
		targetExamOrCareer: "Full Stack Software Engineer",
		authorOrProvider: "University of Helsinki",
		format: "Web Portal",
		accessType: "Free",
		sourceUrl: "https://fullstackopen.com/en",
		sourceLabel: "University of Helsinki",
		rating: 5,
		description: "Free modern open-source course covering React, Redux, Node.js, Express, REST, GraphQL, TypeScript, and CI/CD.",
		tags: [
			"Full Stack",
			"React",
			"NodeJS",
			"TypeScript",
			"Free Certificate"
		]
	},
	{
		id: "ssc-cgl-maths-pyqs",
		title: "SSC CGL 7300+ Quantitative Aptitude Chapterwise",
		category: "Standard Books",
		targetExamOrCareer: "SSC CGL / Banking",
		authorOrProvider: "Rakesh Yadav Readers Publication",
		format: "Book / Paperback",
		accessType: "Paid / Library",
		sourceUrl: "https://rypbooks.com",
		sourceLabel: "Rakesh Yadav Publication",
		rating: 4.8,
		description: "Contains all previous year SSC CGL, CPO, CHSL Math questions with fast arithmetic shortcut solutions.",
		tags: [
			"SSC CGL",
			"Quantitative Aptitude",
			"Maths"
		]
	},
	{
		id: "rbi-official-reports",
		title: "RBI Annual Report & Report on Trend and Progress of Banking in India",
		category: "Official Portals & Syllabus",
		targetExamOrCareer: "RBI Grade B / Finance",
		authorOrProvider: "Reserve Bank of India",
		format: "PDF Download",
		accessType: "Free",
		sourceUrl: "https://rbi.org.in/Scripts/AnnualPublications.aspx",
		sourceLabel: "Official RBI Website",
		rating: 4.9,
		description: "Official monetary and banking statistics directly tested in Phase 2 Economic & Social Issues (ESI) and Finance papers.",
		tags: [
			"RBI Grade B",
			"Official Reports",
			"Finance",
			"Free"
		]
	}
];
var INITIAL_SKILLS = [
	{
		id: "skill-1",
		name: "Python Programming",
		category: "Programming",
		demand: "Very High",
		careers: ["ai-ml-engineer", "data-scientist"],
		learningTimeWeeks: 8
	},
	{
		id: "skill-2",
		name: "SQL & Data Warehousing",
		category: "Data",
		demand: "Very High",
		careers: [
			"data-analyst",
			"data-scientist",
			"backend-developer"
		],
		learningTimeWeeks: 6
	},
	{
		id: "skill-3",
		name: "Indian Constitution & Polity",
		category: "Civil Services",
		demand: "High",
		careers: ["ias-officer", "ips-officer"],
		learningTimeWeeks: 12
	},
	{
		id: "skill-4",
		name: "Machine Learning & Deep Learning",
		category: "AI",
		demand: "Very High",
		careers: ["ai-ml-engineer"],
		learningTimeWeeks: 16
	},
	{
		id: "skill-5",
		name: "Financial Accounting & Valuation",
		category: "Finance",
		demand: "High",
		careers: ["investment-banker", "chartered-accountant"],
		learningTimeWeeks: 10
	},
	{
		id: "skill-6",
		name: "Data Structures & Algorithms",
		category: "Computer Science",
		demand: "Very High",
		careers: ["full-stack-developer", "backend-developer"],
		learningTimeWeeks: 12
	}
];
var INITIAL_BROADCASTS = [{
	id: "notif-1",
	title: "UPSC CSE 2026 Notification Released",
	message: "Union Public Service Commission has officially opened registration window. Apply online before deadline.",
	category: "EXAM",
	priority: "HIGH",
	targetAudience: "ALL",
	link: "/exams",
	publishedAt: "2026-03-10T10:00:00.000Z"
}, {
	id: "notif-2",
	title: "AICTE Pragati Scholarship Application Window Closing",
	message: "Annual ₹50,000 scholarship for female technical diploma/degree students closing in 7 days.",
	category: "SCHOLARSHIP",
	priority: "URGENT",
	targetAudience: "GRADUATES",
	link: "/scholarships",
	publishedAt: "2026-03-12T12:00:00.000Z"
}];
function getManagedCareers() {
	if (typeof localStorage === "undefined") return CAREERS_DATA.map((c) => ({
		...c,
		status: "PUBLISHED",
		lastUpdated: "2026-03-01",
		source: "Official Industry & UGC Data"
	}));
	try {
		const raw = localStorage.getItem("careersetu_admin_careers");
		if (raw) return JSON.parse(raw);
	} catch {}
	const initial = CAREERS_DATA.map((c) => ({
		...c,
		status: "PUBLISHED",
		lastUpdated: "2026-03-01",
		source: "Official Industry & UGC Data"
	}));
	localStorage.setItem("careersetu_admin_careers", JSON.stringify(initial));
	return initial;
}
function saveManagedCareers(careers) {
	if (typeof localStorage === "undefined") return;
	localStorage.setItem("careersetu_admin_careers", JSON.stringify(careers));
}
function upsertManagedCareer(career) {
	const list = getManagedCareers();
	const idx = list.findIndex((c) => c.id === career.id);
	if (idx >= 0) {
		list[idx] = {
			...list[idx],
			...career,
			lastUpdated: (/* @__PURE__ */ new Date()).toISOString().split("T")[0]
		};
		logAuditEvent("CAREER_UPDATED", "Career", career.id, `Updated career ${career.name} (Status: ${career.status || "PUBLISHED"})`);
	} else {
		list.unshift({
			...career,
			lastUpdated: (/* @__PURE__ */ new Date()).toISOString().split("T")[0]
		});
		logAuditEvent("CAREER_CREATED", "Career", career.id, `Created career profile ${career.name}`);
	}
	saveManagedCareers(list);
}
function archiveCareer(careerId) {
	const list = getManagedCareers();
	const item = list.find((c) => c.id === careerId);
	if (item) {
		item.status = item.status === "ARCHIVED" ? "PUBLISHED" : "ARCHIVED";
		saveManagedCareers(list);
		logAuditEvent("CAREER_STATUS_CHANGE", "Career", careerId, `Changed status of ${item.name} to ${item.status}`);
	}
}
function getManagedExams() {
	if (typeof localStorage === "undefined") return EXAMS_DATA.map((e) => ({
		...e,
		status: "PUBLISHED",
		lastUpdated: "2026-03-01",
		source: "Official Conducting Commission"
	}));
	try {
		const raw = localStorage.getItem("careersetu_admin_exams");
		if (raw) return JSON.parse(raw);
	} catch {}
	const initial = EXAMS_DATA.map((e) => ({
		...e,
		status: "PUBLISHED",
		lastUpdated: "2026-03-01",
		source: "Official Conducting Commission"
	}));
	localStorage.setItem("careersetu_admin_exams", JSON.stringify(initial));
	return initial;
}
function saveManagedExams(exams) {
	if (typeof localStorage === "undefined") return;
	localStorage.setItem("careersetu_admin_exams", JSON.stringify(exams));
}
function upsertManagedExam(exam) {
	const list = getManagedExams();
	const idx = list.findIndex((e) => e.id === exam.id);
	if (idx >= 0) {
		list[idx] = {
			...list[idx],
			...exam,
			lastUpdated: (/* @__PURE__ */ new Date()).toISOString().split("T")[0]
		};
		logAuditEvent("EXAM_UPDATED", "Government Exam", exam.id, `Updated exam ${exam.name}`);
	} else {
		list.unshift({
			...exam,
			lastUpdated: (/* @__PURE__ */ new Date()).toISOString().split("T")[0]
		});
		logAuditEvent("EXAM_CREATED", "Government Exam", exam.id, `Created exam profile ${exam.name}`);
	}
	saveManagedExams(list);
}
function getManagedScholarships() {
	if (typeof localStorage === "undefined") return SCHOLARSHIPS_DATA.map((s) => ({
		...s,
		status: "PUBLISHED"
	}));
	try {
		const raw = localStorage.getItem("careersetu_admin_scholarships");
		if (raw) return JSON.parse(raw);
	} catch {}
	const initial = SCHOLARSHIPS_DATA.map((s) => ({
		...s,
		status: "PUBLISHED"
	}));
	localStorage.setItem("careersetu_admin_scholarships", JSON.stringify(initial));
	return initial;
}
function saveManagedScholarships(items) {
	if (typeof localStorage === "undefined") return;
	localStorage.setItem("careersetu_admin_scholarships", JSON.stringify(items));
}
function upsertManagedScholarship(s) {
	const list = getManagedScholarships();
	const idx = list.findIndex((item) => item.id === s.id);
	if (idx >= 0) {
		list[idx] = {
			...list[idx],
			...s,
			lastUpdated: (/* @__PURE__ */ new Date()).toISOString().split("T")[0]
		};
		logAuditEvent("SCHOLARSHIP_UPDATED", "Scholarship", s.id, `Updated scholarship ${s.name}`);
	} else {
		list.unshift({
			...s,
			lastUpdated: (/* @__PURE__ */ new Date()).toISOString().split("T")[0]
		});
		logAuditEvent("SCHOLARSHIP_CREATED", "Scholarship", s.id, `Created scholarship ${s.name}`);
	}
	saveManagedScholarships(list);
}
function getManagedColleges() {
	if (typeof localStorage === "undefined") return COLLEGES_DATA.map((c) => ({
		...c,
		status: "PUBLISHED"
	}));
	try {
		const raw = localStorage.getItem("careersetu_admin_colleges");
		if (raw) return JSON.parse(raw);
	} catch {}
	const initial = COLLEGES_DATA.map((c) => ({
		...c,
		status: "PUBLISHED"
	}));
	localStorage.setItem("careersetu_admin_colleges", JSON.stringify(initial));
	return initial;
}
function saveManagedColleges(items) {
	if (typeof localStorage === "undefined") return;
	localStorage.setItem("careersetu_admin_colleges", JSON.stringify(items));
}
function upsertManagedCollege(c) {
	const list = getManagedColleges();
	const idx = list.findIndex((item) => item.id === c.id);
	if (idx >= 0) {
		list[idx] = {
			...list[idx],
			...c,
			lastUpdated: (/* @__PURE__ */ new Date()).toISOString().split("T")[0]
		};
		logAuditEvent("COLLEGE_UPDATED", "College", c.id, `Updated college ${c.name}`);
	} else {
		list.unshift({
			...c,
			lastUpdated: (/* @__PURE__ */ new Date()).toISOString().split("T")[0]
		});
		logAuditEvent("COLLEGE_CREATED", "College", c.id, `Created college entry ${c.name}`);
	}
	saveManagedColleges(list);
}
function getManagedResources() {
	if (typeof localStorage === "undefined") return RESOURCES_DATA.map((r) => ({
		...r,
		status: "PUBLISHED"
	}));
	try {
		const raw = localStorage.getItem("careersetu_admin_resources");
		if (raw) return JSON.parse(raw);
	} catch {}
	const initial = RESOURCES_DATA.map((r) => ({
		...r,
		status: "PUBLISHED"
	}));
	localStorage.setItem("careersetu_admin_resources", JSON.stringify(initial));
	return initial;
}
function saveManagedResources(items) {
	if (typeof localStorage === "undefined") return;
	localStorage.setItem("careersetu_admin_resources", JSON.stringify(items));
}
function upsertManagedResource(r) {
	const list = getManagedResources();
	const idx = list.findIndex((item) => item.id === r.id);
	if (idx >= 0) {
		list[idx] = {
			...list[idx],
			...r,
			lastUpdated: (/* @__PURE__ */ new Date()).toISOString().split("T")[0]
		};
		logAuditEvent("RESOURCE_UPDATED", "Learning Resource", r.id, `Updated resource ${r.title}`);
	} else {
		list.unshift({
			...r,
			lastUpdated: (/* @__PURE__ */ new Date()).toISOString().split("T")[0]
		});
		logAuditEvent("RESOURCE_CREATED", "Learning Resource", r.id, `Created resource ${r.title}`);
	}
	saveManagedResources(list);
}
function getManagedQuestions() {
	if (typeof localStorage === "undefined") return ASSESSMENT_QUESTIONS.map((q) => ({
		...q,
		active: true
	}));
	try {
		const raw = localStorage.getItem("careersetu_admin_questions");
		if (raw) return JSON.parse(raw);
	} catch {}
	const initial = ASSESSMENT_QUESTIONS.map((q) => ({
		...q,
		active: true
	}));
	localStorage.setItem("careersetu_admin_questions", JSON.stringify(initial));
	return initial;
}
function saveManagedQuestions(questions) {
	if (typeof localStorage === "undefined") return;
	localStorage.setItem("careersetu_admin_questions", JSON.stringify(questions));
}
function upsertManagedQuestion(q) {
	const list = getManagedQuestions();
	const idx = list.findIndex((item) => item.id === q.id);
	if (idx >= 0) {
		list[idx] = q;
		logAuditEvent("QUESTION_UPDATED", "Assessment Question", String(q.id), `Updated Question #${q.order} (${q.category})`);
	} else {
		list.push(q);
		logAuditEvent("QUESTION_CREATED", "Assessment Question", String(q.id), `Added Question #${q.order} (${q.category})`);
	}
	saveManagedQuestions(list);
}
function toggleQuestionActive(questionId) {
	const list = getManagedQuestions();
	const item = list.find((q) => q.id === questionId);
	if (item) {
		item.active = !item.active;
		saveManagedQuestions(list);
		logAuditEvent("QUESTION_STATUS_CHANGE", "Assessment Question", String(questionId), `Toggled active state of Q#${item.order} (${item.category}) to ${item.active}`);
	}
}
function getSkills() {
	if (typeof localStorage === "undefined") return INITIAL_SKILLS;
	try {
		const raw = localStorage.getItem("careersetu_admin_skills");
		if (raw) return JSON.parse(raw);
	} catch {}
	return INITIAL_SKILLS;
}
function getBroadcastNotifications() {
	if (typeof localStorage === "undefined") return INITIAL_BROADCASTS;
	try {
		const raw = localStorage.getItem("careersetu_broadcast_notifs");
		if (raw) return JSON.parse(raw);
	} catch {}
	return INITIAL_BROADCASTS;
}
function saveBroadcastNotifications(notifs) {
	if (typeof localStorage === "undefined") return;
	localStorage.setItem("careersetu_broadcast_notifs", JSON.stringify(notifs));
}
function createBroadcastNotification(notif) {
	const list = getBroadcastNotifications();
	const newEntry = {
		...notif,
		id: "broadcast-" + Date.now(),
		publishedAt: (/* @__PURE__ */ new Date()).toISOString()
	};
	list.unshift(newEntry);
	saveBroadcastNotifications(list);
	logAuditEvent("NOTIFICATION_BROADCAST", "Notification", newEntry.id, `Broadcasted alert: "${newEntry.title}" to target ${newEntry.targetAudience}`);
	return newEntry;
}
//#endregion
export { upsertManagedScholarship as _, getManagedColleges as a, getManagedResources as c, toggleQuestionActive as d, upsertManagedCareer as f, upsertManagedResource as g, upsertManagedQuestion as h, getManagedCareers as i, getManagedScholarships as l, upsertManagedExam as m, createBroadcastNotification as n, getManagedExams as o, upsertManagedCollege as p, getBroadcastNotifications as r, getManagedQuestions as s, archiveCareer as t, getSkills as u };
