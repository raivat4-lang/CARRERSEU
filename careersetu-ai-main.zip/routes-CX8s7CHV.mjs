import { i as __toESM } from "../_runtime.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { a as Trigger2, i as Root2, n as Header, r as Item, t as Content2, v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { n as cn, t as Card } from "./card-95-PmP7N.mjs";
import { t as Badge } from "./badge-BYEzUON3.mjs";
import { t as Button } from "./button-CdcMTBqt.mjs";
import { $ as Flame, At as Bell, C as Search, Ct as CalendarCheck, E as RefreshCw, Et as Brain, G as Landmark, I as Mail, M as Moon, Mt as ArrowRight, N as MessageSquareHeart, P as Menu, Q as Github, R as LogIn, Tt as Briefcase, U as Library, V as Linkedin, X as GraduationCap, _ as Shield, et as FileText, ft as CircleQuestionMark, g as Sparkles, h as Star, i as Wallet, it as ExternalLink, l as Twitter, m as Sun, n as X, p as Target, pt as CircleCheck, q as Info, s as UserPlus, st as Compass, vt as ChevronDown, xt as Calendar } from "../_libs/lucide-react.mjs";
import { a as DialogOverlay, c as DialogTrigger, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { a as DialogHeader, n as DialogContent$1, o as DialogTitle$1, t as Dialog$1 } from "./dialog-d9GHmrLL.mjs";
import { t as Input } from "./input-D7UBWI0-.mjs";
import { t as Logo } from "./Logo-CGI7av7x.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CX8s7CHV.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FALLBACK_EXAM_NEWS = [
	{
		id: "upsc-cse-2026",
		title: "UPSC Civil Services Examination (CSE) 2026 Notification",
		shortName: "UPSC CSE",
		category: "Civil Services",
		status: "Registration Open",
		date: "May 24, 2026",
		eligibility: "Bachelor's degree in any discipline | Age: 21-32 years",
		summary: "Union Public Service Commission has released the prelims notification. Over 1,000 posts announced for IAS, IPS, IFS, and Central Group A/B services.",
		highlights: [
			"Prelims scheduled for May 2026 across major cities",
			"Negative marking of 1/3rd for wrong answers in GS Paper I",
			"CSAT Paper II remains qualifying with 33% minimum mark"
		],
		officialUrl: "https://upsc.gov.in",
		lastUpdated: "Just now"
	},
	{
		id: "gate-2027",
		title: "GATE 2027 Official Exam Calendar & Syllabus Update",
		shortName: "GATE 2027",
		category: "Engineering",
		status: "Upcoming",
		date: "Feb 06-14, 2027",
		eligibility: "3rd year or completed B.Tech / B.E / M.Sc",
		summary: "IIT organizing body releases tentative schedule for Graduate Aptitude Test in Engineering 2027 covering 30 paper disciplines.",
		highlights: [
			"2 new sectional sub-topics added in Data Science & AI paper",
			"Score valid for 3 years for PSU recruitment (ONGC, IOCL, NTPC)",
			"Direct M.Tech admission eligibility for IITs & NITs"
		],
		officialUrl: "https://gate.iitk.ac.in",
		lastUpdated: "Today"
	},
	{
		id: "jee-main-2026",
		title: "JEE Main 2026 Session 2 Scorecard & Rank List Out",
		shortName: "JEE Main",
		category: "Engineering",
		status: "Results Declared",
		date: "April 2026",
		eligibility: "Class 12 Passed/Appearing with Physics, Chemistry & Math",
		summary: "National Testing Agency (NTA) has published JEE Main final ranks. Top 2,50,000 candidates qualify for JEE Advanced 2026.",
		highlights: [
			"JoSAA counseling registration starts next week",
			"Cutoff percentiles announced for General, OBC-NCL, EWS, SC, ST",
			"AIR rank cards available on jeemain.nta.ac.in"
		],
		officialUrl: "https://jeemain.nta.ac.in",
		lastUpdated: "1 day ago"
	},
	{
		id: "neet-ug-2026",
		title: "NEET UG 2026 Registration & Exam Date Announcement",
		shortName: "NEET UG",
		category: "Medical",
		status: "Registration Open",
		date: "May 03, 2026",
		eligibility: "Class 12 with PCB (Physics, Chemistry, Biology) min 50%",
		summary: "National Testing Agency opens NEET UG registration for MBBS, BDS, BAMS, BHMS & Nursing admissions in India.",
		highlights: [
			"Single national level entrance for all AIIMS, JIPMER & Govt Colleges",
			"Pen and paper OMR-based test across 500+ exam centers",
			"720 marks total (Biology 360, Physics 180, Chemistry 180)"
		],
		officialUrl: "https://neet.nta.nic.in",
		lastUpdated: "2 days ago"
	},
	{
		id: "ssc-cgl-2026",
		title: "SSC CGL 2026 Tier 1 Admit Card & Exam City Intimation",
		shortName: "SSC CGL",
		category: "Civil Services",
		status: "Admit Card Released",
		date: "September 2026",
		eligibility: "Graduation in any stream | Age 18-30 years",
		summary: "Staff Selection Commission releases Tier 1 hall tickets for 17,000+ Assistant Section Officer, Inspector & Auditor posts.",
		highlights: [
			"Computer Based Test (CBT) covering Reasoning, Quant, English, GK",
			"Tier 1 qualifying in nature, Tier 2 determines final selection list",
			"Regional website download links live for NR, CR, WR, SR zones"
		],
		officialUrl: "https://ssc.gov.in",
		lastUpdated: "3 days ago"
	},
	{
		id: "ibps-po-2026",
		title: "IBPS Probationary Officer (PO) 2026 Recruitment Drive",
		shortName: "IBPS PO",
		category: "Banking",
		status: "Registration Open",
		date: "October 2026",
		eligibility: "Graduate degree from a recognized university",
		summary: "Institute of Banking Personnel Selection invites online applications for 4,500+ PO/MT posts in 11 participating public sector banks.",
		highlights: [
			"3-stage selection: Prelims, Mains, and Personal Interview",
			"Participating banks include PNB, Bank of Baroda, Canara Bank",
			"Starting salary package approx ₹52,000 - ₹55,000 per month"
		],
		officialUrl: "https://ibps.in",
		lastUpdated: "Just now"
	},
	{
		id: "isro-icrb-2026",
		title: "ISRO Scientist/Engineer Recruitment Notification 2026",
		shortName: "ISRO Scientist",
		category: "Engineering",
		status: "Upcoming",
		date: "November 2026",
		eligibility: "B.E/B.Tech with minimum 65% aggregate marks",
		summary: "Indian Space Research Organisation announces Scientist 'SC' vacancies in Mechanical, Electronics and Computer Science disciplines.",
		highlights: [
			"GATE score based shortlisting followed by written test and interview",
			"Posting at ISRO centers across India (VSSC, URSC, SAC, SDSC)",
			"Prestigious Pay Matrix Level 10 entry for young engineers"
		],
		officialUrl: "https://isro.gov.in",
		lastUpdated: "Today"
	},
	{
		id: "nda-2-2026",
		title: "UPSC NDA & NA (II) Exam 2026 Application Portal",
		shortName: "NDA II 2026",
		category: "Defense",
		status: "Registration Open",
		date: "September 2026",
		eligibility: "Passed/Appearing Class 12 | Unmarried Male/Female candidates",
		summary: "UPSC invites applications for National Defence Academy & Naval Academy Examination (II) 2026 for Army, Navy & Air Force wings.",
		highlights: [
			"Mathematics (300 marks) & General Ability Test (600 marks)",
			"Followed by 5-day SSB Interview for shortlisted candidates",
			"Includes Air Force Flying Branch, Naval Cadets and Army wing"
		],
		officialUrl: "https://upsc.gov.in",
		lastUpdated: "4 days ago"
	}
];
async function fetchGeminiExamNews(categoryFilter) {
	const apiKey = {
		"BASE_URL": "/",
		"DEV": false,
		"MODE": "production",
		"PROD": true,
		"SSR": true,
		"TSS_DEV_SERVER": "false",
		"TSS_DEV_SSR_STYLES_BASEPATH": "/",
		"TSS_DEV_SSR_STYLES_ENABLED": "true",
		"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
		"TSS_INLINE_CSS_ENABLED": "false",
		"TSS_ROUTER_BASEPATH": "",
		"TSS_SERVER_FN_BASE": "/_serverFn/",
		"VITE_GOOGLE_CLIENT_ID": "781343883716-k395k1cpf5ehccrardlrt2kj33m9qk06.apps.googleusercontent.com",
		"VITE_SUPABASE_PROJECT_ID": "hywynexgmdtpeqpuwjir",
		"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_9sNJVlPWSR48ulY_7DNCZA_c85VMMS8",
		"VITE_SUPABASE_URL": "https://hywynexgmdtpeqpuwjir.supabase.co"
	}["VITE_GEMINI_API_KEY"] || {
		"BASE_URL": "/",
		"DEV": false,
		"MODE": "production",
		"PROD": true,
		"SSR": true,
		"TSS_DEV_SERVER": "false",
		"TSS_DEV_SSR_STYLES_BASEPATH": "/",
		"TSS_DEV_SSR_STYLES_ENABLED": "true",
		"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
		"TSS_INLINE_CSS_ENABLED": "false",
		"TSS_ROUTER_BASEPATH": "",
		"TSS_SERVER_FN_BASE": "/_serverFn/",
		"VITE_GOOGLE_CLIENT_ID": "781343883716-k395k1cpf5ehccrardlrt2kj33m9qk06.apps.googleusercontent.com",
		"VITE_SUPABASE_PROJECT_ID": "hywynexgmdtpeqpuwjir",
		"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_9sNJVlPWSR48ulY_7DNCZA_c85VMMS8",
		"VITE_SUPABASE_URL": "https://hywynexgmdtpeqpuwjir.supabase.co"
	}["GEMINI_API_KEY"] || "";
	if (!apiKey) return {
		items: categoryFilter && categoryFilter !== "All" ? FALLBACK_EXAM_NEWS.filter((item) => item.category === categoryFilter) : FALLBACK_EXAM_NEWS,
		source: "cached"
	};
	try {
		const prompt = `You are an expert educational counselor in India. Return the latest 6 exam news updates and notifications for entrance and competitive exams in India for students in 2026/2027 (e.g. UPSC, GATE, JEE Main, NEET, SSC CGL, IBPS PO, ISRO, NDA, CAT).
Return ONLY a valid JSON array of objects without any markdown text or codeblocks around it, matching this JSON schema:
[
  {
    "id": "string",
    "title": "string",
    "shortName": "string",
    "category": "Engineering" | "Medical" | "Civil Services" | "Banking" | "Defense" | "Management",
    "status": "Registration Open" | "Upcoming" | "Admit Card Released" | "Results Declared",
    "date": "string",
    "eligibility": "string",
    "summary": "string",
    "highlights": ["string", "string", "string"],
    "officialUrl": "string",
    "lastUpdated": "Live AI update"
  }
]`;
		const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`;
		const response = await fetch(url, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({
				contents: [{ parts: [{ text: prompt }] }],
				generationConfig: { responseMimeType: "application/json" }
			})
		});
		if (!response.ok) throw new Error(`Gemini API error status: ${response.status}`);
		const textResult = (await response.json())?.candidates?.[0]?.content?.parts?.[0]?.text;
		if (textResult) {
			const parsed = JSON.parse(textResult);
			return {
				items: categoryFilter && categoryFilter !== "All" ? parsed.filter((item) => item.category === categoryFilter) : parsed,
				source: "ai"
			};
		}
	} catch (err) {
		console.warn("Failed to fetch live Gemini exam news, using verified cache:", err);
	}
	return {
		items: categoryFilter && categoryFilter !== "All" ? FALLBACK_EXAM_NEWS.filter((item) => item.category === categoryFilter) : FALLBACK_EXAM_NEWS,
		source: "cached"
	};
}
var CATEGORIES = [
	"All",
	"Engineering",
	"Medical",
	"Civil Services",
	"Banking",
	"Defense",
	"Management"
];
function ExamNewsSection() {
	const [selectedCategory, setSelectedCategory] = (0, import_react.useState)("All");
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [news, setNews] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [isAiPowered, setIsAiPowered] = (0, import_react.useState)(false);
	const [selectedExam, setSelectedExam] = (0, import_react.useState)(null);
	const loadExamNews = async (cat) => {
		setLoading(true);
		const result = await fetchGeminiExamNews(cat);
		setNews(result.items);
		setIsAiPowered(result.source === "ai");
		setLoading(false);
	};
	(0, import_react.useEffect)(() => {
		loadExamNews(selectedCategory);
	}, [selectedCategory]);
	const filteredNews = news.filter((item) => {
		const query = searchQuery.toLowerCase().trim();
		if (!query) return true;
		return item.title.toLowerCase().includes(query) || item.shortName.toLowerCase().includes(query) || item.category.toLowerCase().includes(query) || item.summary.toLowerCase().includes(query);
	});
	const getStatusBadge = (status) => {
		switch (status) {
			case "Registration Open": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[11px] font-semibold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/25",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-emerald-500 animate-pulse" }), status]
			});
			case "Admit Card Released": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[11px] font-semibold bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/25",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-amber-500 animate-pulse" }), status]
			});
			case "Results Declared": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[11px] font-semibold bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/25",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-blue-500" }), status]
			});
			default: return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[11px] font-semibold bg-secondary text-secondary-foreground border border-border",
				children: status
			});
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "exam-news",
		className: "mx-auto max-w-6xl px-4 py-16 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-4 md:flex-row md:items-end md:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "inline-flex items-center gap-2 rounded-full border border-primary/25 bg-primary/10 px-3.5 py-1 text-xs font-semibold text-primary backdrop-blur-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3.5 text-primary animate-pulse" }), "Gemini AI Live Updates"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 text-3xl font-extrabold sm:text-4xl text-foreground",
						children: "Recent Government & Entrance Exam News"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground sm:text-base max-w-2xl leading-relaxed",
						children: "Stay updated with real-time exam notifications, eligibility, key dates, and application portals across India."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					disabled: loading,
					onClick: () => loadExamNews(selectedCategory),
					className: "h-10 rounded-xl gap-2 border-border/80 bg-card/80 hover:bg-primary/10 hover:border-primary/40 hover:text-primary self-start md:self-auto cursor-pointer transition-all",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `size-4 text-primary ${loading ? "animate-spin" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: loading ? "Updating AI News..." : "Refresh News" })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center gap-2 overflow-x-auto pb-2 sm:pb-0 scrollbar-none",
					children: CATEGORIES.map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setSelectedCategory(cat),
						className: `shrink-0 rounded-xl px-4 py-2 text-xs font-semibold transition-all cursor-pointer ${selectedCategory === cat ? "gradient-brand text-primary-foreground shadow-glow scale-[1.02]" : "bg-card/85 hover:bg-accent text-muted-foreground hover:text-foreground border border-border/70 hover:border-primary/30"}`,
						children: cat
					}, cat))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative w-full sm:w-72 shrink-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3.5 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						placeholder: "Search exam, category...",
						value: searchQuery,
						onChange: (e) => setSearchQuery(e.target.value),
						className: "pl-10 h-10 rounded-xl bg-card/80 border-border/85 text-xs sm:text-sm"
					})]
				})]
			}),
			loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3",
				children: [
					1,
					2,
					3,
					4,
					5,
					6
				].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "animate-pulse rounded-2xl p-6 space-y-4 border-border/60 bg-card/50",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-5 bg-accent/60 rounded-full w-1/3" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-6 bg-accent/80 rounded-xl w-3/4" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-16 bg-accent/50 rounded-xl w-full" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 bg-accent/40 rounded-lg w-1/2" })
					]
				}, i))
			}) : filteredNews.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-12 text-center py-14 rounded-3xl bg-card/40 border border-dashed border-border/80",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "mx-auto size-10 text-muted-foreground/50" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-3 text-lg font-semibold text-foreground",
						children: "No exam news found"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: "Try clearing your search query or selecting another category."
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3",
				children: filteredNews.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "hover-lift glass group flex flex-col justify-between rounded-2xl p-6 border-border/80 transition-all hover:border-primary/40 h-full shadow-soft hover:shadow-elegant",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2 flex-wrap",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "outline",
								className: "text-[11px] font-semibold border-primary/20 bg-primary/5 text-primary",
								children: item.category
							}), getStatusBadge(item.status)]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-4 font-display text-lg font-bold text-foreground group-hover:text-primary transition-colors line-clamp-2 leading-snug",
							children: item.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2.5 text-xs leading-relaxed text-muted-foreground line-clamp-3",
							children: item.summary
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex items-center gap-2 text-xs text-muted-foreground border-t border-border/60 pt-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-3.5 text-primary shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "truncate",
								children: ["Exam Date: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-foreground font-semibold",
									children: item.date
								})]
							})]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex items-center justify-between pt-2 border-t border-border/40",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "ghost",
							size: "sm",
							onClick: () => setSelectedExam(item),
							className: "h-9 px-3 text-xs font-semibold text-primary hover:text-primary hover:bg-primary/10 rounded-xl cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "mr-1.5 size-3.5" }), "View Details & Syllabus"]
						}), item.officialUrl && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: item.officialUrl,
							target: "_blank",
							rel: "noreferrer",
							className: "p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-accent/80 transition-colors",
							title: "Official Website",
							"aria-label": "Official Website",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-4" })
						})]
					})]
				}, item.id))
			}),
			selectedExam && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog$1, {
				open: !!selectedExam,
				onOpenChange: () => setSelectedExam(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
					className: "max-w-xl rounded-3xl p-6 sm:p-8 bg-card/95 backdrop-blur-xl border-border",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 mb-2 flex-wrap",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "outline",
							className: "text-xs border-primary/30 text-primary",
							children: selectedExam.category
						}), getStatusBadge(selectedExam.status)]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
						className: "text-xl font-bold font-display text-foreground leading-tight",
						children: selectedExam.title
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 space-y-4 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl bg-accent/40 p-4 border border-border/70",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] font-bold text-muted-foreground uppercase tracking-wider",
									children: "Eligibility Criteria"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 font-medium text-foreground text-xs sm:text-sm leading-relaxed",
									children: selectedExam.eligibility
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] font-bold text-muted-foreground uppercase tracking-wider",
								children: "Overview"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 leading-relaxed text-muted-foreground text-xs sm:text-sm",
								children: selectedExam.summary
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] font-bold text-muted-foreground uppercase tracking-wider mb-2",
								children: "Key Highlights & Updates"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "space-y-2",
								children: selectedExam.highlights.map((hl, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-start gap-2.5 text-xs sm:text-sm text-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-1.5 size-1.5 rounded-full bg-primary shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "leading-relaxed",
										children: hl
									})]
								}, index))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "pt-4 border-t border-border/80 flex items-center justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs text-muted-foreground",
									children: ["Target Window: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "text-foreground",
										children: selectedExam.date
									})]
								}), selectedExam.officialUrl && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									className: "gradient-brand text-primary-foreground rounded-xl text-xs gap-1.5 shadow-glow hover:opacity-95",
									asChild: true,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: selectedExam.officialUrl,
										target: "_blank",
										rel: "noreferrer",
										children: ["Official Portal ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3.5" })]
									})
								})]
							})
						]
					})]
				})
			})
		]
	});
}
var features = [
	{
		icon: Brain,
		title: "AI Career Assessment",
		desc: "50 adaptive questions across interests, personality, reasoning and creativity."
	},
	{
		icon: Target,
		title: "Career Recommendations",
		desc: "Compatibility scores with salary, demand, skills and a step-by-step roadmap."
	},
	{
		icon: Landmark,
		title: "Government Exam Finder",
		desc: "UPSC, SSC, GATE, ISRO, RBI and more — eligibility, pattern and cutoffs."
	},
	{
		icon: CalendarCheck,
		title: "AI Study Planner",
		desc: "Daily, weekly and monthly plans that reschedule themselves when you miss a task."
	},
	{
		icon: Library,
		title: "Learning Resources",
		desc: "Curated books, videos, PDFs, mock tests and current affairs per exam."
	},
	{
		icon: Wallet,
		title: "Scholarship Finder",
		desc: "Matched to your state, income, category and marks with live deadlines."
	},
	{
		icon: GraduationCap,
		title: "College Recommendations",
		desc: "Government and private colleges with fees, placements and admission process."
	},
	{
		icon: FileText,
		title: "Resume Builder",
		desc: "Professional resume, CV and cover letter templates you can export as PDF."
	},
	{
		icon: MessageSquareHeart,
		title: "AI Career Chatbot",
		desc: "Ask anything — streams, eligibility, exams, scholarships — in your language."
	}
];
var stats = [
	{
		value: "100+",
		label: "Career paths"
	},
	{
		value: "20+",
		label: "Government exams"
	},
	{
		value: "50",
		label: "Assessment questions"
	},
	{
		value: "3",
		label: "Languages supported"
	}
];
var categories = [
	{
		icon: Brain,
		name: "Technology",
		roles: "AI Engineer · Cloud · Cyber Security"
	},
	{
		icon: GraduationCap,
		name: "Healthcare",
		roles: "Doctor · Physiotherapist · Nursing"
	},
	{
		icon: Briefcase,
		name: "Management",
		roles: "MBA · Product · Operations"
	},
	{
		icon: Landmark,
		name: "Civil Services",
		roles: "IAS · IPS · IFS"
	},
	{
		icon: Wallet,
		name: "Commerce",
		roles: "CA · CS · Economist"
	},
	{
		icon: FileText,
		name: "Law",
		roles: "Advocate · Patent Analyst"
	},
	{
		icon: Library,
		name: "Science & Research",
		roles: "ISRO · DRDO · Data Science"
	},
	{
		icon: MessageSquareHeart,
		name: "Creative & Media",
		roles: "Design · Journalism · Film"
	}
];
function Features() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "features",
		className: "mx-auto max-w-6xl px-4 py-16 sm:py-20 sm:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-2xl text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "inline-flex items-center gap-2 rounded-full border border-primary/25 bg-primary/10 px-4 py-1 text-xs font-semibold text-primary mb-3 backdrop-blur-xs",
					children: "Comprehensive Toolset"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-3xl font-extrabold sm:text-4xl text-foreground tracking-tight",
					children: "One platform for your entire journey"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm sm:text-base text-muted-foreground leading-relaxed",
					children: "From choosing the right stream after Class 10 to cracking premier competitive exams and building an ATS-ready resume."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3",
			children: features.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "hover-lift glass arch-accent overflow-hidden rounded-3xl p-6 border-border/80 hover:border-primary/40 group transition-all shadow-soft hover:shadow-elegant flex flex-col justify-between",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-start justify-between",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "gradient-brand grid size-12 place-items-center rounded-2xl text-primary-foreground shadow-glow group-hover:scale-105 transition-transform",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(f.icon, { className: "size-5" })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-5 text-base sm:text-lg font-bold text-foreground group-hover:text-primary transition-colors tracking-tight",
						children: f.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs sm:text-sm leading-relaxed text-muted-foreground",
						children: f.desc
					})
				] })
			}, f.title))
		})]
	});
}
function Stats() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "mx-auto max-w-6xl px-4 sm:px-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "gradient-brand shadow-elegant grain grid gap-4 sm:gap-6 rounded-3xl p-6 sm:p-10 grid-cols-2 lg:grid-cols-4 text-primary-foreground relative overflow-hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-white/5 backdrop-blur-[1px] pointer-events-none" }), stats.map((s, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `text-center relative z-10 p-3 sm:p-4 ${index !== 0 ? "lg:border-l lg:border-white/20" : ""}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-4xl sm:text-5xl font-black tracking-tight drop-shadow-xs",
					children: s.value
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs sm:text-sm font-semibold tracking-wide text-white/90",
					children: s.label
				})]
			}, s.label))]
		})
	});
}
function Categories() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "careers",
		className: "mx-auto max-w-6xl px-4 py-16 sm:py-20 sm:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-2xl text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "inline-flex items-center gap-2 rounded-full border border-primary/25 bg-primary/10 px-4 py-1 text-xs font-semibold text-primary mb-3 backdrop-blur-xs",
					children: "Domain Spectrum"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-3xl font-extrabold sm:text-4xl text-foreground tracking-tight",
					children: "Explore 8 High-Growth Domains"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm sm:text-base text-muted-foreground leading-relaxed",
					children: "Discover comprehensive career pathways, skill requirements, and compensation benchmarks tailored to India."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
			children: categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "hover-lift rounded-3xl border-border/75 bg-card/85 p-5 shadow-soft hover:border-primary/45 transition-all cursor-default group",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-11 place-items-center rounded-2xl bg-primary/10 text-primary border border-primary/20 group-hover:bg-primary group-hover:text-primary-foreground transition-colors",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(c.icon, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[11px] font-semibold text-primary opacity-0 group-hover:opacity-100 transition-opacity",
							children: "Explore →"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-4 font-bold text-base text-foreground group-hover:text-primary transition-colors",
						children: c.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1.5 text-xs leading-relaxed text-muted-foreground",
						children: c.roles
					})
				]
			}, c.name))
		})]
	});
}
var hero_career_default = "/assets/hero-career-D_dFKTNC.png";
var trustPoints = [
	"50-question adaptive assessment",
	"100+ career paths mapped",
	"20+ govt exams tracked",
	"Dual English & Hindi support"
];
function Hero() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden pt-8 pb-14 lg:pt-14 lg:pb-18",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gradient-soft absolute inset-0 -z-10 opacity-75" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "blueprint-grid absolute inset-0 -z-10 opacity-55" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -top-36 left-1/3 -z-10 size-[32rem] rounded-full bg-primary/15 blur-[120px] pointer-events-none" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -right-20 top-20 -z-10 size-[28rem] rounded-full bg-violet/15 blur-[100px] pointer-events-none" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-6xl items-center gap-10 px-4 sm:px-6 lg:grid-cols-2 lg:gap-14",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "animate-fade-up",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-xs font-semibold text-primary backdrop-blur-md shadow-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3.5 text-primary animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "AI Career & Exam Intelligence for Indian Students" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "mt-5 text-4xl leading-[1.12] font-extrabold tracking-tight sm:text-5xl lg:text-6xl text-foreground",
							children: ["Bridge your education to a ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-gradient",
								children: "Dream Career"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-xl text-sm leading-relaxed text-muted-foreground sm:text-base lg:text-lg",
							children: "Take our scientific AI career assessment, explore 100+ high-growth careers, track 20+ government exams, and receive adaptive daily study schedules — built specifically for Indian students."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-col gap-3.5 sm:flex-row sm:items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "lg",
								className: "gradient-brand h-12 rounded-xl px-7 text-sm sm:text-base font-semibold text-primary-foreground shadow-glow transition-all hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0 group cursor-pointer",
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/auth",
									search: { mode: "signup" },
									children: ["Start Free Assessment", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "ml-2 size-4 transition-transform duration-200 group-hover:translate-x-1" })]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "lg",
								variant: "outline",
								className: "h-12 rounded-xl border-border/85 bg-card/85 px-6 text-sm sm:text-base font-semibold backdrop-blur-xs hover:bg-accent hover:border-primary/40 hover:-translate-y-0.5 active:translate-y-0 transition-all cursor-pointer",
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: "#features",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "mr-2 size-4 text-primary" }), "Explore Features"]
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 pt-6 border-t border-border/70",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs text-muted-foreground",
								children: trustPoints.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center gap-2 rounded-xl bg-card/50 border border-border/60 px-3 py-2 shadow-2xs backdrop-blur-xs transition-colors hover:border-primary/30",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5 text-primary shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium text-foreground/90",
										children: t
									})]
								}, t))
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative animate-fade-up [animation-delay:120ms] flex justify-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative w-full max-w-md lg:max-w-none",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-4 -z-10 rounded-3xl bg-primary/20 blur-2xl opacity-60 pointer-events-none" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "animate-float",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: hero_career_default,
									alt: "CareerSetu AI guidance dashboard with charts, a compass and study material",
									width: 1280,
									height: 1024,
									className: "mx-auto w-full max-w-md lg:max-w-lg drop-shadow-2xl rounded-2xl border border-white/10"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "glass absolute -bottom-3 left-2 sm:-bottom-2 sm:left-4 rounded-2xl p-3.5 shadow-soft border border-border/80 backdrop-blur-xl transition-transform hover:-translate-y-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 mb-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-emerald-500 animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] font-medium text-muted-foreground",
											children: "Top Career Match"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-gradient font-display text-xl sm:text-2xl font-black leading-tight",
										children: "94% AI Match"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] text-muted-foreground font-semibold mt-0.5",
										children: "AI & Machine Learning"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "glass absolute top-2 right-2 sm:top-5 sm:right-3 rounded-2xl p-3 shadow-soft border border-border/80 backdrop-blur-xl transition-transform hover:-translate-y-1 block",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1.5 mb-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, { className: "size-3.5 text-amber-500 animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] font-medium text-muted-foreground",
											children: "Live Notification"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-xs font-bold text-foreground",
										children: "UPSC CSE 2027 Portal Open"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[9px] text-primary font-semibold mt-0.5 inline-block",
										children: "Updated 10m ago"
									})
								]
							})
						]
					})
				})]
			})
		]
	});
}
var Sheet = Dialog;
var SheetTrigger = DialogTrigger;
var SheetPortal = DialogPortal;
var SheetOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {
	className: cn("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props,
	ref
}));
SheetOverlay.displayName = DialogOverlay.displayName;
var sheetVariants = cva("fixed z-50 gap-4 bg-background p-6 shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500 data-[state=open]:animate-in data-[state=closed]:animate-out", {
	variants: { side: {
		top: "inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
		bottom: "inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
		left: "inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm",
		right: "inset-y-0 right-0 h-full w-3/4 border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right sm:max-w-sm"
	} },
	defaultVariants: { side: "right" }
});
var SheetContent = import_react.forwardRef(({ side = "right", className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
	ref,
	className: cn(sheetVariants({ side }), className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-secondary",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	}), children]
})] }));
SheetContent.displayName = DialogContent.displayName;
var SheetHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-2 text-center sm:text-left", className),
	...props
});
SheetHeader.displayName = "SheetHeader";
var SheetFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
SheetFooter.displayName = "SheetFooter";
var SheetTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
	ref,
	className: cn("text-lg font-semibold text-foreground", className),
	...props
}));
SheetTitle.displayName = DialogTitle.displayName;
var SheetDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
SheetDescription.displayName = DialogDescription.displayName;
var links = [
	{
		label: "Exam News",
		href: "#exam-news",
		icon: Landmark
	},
	{
		label: "Careers",
		href: "#careers",
		icon: Briefcase
	},
	{
		label: "Features",
		href: "#features",
		icon: Sparkles
	},
	{
		label: "Testimonials",
		href: "#testimonials",
		icon: Star
	},
	{
		label: "FAQ",
		href: "#faq",
		icon: CircleQuestionMark
	}
];
function ThemeToggle() {
	const [dark, setDark] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setDark(document.documentElement.classList.contains("dark"));
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		variant: "ghost",
		size: "icon",
		"aria-label": dark ? "Switch to light mode" : "Switch to dark mode",
		onClick: () => {
			const next = !dark;
			document.documentElement.classList.toggle("dark", next);
			setDark(next);
		},
		className: "rounded-xl size-9 text-muted-foreground hover:text-foreground transition-transform hover:scale-105",
		children: dark ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-4 text-amber-400" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-4 text-sky-500" })
	});
}
function Navbar() {
	const [sheetOpen, setSheetOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "sticky top-0 z-50 w-full px-3 sm:px-6 pt-3",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "glass mx-auto flex max-w-6xl items-center justify-between gap-4 rounded-2xl px-4 py-2 sm:px-6 shadow-soft transition-all border border-border/75 backdrop-blur-xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					"aria-label": "CareerSetu home",
					className: "shrink-0 transition-transform hover:scale-[1.02]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden items-center gap-1 lg:flex",
					children: links.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: l.href,
						className: "rounded-xl px-3.5 py-1.5 text-xs sm:text-sm font-medium text-muted-foreground transition-all duration-200 hover:bg-primary/10 hover:text-primary active:scale-98",
						children: l.label
					}, l.href))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeToggle, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "sm",
							className: "hidden sm:inline-flex rounded-xl text-xs font-semibold hover:bg-primary/10 hover:text-primary transition-all",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/student/login",
								children: "Log in"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							className: "gradient-brand hidden text-primary-foreground shadow-glow hover:opacity-95 hover:shadow-lg sm:inline-flex rounded-xl font-semibold text-xs h-9 px-4 transition-all hover:-translate-y-0.5 active:translate-y-0 cursor-pointer",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/auth",
								search: { mode: "signup" },
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3.5 mr-1.5" }), "Get started"]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
							open: sheetOpen,
							onOpenChange: setSheetOpen,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTrigger, {
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									"aria-label": "Open menu",
									className: "lg:hidden rounded-xl size-9 hover:bg-accent/80",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
								side: "right",
								className: "w-80 rounded-l-3xl p-6 bg-card/95 backdrop-blur-xl border-border flex flex-col justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetTitle, {
									className: "text-left font-display font-bold text-lg flex items-center gap-2 pb-4 border-b border-border/60",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "gradient-brand size-8 rounded-xl grid place-items-center text-primary-foreground shadow-glow",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4" })
									}), "CareerSetu Menu"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
									className: "mt-5 flex flex-col gap-1.5",
									children: links.map((l) => {
										const Icon = l.icon;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
											href: l.href,
											onClick: () => setSheetOpen(false),
											className: "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all hover:bg-accent/80 hover:text-primary text-foreground group",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "size-8 rounded-lg bg-primary/10 grid place-items-center text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: l.label })]
										}, l.href);
									})
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "pt-5 border-t border-border/70 flex flex-col gap-2.5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "outline",
											className: "w-full rounded-xl justify-start gap-2 h-10 border-border/80",
											asChild: true,
											onClick: () => setSheetOpen(false),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
												to: "/student/login",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogIn, { className: "size-4 text-primary" }), "Student Sign In"]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											className: "gradient-brand w-full text-primary-foreground rounded-xl shadow-glow justify-start gap-2 h-10 hover:opacity-95",
											asChild: true,
											onClick: () => setSheetOpen(false),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
												to: "/auth",
												search: { mode: "signup" },
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "size-4" }), "Create Free Account"]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
											to: "/admin/login",
											onClick: () => setSheetOpen(false),
											className: "flex items-center justify-center gap-1.5 pt-2 text-[11px] text-muted-foreground hover:text-amber-500 transition-colors",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-3 text-amber-500" }), "Administrator Gateway"]
										})
									]
								})]
							})]
						})
					]
				})
			]
		})
	});
}
var Accordion = Root2;
var AccordionItem = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
	ref,
	className: cn("border-b", className),
	...props
}));
AccordionItem.displayName = "AccordionItem";
var AccordionTrigger = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {
	className: "flex",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Trigger2, {
		ref,
		className: cn("flex flex-1 items-center justify-between py-4 text-sm font-medium cursor-pointer transition-all hover:underline text-left [&[data-state=open]>svg]:rotate-180", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-4 w-4 shrink-0 text-muted-foreground transition-transform duration-200" })]
	})
}));
AccordionTrigger.displayName = Trigger2.displayName;
var AccordionContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	className: "overflow-hidden text-sm data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down",
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("pb-4 pt-0", className),
		children
	})
}));
AccordionContent.displayName = Content2.displayName;
var testimonials = [
	{
		quote: "I was confused between BSc IT and Diploma. The assessment showed a 94% match with Cloud Engineering and gave me a clear roadmap.",
		name: "Aditi Kulkarni",
		meta: "Class 12 · Pune",
		rating: 5,
		domain: "Technology",
		avatarColor: "from-violet-500 to-primary"
	},
	{
		quote: "The study planner rebuilt my schedule every time I missed a day. I finally cleared SSC CGL Tier 1 in my second attempt.",
		name: "Rahul Verma",
		meta: "Graduate · Lucknow",
		rating: 5,
		domain: "Civil Services",
		avatarColor: "from-primary to-sky-400"
	},
	{
		quote: "Scholarship finder alone saved my year — it matched three Maharashtra scholarships I never knew existed and I got all three.",
		name: "Sneha Patil",
		meta: "Diploma · Nashik",
		rating: 5,
		domain: "Scholarships",
		avatarColor: "from-emerald-500 to-teal-400"
	}
];
var faqs = [
	{
		q: "Who is CareerSetu for?",
		a: "Students after Class 10, Class 12, Diploma, Graduation and Post Graduation who want clarity on careers, streams and government exams."
	},
	{
		q: "How does the AI Career Assessment work?",
		a: "You answer 50 adaptive questions across interests, personality, reasoning and creativity. We then generate interest scores, a personality summary, your learning style and top career matches."
	},
	{
		q: "Which government exams are covered?",
		a: "UPSC, SSC CGL and CHSL, MPSC, GATE, DRDO, ISRO, RBI Grade B, SEBI, NABARD, RRB, IB ACIO, CDS, AFCAT, CAPF, ESIC and major PSU recruitments."
	},
	{
		q: "Is it available in Hindi and Marathi?",
		a: "Yes. You pick your preferred language — English, Hindi or Marathi — while creating your account."
	},
	{
		q: "Do I need to pay to start?",
		a: "No. The career assessment, career explorer and exam finder are free to start with."
	}
];
function Testimonials() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "testimonials",
		className: "relative overflow-hidden py-18 sm:py-24",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gradient-soft absolute inset-0 -z-10 opacity-60" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-4 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-2xl text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "inline-flex items-center gap-2 rounded-full border border-primary/25 bg-primary/10 px-4 py-1 text-xs font-semibold text-primary mb-3 backdrop-blur-xs",
						children: "Student Stories"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 text-3xl font-extrabold sm:text-4xl text-foreground tracking-tight",
						children: "Guidance that changed decisions"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm sm:text-base text-muted-foreground leading-relaxed",
						children: "Real students, real results — from career clarity to exam success."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12 grid gap-6 lg:grid-cols-3",
				children: testimonials.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "hover-lift glass arch-accent rounded-3xl p-6 sm:p-7 flex flex-col justify-between border-border/80 hover:border-primary/40 transition-all shadow-soft hover:shadow-elegant",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-center gap-1 mb-4",
							children: Array.from({ length: t.rating }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "size-4 fill-amber-400 text-amber-400" }, i))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative mb-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute -top-3 -left-1 font-display text-5xl text-gradient opacity-20 leading-none select-none pointer-events-none",
								children: "“"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "relative text-xs sm:text-sm leading-relaxed text-foreground font-medium pl-3.5",
								children: t.quote
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 pt-4 border-t border-border/60",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `grid size-10 shrink-0 place-items-center rounded-2xl bg-gradient-to-br ${t.avatarColor} text-white font-bold text-sm shadow-sm`,
									children: t.name.charAt(0)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-bold text-sm text-foreground truncate",
										children: t.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground truncate",
										children: t.meta
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-auto text-[10px] font-semibold px-2.5 py-0.5 rounded-full bg-primary/10 text-primary border border-primary/20 shrink-0",
									children: t.domain
								})
							]
						})
					]
				}, t.name))
			})]
		})]
	});
}
function Faq() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "faq",
		className: "mx-auto max-w-3xl px-4 py-16 sm:py-20 sm:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "inline-flex items-center gap-2 rounded-full border border-primary/25 bg-primary/10 px-4 py-1 text-xs font-semibold text-primary mb-3 backdrop-blur-xs",
					children: "FAQ"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 text-3xl font-extrabold sm:text-4xl text-foreground tracking-tight",
					children: "Questions students ask"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted-foreground leading-relaxed",
					children: "Everything you need to know before getting started."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Accordion, {
			type: "single",
			collapsible: true,
			className: "mt-10 space-y-3",
			children: faqs.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionItem, {
				value: f.q,
				className: "border border-border/80 rounded-2xl px-5 bg-card/80 data-[state=open]:bg-card data-[state=open]:border-primary/40 data-[state=open]:shadow-soft transition-all",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionTrigger, {
					className: "text-left text-sm font-bold py-4 hover:no-underline text-foreground cursor-pointer",
					children: f.q
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionContent, {
					className: "text-xs sm:text-sm leading-relaxed text-muted-foreground pb-4",
					children: f.a
				})]
			}, f.q))
		})]
	});
}
function CtaBand() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "mx-auto max-w-6xl px-4 pb-20 sm:px-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "gradient-brand shadow-elegant grain overflow-hidden rounded-[2.5rem] px-6 py-14 text-center sm:px-12 relative border border-white/10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-0 right-0 size-56 rounded-full bg-white/10 blur-3xl pointer-events-none" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute bottom-0 left-0 size-40 rounded-full bg-black/15 blur-2xl pointer-events-none" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative z-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "inline-flex items-center gap-2 rounded-full bg-white/15 border border-white/20 px-4 py-1.5 text-xs font-semibold text-white/95 mb-5 backdrop-blur-sm shadow-xs",
							children: "✨ Start Free — No Credit Card Required"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-3xl font-extrabold text-primary-foreground sm:text-4xl tracking-tight",
							children: "Your career deserves a plan, not a guess"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mx-auto mt-4 max-w-xl text-primary-foreground/90 text-sm sm:text-base leading-relaxed",
							children: "Start the AI assessment and get your match score, exam shortlist and study plan in minutes."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-col sm:flex-row items-center justify-center gap-3.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "lg",
								variant: "secondary",
								className: "h-12 rounded-xl px-8 text-sm sm:text-base font-bold shadow-lg hover:scale-[1.02] active:scale-100 transition-all cursor-pointer bg-white text-foreground hover:bg-white/95",
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/auth",
									search: { mode: "signup" },
									children: "Start Career Assessment →"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "lg",
								variant: "ghost",
								className: "h-12 rounded-xl px-7 text-sm sm:text-base font-semibold text-primary-foreground/90 hover:text-primary-foreground hover:bg-white/15 transition-colors cursor-pointer border border-white/20",
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/student/login",
									children: "Sign In"
								})
							})]
						})
					]
				})
			]
		})
	});
}
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "border-t border-border bg-card/60",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-10 px-4 py-14 sm:px-6 lg:grid-cols-[1.4fr_repeat(3,1fr)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-sm text-sm leading-relaxed text-muted-foreground",
					children: "AI career and government exam guidance built for Indian students — from Class 10 to Post Graduation."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 flex items-center gap-2",
					children: [
						{
							icon: Twitter,
							label: "Twitter"
						},
						{
							icon: Linkedin,
							label: "LinkedIn"
						},
						{
							icon: Github,
							label: "GitHub"
						},
						{
							icon: Mail,
							label: "Email"
						}
					].map(({ icon: Icon, label }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "#",
						className: "grid size-9 place-items-center rounded-xl bg-accent/60 text-muted-foreground hover:bg-primary/10 hover:text-primary border border-border/60 transition-all",
						"aria-label": label,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
					}, label))
				})
			] }), [
				{
					title: "Platform",
					items: [
						{
							label: "Career Assessment",
							href: "#features"
						},
						{
							label: "Career Explorer",
							href: "#careers"
						},
						{
							label: "Government Exams",
							href: "#exam-news"
						},
						{
							label: "Study Planner",
							href: "#features"
						}
					]
				},
				{
					title: "Resources",
					items: [
						{
							label: "Scholarships",
							href: "#features"
						},
						{
							label: "Colleges",
							href: "#features"
						},
						{
							label: "Learning Resources",
							href: "#features"
						},
						{
							label: "Resume Builder",
							href: "#features"
						}
					]
				},
				{
					title: "Company",
					items: [
						{
							label: "About",
							href: "#"
						},
						{
							label: "Contact",
							href: "#"
						},
						{
							label: "Privacy Policy",
							href: "#"
						},
						{
							label: "Terms of Service",
							href: "#"
						}
					]
				}
			].map((col) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				"aria-label": col.title,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-semibold text-foreground",
					children: col.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 space-y-2.5 text-sm text-muted-foreground",
					children: col.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: item.href,
						className: "transition-colors hover:text-foreground hover:underline underline-offset-2",
						children: item.label
					}) }, item.label))
				})]
			}, col.title))]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-border py-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl flex-col sm:flex-row items-center justify-between gap-3 px-4 sm:px-6 text-xs text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"© ",
					(/* @__PURE__ */ new Date()).getFullYear(),
					" CareerSetu. Made with ❤️ for Indian students."
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#",
							className: "hover:text-foreground transition-colors",
							children: "Privacy"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#",
							className: "hover:text-foreground transition-colors",
							children: "Terms"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "/admin/login",
							className: "hover:text-amber-500 transition-colors",
							children: "Admin Portal"
						})
					]
				})]
			})
		})]
	});
}
function Index() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navbar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stats, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExamNewsSection, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Features, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Categories, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Testimonials, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Faq, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaBand, {})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	});
}
//#endregion
export { Index as component };
