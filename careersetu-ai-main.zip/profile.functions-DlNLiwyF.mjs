import { c as createServerFn } from "./createServerFn-CIHAFgYl.mjs";
import { t as createServerRpc } from "./createServerRpc-B90ckaqP.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-BpbeoxIM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profile.functions-DlNLiwyF.js
var getMyProfile_createServerFn_handler = createServerRpc({
	id: "5dbf46616266e7bfe81c82694a91090a42de6200b3efc1b9d156faf41ac3a479",
	name: "getMyProfile",
	filename: "src/lib/profile.functions.ts"
}, (opts) => getMyProfile.__executeServer(opts));
var getMyProfile = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(getMyProfile_createServerFn_handler, async ({ context }) => {
	const { data, error } = await context.supabase.from("profiles").select("id, full_name, phone, age, gender, state, city, current_education, preferred_language").eq("id", context.userId).maybeSingle();
	if (error) throw error;
	return data;
});
//#endregion
export { getMyProfile_createServerFn_handler };
