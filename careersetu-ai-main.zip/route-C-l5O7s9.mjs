import { i as __toESM } from "../_runtime.mjs";
import { f as Outlet, g as Link, l as useLocation, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { S as isAdmin, h as getCurrentUser, w as logoutUser } from "./rbac-D_Rf6U5V.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { n as cn, t as Card } from "./card-95-PmP7N.mjs";
import { t as Badge } from "./badge-BYEzUON3.mjs";
import { t as Button } from "./button-CdcMTBqt.mjs";
import { At as Bell, B as LoaderCircle, C as Search, Dt as Bot, G as Landmark, J as House, L as LogOut, M as Moon, Mt as ArrowRight, Ot as Bookmark, P as Menu, S as Send, T as RotateCcw, Tt as Briefcase, X as GraduationCap, Z as Globe, _ as Shield, _t as ChevronRight, b as Settings, d as TrendingUp, et as FileText, g as Sparkles, it as ExternalLink, kt as BookOpen, m as Sun, n as X, o as User, ot as Copy, p as Target, t as Zap, ut as Circle, wt as Building2, x as Settings2, xt as Calendar, yt as Check } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, n as DialogContent, o as DialogTitle, t as Dialog } from "./dialog-d9GHmrLL.mjs";
import { t as Input } from "./input-D7UBWI0-.mjs";
import { a as Label2, c as Root2, d as SubTrigger2, f as Trigger, i as ItemIndicator2, l as Separator2, n as Content2, o as Portal2, r as Item2, s as RadioItem2, t as CheckboxItem2, u as SubContent2 } from "../_libs/@radix-ui/react-dropdown-menu+[...].mjs";
import { a as getManagedColleges, c as getManagedResources, i as getManagedCareers, l as getManagedScholarships, o as getManagedExams, r as getBroadcastNotifications } from "./admin-content-store-CcAL24zG.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Logo } from "./Logo-CGI7av7x.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-BfMpEmcB.mjs";
import { t as supabase } from "./client-DVcAC_2T.mjs";
import { r as useQueryClient } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/route-C-l5O7s9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SYSTEM_PROMPT = `You are CareerSetu AI, an expert, encouraging, and highly knowledgeable AI career counselor, education advisor, and mentor for students and professionals in India and globally.
Provide clear, actionable, well-structured answers using bold headings, bullet points, clean numbers, and real-world examples.
Explain complex concepts (like LPA, CTC, exam patterns, top colleges, software career roadmaps, college selection) simply and thoroughly.`;
async function askCareerSetuAI(userQuery, config) {
	const query = userQuery.trim();
	if (!query) return {
		text: "Please provide a question.",
		source: "system"
	};
	const storedGeminiKey = typeof localStorage !== "undefined" ? localStorage.getItem("careersetu_gemini_api_key") || "" : "";
	const storedGroqKey = typeof localStorage !== "undefined" ? localStorage.getItem("careersetu_groq_api_key") || "" : "";
	const storedOpenAIKey = typeof localStorage !== "undefined" ? localStorage.getItem("careersetu_openai_api_key") || "" : "";
	const activeProvider = config?.provider || (typeof localStorage !== "undefined" ? localStorage.getItem("careersetu_ai_provider") || "auto" : "auto");
	const geminiApiKey = config?.geminiKey || storedGeminiKey || {
		"BASE_URL": "/",
		"DEV": false,
		"MODE": "production",
		"PROD": true,
		"SSR": true,
		"TSS_DEV_SERVER": "false",
		"TSS_DEV_SSR_STYLES_BASEPATH": "/",
		"TSS_DEV_SSR_STYLES_ENABLED": "true",
		"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
		"TSS_INLINE_CSS_ENABLED": "false",
		"TSS_ROUTER_BASEPATH": "",
		"TSS_SERVER_FN_BASE": "/_serverFn/",
		"VITE_GOOGLE_CLIENT_ID": "781343883716-k395k1cpf5ehccrardlrt2kj33m9qk06.apps.googleusercontent.com",
		"VITE_SUPABASE_PROJECT_ID": "hywynexgmdtpeqpuwjir",
		"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_9sNJVlPWSR48ulY_7DNCZA_c85VMMS8",
		"VITE_SUPABASE_URL": "https://hywynexgmdtpeqpuwjir.supabase.co"
	}["VITE_GEMINI_API_KEY"] || {
		"BASE_URL": "/",
		"DEV": false,
		"MODE": "production",
		"PROD": true,
		"SSR": true,
		"TSS_DEV_SERVER": "false",
		"TSS_DEV_SSR_STYLES_BASEPATH": "/",
		"TSS_DEV_SSR_STYLES_ENABLED": "true",
		"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
		"TSS_INLINE_CSS_ENABLED": "false",
		"TSS_ROUTER_BASEPATH": "",
		"TSS_SERVER_FN_BASE": "/_serverFn/",
		"VITE_GOOGLE_CLIENT_ID": "781343883716-k395k1cpf5ehccrardlrt2kj33m9qk06.apps.googleusercontent.com",
		"VITE_SUPABASE_PROJECT_ID": "hywynexgmdtpeqpuwjir",
		"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_9sNJVlPWSR48ulY_7DNCZA_c85VMMS8",
		"VITE_SUPABASE_URL": "https://hywynexgmdtpeqpuwjir.supabase.co"
	}["GEMINI_API_KEY"] || "";
	if (activeProvider === "gemini" || geminiApiKey && activeProvider === "auto") {
		if (geminiApiKey) try {
			for (const model of [
				"gemini-2.5-flash",
				"gemini-1.5-flash",
				"gemini-2.0-flash"
			]) {
				const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${geminiApiKey}`, {
					method: "POST",
					headers: { "Content-Type": "application/json" },
					body: JSON.stringify({ contents: [{ parts: [{ text: `${SYSTEM_PROMPT}\n\nUser Question: ${query}` }] }] })
				});
				if (res.ok) {
					const reply = (await res.json())?.candidates?.[0]?.content?.parts?.[0]?.text;
					if (reply) return {
						text: reply,
						source: `Google Gemini (${model})`
					};
				}
			}
		} catch (e) {
			console.warn("Gemini API call failed, falling back:", e);
		}
	}
	const groqApiKey = config?.groqKey || storedGroqKey;
	if (activeProvider === "groq" || groqApiKey && activeProvider === "auto") {
		if (groqApiKey) try {
			const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					Authorization: `Bearer ${groqApiKey}`
				},
				body: JSON.stringify({
					model: config?.modelName || "llama-3.3-70b-versatile",
					messages: [{
						role: "system",
						content: SYSTEM_PROMPT
					}, {
						role: "user",
						content: query
					}],
					temperature: .7
				})
			});
			if (res.ok) {
				const reply = (await res.json())?.choices?.[0]?.message?.content;
				if (reply) return {
					text: reply,
					source: "Groq (Llama 3.3 70B)"
				};
			}
		} catch (e) {
			console.warn("Groq API call failed:", e);
		}
	}
	const openaiApiKey = config?.openaiKey || storedOpenAIKey;
	if (openaiApiKey) try {
		const endpoint = config?.openaiEndpoint || (typeof localStorage !== "undefined" ? localStorage.getItem("careersetu_openai_endpoint") || "https://api.openai.com/v1/chat/completions" : "https://api.openai.com/v1/chat/completions");
		const res = await fetch(endpoint, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${openaiApiKey}`
			},
			body: JSON.stringify({
				model: config?.modelName || "gpt-4o-mini",
				messages: [{
					role: "system",
					content: SYSTEM_PROMPT
				}, {
					role: "user",
					content: query
				}]
			})
		});
		if (res.ok) {
			const reply = (await res.json())?.choices?.[0]?.message?.content;
			if (reply) return {
				text: reply,
				source: "OpenAI / Custom LLM"
			};
		}
	} catch (e) {
		console.warn("Custom OpenAI API failed:", e);
	}
	if (typeof window !== "undefined" && window.puter?.ai) try {
		const puterRes = await window.puter.ai.chat(`${SYSTEM_PROMPT}\n\nQuestion: ${query}`, { model: "gpt-4o-mini" });
		let textOutput = "";
		if (typeof puterRes === "string") textOutput = puterRes;
		else if (puterRes?.message?.content) textOutput = puterRes.message.content;
		if (textOutput && textOutput.length > 20) return {
			text: textOutput,
			source: "CareerSetu Neural AI"
		};
	} catch (err) {
		console.info("Puter AI unavailable, fallback to knowledge engine:", err);
	}
	return {
		text: await getSmartDomainResponse(query),
		source: "CareerSetu Knowledge Engine"
	};
}
async function getSmartDomainResponse(rawQuery) {
	const q = rawQuery.toLowerCase().trim();
	if (q.includes("bsc it") || q.includes("bsc information technology") || q.includes("bsc") && q.includes("it") && (q.includes("college") || q.includes("top") || q.includes("best"))) return `### Top 10 Colleges for B.Sc. IT (Information Technology) in India

B.Sc. IT (Bachelor of Science in Information Technology) is a popular 3-year undergraduate program focusing on software development, database management, networking, and web applications.

---

### 🏛️ Top 10 B.Sc. IT Colleges in India (Ranked):

| Rank | College / University | Location | Admission Criteria | Approx. Annual Fee |
| :--- | :--- | :--- | :--- | :--- |
| **1** | **St. Xavier's College** | Mumbai, Maharashtra | Merit / Entrance (12th PCM) | ₹35,000 - ₹50,000 |
| **2** | **Loyola College** | Chennai, Tamil Nadu | Merit Based (12th Marks) | ₹40,000 - ₹60,000 |
| **3** | **Christ University** (Central Campus) | Bangalore, Karnataka | CUET / Skill Assessment | ₹1,20,000 - ₹1,60,000 |
| **4** | **Fergusson College** | Pune, Maharashtra | Merit / SPPU Norms | ₹45,000 - ₹70,000 |
| **5** | **Madras Christian College (MCC)** | Chennai, Tamil Nadu | Merit Based | ₹35,000 - ₹55,000 |
| **6** | **Mithibai College** (SVKM) | Mumbai, Maharashtra | Merit / Mumbai University | ₹40,000 - ₹65,000 |
| **7** | **Jai Hind College** | Mumbai, Maharashtra | Common Entrance Test (CET) | ₹45,000 - ₹70,000 |
| **8** | **Stella Maris College** | Chennai, Tamil Nadu | Merit Based | ₹30,000 - ₹50,000 |
| **9** | **Mount Carmel College** | Bangalore, Karnataka | Merit + Interview | ₹80,000 - ₹1,20,000 |
| **10**| **PSG College of Arts and Science** | Coimbatore, Tamil Nadu| Merit Based | ₹35,000 - ₹55,000 |

---

### 📋 Eligibility Criteria:
- Passed **Class 12 (Higher Secondary)** from a recognized board (CBSE/ISC/State Board).
- **Mandatory Subject:** Mathematics or Statistics with minimum 45-50% aggregate marks.

---

### 💼 Career Opportunities & Salary Packages:
- **Top Job Roles:** Software Developer, Cloud Associate, Database Administrator, Web Developer, IT Analyst, Quality Assurance (QA) Engineer.
- **Top Recruiters:** TCS, Infosys, Wipro, Cognizant, Deloitte, Accenture, Capgemini, Tech Mahindra.
- **Starting Salary:** **₹3.5 LPA - ₹6.5 LPA** (Can scale to ₹15+ LPA after MCA, MSc IT, or with DSA skills).

---

### 🚀 Recommended Higher Study Paths:
1. **MCA (Master of Computer Applications):** Upgrades your profile to equivalent of B.Tech CSE for Tier 1 product companies.
2. **M.Sc. in Data Science / AI / IT:** For specialized research, machine learning, and analytics careers.
3. **MBA in IT / Systems:** For Product Management, Business Analysis, and IT Consulting.`;
	if (q.includes("bca") && (q.includes("college") || q.includes("top") || q.includes("best") || q.includes("admission"))) return `### Top 10 BCA (Bachelor of Computer Applications) Colleges in India

BCA is a premier 3-year professional course focused on computer applications, software engineering, and programming languages.

---

### 🏛️ Top 10 BCA Colleges in India:

| Rank | College / Institute | City | Admission Process | Approx. Fees / Year |
| :--- | :--- | :--- | :--- | :--- |
| **1** | **Christ University** | Bangalore | Entrance Test + PI | ₹1,50,000 |
| **2** | **Symbiosis Institute of Computer Studies (SICSR)** | Pune | SET Entrance Exam | ₹1,95,000 |
| **3** | **Loyola College** | Chennai | 12th Merit | ₹55,000 |
| **4** | **St. Joseph's University** | Bangalore | Merit + Interview | ₹90,000 |
| **5** | **Madras Christian College (MCC)** | Chennai | 12th Merit | ₹45,000 |
| **6** | **Stella Maris College** | Chennai | 12th Merit | ₹40,000 |
| **7** | **Presidency College** | Bangalore | Merit / Interview | ₹85,000 |
| **8** | **Vellore Institute of Technology (VIT)** | Vellore | 12th Merit Based | ₹1,40,000 |
| **9** | **IMS Noida** | Noida (NCR) | JET Entrance Exam | ₹1,30,000 |
| **10**| **Maharaja Surajmal Institute (MSI - IPU)** | New Delhi | IPU CET / CUET | ₹95,000 |

---

### 💡 Career Prospects:
- **Average Starting Salary:** ₹3.6 LPA - ₹7.0 LPA.
- **Top Pathways:** Full Stack Web Development, Software Engineering, MCA, or Cloud Engineering.`;
	if ((q.includes("engineering") || q.includes("btech") || q.includes("b.tech") || q.includes("iit") || q.includes("nit")) && (q.includes("college") || q.includes("top") || q.includes("best"))) return `### Top 10 Engineering (B.Tech) Colleges in India (NIRF Ranked)

---

### 🏛️ Premier Engineering Institutions:

| Rank | College / Institute | Location | Key Entrance Exam | Median Placement Package |
| :--- | :--- | :--- | :--- | :--- |
| **1** | **IIT Madras** | Chennai, TN | JEE Advanced | ₹21.5 LPA |
| **2** | **IIT Delhi** | New Delhi | JEE Advanced | ₹22.0 LPA |
| **3** | **IIT Bombay** | Mumbai, MH | JEE Advanced | ₹23.5 LPA |
| **4** | **IIT Kanpur** | Kanpur, UP | JEE Advanced | ₹20.0 LPA |
| **5** | **IIT Kharagpur** | Kharagpur, WB | JEE Advanced | ₹19.5 LPA |
| **6** | **IIT Roorkee** | Roorkee, UK | JEE Advanced | ₹18.5 LPA |
| **7** | **IIT Guwahati** | Guwahati, AS | JEE Advanced | ₹18.0 LPA |
| **8** | **BITS Pilani** (Pilani/Goa/Hyd) | Pilani, RJ | BITSAT | ₹19.0 LPA |
| **9** | **NIT Trichy** | Tiruchirappalli, TN | JEE Main | ₹15.5 LPA |
| **10**| **IIIT Hyderabad** | Hyderabad, TS | JEE Main / UGEE | ₹30.0+ LPA (CSE) |

---

### 🎯 Key Branches in High Demand:
1. **Computer Science & Engineering (CSE) / AI & Data Science:** Highest packages (₹18 - ₹55+ LPA).
2. **Electronics & Communication (ECE):** Semiconductor & VLSI design boom.
3. **Mechanical / Electrical:** EV industry and robotics automation.`;
	if ((q.includes("mba") || q.includes("iim") || q.includes("management")) && (q.includes("college") || q.includes("top") || q.includes("best"))) return `### Top 10 MBA / Management Colleges in India

---

### 🏛️ Top Business Schools:

| Rank | B-School | Location | Primary Exam | Average Salary Package |
| :--- | :--- | :--- | :--- | :--- |
| **1** | **IIM Ahmedabad** | Ahmedabad, Gujarat | CAT | **₹34.5 LPA** |
| **2** | **IIM Bangalore** | Bangalore, Karnataka | CAT | **₹35.3 LPA** |
| **3** | **IIM Calcutta** | Kolkata, West Bengal | CAT | **₹35.0 LPA** |
| **4** | **FMS Delhi** (Faculty of Mgmt Studies) | New Delhi | CAT (ROI King! Fee: ₹2L) | **₹34.1 LPA** |
| **5** | **XLRI Jamshedpur** | Jamshedpur, Jharkhand | XAT | **₹32.7 LPA** |
| **6** | **IIM Lucknow** | Lucknow, UP | CAT | **₹32.2 LPA** |
| **7** | **IIM Kozhikode** | Kozhikode, Kerala | CAT | **₹31.0 LPA** |
| **8** | **SPJIMR** | Mumbai, Maharashtra | CAT / XAT | **₹33.0 LPA** |
| **9** | **IIM Indore** | Indore, MP | CAT | **₹30.2 LPA** |
| **10**| **JBIMS** (Jamnalal Bajaj) | Mumbai, Maharashtra | MAH CET / CAT | **₹28.0 LPA** |`;
	if ((q.includes("mbbs") || q.includes("medical") || q.includes("doctor")) && (q.includes("college") || q.includes("top") || q.includes("best"))) return `### Top 10 Medical Colleges (MBBS) in India (NIRF Rankings)

---

### 🏛️ Top Medical Colleges:

| Rank | Institute | Location | Entrance Exam | Total MBBS Seats |
| :--- | :--- | :--- | :--- | :--- |
| **1** | **AIIMS New Delhi** | New Delhi | NEET UG (AIR 1-50) | 125 |
| **2** | **Post Graduate Institute (PGIMER)** | Chandigarh | NEET PG / INI-CET | Post-Grad |
| **3** | **Christian Medical College (CMC)** | Vellore, TN | NEET UG | 100 |
| **4** | **National Institute of Mental Health (NIMHANS)** | Bangalore, KA | INI-CET | Specialized |
| **5** | **JIPMER** | Puducherry | NEET UG | 200 |
| **6** | **King George's Medical University (KGMU)** | Lucknow, UP | NEET UG | 250 |
| **7** | **Madras Medical College (MMC)** | Chennai, TN | NEET UG | 250 |
| **8** | **Armed Forces Medical College (AFMC)** | Pune, MH | NEET UG + ToLR + Interview | 150 |
| **9** | **Kasturba Medical College (KMC)** | Manipal, KA | NEET UG | 250 |
| **10**| **Maulana Azad Medical College (MAMC)** | New Delhi | NEET UG | 250 |`;
	if (q.includes("what is lpa") || q.includes("lpa meaning") || q.includes("lpa stands for") || q.includes("lpa in salary") || q === "lpa" || q.includes("l.p.a") || q.includes("ctc vs lpa") || q.includes("how much is lpa")) return `### What is LPA in Salary? Complete Explanation & Calculation

**LPA** stands for **Lakhs Per Annum** (*1 Lakh = 100,000 Indian Rupees (INR)*). In India, it is the standard metric used by companies and universities to describe an annual salary package or **CTC (Cost to Company)**.

---

### 1. Monthly Breakdown of Common LPA Packages:

| LPA Package | Annual Salary (Gross) | Monthly Gross Salary | Approx. Monthly In-Hand (After PF & Tax)* |
| :--- | :--- | :--- | :--- |
| **₹3.5 LPA** | ₹3,50,000 | ₹29,166 | **~₹24,000 - ₹26,000** |
| **₹6.0 LPA** | ₹6,00,000 | ₹50,000 | **~₹42,000 - ₹45,000** |
| **₹10.0 LPA**| ₹10,00,000 | ₹83,333 | **~₹68,000 - ₹73,000** |
| **₹15.0 LPA**| ₹15,00,000 | ₹1,25,000 | **~₹95,000 - ₹1,03,000** |
| **₹24.0 LPA**| ₹24,00,000 | ₹2,00,000 | **~₹1,45,000 - ₹1,58,000** |
| **₹50.0 LPA**| ₹50,00,000 | ₹4,16,666 | **~₹2,75,000 - ₹3,10,000** |

*\*Note: In-hand depends on basic pay percentage, standard deduction (₹75,000), PF contribution (12%), professional tax, and tax regime.*

---

### 2. Difference Between CTC, Gross, and In-Hand:

1. **CTC (Cost to Company):** Total amount the company spends on you per year (Basic + HRA + Allowances + PF + Gratuity + Insurance + Bonuses + Stocks).
2. **Gross Salary:** CTC minus Employer PF, Gratuity, and non-cash perks.
3. **In-Hand / Take-Home Salary:** Liquid cash credited to your bank account every month after Employee PF, Professional Tax, and Income Tax (TDS).

---

### 3. Key Components of an Indian Offer Letter:
- **Basic Pay (40-50% of CTC):** 100% taxable, baseline for PF & Gratuity.
- **House Rent Allowance (HRA):** Tax-exempt partially if living in rented accommodation.
- **Provident Fund (EPF):** 12% of basic pay contributed by employee + 12% by employer.
- **Variable Bonus (10-20%):** Paid quarterly or annually based on performance metrics.
- **Stocks / RSUs / ESOPs:** Vested over 3-4 years in tech companies and startups.`;
	if (q.includes("ctc vs in hand") || q.includes("difference between ctc") || q.includes("in hand salary")) return `### CTC vs In-Hand Salary: Clear Breakdown

### What is CTC?
**CTC (Cost to Company)** is the total financial expenditure a company incurs on an employee annually. It represents the "on-paper" package.

### What is In-Hand Salary?
**In-Hand (Take-Home) Salary** is the actual liquid cash deposited into your bank account on the 1st of every month.

---

### Why is In-Hand Lower Than CTC?
If your offer letter states **₹12 LPA CTC**, your monthly in-hand is not ₹1,00,000. Here is why:
1. **Provident Fund (EPF):** ₹1,800 to 12% of Basic Pay is deducted for retirement savings.
2. **Income Tax (TDS):** Deducted monthly as per income tax slabs.
3. **Gratuity:** ~4.81% of Basic Pay held by employer (payable after 5 years).
4. **Variable Pay / Performance Bonus:** 10-20% paid only at year-end based on targets.
5. **Non-Cash Perks:** Medical insurance, cab facilities, food coupons included in CTC.

---

### Quick Formula:
\`\`\`
Monthly In-Hand ≈ (Fixed Base CTC - Annual PF - Taxes - Gratuity) ÷ 12
\`\`\`
For a standard ₹12 LPA package, monthly take-home is usually **₹75,000 - ₹82,000**.`;
	if (q.includes("jee") || q.includes("iit") && !q.includes("college")) return `### JEE (Joint Entrance Examination) Comprehensive Guide

**JEE** is India's most prestigious national entrance examination for admission into premier engineering colleges.

---

### 1. Two-Tier Examination Structure:
1. **JEE Main (Conducted by NTA):**
   - **Frequency:** 2 Sessions (January & April).
   - **Colleges:** 32 NITs, 26 IIITs, 38 GFTIs, and state universities.
   - **Eligibility:** Class 12 with Physics, Chemistry, and Mathematics (min 75% aggregate or top 20 percentile).
   - **Format:** Computer Based Test (CBT) | 300 Marks | 3 Hours | 90 Questions (30 each in PCM).
2. **JEE Advanced (Conducted by IITs):**
   - **Eligibility:** Top 2,50,000 rank holders of JEE Main.
   - **Colleges:** 23 Indian Institutes of Technology (IITs).
   - **Format:** 2 Compulsory Papers (Paper 1 & Paper 2, 3 hours each on the same day).

---

### 2. High-Yield Preparation Roadmap:
- **Physics:** Focus on Mechanics, Electromagnetism, Modern Physics, and Thermodynamics. Books: *HC Verma Concepts of Physics*, *DC Pandey*.
- **Chemistry:** 100% mastery of **NCERT line-by-line** (Inorganic & Organic). Physical Chemistry: *RC Mukherjee* or *N. Awasthi*.
- **Mathematics:** Strong problem-solving in Calculus, Vectors & 3D, Coordinate Geometry. Books: *Cengage Series* by G. Tewani.
- **Test Strategy:** Complete at least 40 full-length mock tests and solve 15 years of Chapterwise Previous Year Questions (PYQs).`;
	if (q.includes("neet") || q.includes("mbbs") && !q.includes("college")) return `### NEET UG (National Eligibility cum Entrance Test) Guide

**NEET UG** is the single national entrance exam for admission to MBBS, BDS, BAMS, BHMS, and AIIMS in India.

---

### 1. Exam Pattern & Marking:
- **Total Marks:** 720 Marks (180 questions to attempt out of 200).
- **Subject Weightage:**
  - **Biology (Botany + Zoology):** 360 Marks (90 questions) — *50% of total score!*
  - **Chemistry:** 180 Marks (45 questions).
  - **Physics:** 180 Marks (45 questions).
- **Marking Scheme:** +4 for correct answer, -1 for wrong answer.
- **Duration:** 3 hours 20 minutes (Pen & Paper OMR format).

---

### 2. Proven Blueprint for 650+ Score:
1. **Biology (Target: 340+):** NCERT is mandatory. Memorize diagrams, scientist biographies, and tables. Solve 10,000+ MCQs from *MTG NCERT at your Fingertips*.
2. **Chemistry (Target: 155+):** Master named reactions in Organic, periodic trends in Inorganic, and formula application in Physical.
3. **Physics (Target: 140+):** Keep a dedicated formula notebook. Practice 50 numericals daily with a timer.
4. **Mock Tests:** Attempt at least 35 full-syllabus OMR-based tests to eliminate negative marking and bubble filling errors.`;
	if (q.includes("upsc") || q.includes("ias") || q.includes("ips") || q.includes("civil services")) return `### UPSC Civil Services Examination (CSE) Master Guide

The UPSC CSE is India's premier examination for recruitment into **IAS, IPS, IFS, IRS**, and other Central Group A services.

---

### 1. Three-Stage Examination Architecture:
1. **Stage 1: Preliminary Exam (Objective):**
   - **GS Paper 1 (200 Marks):** Cut-off determining (History, Geography, Polity, Economy, Environment, Current Affairs).
   - **CSAT Paper 2 (200 Marks):** Qualifying only (requires min 33% = 66 marks).
2. **Stage 2: Mains Exam (Subjective/Descriptive):**
   - 9 Papers (Total: 1,750 Marks): Essay (250), GS 1 to GS 4 (1,000 marks), Optional Subject Paper 1 & 2 (500 marks), plus 2 qualifying language papers.
3. **Stage 3: Personality Test / Interview (275 Marks):**
   - Conducted at Dholpur House, New Delhi. Total final ranking is based on **2,025 Marks** (Mains + Interview).

---

### 2. Essential Foundation Booklist:
- **Polity:** *Indian Polity* by M. Laxmikanth.
- **Modern History:** *A Brief History of Modern India* by Spectrum (Rajiv Ahir).
- **Geography:** NCERTs (Class 11 & 12) + *Certificate Physical and Human Geography* by GC Leong.
- **Economy:** *Indian Economy* by Sanjiv Verma or Nitin Singhania + Economic Survey & Budget.
- **Current Affairs:** Daily reading of *The Hindu* or *The Indian Express* + Monthly compilation magazines.`;
	if (q.includes("startup") || q.includes("start a company") || q.includes("entrepreneur") || q.includes("fundraising")) return `### How to Build & Launch a Scalable Startup in India

---

### 1. Step-by-Step Launch Framework:
1. **Problem Discovery & Validation:**
   - Find a high-friction problem customers actively spend money or time trying to solve.
   - Interview 30-50 prospective users before writing code.
2. **Build a Minimum Viable Product (MVP):**
   - Build a core working version in 2-4 weeks using no-code tools (Webflow, FlutterFlow, Supabase) or lightweight full-stack.
   - Measure retention and customer engagement over vanity signups.
3. **Legal Entity & Government Schemes:**
   - **Incorporate:** Register as a **Private Limited (Pvt Ltd)** company on MCA for equity investments.
   - **Startup India (DPIIT):** Get DPIIT recognition at \`startupindia.gov.in\` for 3-year income tax exemption (Section 80-IAC) and capital gains exemptions.
   - **MSME Udyam Registration:** For collateral-free loans, priority bank credit, and government tenders.

---

### 2. Funding Channels:
- **Bootstrapping:** Grow via customer cash flow.
- **Government Grants:** Startup India Seed Fund Scheme (SISFS - up to ₹20 Lakhs grant, ₹50 Lakhs debt).
- **Angel Investors:** Indian Angel Network (IAN), LetsVenture, Mumbai Angels, Inflection Point Ventures.
- **Venture Capital:** Early-stage VCs (Peak XV, Blume Ventures, India Quotient, Elevation Capital).`;
	try {
		const searchTerms = rawQuery.replace(/[?!.,]/g, "").replace(/^(what is|who is|where is|tell me about|explain|how to|top 10|best|give me)\s+/i, "").trim();
		const wikiSearchUrl = `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(searchTerms || rawQuery)}&utf8=&format=json&origin=*`;
		const searchRes = await fetch(wikiSearchUrl);
		if (searchRes.ok) {
			const firstHit = (await searchRes.json())?.query?.search?.[0];
			if (firstHit && firstHit.title) {
				const pageTitle = firstHit.title;
				const pageSummaryUrl = `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(pageTitle)}`;
				const summaryRes = await fetch(pageSummaryUrl);
				if (summaryRes.ok) {
					const summaryData = await summaryRes.json();
					const extract = summaryData.extract || "";
					const description = summaryData.description || "";
					if (extract.length > 50) return `### ${summaryData.title}${description ? ` — ${description}` : ""}

${extract}

---

### 🔍 Key Insights & Context:
- **Core Topic:** ${summaryData.title}
- **Overview Summary:** ${extract.slice(0, 300)}...
- **Practical Relevance:** Understanding this topic provides essential background for academic, professional, and general knowledge development.

💡 *Ask me any follow-up question or specify what you would like to explore further about ${summaryData.title}!*`;
				}
			}
		}
	} catch (e) {
		console.info("Live knowledge lookup error, using default synthesizer:", e);
	}
	const cleanedTitle = rawQuery.replace(/[?!.]/g, "").replace(/^(what is|how to|explain|tell me about|guide for|why is)\s+/i, "").trim();
	return `### Comprehensive Guide: ${cleanedTitle.charAt(0).toUpperCase() + cleanedTitle.slice(1) || rawQuery}

---

### 1. Key Concept & Overview:
Understanding **${rawQuery}** requires analyzing its fundamental principles, practical applications, and strategic value in modern education and career development.

---

### 2. Actionable Roadmap & Key Steps:
1. **Foundational Understanding:** Establish your goals, prerequisites, and resource availability.
2. **Structured Execution:** Break your study or execution into measurable weekly milestones.
3. **Practical Application:** Spend 70% of your time on problem-solving, hands-on projects, or mock evaluations.
4. **Review & Optimization:** Seek feedback from mentors, track performance metrics, and adapt continuously.

💡 *Ask me any follow-up question! For example: "Give me a step-by-step 30-day roadmap" or "What are the best books and resources?"*`;
}
var PRESET_QUESTIONS = [
	"Top 10 colleges for BSc IT",
	"What is LPA in salary?",
	"CTC vs In-Hand Salary difference",
	"How to prepare for JEE Main & IIT?",
	"Top 10 colleges for BCA in India",
	"Top 10 colleges for B.Tech CSE",
	"How to crack UPSC CSE IAS exam?",
	"How to start a startup in India?"
];
function FormattedChatMessage({ text }) {
	const lines = text.split("\n");
	const elements = [];
	let tableRows = [];
	let inTable = false;
	const flushTable = (key) => {
		if (tableRows.length > 0) {
			elements.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarkdownTable, { lines: [...tableRows] }, key));
			tableRows = [];
			inTable = false;
		}
	};
	for (let i = 0; i < lines.length; i++) {
		const trimmed = (lines[i] ?? "").trim();
		if (trimmed.startsWith("|") && trimmed.endsWith("|")) {
			inTable = true;
			tableRows.push(trimmed);
			continue;
		} else if (inTable) flushTable(`table-${i}`);
		if (!trimmed) {
			elements.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-1.5" }, `space-${i}`));
			continue;
		}
		if (trimmed.startsWith("```")) {
			const codeLines = [];
			i++;
			while (i < lines.length && !lines[i]?.trim().startsWith("```")) {
				codeLines.push(lines[i] ?? "");
				i++;
			}
			elements.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "my-2 rounded-xl bg-muted/80 p-3 font-mono text-[11px] sm:text-xs overflow-x-auto text-foreground border border-border/50",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", { children: codeLines.join("\n") })
			}, `code-${i}`));
			continue;
		}
		if (trimmed === "---" || trimmed === "***" || trimmed === "___") {
			elements.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hr", { className: "my-2.5 border-border/50" }, `hr-${i}`));
			continue;
		}
		if (trimmed.startsWith("###") || trimmed.startsWith("##") || trimmed.startsWith("#")) {
			const cleanHeading = trimmed.replace(/^#+\s*/, "").replace(/[💡🤖🌐⚖️🏛️🚀🛡️🩺🎓⏱️]/g, "").trim();
			elements.push(/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "font-bold text-sm sm:text-base text-foreground pt-1.5 pb-0.5 border-b border-border/40 flex items-center gap-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-primary inline-block" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: cleanHeading })]
			}, `h-${i}`));
			continue;
		}
		if (trimmed.startsWith("- ") || trimmed.startsWith("* ")) {
			const content = trimmed.substring(2);
			elements.push(/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-2 pl-1 my-0.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-1.5 size-1.5 rounded-full bg-primary/70 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-foreground/90",
					children: parseInlineFormatting(content)
				})]
			}, `bullet-${i}`));
			continue;
		}
		const numberedMatch = trimmed.match(/^(\d+)\.\s+(.*)$/);
		if (numberedMatch) {
			const num = numberedMatch[1] ?? "1";
			const content = numberedMatch[2] ?? "";
			elements.push(/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-2 pl-0.5 my-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-5 shrink-0 place-items-center rounded-full bg-primary/10 text-primary font-bold text-[11px]",
					children: num
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-foreground font-normal flex-1 pt-0.5",
					children: parseInlineFormatting(content)
				})]
			}, `num-${i}`));
			continue;
		}
		elements.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-foreground/90 my-0.5",
			children: parseInlineFormatting(trimmed)
		}, `p-${i}`));
	}
	flushTable("final-table");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-1.5 text-xs sm:text-sm leading-relaxed",
		children: elements
	});
}
function MarkdownTable({ lines }) {
	if (lines.length < 2) return null;
	const headerCells = (lines[0] ?? "").split("|").map((c) => c.trim()).filter((c) => c.length > 0);
	const rowLines = lines.slice(2);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "my-2.5 overflow-x-auto rounded-xl border border-border bg-card/60 shadow-xs",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full text-left text-xs border-collapse",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
				className: "border-b border-border bg-accent/40",
				children: headerCells.map((h, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
					className: "px-3 py-2 font-semibold text-foreground",
					children: parseInlineFormatting(h)
				}, idx))
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rowLines.map((row, rIdx) => {
				const cells = row.split("|").map((c) => c.trim()).filter((c) => c.length > 0);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
					className: "border-b border-border/30 hover:bg-accent/20",
					children: cells.map((cell, cIdx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-3 py-2 text-foreground/90",
						children: parseInlineFormatting(cell)
					}, cIdx))
				}, rIdx);
			}) })]
		})
	});
}
function parseInlineFormatting(text) {
	return text.split(/(\*\*.*?\*\*|\*.*?\*|`.*?`)/g).map((part, i) => {
		if (part.startsWith("**") && part.endsWith("**")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
			className: "font-bold text-foreground",
			children: part.slice(2, -2)
		}, i);
		if (part.startsWith("*") && part.endsWith("*") && !part.startsWith("**")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
			className: "italic text-foreground/90",
			children: part.slice(1, -1)
		}, i);
		if (part.startsWith("`") && part.endsWith("`")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
			className: "px-1.5 py-0.5 rounded-md bg-muted text-primary font-mono text-[11px] font-semibold",
			children: part.slice(1, -1)
		}, i);
		return part;
	});
}
function CareerChatbot({ onClose }) {
	const [messages, setMessages] = (0, import_react.useState)([{
		id: "1",
		sender: "bot",
		text: `### Welcome to CareerSetu AI Assistant! ✨
I am your smart career, academics, salary, and exam mentor powered by real LLM intelligence.

Ask me **any question** — from what is LPA & salary breakdowns, to competitive exams (JEE, NEET, UPSC, GATE, CAT), software engineering roadmaps, startup guidelines, and colleges!`,
		timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString([], {
			hour: "2-digit",
			minute: "2-digit"
		}),
		source: "CareerSetu Neural AI"
	}]);
	const [input, setInput] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [copiedId, setCopiedId] = (0, import_react.useState)(null);
	const [isSettingsOpen, setIsSettingsOpen] = (0, import_react.useState)(false);
	const [aiProvider, setAiProvider] = (0, import_react.useState)("auto");
	const [customGeminiKey, setCustomGeminiKey] = (0, import_react.useState)("");
	const [customGroqKey, setCustomGroqKey] = (0, import_react.useState)("");
	const [customOpenAIKey, setCustomOpenAIKey] = (0, import_react.useState)("");
	const messagesEndRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (typeof localStorage !== "undefined") {
			const storedProvider = localStorage.getItem("careersetu_ai_provider");
			if (storedProvider) setAiProvider(storedProvider);
			const gKey = localStorage.getItem("careersetu_gemini_api_key");
			if (gKey) setCustomGeminiKey(gKey);
			const groqK = localStorage.getItem("careersetu_groq_api_key");
			if (groqK) setCustomGroqKey(groqK);
			const openAIK = localStorage.getItem("careersetu_openai_api_key");
			if (openAIK) setCustomOpenAIKey(openAIK);
		}
	}, []);
	(0, import_react.useEffect)(() => {
		messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
	}, [messages, loading]);
	const saveSettings = () => {
		if (typeof localStorage !== "undefined") {
			localStorage.setItem("careersetu_ai_provider", aiProvider);
			if (customGeminiKey.trim()) localStorage.setItem("careersetu_gemini_api_key", customGeminiKey.trim());
			else localStorage.removeItem("careersetu_gemini_api_key");
			if (customGroqKey.trim()) localStorage.setItem("careersetu_groq_api_key", customGroqKey.trim());
			else localStorage.removeItem("careersetu_groq_api_key");
			if (customOpenAIKey.trim()) localStorage.setItem("careersetu_openai_api_key", customOpenAIKey.trim());
			else localStorage.removeItem("careersetu_openai_api_key");
		}
		toast.success("AI Engine settings saved!");
		setIsSettingsOpen(false);
	};
	const copyMessage = (id, text) => {
		navigator.clipboard.writeText(text);
		setCopiedId(id);
		toast.success("Copied to clipboard");
		setTimeout(() => setCopiedId(null), 2e3);
	};
	const resetChat = () => {
		setMessages([{
			id: Date.now().toString(),
			sender: "bot",
			text: "### Chat cleared! 🧹\nHow can I help you today with salary calculations, career roadmaps, exam strategies, or college admissions?",
			timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString([], {
				hour: "2-digit",
				minute: "2-digit"
			}),
			source: "CareerSetu Neural AI"
		}]);
		toast.success("Chat history reset");
	};
	const sendMessage = async (userText) => {
		if (!userText.trim()) return;
		const userMsg = {
			id: Date.now().toString(),
			sender: "user",
			text: userText.trim(),
			timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString([], {
				hour: "2-digit",
				minute: "2-digit"
			})
		};
		setMessages((prev) => [...prev, userMsg]);
		setInput("");
		setLoading(true);
		try {
			const response = await askCareerSetuAI(userText, {
				provider: aiProvider,
				geminiKey: customGeminiKey,
				groqKey: customGroqKey,
				openaiKey: customOpenAIKey
			});
			const botMsg = {
				id: (Date.now() + 1).toString(),
				sender: "bot",
				text: response.text,
				timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString([], {
					hour: "2-digit",
					minute: "2-digit"
				}),
				source: response.source
			};
			setMessages((prev) => [...prev, botMsg]);
		} catch (err) {
			const errorMsg = {
				id: (Date.now() + 1).toString(),
				sender: "bot",
				text: "I encountered an error processing your query. Please try asking again or configure an API key in settings.",
				timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString([], {
					hour: "2-digit",
					minute: "2-digit"
				})
			};
			setMessages((prev) => [...prev, errorMsg]);
		} finally {
			setLoading(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "glass flex flex-col h-[600px] w-full max-w-lg rounded-3xl border-primary/20 shadow-2xl overflow-hidden bg-card/95 backdrop-blur-xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "gradient-brand px-5 py-3.5 flex items-center justify-between text-primary-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-9 place-items-center rounded-xl bg-white/20 backdrop-blur shadow-xs",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bot, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "font-bold text-sm leading-none flex items-center gap-1.5",
						children: ["CareerSetu AI Assistant", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3.5 fill-amber-300 text-amber-300 animate-pulse" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1.5 mt-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "inline-block size-1.5 rounded-full bg-emerald-400 animate-ping" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] opacity-90",
							children: customGeminiKey ? "Google Gemini AI Active" : customGroqKey ? "Groq Llama 3.3 Active" : "Neural AI Engine (GPT/Gemini Ready)"
						})]
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							onClick: () => setIsSettingsOpen(true),
							title: "Configure AI Engine",
							className: "h-8 w-8 text-primary-foreground hover:bg-white/20 rounded-full cursor-pointer",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings2, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							onClick: resetChat,
							title: "Reset Chat",
							className: "h-8 w-8 text-primary-foreground hover:bg-white/20 rounded-full cursor-pointer",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" })
						}),
						onClose && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							onClick: onClose,
							className: "h-8 w-8 text-primary-foreground hover:bg-white/20 rounded-full cursor-pointer",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 overflow-y-auto p-4 space-y-3.5 text-xs sm:text-sm",
				children: [
					messages.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `flex items-start gap-2.5 ${m.sender === "user" ? "flex-row-reverse" : "flex-row"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `grid size-7 shrink-0 place-items-center rounded-full text-xs font-semibold shadow-xs ${m.sender === "user" ? "bg-primary text-primary-foreground" : "bg-accent text-foreground"}`,
							children: m.sender === "user" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bot, { className: "size-3.5 text-primary" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `group relative max-w-[90%] rounded-2xl px-4 py-3 shadow-xs ${m.sender === "user" ? "gradient-brand text-primary-foreground rounded-tr-none font-medium" : "bg-background border border-border/80 text-foreground rounded-tl-none"}`,
							children: [m.sender === "user" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs sm:text-sm",
								children: m.text
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormattedChatMessage, { text: m.text }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex items-center justify-between gap-2 pt-1 border-t border-border/40",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `text-[10px] ${m.sender === "user" ? "opacity-75" : "text-muted-foreground"}`,
										children: m.timestamp
									}), m.source && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[9px] px-1.5 py-0.5 rounded-full bg-primary/10 text-primary font-medium",
										children: m.source
									})]
								}), m.sender === "bot" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => copyMessage(m.id, m.text),
									className: "opacity-0 group-hover:opacity-100 transition-opacity p-1 hover:bg-accent rounded text-muted-foreground hover:text-foreground cursor-pointer",
									title: "Copy to clipboard",
									children: copiedId === m.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3 text-emerald-500" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3" })
								})]
							})]
						})]
					}, m.id)),
					loading && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2.5 text-xs text-muted-foreground italic pl-9 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "CareerSetu AI is analyzing your question..." })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { ref: messagesEndRef })
				]
			}),
			messages.length <= 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-3 pb-2 flex gap-1.5 overflow-x-auto scrollbar-none",
				children: PRESET_QUESTIONS.map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => sendMessage(q),
					className: "shrink-0 rounded-xl bg-accent/70 hover:bg-accent px-3 py-1.5 text-[11px] font-medium text-foreground transition-all border border-border/50 hover:border-primary/40 cursor-pointer shadow-2xs",
					children: q
				}, q))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: (e) => {
					e.preventDefault();
					sendMessage(input);
				},
				className: "p-3 bg-card border-t border-border flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					placeholder: "Ask anything...",
					value: input,
					onChange: (e) => setInput(e.target.value),
					className: "h-10 rounded-xl bg-background border-border text-xs sm:text-sm shadow-inner"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					disabled: !input.trim() || loading,
					size: "icon",
					className: "gradient-brand size-10 shrink-0 rounded-xl text-primary-foreground shadow-glow cursor-pointer disabled:opacity-50",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" })
				})]
			}),
			isSettingsOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: isSettingsOpen,
				onOpenChange: setIsSettingsOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-md rounded-3xl p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
						className: "text-lg font-bold font-display flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-5 text-primary" }), "AI Assistant Engine Settings"]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4 text-xs text-muted-foreground mt-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "font-semibold text-foreground block mb-1",
								children: "Preferred AI Model Provider"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: aiProvider,
								onValueChange: (val) => setAiProvider(val),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
									className: "rounded-xl h-10",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Select Provider" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, {
									className: "rounded-2xl",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "auto",
											children: "⚡ Auto (Best Available - Free GPT / Gemini / Expert)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "gemini",
											children: "🌟 Google Gemini (Direct API)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "groq",
											children: "🚀 Groq (Llama 3.3 70B Fast)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "openai",
											children: "🤖 OpenAI / OpenRouter"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "knowledge",
											children: "📚 Offline Career Intelligence Engine"
										})
									]
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "font-semibold text-foreground",
										children: "Google Gemini API Key (Optional)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: "https://aistudio.google.com/app/apikey",
										target: "_blank",
										rel: "noreferrer",
										className: "text-[11px] text-primary hover:underline flex items-center gap-0.5",
										children: ["Get Free Key ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3" })]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "password",
									placeholder: "AIzaSy...",
									value: customGeminiKey,
									onChange: (e) => setCustomGeminiKey(e.target.value),
									className: "h-10 rounded-xl"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "font-semibold text-foreground",
										children: "Groq API Key (Optional)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: "https://console.groq.com/keys",
										target: "_blank",
										rel: "noreferrer",
										className: "text-[11px] text-primary hover:underline flex items-center gap-0.5",
										children: ["Get Free Key ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3" })]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "password",
									placeholder: "gsk_...",
									value: customGroqKey,
									onChange: (e) => setCustomGroqKey(e.target.value),
									className: "h-10 rounded-xl"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2 justify-end pt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									size: "sm",
									onClick: () => setIsSettingsOpen(false),
									className: "rounded-xl cursor-pointer",
									children: "Cancel"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									className: "gradient-brand text-primary-foreground rounded-xl cursor-pointer",
									onClick: saveSettings,
									children: "Save Settings"
								})]
							})
						]
					})]
				})
			})
		]
	});
}
function GlobalSearchModal({ open, onOpenChange }) {
	const [query, setQuery] = (0, import_react.useState)("");
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		const handleKeyDown = (e) => {
			if ((e.metaKey || e.ctrlKey) && e.key === "k") {
				e.preventDefault();
				onOpenChange(!open);
			}
		};
		window.addEventListener("keydown", handleKeyDown);
		return () => window.removeEventListener("keydown", handleKeyDown);
	}, [open, onOpenChange]);
	const q = query.toLowerCase().trim();
	const careersList = getManagedCareers().filter((c) => c.status !== "ARCHIVED");
	const examsList = getManagedExams().filter((e) => e.status !== "ARCHIVED");
	const scholarshipsList = getManagedScholarships().filter((s) => s.status !== "ARCHIVED");
	const collegesList = getManagedColleges().filter((c) => c.status !== "ARCHIVED");
	getManagedResources().filter((r) => r.status !== "ARCHIVED");
	const matchingCareers = q ? careersList.filter((c) => c.name.toLowerCase().includes(q) || c.domain.toLowerCase().includes(q) || c.tags && c.tags.some((t) => t.toLowerCase().includes(q))).slice(0, 4) : careersList.slice(0, 3);
	const matchingExams = q ? examsList.filter((e) => e.name.toLowerCase().includes(q) || e.shortName && e.shortName.toLowerCase().includes(q) || e.conductingBody.toLowerCase().includes(q)).slice(0, 4) : examsList.slice(0, 3);
	const matchingScholarships = q ? scholarshipsList.filter((s) => s.name.toLowerCase().includes(q) || s.provider.toLowerCase().includes(q)).slice(0, 3) : scholarshipsList.slice(0, 2);
	const matchingColleges = q ? collegesList.filter((col) => col.name.toLowerCase().includes(q) || col.city.toLowerCase().includes(q) || col.popularDegrees && col.popularDegrees.some((deg) => deg.toLowerCase().includes(q))).slice(0, 3) : collegesList.slice(0, 2);
	const handleSelect = (path) => {
		onOpenChange(false);
		navigate({ to: path });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-2xl p-0 overflow-hidden rounded-3xl border-primary/20 shadow-2xl bg-card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 px-4 py-3.5 border-b border-border bg-accent/30",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-5 text-muted-foreground shrink-0" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: query,
						onChange: (e) => setQuery(e.target.value),
						placeholder: "Type to search careers, exams, colleges, scholarships...",
						className: "border-0 bg-transparent text-sm sm:text-base focus-visible:ring-0 focus-visible:ring-offset-0 px-0 h-9",
						autoFocus: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: "outline",
						className: "text-[10px] hidden sm:inline-flex text-muted-foreground",
						children: "ESC to close"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-h-[420px] overflow-y-auto p-4 space-y-4 text-xs sm:text-sm",
				children: [
					matchingCareers.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between text-[11px] font-semibold text-muted-foreground px-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-3.5 text-primary" }), " Careers"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [matchingCareers.length, " results"] })]
						}), matchingCareers.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => handleSelect(`/careers`),
							className: "w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-accent/80 transition-colors text-left group cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold text-foreground group-hover:text-primary transition-colors",
								children: c.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[11px] text-muted-foreground",
								children: [
									c.domain,
									" · ",
									c.salary,
									" · ",
									c.demand,
									" Demand"
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" })]
						}, c.id))]
					}),
					matchingExams.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5 pt-2 border-t border-border/50",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between text-[11px] font-semibold text-muted-foreground px-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "size-3.5 text-blue-500" }), " Government & National Exams"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [matchingExams.length, " results"] })]
						}), matchingExams.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => handleSelect(`/exams`),
							className: "w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-accent/80 transition-colors text-left group cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-semibold text-foreground group-hover:text-primary transition-colors",
								children: [
									e.name,
									" (",
									e.shortName,
									")"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[11px] text-muted-foreground",
								children: [
									e.conductingBody,
									" · ",
									e.status
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" })]
						}, e.id))]
					}),
					matchingColleges.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5 pt-2 border-t border-border/50",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between text-[11px] font-semibold text-muted-foreground px-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3.5 text-emerald-500" }), " Top Colleges"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [matchingColleges.length, " results"] })]
						}), matchingColleges.map((col) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => handleSelect(`/colleges`),
							className: "w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-accent/80 transition-colors text-left group cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold text-foreground group-hover:text-primary transition-colors",
								children: col.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[11px] text-muted-foreground",
								children: [
									col.city,
									", ",
									col.state,
									" · NIRF #",
									col.nirfRank
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" })]
						}, col.id))]
					}),
					matchingScholarships.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5 pt-2 border-t border-border/50",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between text-[11px] font-semibold text-muted-foreground px-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "size-3.5 text-amber-500" }), " Scholarships"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [matchingScholarships.length, " results"] })]
						}), matchingScholarships.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => handleSelect(`/scholarships`),
							className: "w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-accent/80 transition-colors text-left group cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold text-foreground group-hover:text-primary transition-colors",
								children: s.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[11px] text-muted-foreground",
								children: [
									s.amount,
									" · Deadline: ",
									s.deadline
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" })]
						}, s.id))]
					})
				]
			})]
		})
	});
}
var DropdownMenu = Root2;
var DropdownMenuTrigger = Trigger;
var DropdownMenuSubTrigger = import_react.forwardRef(({ className, inset, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SubTrigger2, {
	ref,
	className: cn("flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-accent data-[state=open]:bg-accent [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", inset && "pl-8", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "ml-auto" })]
}));
DropdownMenuSubTrigger.displayName = SubTrigger2.displayName;
var DropdownMenuSubContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubContent2, {
	ref,
	className: cn("z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-lg data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-dropdown-menu-content-transform-origin)", className),
	...props
}));
DropdownMenuSubContent.displayName = SubContent2.displayName;
var DropdownMenuContent = import_react.forwardRef(({ className, sideOffset = 4, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal2, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	sideOffset,
	className: cn("z-50 max-h-[var(--radix-dropdown-menu-content-available-height)] min-w-[8rem] overflow-y-auto overflow-x-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-md", "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-dropdown-menu-content-transform-origin)", className),
	...props
}) }));
DropdownMenuContent.displayName = Content2.displayName;
var DropdownMenuItem = import_react.forwardRef(({ className, inset, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item2, {
	ref,
	className: cn("relative flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&>svg]:size-4 [&>svg]:shrink-0", inset && "pl-8", className),
	...props
}));
DropdownMenuItem.displayName = Item2.displayName;
var DropdownMenuCheckboxItem = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CheckboxItem2, {
	ref,
	className: cn("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemIndicator2, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }) })
	}), children]
}));
DropdownMenuCheckboxItem.displayName = CheckboxItem2.displayName;
var DropdownMenuRadioItem = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(RadioItem2, {
	ref,
	className: cn("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemIndicator2, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, { className: "h-2 w-2 fill-current" }) })
	}), children]
}));
DropdownMenuRadioItem.displayName = RadioItem2.displayName;
var DropdownMenuLabel = import_react.forwardRef(({ className, inset, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label2, {
	ref,
	className: cn("px-2 py-1.5 text-sm font-semibold", inset && "pl-8", className),
	...props
}));
DropdownMenuLabel.displayName = Label2.displayName;
var DropdownMenuSeparator = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator2, {
	ref,
	className: cn("-mx-1 my-1 h-px bg-muted", className),
	...props
}));
DropdownMenuSeparator.displayName = Separator2.displayName;
var DropdownMenuShortcut = ({ className, ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("ml-auto text-xs tracking-widest opacity-60", className),
		...props
	});
};
DropdownMenuShortcut.displayName = "DropdownMenuShortcut";
var translations = {
	english: {
		dashboard: "Dashboard",
		assessment: "Career Assessment",
		careers: "Career Explorer",
		exams: "Government Exams",
		studyPlanner: "Study Planner",
		resources: "Learning Resources",
		scholarships: "Scholarship Finder",
		colleges: "College Directory",
		resume: "Resume Builder",
		skillGap: "Skill Gap Analysis",
		progress: "Progress & Badges",
		bookmarks: "My Bookmarks",
		profile: "My Profile",
		settings: "Settings",
		admin: "Admin Panel",
		askAI: "Ask AI Assistant",
		searchPlaceholder: "Search careers, exams, colleges, scholarships... (Press ⌘K)",
		welcomeBack: "Welcome back",
		careerMatchScore: "Career Match Score",
		studyStreak: "Study Streak",
		activeExams: "Tracked Exams",
		scholarshipsAvailable: "Scholarships Available",
		takeAssessment: "Take AI Assessment",
		retakeAssessment: "Retake Assessment",
		viewDetails: "View Details",
		bookmark: "Bookmark",
		bookmarked: "Bookmarked",
		compare: "Compare",
		applyNow: "Apply Now",
		officialWebsite: "Official Website",
		lastUpdated: "Last Updated",
		logout: "Sign Out"
	},
	hindi: {
		dashboard: "डैशबोर्ड",
		assessment: "करियर असेसमेंट",
		careers: "करियर खोजें",
		exams: "सरकारी परीक्षाएं",
		studyPlanner: "स्टडी प्लानर",
		resources: "अध्ययन सामग्री",
		scholarships: "छात्रवृत्ति खोज",
		colleges: "कॉलेज डायरेक्टरी",
		resume: "रिज्यूमे बिल्डर",
		skillGap: "स्किल गैप एनालिसिस",
		progress: "प्रगति और बैज",
		bookmarks: "मेरे बुकमार्क",
		profile: "मेरी प्रोफाइल",
		settings: "सेटिंग्स",
		admin: "एडमिन पैनल",
		askAI: "एआई सहायक से पूछें",
		searchPlaceholder: "करियर, परीक्षा, कॉलेज, छात्रवृत्ति खोजें... (⌘K दबाएं)",
		welcomeBack: "वापसी पर स्वागत है",
		careerMatchScore: "करियर मैच स्कोर",
		studyStreak: "अध्ययन स्ट्रीक",
		activeExams: "ट्रैक की गई परीक्षाएं",
		scholarshipsAvailable: "उपलब्ध छात्रवृत्तियां",
		takeAssessment: "एआई असेसमेंट शुरू करें",
		retakeAssessment: "असेसमेंट दोबारा दें",
		viewDetails: "विवरण देखें",
		bookmark: "बुकमार्क करें",
		bookmarked: "बुकमार्क किया गया",
		compare: "तुलना करें",
		applyNow: "आवेदन करें",
		officialWebsite: "आधिकारिक वेबसाइट",
		lastUpdated: "अंतिम अपडेट",
		logout: "लॉग आउट"
	},
	marathi: {
		dashboard: "डॅशबोर्ड",
		assessment: "करिअर मूल्यमापन",
		careers: "करिअर शोधा",
		exams: "सरकारी परीक्षा",
		studyPlanner: "अभ्यास नियोजक",
		resources: "अभ्यास संसाधने",
		scholarships: "शिष्यवृत्ती शोध",
		colleges: "कॉलेज निर्देशिका",
		resume: "बायोडाटा बिल्डर",
		skillGap: "कौशल्य विश्लेषण",
		progress: "प्रगती आणि बॅज",
		bookmarks: "माझे बुकमार्क",
		profile: "माझे प्रोफाईल",
		settings: "सेटिंग्ज",
		admin: "अॅडमिन पॅनेल",
		askAI: "एआय सहाय्यकाला विचारा",
		searchPlaceholder: "करिअर, परीक्षा, कॉलेज, शिष्यवृत्ती शोधा... (⌘K दाबा)",
		welcomeBack: "पुन्हा स्वागत आहे",
		careerMatchScore: "करिअर जुळणी स्कोअर",
		studyStreak: "अभ्यास सातत्य",
		activeExams: "ट्रॅक केलेल्या परीक्षा",
		scholarshipsAvailable: "उपलब्ध शिष्यवृत्ती",
		takeAssessment: "एआय मूल्यमापन सुरू करा",
		retakeAssessment: "पुन्हा मूल्यमापन करा",
		viewDetails: "तपशील पहा",
		bookmark: "बुकमार्क करा",
		bookmarked: "बुकमार्क केले",
		compare: "तुलना करा",
		applyNow: "अर्ज करा",
		officialWebsite: "अधिकृत वेबसाइट",
		lastUpdated: "शेवटचे अपडेट",
		logout: "लॉग आउट"
	}
};
function getTranslation(lang, key) {
	return (translations[lang] || translations.english)[key] || translations.english[key] || key;
}
function AuthenticatedLayout() {
	const navigate = useNavigate();
	const location = useLocation();
	const queryClient = useQueryClient();
	const [showChatbot, setShowChatbot] = (0, import_react.useState)(false);
	const [showSearch, setShowSearch] = (0, import_react.useState)(false);
	const [sidebarOpen, setSidebarOpen] = (0, import_react.useState)(false);
	const [currentLang, setCurrentLang] = (0, import_react.useState)("english");
	const [unreadNotifications, setUnreadNotifications] = (0, import_react.useState)(3);
	const currentUser = getCurrentUser();
	const userIsAdmin = isAdmin(currentUser);
	const userName = currentUser.full_name || "Student";
	const broadcasts = getBroadcastNotifications();
	(0, import_react.useEffect)(() => {
		if (typeof localStorage !== "undefined") {
			const savedLang = localStorage.getItem("careersetu_language");
			if (savedLang) setCurrentLang(savedLang);
		}
	}, []);
	const changeLanguage = (lang) => {
		setCurrentLang(lang);
		if (typeof localStorage !== "undefined") localStorage.setItem("careersetu_language", lang);
		toast.success(`Language set to ${lang.toUpperCase()}`);
	};
	async function signOut() {
		await queryClient.cancelQueries();
		queryClient.clear();
		logoutUser();
		await supabase.auth.signOut();
		toast.success("Signed out successfully");
		navigate({
			to: "/student/login",
			replace: true
		});
	}
	const currentPath = location.pathname;
	const NAV_ITEMS = [
		{
			label: getTranslation(currentLang, "dashboard"),
			path: "/dashboard",
			icon: House,
			badge: "Home"
		},
		{
			label: getTranslation(currentLang, "assessment"),
			path: "/assessment",
			icon: Target,
			badge: "AI"
		},
		{
			label: getTranslation(currentLang, "careers"),
			path: "/careers",
			icon: Briefcase,
			badge: "100+"
		},
		{
			label: getTranslation(currentLang, "exams"),
			path: "/exams",
			icon: Landmark,
			badge: "20+"
		},
		{
			label: getTranslation(currentLang, "studyPlanner"),
			path: "/study-planner",
			icon: Calendar
		},
		{
			label: getTranslation(currentLang, "resources"),
			path: "/resources",
			icon: BookOpen
		},
		{
			label: getTranslation(currentLang, "scholarships"),
			path: "/scholarships",
			icon: GraduationCap
		},
		{
			label: getTranslation(currentLang, "colleges"),
			path: "/colleges",
			icon: Building2
		},
		{
			label: getTranslation(currentLang, "resume"),
			path: "/resume",
			icon: FileText,
			badge: "ATS"
		},
		{
			label: getTranslation(currentLang, "skillGap"),
			path: "/skill-gap",
			icon: Zap
		},
		{
			label: getTranslation(currentLang, "progress"),
			path: "/progress",
			icon: TrendingUp
		},
		{
			label: getTranslation(currentLang, "bookmarks"),
			path: "/bookmarks",
			icon: Bookmark
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background text-foreground flex flex-col antialiased selection:bg-primary/20",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-40 border-b border-border/80 bg-card/85 backdrop-blur-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex w-full items-center justify-between gap-3 px-4 py-2.5 sm:px-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setSidebarOpen(!sidebarOpen),
									className: "lg:hidden p-2 rounded-xl hover:bg-accent text-muted-foreground hover:text-foreground cursor-pointer",
									"aria-label": "Toggle navigation",
									children: sidebarOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/dashboard",
									"aria-label": "CareerSetu dashboard",
									className: "flex items-center gap-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "outline",
									className: "hidden xl:inline-flex border-primary/20 text-primary text-[11px] bg-primary/5 font-semibold",
									children: "AI Student SaaS"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => setShowSearch(true),
							className: "hidden md:flex items-center justify-between w-72 lg:w-96 h-9 px-3 rounded-xl bg-accent/40 hover:bg-accent/70 border border-border/70 text-xs text-muted-foreground transition-all cursor-pointer shadow-inner",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 truncate",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-3.5 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate",
									children: getTranslation(currentLang, "searchPlaceholder")
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", {
								className: "text-[10px] font-mono px-1.5 py-0.5 rounded bg-card border border-border text-foreground/80",
								children: "⌘K"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1.5 sm:gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									size: "sm",
									onClick: () => setShowChatbot(true),
									className: "h-8 sm:h-9 rounded-xl gap-1.5 border-primary/30 bg-primary/10 hover:bg-primary/20 text-primary text-xs font-bold shadow-xs cursor-pointer",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bot, { className: "size-4 animate-bounce" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "hidden sm:inline",
											children: getTranslation(currentLang, "askAI")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3 text-amber-500 fill-amber-500" })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "ghost",
									size: "icon",
									className: "h-8 w-8 sm:h-9 sm:w-9 rounded-xl text-muted-foreground hover:text-foreground cursor-pointer",
									"aria-label": "Toggle Theme",
									onClick: () => {
										const isDark = document.documentElement.classList.toggle("dark");
										if (typeof localStorage !== "undefined") localStorage.setItem("careersetu_theme", isDark ? "dark" : "light");
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0 text-amber-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "absolute size-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100 text-sky-400" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
									asChild: true,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										variant: "ghost",
										size: "sm",
										className: "h-8 sm:h-9 px-2.5 rounded-xl gap-1.5 text-xs text-muted-foreground hover:text-foreground cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "hidden md:inline uppercase text-[11px] font-semibold",
											children: currentLang.slice(0, 2)
										})]
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
									align: "end",
									className: "w-40 rounded-2xl p-1.5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuLabel, {
											className: "text-[10px] text-muted-foreground",
											children: "Select Language"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
											onClick: () => changeLanguage("english"),
											className: `rounded-xl text-xs cursor-pointer ${currentLang === "english" ? "font-bold text-primary bg-primary/10" : ""}`,
											children: "🇬🇧 English"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
											onClick: () => changeLanguage("hindi"),
											className: `rounded-xl text-xs cursor-pointer ${currentLang === "hindi" ? "font-bold text-primary bg-primary/10" : ""}`,
											children: "🇮🇳 हिन्दी (Hindi)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
											onClick: () => changeLanguage("marathi"),
											className: `rounded-xl text-xs cursor-pointer ${currentLang === "marathi" ? "font-bold text-primary bg-primary/10" : ""}`,
											children: "🇮🇳 मराठी (Marathi)"
										})
									]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
									asChild: true,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										variant: "ghost",
										size: "icon",
										className: "h-8 w-8 sm:h-9 sm:w-9 rounded-xl relative cursor-pointer",
										"aria-label": "Notifications",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-4 text-muted-foreground" }), unreadNotifications > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-1.5 right-1.5 size-2 rounded-full bg-primary animate-pulse" })]
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
									align: "end",
									className: "w-80 rounded-2xl p-4 shadow-xl border-border",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between pb-2 border-b border-border",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-bold text-xs text-foreground",
											children: "Exam & Deadline Alerts"
										}), unreadNotifications > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => {
												setUnreadNotifications(0);
												toast.success("All notifications marked as read");
											},
											className: "text-[10px] text-primary hover:underline cursor-pointer",
											children: "Mark all read"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2 text-xs mt-3 max-h-64 overflow-y-auto pr-1",
										children: [broadcasts.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-2.5 rounded-xl bg-primary/5 border border-primary/20",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between gap-1 mb-0.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "font-semibold text-foreground text-xs",
													children: b.title
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
													variant: "outline",
													className: "text-[9px] px-1 py-0 border-primary/30 text-primary",
													children: b.category
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px] text-muted-foreground",
												children: b.message
											})]
										}, b.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-2.5 rounded-xl bg-accent/40 border border-border/50",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-semibold text-foreground",
												children: "Today's Study Goal: 2 Tasks Remaining"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px] text-muted-foreground mt-0.5",
												children: "Complete your daily scheduled milestones"
											})]
										})]
									})]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
									asChild: true,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										variant: "ghost",
										size: "sm",
										className: "h-8 sm:h-9 rounded-xl gap-2 px-2 cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "grid size-6 place-items-center rounded-full bg-primary text-primary-foreground font-bold text-xs shadow-xs",
											children: userName.charAt(0).toUpperCase()
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "hidden sm:inline text-xs font-semibold truncate max-w-24",
											children: userName
										})]
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
									align: "end",
									className: "w-52 rounded-2xl p-2 shadow-xl border-border",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuLabel, {
											className: "text-xs font-normal text-muted-foreground",
											children: ["Signed in as ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "text-foreground block font-medium truncate",
												children: userName
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, { className: "my-1" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
											onClick: () => navigate({ to: "/profile" }),
											className: "rounded-xl cursor-pointer text-xs",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "mr-2 size-3.5 text-primary" }), getTranslation(currentLang, "profile")]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
											onClick: () => navigate({ to: "/settings" }),
											className: "rounded-xl cursor-pointer text-xs",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "mr-2 size-3.5 text-primary" }), getTranslation(currentLang, "settings")]
										}),
										userIsAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
											onClick: () => navigate({ to: "/admin" }),
											className: "rounded-xl cursor-pointer text-xs font-medium text-amber-500 bg-amber-500/10",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "mr-2 size-3.5 text-amber-500" }), "Admin Management Console"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, { className: "my-1" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
											onSelect: signOut,
											className: "rounded-xl text-destructive focus:text-destructive cursor-pointer text-xs",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "mr-2 size-3.5" }), getTranslation(currentLang, "logout")]
										})
									]
								})] })
							]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 flex max-w-7xl w-full mx-auto",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
						className: `fixed lg:sticky top-[57px] left-0 z-30 h-[calc(100vh-57px)] w-64 shrink-0 bg-card/95 backdrop-blur-xl border-r border-border/80 p-4 overflow-y-auto transition-transform duration-300 ${sidebarOpen ? "translate-x-0 shadow-2xl" : "-translate-x-full lg:translate-x-0"}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/assessment",
									onClick: () => setSidebarOpen(false),
									className: "gradient-brand flex items-center justify-between px-3.5 py-2.5 rounded-2xl text-primary-foreground font-semibold text-xs shadow-glow hover:opacity-95 transition-opacity",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Target, { className: "size-4 animate-spin-slow" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Take Assessment" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-3.5" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "px-3 text-[10px] font-bold uppercase tracking-wider text-muted-foreground/80",
										children: "Navigation"
									}), NAV_ITEMS.map((item) => {
										const Icon = item.icon;
										const isActive = currentPath === item.path || item.path !== "/dashboard" && currentPath.startsWith(item.path);
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
											to: item.path,
											onClick: () => setSidebarOpen(false),
											className: `flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-colors ${isActive ? "bg-primary text-primary-foreground font-semibold shadow-xs" : "text-muted-foreground hover:text-foreground hover:bg-accent/60"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.label })]
											}), item.badge && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `text-[10px] font-semibold px-1.5 py-0.2 rounded-md ${isActive ? "bg-white/20 text-white" : "bg-primary/10 text-primary"}`,
												children: item.badge
											})]
										}, item.path);
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1 pt-3 border-t border-border/60",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "px-3 text-[10px] font-bold uppercase tracking-wider text-muted-foreground/80",
											children: "Account"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
											to: "/profile",
											onClick: () => setSidebarOpen(false),
											className: `flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium transition-colors ${currentPath === "/profile" ? "bg-primary text-primary-foreground font-semibold shadow-xs" : "text-muted-foreground hover:text-foreground hover:bg-accent/60"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: getTranslation(currentLang, "profile") })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
											to: "/settings",
											onClick: () => setSidebarOpen(false),
											className: `flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium transition-colors ${currentPath === "/settings" ? "bg-primary text-primary-foreground font-semibold shadow-xs" : "text-muted-foreground hover:text-foreground hover:bg-accent/60"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: getTranslation(currentLang, "settings") })]
										})
									]
								})
							]
						})
					}),
					sidebarOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						onClick: () => setSidebarOpen(false),
						className: "fixed inset-0 z-20 bg-background/80 backdrop-blur-xs lg:hidden"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
						className: "flex-1 w-full p-4 sm:p-6 lg:p-8 pb-24 lg:pb-12 max-w-5xl",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "lg:hidden fixed bottom-0 left-0 right-0 z-30 bg-card/95 backdrop-blur-xl border-t border-border flex items-center justify-around py-2 px-3 shadow-lg",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/dashboard",
						className: `flex flex-col items-center gap-1 text-[10px] font-medium ${currentPath === "/dashboard" ? "text-primary font-bold" : "text-muted-foreground"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Home" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/careers",
						className: `flex flex-col items-center gap-1 text-[10px] font-medium ${currentPath.startsWith("/careers") ? "text-primary font-bold" : "text-muted-foreground"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Careers" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setShowChatbot(true),
						className: "flex flex-col items-center justify-center -mt-5 size-12 rounded-full gradient-brand text-primary-foreground shadow-glow cursor-pointer",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bot, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/exams",
						className: `flex flex-col items-center gap-1 text-[10px] font-medium ${currentPath.startsWith("/exams") ? "text-primary font-bold" : "text-muted-foreground"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Exams" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/study-planner",
						className: `flex flex-col items-center gap-1 text-[10px] font-medium ${currentPath.startsWith("/study-planner") ? "text-primary font-bold" : "text-muted-foreground"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Study" })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GlobalSearchModal, {
				open: showSearch,
				onOpenChange: setShowSearch
			}),
			showChatbot && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: showChatbot,
				onOpenChange: setShowChatbot,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
					className: "max-w-md p-0 border-0 bg-transparent shadow-none",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CareerChatbot, { onClose: () => setShowChatbot(false) })
				})
			})
		]
	});
}
//#endregion
export { AuthenticatedLayout as component };
