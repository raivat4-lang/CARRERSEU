globalThis.__nitro_main__ = import.meta.url;
import { n as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/assets/admin-content-store-C8pQ1fgc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3068-3ea/WNcKIk2Jnh7Ke82e2EPZU1E\"",
		"mtime": "2026-09-19T13:41:19.240Z",
		"size": 12392,
		"path": "../public/assets/admin-content-store-C8pQ1fgc.js"
	},
	"/assets/admin.first-setup-DyXPTA0Q.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1dd6-Pk8XAvXpYKNO5q11RCvJp3PyMDE\"",
		"mtime": "2026-09-19T13:41:19.241Z",
		"size": 7638,
		"path": "../public/assets/admin.first-setup-DyXPTA0Q.js"
	},
	"/assets/admin.forgot-password-B5pheoXF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2a8d-/6UatL/dK1vs9Xry+615wbBkAO8\"",
		"mtime": "2026-09-19T13:41:19.241Z",
		"size": 10893,
		"path": "../public/assets/admin.forgot-password-B5pheoXF.js"
	},
	"/assets/admin.dashboard-O-6vdH05.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d0-OilTpSp+m57eVIE5VHsI9XwVEnI\"",
		"mtime": "2026-09-19T13:41:19.241Z",
		"size": 208,
		"path": "../public/assets/admin.dashboard-O-6vdH05.js"
	},
	"/favicon.svg": {
		"type": "image/svg+xml",
		"etag": "\"30c-h9L23HoPfClfUf3iLf1F2JurIRU\"",
		"mtime": "2026-09-16T13:24:13.664Z",
		"size": 780,
		"path": "../public/favicon.svg"
	},
	"/assets/admin.login-BEckIw1b.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"23af-tMRTtFgoUeF+InWRs0PAo6Bmdts\"",
		"mtime": "2026-09-19T13:41:19.244Z",
		"size": 9135,
		"path": "../public/assets/admin.login-BEckIw1b.js"
	},
	"/assets/admin.signup-8incsPst.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5dfd-JyfQm1h5nyOxhOIVHfHSKEX+FQY\"",
		"mtime": "2026-09-19T13:41:19.244Z",
		"size": 24061,
		"path": "../public/assets/admin.signup-8incsPst.js"
	},
	"/assets/admin-C3A2gkZB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1cd92-plTnBZcvTQYptVgj/0by2pvvqj4\"",
		"mtime": "2026-09-19T13:41:19.240Z",
		"size": 118162,
		"path": "../public/assets/admin-C3A2gkZB.js"
	},
	"/assets/admin.verify-mfa-DSi5GsmW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2f42-2Q6fsinZkeC4djP7nrO0MjwImdM\"",
		"mtime": "2026-09-19T13:41:19.245Z",
		"size": 12098,
		"path": "../public/assets/admin.verify-mfa-DSi5GsmW.js"
	},
	"/assets/admin.reset-password-nr6_IO2E.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a9-OaoKy2P8fBfzvQy/tuzDTdvgW5k\"",
		"mtime": "2026-09-19T13:41:19.244Z",
		"size": 169,
		"path": "../public/assets/admin.reset-password-nr6_IO2E.js"
	},
	"/assets/arrow-left-Dn5nYYJB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9b-DXBWYaDJz/YTMfvEdMwwyMKeyjg\"",
		"mtime": "2026-09-19T13:41:19.245Z",
		"size": 155,
		"path": "../public/assets/arrow-left-Dn5nYYJB.js"
	},
	"/assets/arrow-right-BEPWhoGI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9b-sBleKNufArjtAysK2DRhamprZpQ\"",
		"mtime": "2026-09-19T13:41:19.245Z",
		"size": 155,
		"path": "../public/assets/arrow-right-BEPWhoGI.js"
	},
	"/assets/assessment-jIUWsRfN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"191e-/EGo8UtMNSQaad8DXy4K4auqAuk\"",
		"mtime": "2026-09-19T13:41:19.246Z",
		"size": 6430,
		"path": "../public/assets/assessment-jIUWsRfN.js"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-09-16T13:24:13.696Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/assets/assessment-questions-BB4nJHoL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2c85-+T6olnYUdJCkeZXL7MhVd+14KZI\"",
		"mtime": "2026-09-19T13:41:19.246Z",
		"size": 11397,
		"path": "../public/assets/assessment-questions-BB4nJHoL.js"
	},
	"/assets/assessment-results-uCXU3PvU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"22ba-3jtZT4zjzb0y5bNh6I6QTNyNpXk\"",
		"mtime": "2026-09-19T13:41:19.246Z",
		"size": 8890,
		"path": "../public/assets/assessment-results-uCXU3PvU.js"
	},
	"/assets/bell-DgI6jO5x.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"118-I7dI39IRM/ARuVd+YIetKVe3ZMw\"",
		"mtime": "2026-09-19T13:41:19.249Z",
		"size": 280,
		"path": "../public/assets/bell-DgI6jO5x.js"
	},
	"/assets/book-open-C9DL596P.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10d-rPTZhxRlSmHe8n/4y9zs1f1BNZI\"",
		"mtime": "2026-09-19T13:41:19.250Z",
		"size": 269,
		"path": "../public/assets/book-open-C9DL596P.js"
	},
	"/assets/auth.callback-D5s7V1n2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f00-c1vjzq8tDJmFMReSOPTAWQIRso0\"",
		"mtime": "2026-09-19T13:41:19.249Z",
		"size": 3840,
		"path": "../public/assets/auth.callback-D5s7V1n2.js"
	},
	"/assets/briefcase-tU36ioOU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d2-QYxXbruR7ufx/xDkHRCZ1Me3X2M\"",
		"mtime": "2026-09-19T13:41:19.251Z",
		"size": 210,
		"path": "../public/assets/briefcase-tU36ioOU.js"
	},
	"/assets/auth-CTwF39-2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"14117-2HeiIdareDi1XjPEPfcRDwyKU0g\"",
		"mtime": "2026-09-19T13:41:19.247Z",
		"size": 82199,
		"path": "../public/assets/auth-CTwF39-2.js"
	},
	"/assets/bookmarks-CKax3XV-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ce4-4maJKOtRmmNq3dywD6c8xsGdxr4\"",
		"mtime": "2026-09-19T13:41:19.251Z",
		"size": 7396,
		"path": "../public/assets/bookmarks-CKax3XV-.js"
	},
	"/assets/calendar-B3yQQbgm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f7-mBXpxQalhMfEWCxJb4OJ/fOLzJw\"",
		"mtime": "2026-09-19T13:41:19.269Z",
		"size": 247,
		"path": "../public/assets/calendar-B3yQQbgm.js"
	},
	"/assets/card-BB7CDD3N.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7ecd-+8UHWYqaPah62dWXfS/CXscYpYM\"",
		"mtime": "2026-09-19T13:41:19.270Z",
		"size": 32461,
		"path": "../public/assets/card-BB7CDD3N.js"
	},
	"/assets/building-2-BLh0mOVw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"175-52riPyqarP3K/K2ZFOK1n37TkCA\"",
		"mtime": "2026-09-19T13:41:19.253Z",
		"size": 373,
		"path": "../public/assets/building-2-BLh0mOVw.js"
	},
	"/assets/careers-D6FA3rYU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4159-7RcKhxO/LKRJ/Pbkb7M2hOmV50M\"",
		"mtime": "2026-09-19T13:41:19.270Z",
		"size": 16729,
		"path": "../public/assets/careers-D6FA3rYU.js"
	},
	"/assets/careersetu-store-BUGn49kH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"236b-3YRoRXn8WClGhlzVl2IWSLVZdRQ\"",
		"mtime": "2026-09-19T13:41:19.271Z",
		"size": 9067,
		"path": "../public/assets/careersetu-store-BUGn49kH.js"
	},
	"/assets/chevron-down-C_dO9U1q.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"76-keMC3ofL6gv5xQWDGezL0Stdft0\"",
		"mtime": "2026-09-19T13:41:19.272Z",
		"size": 118,
		"path": "../public/assets/chevron-down-C_dO9U1q.js"
	},
	"/assets/circle-alert-CJDau4Dt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f0-CuLv5ca91+Yr7CJ3Ni3lrqXSrK4\"",
		"mtime": "2026-09-19T13:41:19.272Z",
		"size": 240,
		"path": "../public/assets/circle-alert-CJDau4Dt.js"
	},
	"/assets/circle-question-mark-BknLfVYu.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ee-1f8/jMKHlh9+F64G8I0pzPClX3Y\"",
		"mtime": "2026-09-19T13:41:19.273Z",
		"size": 238,
		"path": "../public/assets/circle-question-mark-BknLfVYu.js"
	},
	"/assets/colleges-ClsdL4vH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1b5b-i5G4Y1rcORRAP4M16fuOoLc8oJI\"",
		"mtime": "2026-09-19T13:41:19.273Z",
		"size": 7003,
		"path": "../public/assets/colleges-ClsdL4vH.js"
	},
	"/assets/clock-COcvnknD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9f-os5ZwtCwR01F81iSn1xFSNnUE3A\"",
		"mtime": "2026-09-19T13:41:19.273Z",
		"size": 159,
		"path": "../public/assets/clock-COcvnknD.js"
	},
	"/assets/compass-CEolWXNF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f1-gZU3BZQjPqAlyjYBEq9sQjP+N1c\"",
		"mtime": "2026-09-19T13:41:19.274Z",
		"size": 241,
		"path": "../public/assets/compass-CEolWXNF.js"
	},
	"/assets/colleges-data-1OIOuAi2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d7a2-b+pXXnhfQE0L31tAGI/FlV7VjF0\"",
		"mtime": "2026-09-19T13:41:19.274Z",
		"size": 55202,
		"path": "../public/assets/colleges-data-1OIOuAi2.js"
	},
	"/assets/dist-6XRCsHSn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"32f0-cUxADgrvCJuHqqVaBYNvJFJRzuU\"",
		"mtime": "2026-09-19T13:41:19.275Z",
		"size": 13040,
		"path": "../public/assets/dist-6XRCsHSn.js"
	},
	"/assets/dist-CxQLMtpZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6fd-uF5u7ekvcCGTygHAB24UYPKaK4c\"",
		"mtime": "2026-09-19T13:41:19.276Z",
		"size": 1789,
		"path": "../public/assets/dist-CxQLMtpZ.js"
	},
	"/assets/dist-D02EahZX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2da-z8tNv/mZK0shFaqa7q/JyAqk31o\"",
		"mtime": "2026-09-19T13:41:19.276Z",
		"size": 730,
		"path": "../public/assets/dist-D02EahZX.js"
	},
	"/assets/dist-DaMJBOOH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b31-rtIyR+vN1hTrHdF77hoP7Medz+E\"",
		"mtime": "2026-09-19T13:41:19.277Z",
		"size": 2865,
		"path": "../public/assets/dist-DaMJBOOH.js"
	},
	"/assets/external-link-D0we04BV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f1-NCTRz6eriWYURJMJ59rKYj2syhA\"",
		"mtime": "2026-09-19T13:41:19.278Z",
		"size": 241,
		"path": "../public/assets/external-link-D0we04BV.js"
	},
	"/assets/exams-CuOe5mWn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"30f4-eg+7XqcMcLTF+a7ZdY7TSA40m8Y\"",
		"mtime": "2026-09-19T13:41:19.277Z",
		"size": 12532,
		"path": "../public/assets/exams-CuOe5mWn.js"
	},
	"/assets/exams-data-BmssMpcg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"34d1-22oli76IXajfKxFR46qjJcm1eZc\"",
		"mtime": "2026-09-19T13:41:19.278Z",
		"size": 13521,
		"path": "../public/assets/exams-data-BmssMpcg.js"
	},
	"/assets/eye-off-Dc1BvVX2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1a4-q46jESXmlqC+6O/a781oK0TnZBc\"",
		"mtime": "2026-09-19T13:41:19.279Z",
		"size": 420,
		"path": "../public/assets/eye-off-Dc1BvVX2.js"
	},
	"/assets/eye-BLih-J1n.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f6-Q3FI36cwmhZ/LrX8ktnhi33/KEs\"",
		"mtime": "2026-09-19T13:41:19.279Z",
		"size": 246,
		"path": "../public/assets/eye-BLih-J1n.js"
	},
	"/assets/file-text-BEbVpH8I.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"177-/LBeG2erVQROUzY1NbZfIdHLYp4\"",
		"mtime": "2026-09-19T13:41:19.279Z",
		"size": 375,
		"path": "../public/assets/file-text-BEbVpH8I.js"
	},
	"/assets/flame-Dq78G3U4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"bd-hiSyKQODK63O/CeOMEsxfqq0hKE\"",
		"mtime": "2026-09-19T13:41:19.280Z",
		"size": 189,
		"path": "../public/assets/flame-Dq78G3U4.js"
	},
	"/assets/invariant-DEEwAagU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3c-eVh/3DMi1s3cxf4N/OJar+ew1jA\"",
		"mtime": "2026-09-19T13:41:19.280Z",
		"size": 60,
		"path": "../public/assets/invariant-DEEwAagU.js"
	},
	"/assets/jsx-runtime-0vZSBttN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1a8-DT21o0DVEenQwk6wXcylq/J4hZA\"",
		"mtime": "2026-09-19T13:41:19.280Z",
		"size": 424,
		"path": "../public/assets/jsx-runtime-0vZSBttN.js"
	},
	"/assets/key-round-BlZbh3FD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"159-7/3Ri9nS7HFN7u0xZUqcrRgdMcs\"",
		"mtime": "2026-09-19T13:41:19.281Z",
		"size": 345,
		"path": "../public/assets/key-round-BlZbh3FD.js"
	},
	"/assets/index-Bvx_0a4f.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1026b9-vecPj63Ue1f2qMOAlGpGD4zPJ8o\"",
		"mtime": "2026-09-19T13:41:19.238Z",
		"size": 1058489,
		"path": "../public/assets/index-Bvx_0a4f.js"
	},
	"/assets/hero-career-D_dFKTNC.png": {
		"type": "image/png",
		"etag": "\"154e2a-GAjpDX61F9nprhxugaCtEzxR8WQ\"",
		"mtime": "2026-09-19T13:41:19.295Z",
		"size": 1396266,
		"path": "../public/assets/hero-career-D_dFKTNC.png"
	},
	"/assets/label-BXcizJ9S.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2be-S7yd326xPK2eImBwrLuX6PocRl4\"",
		"mtime": "2026-09-19T13:41:19.281Z",
		"size": 702,
		"path": "../public/assets/label-BXcizJ9S.js"
	},
	"/assets/link-00_398TT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5930-wt18uUaUQvOC/bBdfT8Yv5UeuJQ\"",
		"mtime": "2026-09-19T13:41:19.282Z",
		"size": 22832,
		"path": "../public/assets/link-00_398TT.js"
	},
	"/assets/loader-circle-dfnGM31Q.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"86-e6pSQthIASFZSzw0x/46d4c1PD4\"",
		"mtime": "2026-09-19T13:41:19.282Z",
		"size": 134,
		"path": "../public/assets/loader-circle-dfnGM31Q.js"
	},
	"/assets/lock-CbGycxOR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c4-FRNxM7h4ZKLl3RmtoPJs+9p++HE\"",
		"mtime": "2026-09-19T13:41:19.283Z",
		"size": 196,
		"path": "../public/assets/lock-CbGycxOR.js"
	},
	"/assets/Logo-CMwvEJ8R.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4e0-HyoFKDnjSsnlliG5XesHQMwXcJo\"",
		"mtime": "2026-09-19T13:41:19.239Z",
		"size": 1248,
		"path": "../public/assets/Logo-CMwvEJ8R.js"
	},
	"/assets/menu-Rd8_TGju.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b3-kb2CDjVjSEvzBL7tKsM+wAwHz/U\"",
		"mtime": "2026-09-19T13:41:19.283Z",
		"size": 179,
		"path": "../public/assets/menu-Rd8_TGju.js"
	},
	"/assets/mail-CxQAHNNm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cb-jRqIlwEi/fK2DtPI5h/Xpnt7n58\"",
		"mtime": "2026-09-19T13:41:19.283Z",
		"size": 203,
		"path": "../public/assets/mail-CxQAHNNm.js"
	},
	"/assets/profile-BQzbQfea.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1777-kEspSkXQsYTciYCJUJ7KL5VwvmI\"",
		"mtime": "2026-09-19T13:41:19.284Z",
		"size": 6007,
		"path": "../public/assets/profile-BQzbQfea.js"
	},
	"/assets/react-SIfiwpqq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ff9-FGVdof4/lFGmrdRsB9EIvuwBlYc\"",
		"mtime": "2026-09-19T13:41:19.284Z",
		"size": 8185,
		"path": "../public/assets/react-SIfiwpqq.js"
	},
	"/assets/progress-BVzgK7HN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1c0e-mTkozNnhuKOrVU8hxXLsWKR9N3w\"",
		"mtime": "2026-09-19T13:41:19.284Z",
		"size": 7182,
		"path": "../public/assets/progress-BVzgK7HN.js"
	},
	"/assets/refresh-cw-CyIkjZeM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"137-avfF0fQO+/tMTjAQMJ6b/vieIS0\"",
		"mtime": "2026-09-19T13:41:19.285Z",
		"size": 311,
		"path": "../public/assets/refresh-cw-CyIkjZeM.js"
	},
	"/assets/resources-D0AdgYPo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1897-sQXkqh7AX97lNhqvOP6JKzoqQsk\"",
		"mtime": "2026-09-19T13:41:19.285Z",
		"size": 6295,
		"path": "../public/assets/resources-D0AdgYPo.js"
	},
	"/assets/resume-CJxqivw2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3ae8-1DDAg8XZn7gslnsbMgyYNxJs0oc\"",
		"mtime": "2026-09-19T13:41:19.285Z",
		"size": 15080,
		"path": "../public/assets/resume-CJxqivw2.js"
	},
	"/assets/rotate-ccw-C3TgJiXB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"be-IN4JC3ZUvFCShwKDdH0KtW+mBRs\"",
		"mtime": "2026-09-19T13:41:19.286Z",
		"size": 190,
		"path": "../public/assets/rotate-ccw-C3TgJiXB.js"
	},
	"/assets/routes-DBgtXAN9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d783-W4ryyXXVm8WQXdbQIry562AEyWI\"",
		"mtime": "2026-09-19T13:41:19.287Z",
		"size": 55171,
		"path": "../public/assets/routes-DBgtXAN9.js"
	},
	"/assets/route-Lxhw1QYN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1476f-WblT5w5vT7tsbadfwmKtYysasgY\"",
		"mtime": "2026-09-19T13:41:19.286Z",
		"size": 83823,
		"path": "../public/assets/route-Lxhw1QYN.js"
	},
	"/assets/save-Cds0NNFH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13d-66GjpTWj8JuyHvmgTAzZkQ/Me3M\"",
		"mtime": "2026-09-19T13:41:19.287Z",
		"size": 317,
		"path": "../public/assets/save-Cds0NNFH.js"
	},
	"/assets/settings-DCsX1HL_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"29fb-dPtzCpJ2059HmxAeMrBjG5g0yxI\"",
		"mtime": "2026-09-19T13:41:19.288Z",
		"size": 10747,
		"path": "../public/assets/settings-DCsX1HL_.js"
	},
	"/assets/scholarships-h6-WKnvl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1871-SSlmhRIiGig/hmE0YfVktmHgaqA\"",
		"mtime": "2026-09-19T13:41:19.287Z",
		"size": 6257,
		"path": "../public/assets/scholarships-h6-WKnvl.js"
	},
	"/assets/select-BrfgtSk_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"bd78-CheLcB5neQRoqIUqNDURncocavQ\"",
		"mtime": "2026-09-19T13:41:19.288Z",
		"size": 48504,
		"path": "../public/assets/select-BrfgtSk_.js"
	},
	"/assets/settings-DWQVU4K3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"29a-VrXzRbLUlYA09Ezv4pghs7r6stE\"",
		"mtime": "2026-09-19T13:41:19.288Z",
		"size": 666,
		"path": "../public/assets/settings-DWQVU4K3.js"
	},
	"/assets/shield-alert-CcfBXc2S.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"157-C13Gs7+S2yjRxzq/ny4ZyDZqkA8\"",
		"mtime": "2026-09-19T13:41:19.288Z",
		"size": 343,
		"path": "../public/assets/shield-alert-CcfBXc2S.js"
	},
	"/assets/shield-bTReFHjo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"106-keQMYp20pnzIaZmxZLglWEYIdXI\"",
		"mtime": "2026-09-19T13:41:19.289Z",
		"size": 262,
		"path": "../public/assets/shield-bTReFHjo.js"
	},
	"/assets/shield-check-Vfuvg4nz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"136-ApS7+jDjoNNasxVSOfnvNVQFxIc\"",
		"mtime": "2026-09-19T13:41:19.289Z",
		"size": 310,
		"path": "../public/assets/shield-check-Vfuvg4nz.js"
	},
	"/assets/skill-gap-b6WN9XCo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1a09-9dyrIESoFThZq+3wwYKOnA7+pMs\"",
		"mtime": "2026-09-19T13:41:19.289Z",
		"size": 6665,
		"path": "../public/assets/skill-gap-b6WN9XCo.js"
	},
	"/assets/star-BNOLLNP6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ce-dMjuoFEI22S6mUHwdAEQlqyB2dg\"",
		"mtime": "2026-09-19T13:41:19.290Z",
		"size": 462,
		"path": "../public/assets/star-BNOLLNP6.js"
	},
	"/assets/student.login-UhYpwD0Q.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e31-QdzKLdAKvj5tonfvwe8VjrPj+Ws\"",
		"mtime": "2026-09-19T13:41:19.290Z",
		"size": 7729,
		"path": "../public/assets/student.login-UhYpwD0Q.js"
	},
	"/assets/student.dashboard-B8IUsXAs.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d4-4pMJNdthGYfQYq2IFCrrjVW5u5g\"",
		"mtime": "2026-09-19T13:41:19.290Z",
		"size": 212,
		"path": "../public/assets/student.dashboard-B8IUsXAs.js"
	},
	"/assets/student.signup-C7hiUeYb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3180-jbqnMhWNbOwZ0BEPpsBkDw8A+I0\"",
		"mtime": "2026-09-19T13:41:19.291Z",
		"size": 12672,
		"path": "../public/assets/student.signup-C7hiUeYb.js"
	},
	"/assets/student.verify-mfa-BBc8dgIZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"310f-dAyP7nOTiAPPSAgEBO6Sf/QWW34\"",
		"mtime": "2026-09-19T13:41:19.291Z",
		"size": 12559,
		"path": "../public/assets/student.verify-mfa-BBc8dgIZ.js"
	},
	"/assets/study-planner--3AK0OnB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2a9a-KW5PlLZEXCrxHTJW0wZCVhzc5bo\"",
		"mtime": "2026-09-19T13:41:19.291Z",
		"size": 10906,
		"path": "../public/assets/study-planner--3AK0OnB.js"
	},
	"/assets/sun-Dk7zMYoC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"272-ttkeDEGffzuQ5M16sv4IMCZA4Lk\"",
		"mtime": "2026-09-19T13:41:19.292Z",
		"size": 626,
		"path": "../public/assets/sun-Dk7zMYoC.js"
	},
	"/assets/trending-up-D6CurdqJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-afCGUoLJjp4ZtGHPCTwR+EC4C/o\"",
		"mtime": "2026-09-19T13:41:19.292Z",
		"size": 165,
		"path": "../public/assets/trending-up-D6CurdqJ.js"
	},
	"/assets/styles-nKVPTVeb.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"2407c-LhoCEH/5k2OguvzBkV9msAY8CTQ\"",
		"mtime": "2026-09-19T13:41:19.295Z",
		"size": 147580,
		"path": "../public/assets/styles-nKVPTVeb.css"
	},
	"/assets/user-check-Nd6eRP8K.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e9-+WFwI6ddWvrYtO2AP3l3N+mGBZ0\"",
		"mtime": "2026-09-19T13:41:19.293Z",
		"size": 233,
		"path": "../public/assets/user-check-Nd6eRP8K.js"
	},
	"/assets/user-CPmcM1lX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ba-wOPOcHsdBZiT05UjvPVOKMr4/fQ\"",
		"mtime": "2026-09-19T13:41:19.293Z",
		"size": 186,
		"path": "../public/assets/user-CPmcM1lX.js"
	},
	"/assets/trophy-gTB8pQE1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d2-Ves8lQMKlBJKUynxtBgdFBBozjE\"",
		"mtime": "2026-09-19T13:41:19.292Z",
		"size": 466,
		"path": "../public/assets/trophy-gTB8pQE1.js"
	},
	"/assets/user-plus-CcHkKspJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"12c-xnm11g2mWUPwZfTEWNvakOURynM\"",
		"mtime": "2026-09-19T13:41:19.294Z",
		"size": 300,
		"path": "../public/assets/user-plus-CcHkKspJ.js"
	},
	"/assets/useRouter-BOIK_ctv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2a7-0ptir6rquYtCnkF9MtfZcx4hK0s\"",
		"mtime": "2026-09-19T13:41:19.293Z",
		"size": 679,
		"path": "../public/assets/useRouter-BOIK_ctv.js"
	},
	"/assets/zap-D6yiHB6h.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fc-0CEDxV4nsCVf6t02d630STGNh/0\"",
		"mtime": "2026-09-19T13:41:19.294Z",
		"size": 252,
		"path": "../public/assets/zap-D6yiHB6h.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_3rWQ8V = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_3rWQ8V
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
