import { i as __toESM } from "../_runtime.mjs";
import { g as Link, v as useNavigate, y as useSearch } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as registerStudentUser, g as getUserByEmail, l as createAndDispatchMfaCode, n as authenticateStudent, s as completeStudentMfaLogin, x as initiateStudentLogin } from "./rbac-D_Rf6U5V.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Card } from "./card-95-PmP7N.mjs";
import { t as Button } from "./button-CdcMTBqt.mjs";
import { B as LoaderCircle, E as RefreshCw, I as Mail, Mt as ArrowRight, Nt as ArrowLeft, c as UserCheck, g as Sparkles, ht as CircleAlert, pt as CircleCheck, z as Lock } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-D7UBWI0-.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-mEmCUBpO.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Logo } from "./Logo-CGI7av7x.mjs";
import { t as Label } from "./label-DiINKb2h.mjs";
import { i as LANGUAGES, n as GENDERS, r as INDIAN_STATES, t as EDUCATION_LEVELS } from "./options-f9ysKH3u.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-BfMpEmcB.mjs";
import { n as objectType, r as stringType, t as coerce } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-BNu5LqbP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var signupSchema = objectType({
	full_name: stringType().trim().min(2, "Enter your full name").max(80),
	email: stringType().trim().email("Enter a valid email").max(255),
	password: stringType().min(6, "Password must be at least 6 characters").max(72),
	phone: stringType().trim().regex(/^[0-9]{10}$/, "Enter a 10 digit phone number"),
	age: coerce.number().int().min(12, "Age must be 12 or above").max(60),
	gender: stringType().min(1, "Select your gender"),
	state: stringType().min(1, "Select your state"),
	city: stringType().trim().min(2, "Enter your city").max(60),
	current_education: stringType().min(1, "Select your current education"),
	preferred_language: stringType().min(1, "Select a language")
});
var GOOGLE_CLIENT_ID = {
	"BASE_URL": "/",
	"DEV": false,
	"MODE": "production",
	"PROD": true,
	"SSR": true,
	"TSS_DEV_SERVER": "false",
	"TSS_DEV_SSR_STYLES_BASEPATH": "/",
	"TSS_DEV_SSR_STYLES_ENABLED": "true",
	"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
	"TSS_INLINE_CSS_ENABLED": "false",
	"TSS_ROUTER_BASEPATH": "",
	"TSS_SERVER_FN_BASE": "/_serverFn/",
	"VITE_GOOGLE_CLIENT_ID": "781343883716-k395k1cpf5ehccrardlrt2kj33m9qk06.apps.googleusercontent.com",
	"VITE_SUPABASE_PROJECT_ID": "hywynexgmdtpeqpuwjir",
	"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_9sNJVlPWSR48ulY_7DNCZA_c85VMMS8",
	"VITE_SUPABASE_URL": "https://hywynexgmdtpeqpuwjir.supabase.co"
}["VITE_GOOGLE_CLIENT_ID"];
function GoogleButton({ label }) {
	const navigate = useNavigate();
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [showSetup, setShowSetup] = (0, import_react.useState)(false);
	const handleGoogleLogin = async () => {
		if (!GOOGLE_CLIENT_ID) {
			setShowSetup((v) => !v);
			return;
		}
		setLoading(true);
		try {
			await loadGsiScript();
			if (window.google?.accounts?.oauth2?.initTokenClient) {
				window.google.accounts.oauth2.initTokenClient({
					client_id: GOOGLE_CLIENT_ID,
					scope: "email profile openid",
					callback: async (tokenResponse) => {
						if (tokenResponse.error) {
							if (tokenResponse.error !== "popup_closed_by_user") toast.error(`Google sign-in error: ${tokenResponse.error}`);
							setLoading(false);
							return;
						}
						try {
							const payload = await (await fetch("https://www.googleapis.com/oauth2/v3/userinfo", { headers: { Authorization: `Bearer ${tokenResponse.access_token}` } })).json();
							if (!payload?.email) {
								toast.error("Google sign-in failed: could not read your email.");
								setLoading(false);
								return;
							}
							const { setCurrentUser } = await import("./rbac-D_Rf6U5V.mjs").then((n) => n.T);
							setCurrentUser({
								id: `google-${payload.sub}`,
								name: payload.name || payload.email.split("@")[0],
								full_name: payload.name || payload.email.split("@")[0],
								email: payload.email,
								password_hash: null,
								role: "STUDENT",
								is_active: true,
								status: "ACTIVE",
								email_verified: true,
								is_first_login: false,
								preferred_language: "english",
								created_at: (/* @__PURE__ */ new Date()).toISOString(),
								registeredAt: (/* @__PURE__ */ new Date()).toISOString(),
								updated_at: (/* @__PURE__ */ new Date()).toISOString(),
								lastActive: (/* @__PURE__ */ new Date()).toISOString()
							});
							toast.success(`Welcome, ${payload.name || payload.email}!`);
							navigate({ to: "/dashboard" });
						} catch (fetchErr) {
							toast.error("Could not fetch Google profile details.");
							setLoading(false);
						}
					},
					error_callback: (err) => {
						console.error("Google Auth error:", err);
						setLoading(false);
					}
				}).requestAccessToken();
				return;
			}
			window.google.accounts.id.initialize({
				client_id: GOOGLE_CLIENT_ID,
				callback: async (response) => {
					const payload = parseGoogleJwt(response.credential);
					if (!payload?.email) {
						toast.error("Google sign-in failed: could not read your profile.");
						setLoading(false);
						return;
					}
					const { setCurrentUser } = await import("./rbac-D_Rf6U5V.mjs").then((n) => n.T);
					setCurrentUser({
						id: `google-${payload.sub}`,
						name: payload.name || payload.email.split("@")[0],
						full_name: payload.name || payload.email.split("@")[0],
						email: payload.email,
						password_hash: null,
						role: "STUDENT",
						is_active: true,
						status: "ACTIVE",
						email_verified: true,
						is_first_login: false,
						preferred_language: "english",
						created_at: (/* @__PURE__ */ new Date()).toISOString(),
						registeredAt: (/* @__PURE__ */ new Date()).toISOString(),
						updated_at: (/* @__PURE__ */ new Date()).toISOString(),
						lastActive: (/* @__PURE__ */ new Date()).toISOString()
					});
					toast.success(`Welcome, ${payload.name || payload.email}!`);
					navigate({ to: "/dashboard" });
				},
				context: "signin",
				ux_mode: "popup"
			});
			window.google.accounts.id.prompt((notification) => {
				if (notification.isNotDisplayed() || notification.isSkippedMoment()) setLoading(false);
			});
		} catch (err) {
			toast.error(err?.message || "Google sign-in failed.");
			setLoading(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			type: "button",
			variant: "outline",
			id: "google-signin-btn",
			className: "h-11 w-full rounded-2xl gap-2.5 font-medium border-border/80 hover:bg-accent/70 transition-all cursor-pointer shadow-xs",
			disabled: loading,
			onClick: handleGoogleLogin,
			children: [loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
				viewBox: "0 0 24 24",
				className: "size-4 shrink-0",
				"aria-hidden": "true",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						fill: "#4285F4",
						d: "M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						fill: "#34A853",
						d: "M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						fill: "#FBBC05",
						d: "M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						fill: "#EA4335",
						d: "M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
					})
				]
			}), label]
		}), showSetup && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-2xl bg-amber-400/10 border border-amber-400/40 p-3.5 text-xs space-y-2 animate-fade-up",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-bold text-amber-300",
				children: "🔧 Google OAuth Setup (one-time, ~2 min)"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
				className: "text-amber-200/80 space-y-1.5 list-decimal list-inside leading-relaxed",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["Go to ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "https://console.cloud.google.com/apis/credentials",
						target: "_blank",
						rel: "noopener noreferrer",
						className: "underline hover:text-amber-100",
						children: "Google Cloud Console → Credentials"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["Click ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Create Credentials → OAuth 2.0 Client ID → Web Application" })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						"Add ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
							className: "bg-amber-400/20 px-1 rounded",
							children: "http://localhost:8080"
						}),
						" to Authorized JavaScript Origins"
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						"Copy the Client ID, add to ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
							className: "bg-amber-400/20 px-1 rounded",
							children: ".env"
						}),
						":",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
							className: "bg-amber-400/20 px-1 rounded block mt-1 font-mono",
							children: "VITE_GOOGLE_CLIENT_ID=your_id"
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Restart the dev server — Google login works instantly!" })
				]
			})]
		})]
	});
}
function loadGsiScript() {
	return new Promise((resolve, reject) => {
		if (window.google?.accounts?.id) {
			resolve();
			return;
		}
		const existing = document.getElementById("gsi-client-script");
		if (existing) {
			existing.addEventListener("load", () => resolve());
			return;
		}
		const script = document.createElement("script");
		script.id = "gsi-client-script";
		script.src = "https://accounts.google.com/gsi/client";
		script.async = true;
		script.defer = true;
		script.onload = () => resolve();
		script.onerror = () => reject(/* @__PURE__ */ new Error("Could not load Google Sign-In. Check your internet connection."));
		document.head.appendChild(script);
	});
}
function parseGoogleJwt(token) {
	try {
		const payload = token.split(".")[1];
		if (!payload) return null;
		return JSON.parse(atob(payload.replace(/-/g, "+").replace(/_/g, "/")));
	} catch {
		return null;
	}
}
function AuthPage() {
	const { mode } = useSearch({ from: "/auth" });
	const navigate = useNavigate();
	const [loginStep, setLoginStep] = (0, import_react.useState)("CREDENTIALS");
	const [pendingEmail, setPendingEmail] = (0, import_react.useState)("");
	const [maskedEmail, setMaskedEmail] = (0, import_react.useState)("");
	const [otp, setOtp] = (0, import_react.useState)([
		"",
		"",
		"",
		"",
		"",
		""
	]);
	const [otpCode, setOtpCode] = (0, import_react.useState)("");
	const [otpError, setOtpError] = (0, import_react.useState)("");
	const otpRefs = (0, import_react.useRef)([]);
	const [timeLeft, setTimeLeft] = (0, import_react.useState)(600);
	const [resendCooldown, setResendCooldown] = (0, import_react.useState)(45);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [demoLoading, setDemoLoading] = (0, import_react.useState)(false);
	const [errors, setErrors] = (0, import_react.useState)({});
	const [devOtp, setDevOtp] = (0, import_react.useState)();
	(0, import_react.useEffect)(() => {
		if (loginStep !== "OTP" || timeLeft <= 0) return;
		const timer = setInterval(() => setTimeLeft((prev) => Math.max(0, prev - 1)), 1e3);
		return () => clearInterval(timer);
	}, [loginStep, timeLeft]);
	(0, import_react.useEffect)(() => {
		if (loginStep !== "OTP" || resendCooldown <= 0) return;
		const timer = setInterval(() => setResendCooldown((prev) => Math.max(0, prev - 1)), 1e3);
		return () => clearInterval(timer);
	}, [loginStep, resendCooldown]);
	const formatTimer = (seconds) => {
		const mins = Math.floor(seconds / 60);
		const secs = seconds % 60;
		return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
	};
	function handleDemoLogin() {
		setDemoLoading(true);
		const res = authenticateStudent("aditi.kulkarni@gmail.com", "student123");
		if (res.success && res.user) {
			toast.success("Signed in as Demo Student (Aditi Kulkarni)!");
			navigate({ to: "/dashboard" });
		}
		setDemoLoading(false);
	}
	async function handleLoginSubmit(e) {
		e.preventDefault();
		const form = new FormData(e.currentTarget);
		const email = String(form.get("email") ?? "").trim();
		const password = String(form.get("password") ?? "");
		if (!email || !password) {
			toast.error("Please enter both your email and password.");
			return;
		}
		setLoading(true);
		try {
			const res = await initiateStudentLogin(email, password);
			if (res.success) {
				setPendingEmail(email.toLowerCase());
				setMaskedEmail(res.maskedEmail || email);
				setDevOtp(res.devOtp);
				setLoginStep("OTP");
				setTimeLeft(600);
				setResendCooldown(45);
				setOtp([
					"",
					"",
					"",
					"",
					"",
					""
				]);
				setOtpCode("");
				setOtpError("");
				if (typeof sessionStorage !== "undefined") {
					sessionStorage.setItem("careersetu_pending_student_email", email.toLowerCase());
					sessionStorage.setItem("careersetu_pending_student_masked", res.maskedEmail || "");
				}
				toast.success(`Security verification code sent to ${res.maskedEmail || email}.`);
				setTimeout(() => otpRefs.current[0]?.focus(), 150);
			} else toast.error(res.error || "Invalid credentials. Please verify your email and password.");
		} catch {
			toast.error("An unexpected error occurred during authentication.");
		} finally {
			setLoading(false);
		}
	}
	async function handleOtpVerify(e) {
		e.preventDefault();
		const cleanOtp = otp.join("").trim();
		if (!cleanOtp || cleanOtp.length !== 6) {
			setOtpError("Please enter the complete 6-digit verification code.");
			return;
		}
		setLoading(true);
		setOtpError("");
		try {
			const result = await completeStudentMfaLogin(pendingEmail, cleanOtp);
			if (!result.success) {
				setOtpError(result.error || "The verification code is incorrect or has expired.");
				setOtp([
					"",
					"",
					"",
					"",
					"",
					""
				]);
				setTimeout(() => otpRefs.current[0]?.focus(), 50);
				setLoading(false);
				return;
			}
			toast.success(`Welcome back, ${result.user?.name || "Student"}!`);
			navigate({ to: "/dashboard" });
		} catch {
			setOtpError("Verification error. Please try again.");
		} finally {
			setLoading(false);
		}
	}
	async function handleResendCode() {
		if (resendCooldown > 0) return;
		const user = getUserByEmail(pendingEmail);
		if (!user) {
			toast.error("Session expired. Please sign in again.");
			setLoginStep("CREDENTIALS");
			return;
		}
		setLoading(true);
		setOtp([
			"",
			"",
			"",
			"",
			"",
			""
		]);
		setOtpError("");
		try {
			const dispatch = await createAndDispatchMfaCode(user, "LOGIN");
			setTimeLeft(600);
			setResendCooldown(45);
			if (dispatch.devOtp) setDevOtp(dispatch.devOtp);
			toast.success("A fresh verification code has been dispatched to your email.");
			setTimeout(() => otpRefs.current[0]?.focus(), 100);
		} catch {
			toast.error("Failed to resend code. Please try again in a few moments.");
		} finally {
			setLoading(false);
		}
	}
	async function handleSignup(e) {
		e.preventDefault();
		const form = Object.fromEntries(new FormData(e.currentTarget).entries());
		const parsed = signupSchema.safeParse(form);
		if (!parsed.success) {
			const fieldErrors = {};
			for (const issue of parsed.error.issues) fieldErrors[String(issue.path[0])] = issue.message;
			setErrors(fieldErrors);
			return;
		}
		setErrors({});
		setLoading(true);
		const { email, password, ...meta } = parsed.data;
		try {
			const res = await registerStudentUser({
				email,
				password,
				name: meta.full_name,
				full_name: meta.full_name,
				phone: meta.phone,
				age: String(meta.age),
				gender: meta.gender,
				state: meta.state,
				city: meta.city,
				education: meta.current_education,
				current_education: meta.current_education,
				preferred_language: meta.preferred_language
			});
			if (res.success && res.user) {
				setPendingEmail(email.toLowerCase());
				setMaskedEmail(email);
				setLoginStep("OTP");
				setTimeLeft(600);
				setResendCooldown(45);
				if (typeof sessionStorage !== "undefined") sessionStorage.setItem("careersetu_pending_student_email", email.toLowerCase());
				toast.success(`Account registered! Verification code sent to ${email}.`);
			} else toast.error(res.error || "Could not complete registration.");
		} catch {
			toast.error("Failed to complete registration.");
		} finally {
			setLoading(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background text-foreground relative overflow-hidden flex flex-col justify-between px-4 py-8 sm:py-12 antialiased",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gradient-soft absolute inset-0 -z-10 opacity-70" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "blueprint-grid absolute inset-0 -z-10 opacity-40" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -top-32 left-1/2 -translate-x-1/2 -z-10 size-[36rem] rounded-full bg-primary/12 blur-[140px] pointer-events-none" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -bottom-20 right-1/4 -z-10 size-[24rem] rounded-full bg-violet/10 blur-[100px] pointer-events-none" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto w-full max-w-lg",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "mb-6 flex justify-center transition-transform hover:scale-105",
						"aria-label": "CareerSetu home",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { size: "lg" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 rounded-2xl bg-card/80 border border-primary/25 p-3.5 flex items-center justify-between text-xs sm:text-sm backdrop-blur-md shadow-soft",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-7 place-items-center rounded-xl bg-primary/10 text-primary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4 text-primary" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium text-foreground text-xs sm:text-sm",
								children: "Instant evaluation demo mode"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							onClick: handleDemoLogin,
							disabled: demoLoading,
							className: "gradient-brand text-primary-foreground text-xs rounded-xl h-8 px-3.5 shrink-0 shadow-glow font-semibold cursor-pointer",
							children: [demoLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3 animate-spin mr-1" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "size-3.5 mr-1" }), "Demo Login"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: "glass rounded-3xl p-6 sm:p-8 shadow-elegant border-border/80 backdrop-blur-xl",
						children: loginStep === "OTP" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-5 animate-fade-up",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between pb-4 border-b border-border/80",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "grid size-11 place-items-center rounded-2xl bg-primary/10 text-primary border border-primary/20 shadow-xs",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-5 text-primary" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
											className: "text-xl font-bold font-display text-foreground",
											children: "Email Security Code"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-muted-foreground",
											children: "Step 2: Enter 6-digit verification code"
										})] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										variant: "ghost",
										size: "sm",
										onClick: () => {
											setLoginStep("CREDENTIALS");
											setOtp([
												"",
												"",
												"",
												"",
												"",
												""
											]);
											setOtpError("");
										},
										className: "h-8 px-2.5 text-xs text-muted-foreground hover:text-foreground rounded-xl cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-3.5 mr-1" }), " Back"]
									})]
								}),
								devOtp && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-2xl border border-amber-400/50 bg-amber-400/10 p-3.5 flex items-start gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-amber-400 text-lg leading-none mt-0.5",
										children: "🔧"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-bold text-amber-300 mb-1",
											children: "Dev Mode — OTP (no SMTP configured)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-mono text-2xl font-black tracking-[0.35em] text-amber-200 select-all",
											children: devOtp
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[10px] text-amber-400/70 mt-1",
											children: "This banner is hidden when real email delivery is active."
										})
									] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3.5 rounded-2xl bg-accent/40 border border-border/70 text-xs space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-muted-foreground",
										children: "A 6-digit single-use security code was generated on the backend and sent to:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-mono font-bold text-primary text-sm tracking-wide",
										children: maskedEmail || pendingEmail
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
									onSubmit: handleOtpVerify,
									className: "space-y-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between mb-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-xs font-semibold text-foreground",
													children: "Enter 6-Digit Code"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: `text-[11px] font-mono tabular-nums ${timeLeft <= 60 ? "text-red-400" : "text-muted-foreground"}`,
													children: timeLeft > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Expires in ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
														className: timeLeft <= 60 ? "text-red-400" : "text-amber-500",
														children: formatTimer(timeLeft)
													})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-red-400 font-semibold",
														children: "Code expired"
													})
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "flex gap-2 sm:gap-2.5 justify-center",
												onPaste: (e) => {
													e.preventDefault();
													const pasted = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, 6);
													if (!pasted) return;
													const digits = pasted.split("");
													const newOtp = Array.from({ length: 6 }, (_, i) => digits[i] || "");
													setOtp(newOtp);
													setOtpError("");
													setTimeout(() => otpRefs.current[Math.min(pasted.length, 5)]?.focus(), 20);
												},
												children: otp.map((digit, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													ref: (el) => {
														otpRefs.current[index] = el;
													},
													type: "text",
													inputMode: "numeric",
													maxLength: 6,
													value: digit,
													disabled: loading || timeLeft <= 0,
													onChange: (e) => {
														setOtpError("");
														const val = e.target.value;
														if (val.length > 1) {
															const digits = val.replace(/\D/g, "").slice(0, 6).split("");
															const newOtp = Array.from({ length: 6 }, (_, i) => digits[i] || "");
															setOtp(newOtp);
															setTimeout(() => otpRefs.current[Math.min(digits.length, 5)]?.focus(), 20);
															return;
														}
														const d = val.replace(/\D/g, "");
														const newOtp = [...otp];
														newOtp[index] = d;
														setOtp(newOtp);
														if (d && index < 5) setTimeout(() => otpRefs.current[index + 1]?.focus(), 20);
													},
													onKeyDown: (e) => {
														if (e.key === "Backspace") if (!otp[index] && index > 0) {
															const newOtp = [...otp];
															newOtp[index - 1] = "";
															setOtp(newOtp);
															setTimeout(() => otpRefs.current[index - 1]?.focus(), 20);
														} else {
															const newOtp = [...otp];
															newOtp[index] = "";
															setOtp(newOtp);
														}
														else if (e.key === "ArrowLeft" && index > 0) otpRefs.current[index - 1]?.focus();
														else if (e.key === "ArrowRight" && index < 5) otpRefs.current[index + 1]?.focus();
													},
													onFocus: (e) => e.target.select(),
													style: {
														width: "100%",
														maxWidth: "56px",
														aspectRatio: "1",
														borderRadius: "14px",
														border: `2px solid ${digit ? "hsl(var(--primary))" : otpError ? "rgba(239,68,68,0.6)" : "hsl(var(--border))"}`,
														background: digit ? "hsl(var(--primary) / 0.05)" : "hsl(var(--background))",
														color: "hsl(var(--foreground))",
														textAlign: "center",
														fontSize: "1.4rem",
														fontWeight: "900",
														fontFamily: "monospace",
														outline: "none",
														transition: "all 0.15s ease",
														opacity: loading || timeLeft <= 0 ? .5 : 1,
														boxShadow: digit ? "0 0 0 3px hsl(var(--primary) / 0.15)" : "none"
													},
													onFocusCapture: (e) => {
														e.currentTarget.style.borderColor = "hsl(var(--primary))";
														e.currentTarget.style.boxShadow = "0 0 0 3px hsl(var(--primary) / 0.2)";
													},
													onBlurCapture: (e) => {
														const v = e.currentTarget.value;
														e.currentTarget.style.borderColor = v ? "hsl(var(--primary))" : "hsl(var(--border))";
														e.currentTarget.style.boxShadow = v ? "0 0 0 3px hsl(var(--primary) / 0.15)" : "none";
													},
													"aria-label": `Digit ${index + 1}`
												}, index))
											}),
											otpError && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-2.5 flex items-start gap-2 p-2.5 rounded-xl bg-red-500/10 border border-red-500/25 text-xs text-red-400",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "size-3.5 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: otpError })]
											})
										] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											type: "submit",
											disabled: loading || otp.join("").length !== 6 || timeLeft <= 0,
											className: "gradient-brand h-12 w-full rounded-2xl text-primary-foreground font-bold shadow-glow text-sm cursor-pointer disabled:opacity-50",
											children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mr-2 size-4 animate-spin" }), "Verifying Code..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mr-2 size-4" }), "Verify & Open Dashboard"] })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-xs text-muted-foreground pt-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Didn't receive the email?" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: handleResendCode,
												disabled: resendCooldown > 0 || loading,
												className: `flex items-center gap-1.5 font-semibold cursor-pointer transition-colors ${resendCooldown > 0 ? "text-muted-foreground/60 cursor-not-allowed" : "text-primary hover:underline"}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `size-3 ${loading ? "animate-spin" : ""}` }), resendCooldown > 0 ? `Resend in ${resendCooldown}s` : "Resend Code"]
											})]
										})
									]
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
							value: mode,
							onValueChange: (v) => navigate({
								to: "/auth",
								search: { mode: v === "signup" ? "signup" : "login" }
							}),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
									className: "grid w-full grid-cols-2 rounded-2xl p-1 bg-accent/60 h-12",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
										value: "login",
										className: "rounded-xl font-semibold text-xs sm:text-sm",
										children: "Log in"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
										value: "signup",
										className: "rounded-xl font-semibold text-xs sm:text-sm",
										children: "Sign up"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
									value: "login",
									className: "mt-6 space-y-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
											className: "text-2xl font-bold font-display text-foreground",
											children: "Welcome Back"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-xs sm:text-sm text-muted-foreground",
											children: "Sign in to your student account with secure Email MFA."
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
											className: "space-y-4",
											onSubmit: handleLoginSubmit,
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "space-y-1.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
														htmlFor: "login-email",
														className: "text-xs font-semibold",
														children: "Email Address"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														id: "login-email",
														name: "email",
														type: "email",
														required: true,
														autoComplete: "email",
														defaultValue: "aditi.kulkarni@gmail.com",
														placeholder: "you@example.com",
														className: "h-11 rounded-2xl bg-background border-border"
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "space-y-1.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "flex items-center justify-between",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
															htmlFor: "login-password",
															className: "text-xs font-semibold",
															children: "Password"
														})
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														id: "login-password",
														name: "password",
														type: "password",
														required: true,
														autoComplete: "current-password",
														defaultValue: "student123",
														placeholder: "••••••••",
														className: "h-11 rounded-2xl bg-background border-border"
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
													type: "submit",
													disabled: loading,
													className: "gradient-brand h-12 w-full rounded-2xl text-primary-foreground font-semibold shadow-glow hover:opacity-90 mt-2 cursor-pointer",
													children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mr-2 size-4 animate-spin" }), "Generating & Sending Code..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Continue to Email Verification", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "ml-2 size-4" })] })
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Divider, {}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoogleButton, { label: "Continue with Google" })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
									value: "signup",
									className: "mt-6 space-y-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
											className: "text-2xl font-bold font-display text-foreground",
											children: "Create Student Profile"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-xs sm:text-sm text-muted-foreground",
											children: "Get AI-powered career recommendations and customized exam roadmaps."
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
											className: "space-y-4",
											onSubmit: handleSignup,
											noValidate: true,
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
													label: "Full name",
													name: "full_name",
													error: errors["full_name"],
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														id: "full_name",
														name: "full_name",
														placeholder: "Aditi Kulkarni",
														className: "h-11 rounded-2xl bg-background border-border"
													})
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "grid gap-4 sm:grid-cols-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
														label: "Email",
														name: "email",
														error: errors["email"],
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
															id: "email",
															name: "email",
															type: "email",
															autoComplete: "email",
															placeholder: "you@example.com",
															className: "h-11 rounded-2xl bg-background border-border"
														})
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
														label: "Password",
														name: "password",
														error: errors["password"],
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
															id: "password",
															name: "password",
															type: "password",
															autoComplete: "new-password",
															placeholder: "Min 6 characters",
															className: "h-11 rounded-2xl bg-background border-border"
														})
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "grid gap-4 sm:grid-cols-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
														label: "Phone number",
														name: "phone",
														error: errors["phone"],
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
															id: "phone",
															name: "phone",
															inputMode: "numeric",
															placeholder: "9876543210",
															className: "h-11 rounded-2xl bg-background border-border"
														})
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
														label: "Age",
														name: "age",
														error: errors["age"],
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
															id: "age",
															name: "age",
															inputMode: "numeric",
															placeholder: "20",
															className: "h-11 rounded-2xl bg-background border-border"
														})
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "grid gap-4 sm:grid-cols-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
														label: "Gender",
														name: "gender",
														error: errors["gender"],
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
															name: "gender",
															placeholder: "Select gender",
															options: GENDERS
														})
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
														label: "State",
														name: "state",
														error: errors["state"],
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
															name: "state",
															placeholder: "Select state",
															options: INDIAN_STATES.map((s) => ({
																value: s,
																label: s
															}))
														})
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "grid gap-4 sm:grid-cols-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
														label: "City",
														name: "city",
														error: errors["city"],
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
															id: "city",
															name: "city",
															placeholder: "Pune",
															className: "h-11 rounded-2xl bg-background border-border"
														})
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
														label: "Current education",
														name: "current_education",
														error: errors["current_education"],
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
															name: "current_education",
															placeholder: "Select level",
															options: EDUCATION_LEVELS
														})
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
													label: "Preferred language",
													name: "preferred_language",
													error: errors["preferred_language"],
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
														name: "preferred_language",
														placeholder: "Select language",
														options: LANGUAGES,
														defaultValue: "english"
													})
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
													type: "submit",
													disabled: loading,
													className: "gradient-brand h-12 w-full rounded-2xl text-primary-foreground font-semibold shadow-glow hover:opacity-90 mt-2 cursor-pointer",
													children: [loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mr-2 size-4 animate-spin" }) : null, "Create Profile & Send Security Code"]
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Divider, {}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoogleButton, { label: "Sign up with Google" })
									]
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-muted-foreground gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "hover:text-foreground transition-colors",
							children: "← Back to home"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/admin/login",
							className: "text-amber-500 hover:text-amber-400 font-semibold flex items-center gap-1 transition-colors",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3" }), " Admin Gateway →"]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "text-center text-[11px] text-muted-foreground py-4",
				children: "Protected by Cryptographic PBKDF2 Password Hashing & Backend Email Security Code Verification"
			})
		]
	});
}
function Divider() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "my-5 flex items-center gap-3 text-xs text-muted-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-border/80" }),
			"or",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-border/80" })
		]
	});
}
function Field({ label, name, error, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				htmlFor: name,
				className: "text-xs font-semibold text-foreground",
				children: label
			}),
			children,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] text-destructive font-medium",
				children: error
			}) : null
		]
	});
}
function SelectField({ name, placeholder, options, defaultValue }) {
	const [value, setValue] = (0, import_react.useState)(defaultValue ?? "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type: "hidden",
		name,
		value
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
		value,
		onValueChange: setValue,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
			id: name,
			className: "h-11 w-full rounded-2xl bg-background border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, {
			className: "max-h-72 rounded-2xl",
			children: options.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
				value: o.value,
				className: "rounded-xl",
				children: o.label
			}, o.value))
		})]
	})] });
}
//#endregion
export { AuthPage as component };
