import { i as __toESM } from "../_runtime.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Card } from "./card-95-PmP7N.mjs";
import { t as Badge } from "./badge-BYEzUON3.mjs";
import { g as Sparkles, kt as BookOpen, t as Zap } from "../_libs/lucide-react.mjs";
import { i as getManagedCareers } from "./admin-content-store-CcAL24zG.mjs";
import { h as saveSkillGapStore, o as getSkillGapStore } from "./careersetu-store-CamG1tac.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Progress } from "./progress-CNflbst_.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-BfMpEmcB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/skill-gap-BcUOYw2x.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUS_OPTIONS = [
	"Not Started",
	"Learning",
	"Intermediate",
	"Advanced"
];
function SkillGapPage() {
	const [store, setStore] = (0, import_react.useState)(getSkillGapStore());
	const [careersList, setCareersList] = (0, import_react.useState)(() => {
		const live = getManagedCareers().filter((c) => c.status !== "ARCHIVED");
		return live.length > 0 ? live : [];
	});
	(0, import_react.useEffect)(() => {
		const live = getManagedCareers().filter((c) => c.status !== "ARCHIVED");
		setCareersList(live);
		setStore(getSkillGapStore());
	}, []);
	const selectedCareer = careersList.find((c) => c.id === store.targetCareerId) ?? careersList[0] ?? {
		id: "ai-ml-engineer",
		name: "AI & Machine Learning Engineer",
		domain: "Technology",
		requiredSkills: [
			"Python",
			"Machine Learning",
			"Deep Learning",
			"SQL",
			"Statistics"
		]
	};
	const handleCareerChange = (careerId) => {
		const career = careersList.find((c) => c.id === careerId);
		if (!career) return;
		const newStatuses = {};
		(career.requiredSkills || []).forEach((s) => {
			newStatuses[s] = store.skillStatuses[s] ?? "Not Started";
		});
		const newStore = {
			targetCareerId: careerId,
			skillStatuses: newStatuses
		};
		setStore(newStore);
		saveSkillGapStore(newStore);
		toast.success(`Target career set to ${career.name}`);
	};
	const handleStatusChange = (skill, status) => {
		const updated = {
			...store,
			skillStatuses: {
				...store.skillStatuses,
				[skill]: status
			}
		};
		setStore(updated);
		saveSkillGapStore(updated);
		toast.success(`Updated ${skill} to ${status}`);
	};
	const skillsList = selectedCareer.requiredSkills || [
		"Python",
		"SQL",
		"Problem Solving"
	];
	const advancedCount = skillsList.filter((s) => store.skillStatuses[s] === "Advanced").length;
	const intermediateCount = skillsList.filter((s) => store.skillStatuses[s] === "Intermediate").length;
	const learningCount = skillsList.filter((s) => store.skillStatuses[s] === "Learning").length;
	const readinessScore = skillsList.length > 0 ? Math.min(100, Math.round((advancedCount * 1 + intermediateCount * .65 + learningCount * .3) / skillsList.length * 100)) : 50;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 max-w-4xl mx-auto py-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-9 place-items-center rounded-xl bg-primary/10 text-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-xl sm:text-2xl font-bold font-display text-foreground",
						children: "Skill Gap & Readiness Analysis"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs sm:text-sm text-muted-foreground mt-1",
					children: "Compare your current skill competencies against target industry requirements."
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "glass p-5 rounded-3xl border-border/80 shadow-md bg-card/90 space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[11px] font-semibold text-muted-foreground block",
							children: "Select Target Dream Career:"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: selectedCareer.id,
							onValueChange: handleCareerChange,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								className: "w-72 h-10 rounded-xl text-xs font-semibold bg-background",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, {
								className: "rounded-2xl max-h-64",
								children: careersList.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
									value: c.id,
									className: "text-xs",
									children: [
										c.name,
										" (",
										c.domain,
										")"
									]
								}, c.id))
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[11px] font-medium text-muted-foreground block",
							children: "Role Readiness Index"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xl font-bold text-primary font-display",
							children: [readinessScore, "% Match"]
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5 pt-2 border-t border-border/40",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between text-xs text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Core Competency Progress" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-semibold text-foreground",
							children: [
								advancedCount,
								" Advanced · ",
								intermediateCount,
								" Intermediate · ",
								skillsList.length - advancedCount - intermediateCount,
								" To Learn"
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
						value: readinessScore,
						className: "h-2 rounded-full"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
					className: "font-bold text-sm text-foreground flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4 text-primary" }), " Required Skills & Your Current Level"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2.5",
					children: skillsList.map((skill, idx) => {
						const status = store.skillStatuses[skill] ?? "Not Started";
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "p-4 rounded-2xl border border-border/80 hover:border-primary/40 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs bg-card",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-bold text-xs sm:text-sm text-foreground",
										children: skill
									}), idx < 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										className: "bg-rose-500/10 text-rose-500 border-rose-500/20 text-[9px] py-0",
										children: "High Priority"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[11px] text-muted-foreground",
									children: [
										"Required for ",
										selectedCareer.name,
										" technical assessments and job roles."
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 shrink-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] text-muted-foreground hidden sm:inline",
									children: "Proficiency:"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: status,
									onValueChange: (val) => handleStatusChange(skill, val),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										className: `w-36 h-8 rounded-xl text-xs font-semibold ${status === "Advanced" ? "bg-emerald-500/10 text-emerald-600 border-emerald-500/30" : status === "Intermediate" ? "bg-sky-500/10 text-sky-600 border-sky-500/30" : status === "Learning" ? "bg-amber-500/10 text-amber-600 border-amber-500/30" : "bg-muted text-muted-foreground"}`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, {
										className: "rounded-2xl",
										children: STATUS_OPTIONS.map((st) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: st,
											className: "text-xs",
											children: st
										}, st))
									})]
								})]
							})]
						}, skill);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "glass p-5 rounded-3xl border-border/80 shadow-md bg-card/90 space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
					className: "font-bold text-sm text-foreground flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-4 text-primary" }), " Recommended Next Steps"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2 text-xs text-foreground/90",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "leading-relaxed",
						children: [
							"To achieve a 90%+ readiness score for ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: selectedCareer.name }),
							", focus on converting your highest-priority missing skills into \"Intermediate\" through 30 days of structured hands-on projects."
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2 pt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/resources",
							className: "inline-flex items-center gap-1.5 gradient-brand text-primary-foreground font-bold text-xs py-2 px-3.5 rounded-xl shadow-xs",
							children: "Explore Learning Resources →"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/study-planner",
							className: "inline-flex items-center gap-1.5 border border-border bg-accent/40 text-foreground font-semibold text-xs py-2 px-3.5 rounded-xl hover:bg-accent",
							children: "Schedule Daily Practice Plan"
						})]
					})]
				})]
			})
		]
	});
}
//#endregion
export { SkillGapPage as component };
