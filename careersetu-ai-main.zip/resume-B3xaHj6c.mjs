import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { n as cn, t as Card } from "./card-95-PmP7N.mjs";
import { t as Button } from "./button-CdcMTBqt.mjs";
import { O as Printer, T as RotateCcw, Tt as Briefcase, X as GraduationCap, at as Download, et as FileText, g as Sparkles, nt as Eye, o as User, r as WandSparkles, w as Save } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-D7UBWI0-.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-mEmCUBpO.mjs";
import { a as getResumeData, m as saveResumeData, t as DEFAULT_RESUME_DATA } from "./careersetu-store-CamG1tac.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/resume-B3xaHj6c.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-[60px] w-full rounded-md border border-input bg-transparent px-3 py-2 text-base shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className),
		ref,
		...props
	});
});
Textarea.displayName = "Textarea";
function ResumeBuilderPage() {
	const [resume, setResume] = (0, import_react.useState)(getResumeData());
	const [activeTab, setActiveTab] = (0, import_react.useState)("edit");
	const [selectedTemplate, setSelectedTemplate] = (0, import_react.useState)("modern-minimal");
	const [isAiGenerating, setIsAiGenerating] = (0, import_react.useState)(false);
	const printRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		setResume(getResumeData());
	}, []);
	const handleSave = () => {
		saveResumeData(resume);
		toast.success("Resume saved successfully!");
	};
	const handleReset = () => {
		if (window.confirm("Reset resume to sample template data?")) {
			setResume(DEFAULT_RESUME_DATA);
			saveResumeData(DEFAULT_RESUME_DATA);
			toast.info("Reset to default resume template");
		}
	};
	const handlePrint = () => {
		window.print();
	};
	const handleAiEnhanceSummary = () => {
		setIsAiGenerating(true);
		setTimeout(() => {
			const enhanced = `Results-oriented technologist and strategist with proven expertise in modern full-stack development, scalable system architectures, and data-driven problem solving. Skilled in collaborating across multidisciplinary teams, optimizing algorithmic pipelines, and building user-centric digital applications.`;
			setResume((prev) => ({
				...prev,
				summary: enhanced
			}));
			setIsAiGenerating(false);
			toast.success("AI enhanced professional summary!");
		}, 800);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 max-w-5xl mx-auto py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-border",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-9 place-items-center rounded-xl bg-primary/10 text-primary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-5" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl sm:text-2xl font-bold font-display text-foreground",
					children: "ATS-Optimized Resume Builder"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs sm:text-sm text-muted-foreground mt-1",
				children: "Build clean, recruiter-tested resumes with live layout preview, AI copy enhancement, and PDF export."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: handleReset,
						className: "rounded-xl text-xs cursor-pointer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-3.5 mr-1" }), " Reset"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: handleSave,
						className: "rounded-xl text-xs cursor-pointer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-3.5 mr-1 text-primary" }), " Save"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						onClick: handlePrint,
						className: "gradient-brand text-primary-foreground font-bold rounded-xl shadow-glow cursor-pointer gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5" }), " Download PDF / Print"]
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
			value: activeTab,
			onValueChange: (v) => setActiveTab(v),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
					className: "rounded-2xl p-1 bg-accent/60 w-full sm:w-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "edit",
						className: "rounded-xl text-xs font-semibold",
						children: "✏️ Edit Content"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
						value: "preview",
						className: "rounded-xl text-xs font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-3.5 mr-1" }), " Live Resume Preview"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
					value: "edit",
					className: "space-y-6 mt-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "glass p-5 rounded-3xl border-border/80 shadow-xs space-y-4 bg-card/90",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "font-bold text-sm text-foreground flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-4 text-primary" }), " 1. Contact & Personal Details"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "font-semibold text-muted-foreground block mb-1",
										children: "Full Name"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: resume.personalInfo.fullName,
										onChange: (e) => setResume({
											...resume,
											personalInfo: {
												...resume.personalInfo,
												fullName: e.target.value
											}
										}),
										className: "rounded-xl h-9"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "font-semibold text-muted-foreground block mb-1",
										children: "Email Address"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: resume.personalInfo.email,
										onChange: (e) => setResume({
											...resume,
											personalInfo: {
												...resume.personalInfo,
												email: e.target.value
											}
										}),
										className: "rounded-xl h-9"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "font-semibold text-muted-foreground block mb-1",
										children: "Phone Number"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: resume.personalInfo.phone,
										onChange: (e) => setResume({
											...resume,
											personalInfo: {
												...resume.personalInfo,
												phone: e.target.value
											}
										}),
										className: "rounded-xl h-9"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "font-semibold text-muted-foreground block mb-1",
										children: "Location (City, State)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: resume.personalInfo.location,
										onChange: (e) => setResume({
											...resume,
											personalInfo: {
												...resume.personalInfo,
												location: e.target.value
											}
										}),
										className: "rounded-xl h-9"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "font-semibold text-muted-foreground block mb-1",
										children: "Professional Title / Headline"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: resume.personalInfo.headline,
										onChange: (e) => setResume({
											...resume,
											personalInfo: {
												...resume.personalInfo,
												headline: e.target.value
											}
										}),
										className: "rounded-xl h-9"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "font-semibold text-muted-foreground block mb-1",
										children: "LinkedIn / Portfolio URL"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: resume.personalInfo.linkedinUrl,
										onChange: (e) => setResume({
											...resume,
											personalInfo: {
												...resume.personalInfo,
												linkedinUrl: e.target.value
											}
										}),
										className: "rounded-xl h-9"
									})] })
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "glass p-5 rounded-3xl border-border/80 shadow-xs space-y-3 bg-card/90",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "font-bold text-sm text-foreground flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4 text-primary" }), " 2. Professional Summary"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									size: "sm",
									onClick: handleAiEnhanceSummary,
									disabled: isAiGenerating,
									className: "rounded-xl text-xs font-semibold border-primary/30 text-primary hover:bg-primary/10 gap-1.5 cursor-pointer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WandSparkles, { className: "size-3.5 text-amber-500" }), isAiGenerating ? "Enhancing..." : "AI Enhance Summary"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								value: resume.summary,
								onChange: (e) => setResume({
									...resume,
									summary: e.target.value
								}),
								rows: 3,
								className: "rounded-xl text-xs leading-relaxed"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "glass p-5 rounded-3xl border-border/80 shadow-xs space-y-4 bg-card/90",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center justify-between",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "font-bold text-sm text-foreground flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "size-4 text-primary" }), " 3. Education"]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-3",
								children: resume.education.map((edu, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "p-3.5 rounded-2xl bg-accent/30 border border-border space-y-2 text-xs",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-1 sm:grid-cols-3 gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "font-semibold text-muted-foreground block mb-1",
												children: "Institution Name"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												value: edu.institution,
												onChange: (e) => {
													const updated = [...resume.education];
													updated[idx].institution = e.target.value;
													setResume({
														...resume,
														education: updated
													});
												},
												className: "rounded-xl h-8 text-xs"
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "font-semibold text-muted-foreground block mb-1",
												children: "Degree & Stream"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												value: edu.degree,
												onChange: (e) => {
													const updated = [...resume.education];
													updated[idx].degree = e.target.value;
													setResume({
														...resume,
														education: updated
													});
												},
												className: "rounded-xl h-8 text-xs"
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "font-semibold text-muted-foreground block mb-1",
												children: "Graduation Year / Grade"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												value: `${edu.startDate} - ${edu.endDate} (${edu.grade})`,
												onChange: (e) => {
													const updated = [...resume.education];
													updated[idx].grade = e.target.value;
													setResume({
														...resume,
														education: updated
													});
												},
												className: "rounded-xl h-8 text-xs"
											})] })
										]
									})
								}, edu.id))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "glass p-5 rounded-3xl border-border/80 shadow-xs space-y-4 bg-card/90",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "font-bold text-sm text-foreground flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-4 text-primary" }), " 4. Projects & Internships"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-3",
								children: resume.projects.map((proj, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3.5 rounded-2xl bg-accent/30 border border-border space-y-2 text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "font-semibold text-muted-foreground block mb-1",
											children: "Project Title"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: proj.title,
											onChange: (e) => {
												const updated = [...resume.projects];
												updated[idx].title = e.target.value;
												setResume({
													...resume,
													projects: updated
												});
											},
											className: "rounded-xl h-8 text-xs"
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "font-semibold text-muted-foreground block mb-1",
											children: "Tech Stack"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: proj.techStack,
											onChange: (e) => {
												const updated = [...resume.projects];
												updated[idx].techStack = e.target.value;
												setResume({
													...resume,
													projects: updated
												});
											},
											className: "rounded-xl h-8 text-xs"
										})] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "font-semibold text-muted-foreground block mb-1",
										children: "Description & Impact"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
										value: proj.description,
										onChange: (e) => {
											const updated = [...resume.projects];
											updated[idx].description = e.target.value;
											setResume({
												...resume,
												projects: updated
											});
										},
										rows: 2,
										className: "rounded-xl text-xs"
									})] })]
								}, proj.id))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "glass p-5 rounded-3xl border-border/80 shadow-xs space-y-3 bg-card/90",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "font-bold text-sm text-foreground flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WandSparkles, { className: "size-4 text-primary" }), " 5. Core Technical Skills"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: resume.skills?.technical?.join(", ") || "",
								onChange: (e) => setResume({
									...resume,
									skills: {
										...resume.skills,
										technical: e.target.value.split(",").map((s) => s.trim())
									}
								}),
								placeholder: "e.g. Python, TypeScript, React, SQL, PyTorch, Git",
								className: "rounded-xl text-xs h-9"
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
					value: "preview",
					className: "space-y-4 mt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between text-xs text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "A4 Document Preview" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							onClick: handlePrint,
							className: "gradient-brand text-primary-foreground font-bold rounded-xl shadow-glow cursor-pointer gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-3.5" }), " Print / Save as PDF"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						ref: printRef,
						className: "w-full max-w-3xl mx-auto bg-white text-slate-900 p-8 sm:p-12 rounded-2xl shadow-2xl border border-slate-200 font-sans space-y-6 text-left leading-relaxed text-xs sm:text-sm print:p-0 print:border-0 print:shadow-none",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "border-b border-slate-300 pb-4 space-y-1 text-center",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
										className: "text-2xl sm:text-3xl font-bold tracking-tight text-slate-950 uppercase",
										children: resume.personalInfo.fullName
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-semibold text-slate-600",
										children: resume.personalInfo.headline
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center justify-center gap-2.5 text-[11px] text-slate-500 pt-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: resume.personalInfo.location }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: resume.personalInfo.email }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: resume.personalInfo.phone }),
											resume.personalInfo.linkedinUrl && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
												href: resume.personalInfo.linkedinUrl,
												className: "text-blue-600 underline",
												children: "LinkedIn"
											})] })
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-xs font-bold text-slate-800 uppercase tracking-wider border-b border-slate-200 pb-0.5",
									children: "Professional Summary"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-slate-700 leading-relaxed pt-1",
									children: resume.summary
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-xs font-bold text-slate-800 uppercase tracking-wider border-b border-slate-200 pb-0.5",
									children: "Education"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "space-y-2 pt-1",
									children: resume.education.map((edu) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between items-start text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-slate-900 block font-semibold",
											children: edu.institution
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-slate-600",
											children: [
												edu.degree,
												" — ",
												edu.fieldOfStudy
											]
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-right font-medium text-slate-500 text-[11px]",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
												edu.startDate,
												" – ",
												edu.endDate
											] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block font-bold text-slate-700",
												children: edu.grade
											})]
										})]
									}, edu.id))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-xs font-bold text-slate-800 uppercase tracking-wider border-b border-slate-200 pb-0.5",
									children: "Projects & Experience"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "space-y-3 pt-1",
									children: resume.projects.map((proj) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1 text-xs",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex justify-between items-center",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
													className: "text-slate-900 font-semibold",
													children: proj.title
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[11px] font-mono text-slate-500",
													children: proj.techStack
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-slate-700",
												children: proj.description
											}),
											proj.bullets && proj.bullets.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
												className: "list-disc pl-4 space-y-0.5 text-slate-600 text-[11px]",
												children: proj.bullets.map((b, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: b }, i))
											})
										]
									}, proj.id))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-xs font-bold text-slate-800 uppercase tracking-wider border-b border-slate-200 pb-0.5",
									children: "Skills & Competencies"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs text-slate-700 space-y-1 pt-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "text-slate-900 font-semibold",
										children: "Technical: "
									}), resume.skills?.technical?.join(", ") || "Python, React, SQL"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "text-slate-900 font-semibold",
										children: "Languages: "
									}), resume.languages?.join(", ") || "English, Hindi"] })]
								})]
							})
						]
					})]
				})
			]
		})]
	});
}
//#endregion
export { ResumeBuilderPage as component };
