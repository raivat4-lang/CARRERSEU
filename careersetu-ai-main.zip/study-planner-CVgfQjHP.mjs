import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Card } from "./card-95-PmP7N.mjs";
import { t as Badge } from "./badge-BYEzUON3.mjs";
import { t as Button } from "./button-CdcMTBqt.mjs";
import { $ as Flame, ct as Clock, f as Trash2, g as Sparkles, k as Plus, mt as CircleCheckBig, pt as CircleCheck, xt as Calendar } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, n as DialogContent, o as DialogTitle, t as Dialog } from "./dialog-d9GHmrLL.mjs";
import { t as Input } from "./input-D7UBWI0-.mjs";
import { t as EXAMS_DATA } from "./exams-data-C-FGqv-l.mjs";
import { c as getStudyTasks, d as rescheduleMissedTasks, g as saveStudyTasks } from "./careersetu-store-CamG1tac.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Progress } from "./progress-CNflbst_.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-BfMpEmcB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/study-planner-CVgfQjHP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function StudyPlannerPage() {
	const [tasks, setTasks] = (0, import_react.useState)([]);
	const [selectedExamId, setSelectedExamId] = (0, import_react.useState)("upsc-cse");
	const [dailyHours, setDailyHours] = (0, import_react.useState)("4");
	const [isAddTaskOpen, setIsAddTaskOpen] = (0, import_react.useState)(false);
	const [newTitle, setNewTitle] = (0, import_react.useState)("");
	const [newSubject, setNewSubject] = (0, import_react.useState)("Core Syllabus");
	const [newMinutes, setNewMinutes] = (0, import_react.useState)(60);
	const [newPriority, setNewPriority] = (0, import_react.useState)("High");
	(0, import_react.useEffect)(() => {
		const { rescheduledCount } = rescheduleMissedTasks();
		if (rescheduledCount > 0) toast.info(`Moved ${rescheduledCount} overdue tasks to today's schedule`);
		setTasks(getStudyTasks());
	}, []);
	const todayStr = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
	const handleToggleComplete = (taskId) => {
		const updated = tasks.map((t) => t.id === taskId ? {
			...t,
			completed: !t.completed
		} : t);
		setTasks(updated);
		saveStudyTasks(updated);
		if (updated.find((t) => t.id === taskId)?.completed) toast.success("Task completed! Streak updated 🔥");
	};
	const handleDeleteTask = (taskId) => {
		const updated = tasks.filter((t) => t.id !== taskId);
		setTasks(updated);
		saveStudyTasks(updated);
		toast.info("Task removed");
	};
	const handleAddTask = (e) => {
		e.preventDefault();
		if (!newTitle.trim()) return;
		const updated = [{
			id: "task-" + Date.now(),
			title: newTitle.trim(),
			subject: newSubject,
			date: todayStr,
			timeEstimateMins: newMinutes,
			completed: false,
			priority: newPriority,
			targetExamId: selectedExamId
		}, ...tasks];
		setTasks(updated);
		saveStudyTasks(updated);
		setIsAddTaskOpen(false);
		setNewTitle("");
		toast.success("New task scheduled for today!");
	};
	const todayTasks = tasks.filter((t) => t.date === todayStr);
	const completedToday = todayTasks.filter((t) => t.completed).length;
	const todayProgress = todayTasks.length > 0 ? Math.round(completedToday / todayTasks.length * 100) : 0;
	const totalStudyMinutesToday = todayTasks.filter((t) => t.completed).reduce((acc, curr) => acc + curr.timeEstimateMins, 0);
	const selectedExam = EXAMS_DATA.find((e) => e.id === selectedExamId) ?? EXAMS_DATA[0];
	const handleGenerateAdaptiveSchedule = () => {
		const updated = [...[
			{
				title: `Read NCERT / Foundation chapter for ${selectedExam.shortName}`,
				subject: "Core Foundation",
				mins: 60,
				priority: "High"
			},
			{
				title: `Solve 25 Previous Year Questions (PYQs) for ${selectedExam.shortName}`,
				subject: "Practice Drills",
				mins: 90,
				priority: "High"
			},
			{
				title: `Daily Current Affairs & Editorial Analysis`,
				subject: "General Awareness",
				mins: 45,
				priority: "Medium"
			},
			{
				title: `Revision of Formula Sheet & Recurring Mistakes Note`,
				subject: "Active Recall",
				mins: 30,
				priority: "Normal"
			}
		].map((item, idx) => ({
			id: "gen-" + Date.now() + "-" + idx,
			title: item.title,
			subject: item.subject,
			date: todayStr,
			timeEstimateMins: item.mins,
			completed: false,
			priority: item.priority,
			targetExamId: selectedExamId
		})), ...tasks];
		setTasks(updated);
		saveStudyTasks(updated);
		toast.success(`Generated 4-task adaptive study schedule for ${selectedExam.shortName}!`);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 max-w-4xl mx-auto py-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-border",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-9 place-items-center rounded-xl bg-primary/10 text-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-xl sm:text-2xl font-bold font-display text-foreground",
						children: "Adaptive AI Study Planner"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs sm:text-sm text-muted-foreground mt-1",
					children: "Personalized daily schedule, automatic overdue task rescheduling, and consistency streak tracking."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center gap-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						onClick: () => setIsAddTaskOpen(true),
						className: "rounded-xl gradient-brand text-primary-foreground font-bold shadow-xs cursor-pointer gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " Add Task"]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "glass p-5 rounded-3xl border-border/80 shadow-md bg-card/90 space-y-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] font-semibold text-muted-foreground block",
								children: "Target Exam / Goal:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: selectedExamId,
								onValueChange: setSelectedExamId,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
									className: "w-56 h-9 rounded-xl text-xs font-semibold bg-background",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, {
									className: "rounded-2xl",
									children: EXAMS_DATA.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: e.id,
										className: "text-xs",
										children: e.name
									}, e.id))
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] font-semibold text-muted-foreground block",
								children: "Daily Study Target:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: dailyHours,
								onValueChange: setDailyHours,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
									className: "w-28 h-9 rounded-xl text-xs font-semibold bg-background",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, {
									className: "rounded-2xl",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "2",
											className: "text-xs",
											children: "2 Hours/day"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "4",
											className: "text-xs",
											children: "4 Hours/day"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "6",
											className: "text-xs",
											children: "6 Hours/day"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "8",
											className: "text-xs",
											children: "8 Hours/day"
										})
									]
								})]
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: handleGenerateAdaptiveSchedule,
						className: "rounded-xl text-xs font-bold border-primary/30 text-primary hover:bg-primary/10 gap-1.5 cursor-pointer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3.5 text-amber-500 fill-amber-500" }), "AI Auto-Generate Plan"]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 sm:grid-cols-3 gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "glass p-4 rounded-3xl border-border/80 shadow-xs space-y-2 bg-card/90",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between text-xs text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Today's Task Progress" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
									className: "text-primary font-bold",
									children: [todayProgress, "%"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
								value: todayProgress,
								className: "h-2 rounded-full"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[11px] text-muted-foreground",
								children: [
									completedToday,
									" of ",
									todayTasks.length,
									" milestones checked off"
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "glass p-4 rounded-3xl border-border/80 shadow-xs flex items-center gap-3.5 bg-card/90",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-11 place-items-center rounded-2xl bg-amber-500/10 text-amber-500",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, { className: "size-6 animate-pulse" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] font-medium text-muted-foreground block",
								children: "Study Streak"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-lg font-bold text-foreground",
								children: "7 Days Active 🔥"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] text-emerald-500 font-semibold",
								children: "Top 5% Consistency"
							})
						] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "glass p-4 rounded-3xl border-border/80 shadow-xs flex items-center gap-3.5 bg-card/90",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-11 place-items-center rounded-2xl bg-emerald-500/10 text-emerald-500",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-6" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] font-medium text-muted-foreground block",
								children: "Study Time Completed"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-lg font-bold text-foreground",
								children: [totalStudyMinutesToday, " Minutes"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-[10px] text-muted-foreground",
								children: [
									"Goal: ",
									parseInt(dailyHours) * 60,
									" mins"
								]
							})
						] })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "font-bold text-sm text-foreground flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 text-primary" }), " Today's Scheduled Milestones"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground font-mono",
						children: todayStr
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2.5",
					children: [todayTasks.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: `p-4 rounded-2xl border transition-all flex items-start justify-between gap-3 shadow-xs ${t.completed ? "bg-muted/40 border-border/40 opacity-75" : "bg-card border-border/80 hover:border-primary/40"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => handleToggleComplete(t.id),
								className: `mt-0.5 size-5 rounded-lg grid place-items-center border transition-all cursor-pointer ${t.completed ? "bg-emerald-500 text-white border-emerald-500" : "border-border hover:border-primary bg-background"}`,
								children: t.completed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheckBig, { className: "size-3.5 stroke-[3]" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: `font-semibold text-xs sm:text-sm text-foreground ${t.completed ? "line-through text-muted-foreground" : ""}`,
									children: t.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center gap-2 text-[10px] text-muted-foreground",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											variant: "outline",
											className: "text-[9px] py-0",
											children: t.subject
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
											"⏱️ ",
											t.timeEstimateMins,
											" mins"
										] }),
										t.rescheduledCount && t.rescheduledCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-amber-500 font-semibold bg-amber-500/10 px-1.5 py-0.2 rounded",
											children: [
												"Auto-Rescheduled (",
												t.rescheduledCount,
												"x)"
											]
										})
									]
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => handleDeleteTask(t.id),
							className: "p-1 rounded-lg text-muted-foreground hover:text-destructive transition-colors cursor-pointer",
							title: "Delete task",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
						})]
					}, t.id)), todayTasks.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "glass p-8 text-center rounded-3xl border-border space-y-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-8 mx-auto text-muted-foreground" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold text-xs text-foreground",
								children: "No tasks scheduled for today yet!"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-muted-foreground max-w-xs mx-auto",
								children: "Click \"AI Auto-Generate Plan\" or \"Add Task\" to populate today's schedule."
							})
						]
					})]
				})]
			}),
			isAddTaskOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: isAddTaskOpen,
				onOpenChange: setIsAddTaskOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-md p-6 rounded-3xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
						className: "text-base font-bold font-display flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4 text-primary" }), " Add Custom Study Task"]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleAddTask,
						className: "space-y-4 text-xs mt-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "font-semibold text-foreground block mb-1",
								children: "Task Title / Milestone"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: newTitle,
								onChange: (e) => setNewTitle(e.target.value),
								placeholder: "e.g. Solve 20 questions on Electromagnetism",
								className: "rounded-xl h-10",
								required: true
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "font-semibold text-foreground block mb-1",
									children: "Subject"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: newSubject,
									onChange: (e) => setNewSubject(e.target.value),
									placeholder: "e.g. Physics / Polity",
									className: "rounded-xl h-10"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "font-semibold text-foreground block mb-1",
									children: "Duration (Minutes)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: newMinutes,
									onChange: (e) => setNewMinutes(parseInt(e.target.value) || 30),
									min: 15,
									max: 360,
									className: "rounded-xl h-10"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2 justify-end pt-3 border-t border-border",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "outline",
									size: "sm",
									onClick: () => setIsAddTaskOpen(false),
									className: "rounded-xl",
									children: "Cancel"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									size: "sm",
									className: "gradient-brand text-primary-foreground font-bold rounded-xl",
									children: "Save Task"
								})]
							})
						]
					})]
				})
			})
		]
	});
}
//#endregion
export { StudyPlannerPage as component };
