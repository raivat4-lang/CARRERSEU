//#region node_modules/.nitro/vite/services/ssr/assets/__23tanstack-start-server-fn-resolver-CQckkHM2.js
var manifest = {
	"30b51e85fa0c376e6f30cf1699b3e7ba7a576623749526186cc633f00b42c6ee": {
		functionName: "verifyEmailOtpServerFn_createServerFn_handler",
		importer: () => import("./_ssr/auth.functions-DrL5kF7z.mjs")
	},
	"3c242df52bab37d251e2986cea68e4c514ec03074767cce04aa8da5a8dae7b72": {
		functionName: "verifyStudentAccessServerFn_createServerFn_handler",
		importer: () => import("./_ssr/auth.functions-DrL5kF7z.mjs")
	},
	"47a91ffb18276e5b52c5df1512d391c1092d1c0cca3f93438b318db025c45604": {
		functionName: "dispatchEmailOtpServerFn_createServerFn_handler",
		importer: () => import("./_ssr/auth.functions-DrL5kF7z.mjs")
	},
	"5dbf46616266e7bfe81c82694a91090a42de6200b3efc1b9d156faf41ac3a479": {
		functionName: "getMyProfile_createServerFn_handler",
		importer: () => import("./_ssr/profile.functions-DlNLiwyF.mjs")
	},
	"6484f007b1fc41a42de564e5ca21f6324e9f9082cea1f053ead767b7a05501d4": {
		functionName: "issueAuthenticatedSessionServerFn_createServerFn_handler",
		importer: () => import("./_ssr/auth.functions-DrL5kF7z.mjs")
	},
	"cc18aeb21e4e1ddbe2d74853e6616f2ba0b78c6a740f4dec4e896de9fbc7200f": {
		functionName: "verifyAdminAccessServerFn_createServerFn_handler",
		importer: () => import("./_ssr/auth.functions-DrL5kF7z.mjs")
	},
	"d424ee3e8af7c19202aeae85f5b466ac39f54dc484ba38a9546da60d20c47bda": {
		functionName: "dispatchResendOtpDirectServerFn_createServerFn_handler",
		importer: () => import("./_ssr/auth.functions-DrL5kF7z.mjs")
	}
};
async function getServerFnById(id, access) {
	const serverFnInfo = manifest[id];
	if (!serverFnInfo) throw new Error("Server function info not found for " + id);
	const fnModule = serverFnInfo.module ?? await serverFnInfo.importer();
	if (!fnModule) throw new Error("Server function module not resolved for " + id);
	const action = fnModule[serverFnInfo.functionName];
	if (!action) throw new Error("Server function module export not resolved for serverFn ID: " + id);
	return action;
}
//#endregion
export { getServerFnById as t };
