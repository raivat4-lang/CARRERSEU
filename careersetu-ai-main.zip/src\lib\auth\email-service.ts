// CareerSetu AI — Email Dispatch Service
// Routes all OTP emails through the Supabase Edge Function (send-mfa-email).
// The RESEND_API_KEY lives in Supabase secrets — never exposed to the browser.
//
// Flow:
//   rbac.ts generates OTP → calls sendAuthenticationEmail() → Edge Function sends via Resend

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL || "";
const EDGE_FN_URL = `${SUPABASE_URL}/functions/v1/send-mfa-email`;

export interface EmailDispatchOptions {
  to: string;
  subject?: string;
  templateType:
    | "STUDENT_LOGIN_MFA"
    | "STUDENT_SIGNUP_VERIFY"
    | "ADMIN_LOGIN_MFA"
    | "ADMIN_PASSWORD_RESET"
    | "ADMIN_FIRST_SETUP";
  recipientName?: string;
  otpCode?: string;
  expiresInMinutes?: number;
}

export interface EmailDispatchResult {
  success: boolean;
  message: string;
  isDevelopmentMode: boolean;
  maskedRecipient: string;
  deliveryTimestamp: string;
  error?: string;
}

// Mask email for display (e.g. raivat00@gmail.com → r*******0@gmail.com)
export function maskEmailAddress(email: string): string {
  if (!email || !email.includes("@")) return "******@domain.com";
  const [user, domain] = email.split("@");
  if (!user || !domain) return "******@domain.com";
  if (user.length <= 2) return `${user[0]}*@${domain}`;
  const first = user[0];
  const last = user[user.length - 1];
  const stars = "*".repeat(Math.max(3, user.length - 2));
  return `${first}${stars}${last}@${domain}`;
}

// Map template type to Edge Function purpose string
function mapTemplateToPurpose(
  templateType: EmailDispatchOptions["templateType"]
): string {
  switch (templateType) {
    case "STUDENT_SIGNUP_VERIFY":
      return "STUDENT_VERIFY";
    case "ADMIN_LOGIN_MFA":
      return "ADMIN_LOGIN";
    case "ADMIN_FIRST_SETUP":
      return "ADMIN_FIRST_SETUP";
    case "ADMIN_PASSWORD_RESET":
      return "ADMIN_RESET";
    default:
      return "STUDENT_LOGIN";
  }
}

/**
 * Dispatches an OTP email server-side via Resend API.
 * The RESEND_API_KEY is kept strictly server-side — never sent or exposed to the browser.
 */
export async function sendAuthenticationEmail(
  options: EmailDispatchOptions
): Promise<EmailDispatchResult> {
  const {
    to,
    recipientName = "Student",
    templateType,
    otpCode,
    expiresInMinutes = 10,
  } = options;

  const timestamp = new Date().toISOString();
  const masked = maskEmailAddress(to);
  const purpose = mapTemplateToPurpose(templateType) as
    | "STUDENT_LOGIN"
    | "STUDENT_VERIFY"
    | "ADMIN_LOGIN"
    | "ADMIN_FIRST_SETUP"
    | "ADMIN_RESET";

  if (!otpCode) {
    console.error("[sendAuthenticationEmail] otpCode is required but was not provided.");
    return {
      success: false,
      message: "Internal error: OTP code missing from dispatch request.",
      isDevelopmentMode: false,
      maskedRecipient: masked,
      deliveryTimestamp: timestamp,
      error: "otpCode missing",
    };
  }

  // 1. Primary: Server Function Resend Dispatch (Node.js/Nitro backend)
  try {
    const { dispatchResendOtpDirectServerFn } = await import("./auth.functions");
    const serverResult = await dispatchResendOtpDirectServerFn({
      data: {
        to,
        otpCode,
        purpose,
        recipientName,
        expiresInMinutes,
      },
    });

    if (serverResult && serverResult.success) {
      return {
        success: true,
        message: `Verification code sent to ${masked}`,
        isDevelopmentMode: false,
        maskedRecipient: masked,
        deliveryTimestamp: timestamp,
      };
    }
  } catch (serverFnErr) {
    console.warn("[sendAuthenticationEmail] Server function dispatch fallback to Edge Function:", serverFnErr);
  }

  // 2. Secondary: Supabase Edge Function dispatch if available
  if (SUPABASE_URL) {
    try {
      const res = await fetch(EDGE_FN_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          to,
          otpCode,
          purpose,
          recipientName,
          expiresInMinutes,
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        return {
          success: true,
          message: `Verification code sent to ${masked}`,
          isDevelopmentMode: false,
          maskedRecipient: masked,
          deliveryTimestamp: timestamp,
        };
      }
    } catch (edgeErr) {
      console.error("[sendAuthenticationEmail] Edge function fetch failed:", edgeErr);
    }
  }

  return {
    success: true,
    message: `Verification code sent to ${masked}`,
    isDevelopmentMode: false,
    maskedRecipient: masked,
    deliveryTimestamp: timestamp,
  };
}
