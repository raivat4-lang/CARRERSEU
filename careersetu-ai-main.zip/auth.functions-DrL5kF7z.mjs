import { c as createServerFn } from "./createServerFn-CIHAFgYl.mjs";
import { t as createServerRpc } from "./createServerRpc-B90ckaqP.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth.functions-DrL5kF7z.js
function maskEmail(email) {
	if (!email || !email.includes("@")) return "******@domain.com";
	const [user, domain] = email.split("@");
	if (!user || !domain) return "******@domain.com";
	if (user.length <= 2) return `${user[0]}*@${domain}`;
	const first = user[0];
	const last = user[user.length - 1];
	return `${first}${"*".repeat(Math.max(3, user.length - 2))}${last}@${domain}`;
}
var resendRateLimitMap = /* @__PURE__ */ new Map();
var dispatchEmailOtpServerFn_createServerFn_handler = createServerRpc({
	id: "47a91ffb18276e5b52c5df1512d391c1092d1c0cca3f93438b318db025c45604",
	name: "dispatchEmailOtpServerFn",
	filename: "src/lib/auth/auth.functions.ts"
}, (opts) => dispatchEmailOtpServerFn.__executeServer(opts));
var dispatchEmailOtpServerFn = createServerFn({ method: "POST" }).validator((data) => data).handler(dispatchEmailOtpServerFn_createServerFn_handler, async ({ data }) => {
	const { generate6DigitOtp, hashOtp, signChallenge } = await import("./session.server-XfVCDd2_.mjs");
	const { sendEmailViaSmtp } = await import("./email.server-DSGYwhG3.mjs");
	const cleanEmail = (data.email || "").trim().toLowerCase();
	const purpose = data.purpose || "STUDENT_LOGIN";
	const recipientName = data.recipientName || "Student";
	if (!cleanEmail || !cleanEmail.includes("@")) return {
		success: false,
		error: "A valid email address is required."
	};
	const now = Date.now();
	const lastSent = resendRateLimitMap.get(cleanEmail);
	if (lastSent && now - lastSent < 15e3) return {
		success: false,
		error: `Please wait ${Math.ceil((15e3 - (now - lastSent)) / 1e3)} seconds before requesting another code.`
	};
	resendRateLimitMap.set(cleanEmail, now);
	const otpCode = generate6DigitOtp();
	const codeHash = hashOtp(otpCode);
	const expiresInMinutes = 10;
	const expiresAt = now + 6e5;
	const emailResult = await sendEmailViaSmtp({
		to: cleanEmail,
		subject: `CareerSetu Verification Code`,
		recipientName,
		otpCode,
		purpose,
		expiresInMinutes
	});
	const challengeToken = signChallenge({
		email: cleanEmail,
		codeHash,
		purpose,
		expiresAt,
		attemptCount: 0
	});
	return {
		success: true,
		maskedEmail: maskEmail(cleanEmail),
		expiresInMinutes,
		challengeToken,
		sentViaSmtp: emailResult.sentViaSmtp,
		devOtp: emailResult.sentViaSmtp ? void 0 : otpCode
	};
});
var verifyEmailOtpServerFn_createServerFn_handler = createServerRpc({
	id: "30b51e85fa0c376e6f30cf1699b3e7ba7a576623749526186cc633f00b42c6ee",
	name: "verifyEmailOtpServerFn",
	filename: "src/lib/auth/auth.functions.ts"
}, (opts) => verifyEmailOtpServerFn.__executeServer(opts));
var verifyEmailOtpServerFn = createServerFn({ method: "POST" }).validator((data) => data).handler(verifyEmailOtpServerFn_createServerFn_handler, async ({ data }) => {
	const { verifyAndDecodeChallenge, hashOtp, signChallenge } = await import("./session.server-XfVCDd2_.mjs");
	const cleanEmail = (data.email || "").trim().toLowerCase();
	const cleanOtp = (data.otp || "").trim();
	const token = data.challengeToken;
	if (!cleanOtp || cleanOtp.length !== 6) return {
		valid: false,
		error: "Please enter the complete 6-digit verification code."
	};
	if (!token) return {
		valid: false,
		error: "Session challenge expired. Please request a new code."
	};
	const challenge = verifyAndDecodeChallenge(token);
	if (!challenge) return {
		valid: false,
		error: "Invalid security verification token. Please sign in again."
	};
	if (challenge.email.toLowerCase() !== cleanEmail) return {
		valid: false,
		error: "Email mismatch for verification token."
	};
	if (Date.now() > challenge.expiresAt) return {
		valid: false,
		error: "Verification code has expired. Please request a new code."
	};
	if (challenge.attemptCount >= 5) return {
		valid: false,
		error: "Too many failed attempts. Code locked for security. Please request a new code."
	};
	if (hashOtp(cleanOtp) !== challenge.codeHash) {
		challenge.attemptCount += 1;
		const updatedToken = signChallenge(challenge);
		const remaining = 5 - challenge.attemptCount;
		return {
			valid: false,
			updatedChallengeToken: updatedToken,
			error: `Incorrect verification code. ${remaining > 0 ? `${remaining} attempts remaining.` : "Code locked."}`
		};
	}
	return {
		valid: true,
		email: cleanEmail,
		purpose: challenge.purpose
	};
});
var issueAuthenticatedSessionServerFn_createServerFn_handler = createServerRpc({
	id: "6484f007b1fc41a42de564e5ca21f6324e9f9082cea1f053ead767b7a05501d4",
	name: "issueAuthenticatedSessionServerFn",
	filename: "src/lib/auth/auth.functions.ts"
}, (opts) => issueAuthenticatedSessionServerFn.__executeServer(opts));
var issueAuthenticatedSessionServerFn = createServerFn({ method: "POST" }).validator((data) => data).handler(issueAuthenticatedSessionServerFn_createServerFn_handler, async ({ data }) => {
	const { signSessionToken } = await import("./session.server-XfVCDd2_.mjs");
	const cleanEmail = (data.email || "").trim().toLowerCase();
	const role = data.role;
	if (!cleanEmail) return {
		success: false,
		error: "Email is required."
	};
	if (role === "ADMIN") {
		if (![
			"raivats4@gmail.com",
			"tysonfire13@gmail.com",
			"admin@careersetu.ai"
		].includes(cleanEmail)) {
			const { getAllUsers } = await import("./rbac-D_Rf6U5V.mjs").then((n) => n.T);
			if (!getAllUsers().find((u) => u.email.toLowerCase() === cleanEmail && u.role === "ADMIN" && u.is_active)) return {
				success: false,
				error: "Access forbidden: Account is not authorized as an administrator."
			};
		}
	}
	const now = Date.now();
	const expiresAt = now + 6048e5;
	const payload = {
		userId: data.userId || (role === "ADMIN" ? "a0000000-0000-0000-0000-000000000001" : `usr-${Date.now()}`),
		email: cleanEmail,
		role,
		mfaVerified: true,
		issuedAt: now,
		expiresAt
	};
	return {
		success: true,
		token: signSessionToken(payload),
		session: payload
	};
});
var verifyAdminAccessServerFn_createServerFn_handler = createServerRpc({
	id: "cc18aeb21e4e1ddbe2d74853e6616f2ba0b78c6a740f4dec4e896de9fbc7200f",
	name: "verifyAdminAccessServerFn",
	filename: "src/lib/auth/auth.functions.ts"
}, (opts) => verifyAdminAccessServerFn.__executeServer(opts));
var verifyAdminAccessServerFn = createServerFn({ method: "POST" }).validator((data) => data).handler(verifyAdminAccessServerFn_createServerFn_handler, async ({ data }) => {
	const { verifyAndDecodeSessionToken } = await import("./session.server-XfVCDd2_.mjs");
	const token = (data.token || "").trim();
	if (!token) return {
		authorized: false,
		error: "Authentication token missing."
	};
	const session = verifyAndDecodeSessionToken(token);
	if (!session) return {
		authorized: false,
		error: "Session token invalid or expired."
	};
	if (session.role !== "ADMIN" || !session.mfaVerified) return {
		authorized: false,
		error: "Forbidden: 2FA-verified Administrator role required."
	};
	return {
		authorized: true,
		user: {
			id: session.userId,
			email: session.email,
			role: session.role,
			mfaVerified: session.mfaVerified
		}
	};
});
var verifyStudentAccessServerFn_createServerFn_handler = createServerRpc({
	id: "3c242df52bab37d251e2986cea68e4c514ec03074767cce04aa8da5a8dae7b72",
	name: "verifyStudentAccessServerFn",
	filename: "src/lib/auth/auth.functions.ts"
}, (opts) => verifyStudentAccessServerFn.__executeServer(opts));
var verifyStudentAccessServerFn = createServerFn({ method: "POST" }).validator((data) => data).handler(verifyStudentAccessServerFn_createServerFn_handler, async ({ data }) => {
	const { verifyAndDecodeSessionToken } = await import("./session.server-XfVCDd2_.mjs");
	const token = (data.token || "").trim();
	if (!token) return {
		authorized: false,
		error: "Authentication token missing."
	};
	const session = verifyAndDecodeSessionToken(token);
	if (!session) return {
		authorized: false,
		error: "Session token invalid or expired."
	};
	if (!session.mfaVerified) return {
		authorized: false,
		error: "MFA verification required."
	};
	return {
		authorized: true,
		user: {
			id: session.userId,
			email: session.email,
			role: session.role,
			mfaVerified: session.mfaVerified
		}
	};
});
var dispatchResendOtpDirectServerFn_createServerFn_handler = createServerRpc({
	id: "d424ee3e8af7c19202aeae85f5b466ac39f54dc484ba38a9546da60d20c47bda",
	name: "dispatchResendOtpDirectServerFn",
	filename: "src/lib/auth/auth.functions.ts"
}, (opts) => dispatchResendOtpDirectServerFn.__executeServer(opts));
var dispatchResendOtpDirectServerFn = createServerFn({ method: "POST" }).validator((data) => data).handler(dispatchResendOtpDirectServerFn_createServerFn_handler, async ({ data }) => {
	const { sendEmailViaSmtp } = await import("./email.server-DSGYwhG3.mjs");
	const cleanEmail = (data.to || "").trim().toLowerCase();
	const purpose = data.purpose || "STUDENT_LOGIN";
	const recipientName = data.recipientName || "User";
	const otpCode = data.otpCode;
	const expiresInMinutes = data.expiresInMinutes || 10;
	if (!cleanEmail || !cleanEmail.includes("@")) return {
		success: false,
		error: "A valid email address is required."
	};
	if (!otpCode) return {
		success: false,
		error: "OTP code missing."
	};
	const emailResult = await sendEmailViaSmtp({
		to: cleanEmail,
		subject: "CareerSetu Verification Code",
		recipientName,
		otpCode,
		purpose,
		expiresInMinutes
	});
	return {
		success: emailResult.success,
		sentViaSmtp: emailResult.sentViaSmtp,
		error: emailResult.error
	};
});
//#endregion
export { dispatchEmailOtpServerFn_createServerFn_handler, dispatchResendOtpDirectServerFn_createServerFn_handler, issueAuthenticatedSessionServerFn_createServerFn_handler, verifyAdminAccessServerFn_createServerFn_handler, verifyEmailOtpServerFn_createServerFn_handler, verifyStudentAccessServerFn_createServerFn_handler };
