import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Card } from "./card-95-PmP7N.mjs";
import { t as Badge } from "./badge-BYEzUON3.mjs";
import { C as Search, Ot as Bookmark, h as Star, it as ExternalLink, kt as BookOpen, mt as CircleCheckBig } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-D7UBWI0-.mjs";
import { c as getManagedResources } from "./admin-content-store-CcAL24zG.mjs";
import { _ as toggleBookmark, l as isBookmarked } from "./careersetu-store-CamG1tac.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-BfMpEmcB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/resources-CaoG8GsZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var RESOURCE_CATEGORIES = [
	"All Categories",
	"Standard Books",
	"Official Portals & Syllabus",
	"YouTube Courses",
	"Practice Papers & PYQs",
	"Free PDFs & Notes"
];
function LearningResourcesPage() {
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [selectedCategory, setSelectedCategory] = (0, import_react.useState)("All Categories");
	const [bookmarkedMap, setBookmarkedMap] = (0, import_react.useState)({});
	const [completedMap, setCompletedMap] = (0, import_react.useState)({});
	const [resourcesList, setResourcesList] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		const live = getManagedResources().filter((r) => r.status !== "ARCHIVED");
		setResourcesList(live);
		const bMap = {};
		live.forEach((r) => {
			bMap[r.id] = isBookmarked("resources", r.id);
		});
		setBookmarkedMap(bMap);
		if (typeof localStorage !== "undefined") {
			const comp = localStorage.getItem("careersetu_completed_resources");
			if (comp) try {
				setCompletedMap(JSON.parse(comp));
			} catch {}
		}
	}, []);
	const handleToggleBookmark = (id) => {
		const isNow = toggleBookmark("resources", id);
		setBookmarkedMap((prev) => ({
			...prev,
			[id]: isNow
		}));
		toast.success(isNow ? "Resource saved to bookmarks" : "Removed from bookmarks");
	};
	const handleToggleComplete = (id) => {
		const updated = {
			...completedMap,
			[id]: !completedMap[id]
		};
		setCompletedMap(updated);
		if (typeof localStorage !== "undefined") localStorage.setItem("careersetu_completed_resources", JSON.stringify(updated));
		toast.success(updated[id] ? "Marked resource as completed! 🎉" : "Marked as incomplete");
	};
	const filteredResources = (0, import_react.useMemo)(() => {
		return resourcesList.filter((r) => {
			const q = searchQuery.toLowerCase().trim();
			const matchesSearch = !q || r.title.toLowerCase().includes(q) || r.authorOrProvider && r.authorOrProvider.toLowerCase().includes(q) || r.targetExamOrCareer && r.targetExamOrCareer.toLowerCase().includes(q) || r.tags && r.tags.some((t) => t.toLowerCase().includes(q));
			const matchesCat = selectedCategory === "All Categories" || r.category === selectedCategory;
			return matchesSearch && matchesCat;
		});
	}, [
		resourcesList,
		searchQuery,
		selectedCategory
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 max-w-5xl mx-auto py-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-9 place-items-center rounded-xl bg-primary/10 text-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-xl sm:text-2xl font-bold font-display text-foreground",
						children: "Curated Learning Resources & PYQs"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs sm:text-sm text-muted-foreground mt-1",
					children: "Standard textbooks, official previous year question banks, free YouTube series, and verified portals."
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "glass p-4 rounded-3xl border-border/80 shadow-xs space-y-3 bg-card/80",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 gap-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-2.5 size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: searchQuery,
							onChange: (e) => setSearchQuery(e.target.value),
							placeholder: "Search by book, exam, author, topic...",
							className: "pl-9 h-10 rounded-xl bg-background border-border text-xs sm:text-sm"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: selectedCategory,
						onValueChange: setSelectedCategory,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "rounded-xl h-10 text-xs bg-background",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Category" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, {
							className: "rounded-2xl",
							children: RESOURCE_CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: c,
								className: "text-xs",
								children: c
							}, c))
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between text-xs pt-1 text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						"Showing ",
						filteredResources.length,
						" verified learning resources"
					] }), (searchQuery || selectedCategory !== "All Categories") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							setSearchQuery("");
							setSelectedCategory("All Categories");
						},
						className: "text-primary hover:underline text-[11px] font-medium cursor-pointer",
						children: "Clear Filters"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 md:grid-cols-2 gap-4",
				children: filteredResources.map((res) => {
					const isSaved = bookmarkedMap[res.id];
					const isDone = completedMap[res.id];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: `glass p-5 rounded-3xl border transition-all flex flex-col justify-between space-y-4 shadow-xs hover:shadow-lg ${isDone ? "bg-muted/30 border-border/50 opacity-80" : "bg-card/90 border-border/80 hover:border-primary/40"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "outline",
										className: "text-[10px] border-primary/20 text-primary bg-primary/5",
										children: res.category
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[10px] font-semibold text-amber-500 bg-amber-500/10 px-1.5 py-0.5 rounded-md flex items-center gap-0.5",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "size-3 fill-amber-500 text-amber-500" }),
												" ",
												res.rating
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => handleToggleBookmark(res.id),
											className: "p-1 rounded-lg text-muted-foreground hover:text-primary transition-colors cursor-pointer",
											title: "Bookmark resource",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: `size-3.5 ${isSaved ? "fill-primary text-primary" : ""}` })
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-bold text-base text-foreground leading-snug",
										children: res.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs font-semibold text-primary mt-0.5",
										children: [
											res.authorOrProvider,
											" · Target: ",
											res.targetExamOrCareer
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground mt-1.5 line-clamp-2 leading-relaxed",
										children: res.description
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-wrap gap-1 pt-1",
									children: res.tags.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[10px] px-2 py-0.5 rounded-md bg-accent text-foreground font-mono",
										children: ["#", t]
									}, t))
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2 pt-3 border-t border-border/40",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => handleToggleComplete(res.id),
								className: `flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1.5 rounded-xl border transition-colors cursor-pointer ${isDone ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30" : "hover:bg-accent border-border text-muted-foreground"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheckBig, { className: `size-3.5 ${isDone ? "fill-emerald-500 text-white" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isDone ? "Completed" : "Mark Done" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: res.sourceUrl,
								target: "_blank",
								rel: "noreferrer",
								className: "inline-flex items-center gap-1 text-xs font-bold text-primary hover:underline",
								children: [
									"Open ",
									res.sourceLabel,
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3.5" })
								]
							})]
						})]
					}, res.id);
				})
			})
		]
	});
}
//#endregion
export { LearningResourcesPage as component };
