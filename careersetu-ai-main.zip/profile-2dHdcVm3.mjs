import { i as __toESM } from "../_runtime.mjs";
import { h as getCurrentUser, k as setCurrentUser } from "./rbac-D_Rf6U5V.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Card } from "./card-95-PmP7N.mjs";
import { t as Button } from "./button-CdcMTBqt.mjs";
import { X as GraduationCap, g as Sparkles, o as User, w as Save } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-D7UBWI0-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Progress } from "./progress-CNflbst_.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-BfMpEmcB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profile-2dHdcVm3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProfilePage() {
	const currentUser = getCurrentUser();
	const [profile, setProfile] = (0, import_react.useState)({
		fullName: currentUser.full_name || "Student User",
		email: currentUser.email || "student@careersetu.ai",
		phone: currentUser.phone || "+91 98765 43210",
		city: currentUser.city || "Mumbai",
		state: currentUser.state || "Maharashtra",
		educationLevel: currentUser.current_education || "Graduate (B.Tech CS)",
		stream: "Computer Science & AI",
		targetCareer: "AI & Machine Learning Engineer",
		preferredLanguage: currentUser.preferred_language || "English"
	});
	(0, import_react.useEffect)(() => {
		const user = getCurrentUser();
		setProfile({
			fullName: user.full_name || "Student User",
			email: user.email || "student@careersetu.ai",
			phone: user.phone || "+91 98765 43210",
			city: user.city || "Mumbai",
			state: user.state || "Maharashtra",
			educationLevel: user.current_education || "Graduate (B.Tech CS)",
			stream: "Computer Science & AI",
			targetCareer: "AI & Machine Learning Engineer",
			preferredLanguage: user.preferred_language || "English"
		});
	}, []);
	const handleSave = (e) => {
		e.preventDefault();
		const updatedUser = {
			...currentUser,
			full_name: profile.fullName,
			phone: profile.phone,
			city: profile.city,
			state: profile.state,
			current_education: profile.educationLevel,
			preferred_language: profile.preferredLanguage
		};
		setCurrentUser(updatedUser);
		toast.success("Profile updated successfully!");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 max-w-3xl mx-auto py-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-center justify-between pb-4 border-b border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "text-xl sm:text-2xl font-bold font-display text-foreground flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-5 text-primary" }), " My Student Profile"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs sm:text-sm text-muted-foreground mt-1",
					children: "Personalize your academic background to optimize AI recommendations."
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "glass p-5 rounded-3xl border-border/80 shadow-xs bg-card/90 space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between text-xs text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold text-foreground",
						children: "Profile Completeness"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "text-emerald-500 font-bold",
						children: "92% Completed"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
					value: 92,
					className: "h-2 rounded-full"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
				onSubmit: handleSave,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "glass p-6 sm:p-8 rounded-3xl border-border/80 shadow-md bg-card/90 space-y-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "font-bold text-sm text-foreground flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "size-4 text-primary" }), " Academic & Personal Details"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "font-semibold text-muted-foreground block mb-1",
									children: "Full Legal Name"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: profile.fullName,
									onChange: (e) => setProfile({
										...profile,
										fullName: e.target.value
									}),
									className: "rounded-xl h-10",
									required: true
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "font-semibold text-muted-foreground block mb-1",
									children: "Email Address"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "email",
									value: profile.email,
									onChange: (e) => setProfile({
										...profile,
										email: e.target.value
									}),
									className: "rounded-xl h-10",
									required: true
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "font-semibold text-muted-foreground block mb-1",
									children: "Phone Number"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: profile.phone,
									onChange: (e) => setProfile({
										...profile,
										phone: e.target.value
									}),
									className: "rounded-xl h-10"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "font-semibold text-muted-foreground block mb-1",
									children: "Current Education Level"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: profile.educationLevel,
									onValueChange: (val) => setProfile({
										...profile,
										educationLevel: val
									}),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										className: "rounded-xl h-10 bg-background text-xs",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, {
										className: "rounded-2xl",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "class_10",
												className: "text-xs",
												children: "Class 10 (Secondary)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "class_12",
												className: "text-xs",
												children: "Class 12 (Higher Secondary)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "diploma",
												className: "text-xs",
												children: "Polytechnic Diploma"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "graduate",
												className: "text-xs",
												children: "Undergraduate / Bachelor's"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "post_graduate",
												className: "text-xs",
												children: "Postgraduate / Master's"
											})
										]
									})]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "font-semibold text-muted-foreground block mb-1",
									children: "City"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: profile.city,
									onChange: (e) => setProfile({
										...profile,
										city: e.target.value
									}),
									className: "rounded-xl h-10"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "font-semibold text-muted-foreground block mb-1",
									children: "State"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: profile.state,
									onChange: (e) => setProfile({
										...profile,
										state: e.target.value
									}),
									className: "rounded-xl h-10"
								})] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3 pt-3 border-t border-border",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "font-bold text-sm text-foreground flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4 text-primary" }), " Career Aspirations"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "font-semibold text-muted-foreground block mb-1",
									children: "Academic Stream"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: profile.stream,
									onChange: (e) => setProfile({
										...profile,
										stream: e.target.value
									}),
									className: "rounded-xl h-10"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "font-semibold text-muted-foreground block mb-1",
									children: "Primary Target Career"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: profile.targetCareer,
									onChange: (e) => setProfile({
										...profile,
										targetCareer: e.target.value
									}),
									className: "rounded-xl h-10"
								})] })]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex justify-end pt-4 border-t border-border",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "submit",
								size: "sm",
								className: "gradient-brand text-primary-foreground font-bold rounded-xl shadow-glow cursor-pointer gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-4" }), " Save Profile Changes"]
							})
						})
					]
				})
			})
		]
	});
}
//#endregion
export { ProfilePage as component };
