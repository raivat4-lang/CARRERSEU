//#region node_modules/.nitro/vite/services/ssr/assets/colleges-data-D-tQlA8g.js
var CAREERS_DATA = [
	{
		id: "ai-ml-engineer",
		name: "AI & Machine Learning Engineer",
		domain: "Technology",
		salary: "₹12 - ₹40 LPA",
		minSalaryLPA: 12,
		maxSalaryLPA: 40,
		demand: "Very High",
		educationRequired: "Graduate",
		sector: "Private",
		workType: "Hybrid",
		description: "Design and deploy intelligent neural networks, LLMs, computer vision, and predictive models.",
		responsibilities: [
			"Train deep learning architectures and fine-tune Large Language Models",
			"Build scalable machine learning pipelines with PyTorch and TensorFlow",
			"Optimize model latency, GPU inference, and deployment on AWS/GCP",
			"Collaborate with data engineers to ensure high-quality feature stores"
		],
		requiredSkills: [
			"Python",
			"PyTorch",
			"Transformers",
			"SQL",
			"Linear Algebra",
			"Docker",
			"MLOps"
		],
		degrees: [
			"B.Tech in CSE / AI & DS",
			"M.Tech / MS in Computer Science",
			"BCA + MCA with AI Specialization"
		],
		topColleges: [
			"IIT Bombay",
			"IIT Delhi",
			"IIIT Hyderabad",
			"BITS Pilani",
			"IISc Bangalore"
		],
		topRecruiters: [
			"Google",
			"Microsoft",
			"NVIDIA",
			"Amazon",
			"OpenAI",
			"Flipkart",
			"Zomato"
		],
		futureScope: "Explosive growth with enterprise GenAI adoption and autonomous systems.",
		roadmap: [
			{
				stage: "Stage 1",
				title: "Math & Python Foundations",
				desc: "Master Linear Algebra, Multivariable Calculus, Probability, and Python programming."
			},
			{
				stage: "Stage 2",
				title: "Classical Machine Learning",
				desc: "Build supervised/unsupervised models using Scikit-Learn, Pandas, and NumPy."
			},
			{
				stage: "Stage 3",
				title: "Deep Learning & Neural Networks",
				desc: "Master PyTorch, CNNs, RNNs, and Transformer architectures (BERT, GPT)."
			},
			{
				stage: "Stage 4",
				title: "LLMs & Generative AI",
				desc: "Fine-tune models with LoRA, build RAG pipelines using LangChain and Vector DBs."
			},
			{
				stage: "Stage 5",
				title: "MLOps & Cloud Deployment",
				desc: "Deploy models with FastAPI, Docker, Kubernetes, and AWS SageMaker."
			},
			{
				stage: "Stage 6",
				title: "Portfolio & High-Value Placement",
				desc: "Publish open-source AI projects, contribute to HuggingFace, and interview."
			}
		],
		governmentExams: [
			"ISRO Scientist (Computer Science)",
			"DRDO Scientist B",
			"NIC Scientist"
		],
		relatedCareerIds: [
			"data-scientist",
			"cloud-architect",
			"cyber-security-analyst"
		],
		tags: [
			"Artificial Intelligence",
			"Deep Learning",
			"Generative AI",
			"High Salary",
			"Top Trend"
		]
	},
	{
		id: "full-stack-developer",
		name: "Full Stack Software Engineer",
		domain: "Technology",
		salary: "₹8 - ₹26 LPA",
		minSalaryLPA: 8,
		maxSalaryLPA: 26,
		demand: "Very High",
		educationRequired: "Graduate",
		sector: "Both",
		workType: "Remote Friendly",
		description: "Architect and engineer end-to-end web applications across front-end, back-end APIs, and databases.",
		responsibilities: [
			"Develop responsive user interfaces using React, Next.js, and TypeScript",
			"Create robust microservices and REST/GraphQL APIs with Node.js or Go",
			"Manage relational and NoSQL databases like PostgreSQL, Redis, and MongoDB",
			"Implement CI/CD automated deployments on Vercel and AWS"
		],
		requiredSkills: [
			"TypeScript",
			"React",
			"Node.js",
			"PostgreSQL",
			"Tailwind CSS",
			"Git",
			"System Design"
		],
		degrees: [
			"B.Tech CSE / IT",
			"BCA + MCA",
			"B.Sc Computer Science / IT"
		],
		topColleges: [
			"IITs",
			"NIT Trichy",
			"IIIT Allahabad",
			"VIT Vellore",
			"DTU Delhi"
		],
		topRecruiters: [
			"Adobe",
			"Uber",
			"Swiggy",
			"PhonePe",
			"Atlassian",
			"CRED"
		],
		futureScope: "Continuous evergreen demand across all tech startups and global SaaS enterprises.",
		roadmap: [
			{
				stage: "Stage 1",
				title: "Core Web Fundamentals",
				desc: "HTML5, modern CSS, JavaScript (ES6+), and responsive layouts."
			},
			{
				stage: "Stage 2",
				title: "Modern Front-End Mastery",
				desc: "React, Next.js, TypeScript, state management, and Tailwind CSS."
			},
			{
				stage: "Stage 3",
				title: "Back-End & API Development",
				desc: "Node.js, Express, RESTful APIs, authentication, and security."
			},
			{
				stage: "Stage 4",
				title: "Database & Performance Tuning",
				desc: "PostgreSQL, Prisma ORM, Redis caching, and database indexing."
			},
			{
				stage: "Stage 5",
				title: "DevOps & System Architecture",
				desc: "Docker containers, GitHub Actions CI/CD, and AWS deployment."
			},
			{
				stage: "Stage 6",
				title: "Production SaaS Project",
				desc: "Build & launch a production SaaS with Stripe/Razorpay payments."
			}
		],
		governmentExams: [
			"NIC Scientist B",
			"ISRO Scientist/Engineer",
			"SBI PO (IT Officer)"
		],
		relatedCareerIds: [
			"ai-ml-engineer",
			"cloud-architect",
			"mobile-app-developer"
		],
		tags: [
			"React",
			"NodeJS",
			"Full Stack",
			"SaaS",
			"Remote Work"
		]
	},
	{
		id: "data-scientist",
		name: "Data Scientist & Analytics Lead",
		domain: "Technology",
		salary: "₹10 - ₹32 LPA",
		minSalaryLPA: 10,
		maxSalaryLPA: 32,
		demand: "High",
		educationRequired: "Graduate",
		sector: "Both",
		workType: "Hybrid",
		description: "Extract predictive patterns, build business forecasting algorithms, and drive data-informed decisions.",
		responsibilities: [
			"Perform exploratory data analysis and hypothesis testing on large datasets",
			"Build regression, clustering, and classification models with Scikit-learn",
			"Create executive dashboards in Tableau, Power BI, and Streamlit",
			"Communicate statistical findings to leadership and product managers"
		],
		requiredSkills: [
			"Python",
			"R",
			"SQL",
			"Tableau",
			"Power BI",
			"Statistics",
			"Machine Learning"
		],
		degrees: [
			"B.Tech CSE/Stats",
			"B.Sc Statistics/Maths",
			"M.Sc Data Science"
		],
		topColleges: [
			"ISI Kolkata",
			"IIT Kharagpur",
			"IIT Bombay",
			"CMI Chennai",
			"BITS Pilani"
		],
		topRecruiters: [
			"Fractal Analytics",
			"Mu Sigma",
			"Amazon",
			"McKinsey",
			"JPMorgan Chase"
		],
		futureScope: "High demand across fintech, retail, healthcare, and e-commerce analytics.",
		roadmap: [
			{
				stage: "Stage 1",
				title: "Statistics & Mathematical Foundations",
				desc: "Descriptive & inferential stats, probability distributions, hypothesis testing."
			},
			{
				stage: "Stage 2",
				title: "SQL & Data Wrangling",
				desc: "Advanced SQL queries, window functions, Pandas, and data cleaning."
			},
			{
				stage: "Stage 3",
				title: "Data Visualization & Storytelling",
				desc: "Power BI, Tableau, Matplotlib, and executive presentations."
			},
			{
				stage: "Stage 4",
				title: "Predictive Modeling",
				desc: "Regression, Decision Trees, XGBoost, and Time-Series forecasting."
			},
			{
				stage: "Stage 5",
				title: "Big Data & Production",
				desc: "PySpark, BigQuery, Databricks, and cloud data lakes."
			},
			{
				stage: "Stage 6",
				title: "End-to-End Capstone",
				desc: "Deploy an interactive predictive analytics dashboard on Streamlit."
			}
		],
		governmentExams: [
			"RBI Grade B (DEPR/DSIM)",
			"Indian Statistical Service (ISS)",
			"NIC Scientist"
		],
		tags: [
			"Data Science",
			"Python",
			"SQL",
			"Statistics",
			"High Demand"
		]
	},
	{
		id: "cloud-architect",
		name: "Cloud Architect & DevOps Engineer",
		domain: "Technology",
		salary: "₹12 - ₹36 LPA",
		minSalaryLPA: 12,
		maxSalaryLPA: 36,
		demand: "Very High",
		educationRequired: "Graduate",
		sector: "Both",
		workType: "Remote Friendly",
		description: "Architect high-availability cloud infrastructure and automate software delivery pipelines.",
		responsibilities: [
			"Design multi-region cloud architectures on AWS, GCP, or Azure",
			"Automate infrastructure provisioning using Terraform and Ansible",
			"Manage Kubernetes clusters and Docker container orchestration",
			"Ensure 99.99% system uptime, load balancing, and disaster recovery"
		],
		requiredSkills: [
			"AWS/GCP/Azure",
			"Kubernetes",
			"Docker",
			"Terraform",
			"Linux",
			"CI/CD",
			"Bash"
		],
		degrees: [
			"B.Tech in CSE / IT",
			"BCA + MCA",
			"Diploma in Computer Hardware/Networking"
		],
		topColleges: [
			"IITs",
			"NITs",
			"IIITs",
			"Thapar University",
			"Manipal Institute of Technology"
		],
		topRecruiters: [
			"Amazon Web Services",
			"Microsoft Azure",
			"Google Cloud",
			"Red Hat",
			"Cisco"
		],
		futureScope: "Essential for 100% of modern software enterprises moving to the cloud.",
		roadmap: [
			{
				stage: "Stage 1",
				title: "Linux & Networking Mastery",
				desc: "Linux command line, shell scripting, DNS, TCP/IP, and SSH."
			},
			{
				stage: "Stage 2",
				title: "Cloud Fundamentals (AWS/GCP)",
				desc: "EC2, S3, VPC, IAM, Lambda, and CloudWatch."
			},
			{
				stage: "Stage 3",
				title: "Containerization (Docker)",
				desc: "Dockerfiles, multi-stage builds, networking, and volume management."
			},
			{
				stage: "Stage 4",
				title: "Orchestration (Kubernetes)",
				desc: "Pods, Deployments, Services, Helm charts, and Ingress controllers."
			},
			{
				stage: "Stage 5",
				title: "Infrastructure as Code (IaC)",
				desc: "Terraform modules, state management, and GitOps workflows."
			},
			{
				stage: "Stage 6",
				title: "Professional Certifications",
				desc: "Earn AWS Solutions Architect / CKA (Certified Kubernetes Admin)."
			}
		],
		governmentExams: [
			"DRDO RAC",
			"ISRO Scientist B",
			"CDAC Technical Officer"
		],
		tags: [
			"Cloud",
			"DevOps",
			"AWS",
			"Kubernetes",
			"Infrastructure"
		]
	},
	{
		id: "cyber-security-analyst",
		name: "Cybersecurity Analyst & Ethical Hacker",
		domain: "Technology",
		salary: "₹8 - ₹28 LPA",
		minSalaryLPA: 8,
		maxSalaryLPA: 28,
		demand: "Very High",
		educationRequired: "Graduate",
		sector: "Both",
		workType: "Hybrid",
		description: "Protect enterprise digital assets, conduct vulnerability audits, and counter cyber threats.",
		responsibilities: [
			"Perform penetration testing and vulnerability assessments (VAPT)",
			"Monitor SIEM logs and respond to active network security breaches",
			"Conduct security audits for ISO 27001, SOC 2, and GDPR compliance",
			"Implement zero-trust network architectures and cryptographic protocols"
		],
		requiredSkills: [
			"Ethical Hacking",
			"Wireshark",
			"Burp Suite",
			"SIEM",
			"Cryptography",
			"Network Security"
		],
		degrees: [
			"B.Tech CSE (Cyber Security)",
			"B.Sc IT / Cyber Security",
			"BCA + Certifications (CEH/OSCP)"
		],
		topColleges: [
			"National Forensic Sciences University (NFSU)",
			"IIT Kanpur (C3i)",
			"IIIT Delhi",
			"Amrita University"
		],
		topRecruiters: [
			"PwC",
			"EY",
			"KPMG",
			"Deloitte",
			"CrowdStrike",
			"Palantir",
			"Indian Armed Forces Cyber Wing"
		],
		futureScope: "Critical national security and enterprise demand due to surging cyber warfare risks.",
		roadmap: [
			{
				stage: "Stage 1",
				title: "Networking & OS Fundamentals",
				desc: "OSI model, Wireshark packet analysis, Linux/Windows internals."
			},
			{
				stage: "Stage 2",
				title: "Security Tools & Web Hacking",
				desc: "OWASP Top 10 vulnerabilities, Burp Suite, Nmap, Metasploit."
			},
			{
				stage: "Stage 3",
				title: "Defensive Security (SOC & SIEM)",
				desc: "Log monitoring using Splunk, threat hunting, and incident response."
			},
			{
				stage: "Stage 4",
				title: "Certifications Preparation",
				desc: "Prepare for CompTIA Security+, CEH, or eJPT certifications."
			},
			{
				stage: "Stage 5",
				title: "Advanced Pen Testing (OSCP)",
				desc: "Active Directory exploitation, buffer overflows, and privilege escalation."
			},
			{
				stage: "Stage 6",
				title: "Bug Bounty & Industry Role",
				desc: "Participate on HackerOne/Bugcrowd and secure cybersecurity roles."
			}
		],
		governmentExams: [
			"CERT-In Analyst",
			"NTRO Scientist",
			"IB ACIO (Technical)",
			"DRDO Scientist"
		],
		tags: [
			"Cyber Security",
			"Ethical Hacking",
			"InfoSec",
			"High Demand",
			"National Security"
		]
	},
	{
		id: "mobile-app-developer",
		name: "Mobile App Developer (Flutter & React Native)",
		domain: "Technology",
		salary: "₹7 - ₹22 LPA",
		minSalaryLPA: 7,
		maxSalaryLPA: 22,
		demand: "High",
		educationRequired: "Graduate",
		sector: "Private",
		workType: "Remote Friendly",
		description: "Build fluid, cross-platform Android & iOS applications with native performance and animations.",
		responsibilities: [
			"Develop cross-platform apps using Flutter/React Native",
			"Integrate native device APIs and push notifications",
			"Publish and optimize apps on Google Play Store and Apple App Store"
		],
		requiredSkills: [
			"Flutter",
			"Dart",
			"React Native",
			"Swift/Kotlin",
			"Firebase",
			"App Store Guidelines"
		],
		degrees: [
			"B.Tech CSE/IT",
			"BCA",
			"B.Sc Computer Science"
		],
		topColleges: [
			"IITs",
			"NITs",
			"Manipal",
			"SRM",
			"Symbiosis"
		],
		topRecruiters: [
			"Paytm",
			"Zomato",
			"Uber",
			"MakeMyTrip",
			"Urban Company"
		],
		futureScope: "Steady demand with mobile-first consumer economy in India.",
		roadmap: [
			{
				stage: "Stage 1",
				title: "Language Foundations",
				desc: "Master Dart or TypeScript/JavaScript."
			},
			{
				stage: "Stage 2",
				title: "UI & State Management",
				desc: "Build widgets/screens, Bloc/Provider/Redux state flows."
			},
			{
				stage: "Stage 3",
				title: "Backend Integration",
				desc: "REST APIs, Firebase Auth, Push Notifications, offline caching."
			},
			{
				stage: "Stage 4",
				title: "Native Bridge & Performance",
				desc: "Kotlin/Swift native bridging, rendering optimization."
			},
			{
				stage: "Stage 5",
				title: "Store Publishing",
				desc: "Build signing, release pipelines, Play Store & App Store deployments."
			}
		],
		tags: [
			"Flutter",
			"React Native",
			"Android",
			"iOS",
			"Mobile Dev"
		]
	},
	{
		id: "blockchain-engineer",
		name: "Blockchain & Web3 Developer",
		domain: "Technology",
		salary: "₹12 - ₹35 LPA",
		minSalaryLPA: 12,
		maxSalaryLPA: 35,
		demand: "Medium",
		educationRequired: "Graduate",
		sector: "Private",
		workType: "Remote Friendly",
		description: "Design decentralized smart contracts, crypto protocols, and zero-knowledge proof applications.",
		responsibilities: [
			"Write secure Solidity smart contracts",
			"Audit protocols for re-entrancy attacks",
			"Integrate dApps with Ethers.js"
		],
		requiredSkills: [
			"Solidity",
			"Ethereum",
			"Rust",
			"Hardhat",
			"Cryptography",
			"Smart Contract Security"
		],
		degrees: [
			"B.Tech CSE",
			"B.Sc IT",
			"M.Tech CSE"
		],
		topColleges: [
			"IIT Bombay",
			"IIT Madras",
			"IIIT Hyderabad",
			"BITS Pilani"
		],
		topRecruiters: [
			"Polygon (Matic)",
			"Coinbase",
			"Consensys",
			"Binance",
			"Web3 Startups"
		],
		futureScope: "High paying remote opportunities globally.",
		roadmap: [
			{
				stage: "Stage 1",
				title: "Cryptography & Blockchain Basics",
				desc: "Hashing, public/private keys, consensus mechanisms."
			},
			{
				stage: "Stage 2",
				title: "Solidity & Smart Contracts",
				desc: "Writing ERC-20, ERC-721 tokens and decentralized protocols."
			},
			{
				stage: "Stage 3",
				title: "Security & Testing",
				desc: "Hardhat, Foundry, testing reentrancy and arithmetic edge cases."
			},
			{
				stage: "Stage 4",
				title: "Front-End dApp Integration",
				desc: "Ethers.js, Wagmi, RainbowKit, and Web3 wallets."
			}
		],
		tags: [
			"Blockchain",
			"Solidity",
			"Web3",
			"Crypto",
			"Remote"
		]
	},
	{
		id: "game-developer",
		name: "Game Developer & Unity/Unreal Engineer",
		domain: "Technology",
		salary: "₹6 - ₹20 LPA",
		minSalaryLPA: 6,
		maxSalaryLPA: 20,
		demand: "Medium",
		educationRequired: "Graduate",
		sector: "Private",
		workType: "Hybrid",
		description: "Create interactive 2D/3D games, game physics, AR/VR experiences, and interactive mechanics.",
		responsibilities: [
			"Program gameplay mechanics in C# or C++",
			"Optimize rendering pipeline in Unity or Unreal Engine",
			"Integrate multiplayer networking"
		],
		requiredSkills: [
			"Unity 3D",
			"Unreal Engine",
			"C#",
			"C++",
			"3D Math",
			"Shader Programming"
		],
		degrees: [
			"B.Tech CSE",
			"B.Sc Game Design & Animation",
			"Diploma in Game Development"
		],
		topColleges: [
			"National Institute of Design (NID)",
			"IIT Bombay (IDC)",
			"Rubika India",
			"MAAC"
		],
		topRecruiters: [
			"Ubisoft India",
			"Electronic Arts (EA)",
			"Nazara Technologies",
			"Dream11",
			"Zynga"
		],
		futureScope: "Surging with esports, mobile gaming, and VR headsets.",
		roadmap: [
			{
				stage: "Stage 1",
				title: "Programming & Math",
				desc: "C#/C++, Vectors, Quaternions, and Physics calculations."
			},
			{
				stage: "Stage 2",
				title: "Unity Fundamentals",
				desc: "GameObjects, Prefabs, Physics engines, and Animation trees."
			},
			{
				stage: "Stage 3",
				title: "Unreal & C++",
				desc: "Blueprints, Unreal C++, Lumen lighting, and landscape generation."
			},
			{
				stage: "Stage 4",
				title: "Multiplayer & Publishing",
				desc: "Photon/Mirror networking, Steam/Play Store publishing."
			}
		],
		tags: [
			"Game Dev",
			"Unity",
			"Unreal Engine",
			"C#",
			"Gaming"
		]
	},
	{
		id: "ias-officer",
		name: "IAS / IPS Officer (UPSC Civil Services)",
		domain: "Government & Defense",
		salary: "₹7 - ₹22 LPA + Govt Perks",
		minSalaryLPA: 7,
		maxSalaryLPA: 22,
		demand: "Prestigious",
		educationRequired: "Graduate",
		sector: "Government",
		workType: "Field Work",
		description: "Lead district administrative governance, public policy formulation, law enforcement, and national development.",
		responsibilities: [
			"Administer district governance, revenue collection, and public welfare schemes",
			"Maintain law and order, disaster relief, and law enforcement (IPS)",
			"Formulate policies in state secretariats and Central Ministries",
			"Represent India in bilateral negotiations and inter-ministerial committees"
		],
		requiredSkills: [
			"Public Administration",
			"Decision Making",
			"Crisis Management",
			"Ethics",
			"Policy Formulation"
		],
		degrees: ["Bachelor's Degree in ANY Discipline (BA, B.Sc, B.Tech, MBBS, B.Com, LLB)"],
		topColleges: ["Any Recognized University / LBSNAA Mussoorie Training"],
		topRecruiters: ["Government of India", "State Governments"],
		futureScope: "Highest administrative authority, social impact, and leadership in India.",
		roadmap: [
			{
				stage: "Stage 1",
				title: "NCERT Foundation",
				desc: "Read Class 6-12 NCERTs for History, Geography, Polity, and Economy."
			},
			{
				stage: "Stage 2",
				title: "Standard Reference Books",
				desc: "Laxmikanth (Polity), Spectrum (Modern History), GC Leong (Geography)."
			},
			{
				stage: "Stage 3",
				title: "Optional Subject Selection",
				desc: "Choose and complete optional subject syllabus 6 months before Prelims."
			},
			{
				stage: "Stage 4",
				title: "Prelims Test Series & CSAT",
				desc: "Solve 50+ mock tests and 10 years PYQs with rigorous time management."
			},
			{
				stage: "Stage 5",
				title: "Mains Answer Writing",
				desc: "Daily answer writing practice for GS 1-4 and Essay papers."
			},
			{
				stage: "Stage 6",
				title: "Personality Test / Interview",
				desc: "Current affairs mastery, DAF analysis, and mock interviews."
			}
		],
		governmentExams: [
			"UPSC CSE",
			"State PSC (MPSC, UPPSC, BPSC, KPSC)",
			"UPSC CDS"
		],
		relatedCareerIds: ["ssc-cgl-officer", "defense-officer-army-navy-airforce"],
		tags: [
			"UPSC",
			"IAS",
			"IPS",
			"Government Job",
			"Prestigious",
			"Civil Services"
		]
	},
	{
		id: "isro-drdo-scientist",
		name: "ISRO / DRDO Space & Defense Scientist",
		domain: "Government & Defense",
		salary: "₹9 - ₹24 LPA + Scientific Allowances",
		minSalaryLPA: 9,
		maxSalaryLPA: 24,
		demand: "Prestigious",
		educationRequired: "Graduate",
		sector: "Government",
		workType: "On-Site",
		description: "Develop cutting-edge space launch vehicles, satellites, missile defense systems, and radar technologies.",
		responsibilities: [
			"Design propulsion, satellite avionics, and space flight software",
			"Conduct aerodynamic and structural simulations for launch vehicles",
			"Develop radar, electronic warfare, and defense payloads"
		],
		requiredSkills: [
			"Engineering Fundamentals",
			"Aerodynamics / Electronics",
			"MATLAB",
			"C++",
			"Signal Processing"
		],
		degrees: ["B.E / B.Tech in Mechanical, ECE, CSE, Aerospace with min 65% aggregate", "M.Tech / Ph.D"],
		topColleges: [
			"IIST Thiruvananthapuram",
			"IITs",
			"NITs",
			"IISc Bangalore"
		],
		topRecruiters: [
			"ISRO (VSSC, URSC, SAC)",
			"DRDO (DRDL, RCI, ADE)",
			"BARC"
		],
		futureScope: "Pivotal role in India's Gaganyaan manned mission, Chandrayaan series, and defense indigenization.",
		roadmap: [
			{
				stage: "Stage 1",
				title: "Core Engineering Mastery",
				desc: "Build top conceptual clarity in thermodynamics, fluid mechanics, or digital electronics."
			},
			{
				stage: "Stage 2",
				title: "GATE Exam Preparation",
				desc: "Crack GATE with Top 500 All India Rank (AIR)."
			},
			{
				stage: "Stage 3",
				title: "ISRO ICRB / DRDO RAC Written Test",
				desc: "Solve technical domain questions with high accuracy."
			},
			{
				stage: "Stage 4",
				title: "Technical Subject Interview",
				desc: "In-depth panel interview focusing on core engineering principles and thesis."
			}
		],
		governmentExams: [
			"ISRO ICRB",
			"DRDO RAC",
			"GATE",
			"BARC OCES/DGFS"
		],
		relatedCareerIds: ["ai-ml-engineer", "data-scientist"],
		tags: [
			"ISRO",
			"DRDO",
			"Scientist",
			"Space",
			"Defense",
			"High Prestige"
		]
	},
	{
		id: "defense-officer-army-navy-airforce",
		name: "Armed Forces Officer (Army / Navy / Air Force)",
		domain: "Government & Defense",
		salary: "₹9 - ₹25 LPA + Military Perks",
		minSalaryLPA: 9,
		maxSalaryLPA: 25,
		demand: "Prestigious",
		educationRequired: "Class 12",
		sector: "Government",
		workType: "Field Work",
		description: "Commissioned officer leading military troops, combat operations, maritime security, and fighter squadrons.",
		responsibilities: [
			"Lead military units in tactical operations and border defense",
			"Command strategic naval warships and submarine missions (Navy)",
			"Pilot frontline fighter aircraft and helicopters (Air Force)",
			"Manage logistics, tactical communications, and troops welfare"
		],
		requiredSkills: [
			"Officer Like Qualities (OLQ)",
			"Leadership",
			"Physical Fitness",
			"Strategic Thinking",
			"Courage"
		],
		degrees: ["Class 12 (for NDA)", "Graduation in any discipline (for CDS/AFCAT/INET)"],
		topColleges: [
			"National Defence Academy (NDA) Khadakwasla",
			"Indian Military Academy (IMA) Dehradun",
			"Air Force Academy (AFA) Dundigal",
			"Indian Naval Academy (INA) Ezhimala"
		],
		topRecruiters: [
			"Indian Army",
			"Indian Navy",
			"Indian Air Force"
		],
		futureScope: "Honorable national defense leadership with rapid officer promotions and lifelong defense benefits.",
		roadmap: [
			{
				stage: "Stage 1",
				title: "Eligibility & Exam Application",
				desc: "Appear for UPSC NDA after 12th or UPSC CDS / AFCAT during Graduation."
			},
			{
				stage: "Stage 2",
				title: "Written Exam Clearance",
				desc: "Clear Math + General Ability Tests (English, GK, Physics)."
			},
			{
				stage: "Stage 3",
				title: "SSB Interview (5 Days)",
				desc: "Clear Screening, Psychological tests, GTO tasks, and Personal Interview."
			},
			{
				stage: "Stage 4",
				title: "Specialized Medical Board",
				desc: "Pass rigorous military medical examinations (SMB/AMB)."
			},
			{
				stage: "Stage 5",
				title: "Academy Training & Commissioning",
				desc: "3-4 years military & academic training leading to Lieutenant / Flying Officer / Sub Lieutenant rank."
			}
		],
		governmentExams: [
			"UPSC NDA",
			"UPSC CDS",
			"AFCAT",
			"CAPF AC"
		],
		tags: [
			"Army",
			"Navy",
			"Air Force",
			"NDA",
			"CDS",
			"SSB",
			"Defense"
		]
	},
	{
		id: "commercial-pilot",
		name: "Commercial Airline Pilot",
		domain: "Government & Defense",
		salary: "₹18 - ₹75 LPA",
		minSalaryLPA: 18,
		maxSalaryLPA: 75,
		demand: "High",
		educationRequired: "Class 12",
		sector: "Private",
		workType: "On-Site",
		description: "Fly commercial passenger airliners and cargo jets across domestic and international flight routes.",
		responsibilities: [
			"Operate commercial aircraft safely",
			"Calculate flight plans and fuel requirements",
			"Communicate with Air Traffic Control (ATC)"
		],
		requiredSkills: [
			"Aviation Navigation",
			"Quick Reflexes",
			"Spatial Awareness",
			"Crew Resource Management"
		],
		degrees: ["Class 12 with Physics & Math (min 50%) + DGCA Commercial Pilot License (CPL)"],
		topColleges: [
			"IGRUA Rae Bareli",
			"NFTI Gondia",
			"IndiGo Cadet Pilot Program",
			"CAE Oxford"
		],
		topRecruiters: [
			"Air India",
			"IndiGo",
			"Akasa Air",
			"Emirates",
			"Qatar Airways",
			"SpiceJet"
		],
		futureScope: "Surging demand with 1000+ new aircraft ordered by Indian airlines.",
		roadmap: [
			{
				stage: "Stage 1",
				title: "Class 2 & Class 1 Medicals",
				desc: "Clear mandatory DGCA medical assessments."
			},
			{
				stage: "Stage 2",
				title: "DGCA Ground Theory Exams",
				desc: "Clear Navigation, Meteorology, Air Regs, Technical Gen."
			},
			{
				stage: "Stage 3",
				title: "200 Flying Hours Training",
				desc: "Solo, cross-country, and night flight hours at a DGCA approved FTO."
			},
			{
				stage: "Stage 4",
				title: "Type Rating (A320/B737)",
				desc: "Simulator & jet engine training for commercial airliners."
			},
			{
				stage: "Stage 5",
				title: "First Officer Entry",
				desc: "Join airline as Junior First Officer."
			}
		],
		tags: [
			"Pilot",
			"Aviation",
			"Flying",
			"High Salary",
			"Travel"
		]
	},
	{
		id: "rbi-grade-b-officer",
		name: "RBI Grade B Manager & Central Banker",
		domain: "Government & Defense",
		salary: "₹14 - ₹26 LPA + Central Banking Housing",
		minSalaryLPA: 14,
		maxSalaryLPA: 26,
		demand: "Prestigious",
		educationRequired: "Graduate",
		sector: "Government",
		workType: "On-Site",
		description: "Regulate India's banking system, manage foreign exchange reserves, and execute monetary policy.",
		responsibilities: [
			"Formulate monetary policy and interest rate benchmarks",
			"Supervise commercial banks and NBFCs",
			"Manage currency issuance and forex reserves"
		],
		requiredSkills: [
			"Economics",
			"Finance",
			"Management",
			"Macroeconomics",
			"Quantitative Analysis"
		],
		degrees: ["Graduation in any discipline with minimum 60% marks"],
		topColleges: [
			"Delhi School of Economics",
			"IIMs",
			"IITs",
			"SRCC",
			"Any University"
		],
		topRecruiters: ["Reserve Bank of India (RBI)"],
		futureScope: "Most prestigious regulatory finance position in India with world-class work culture.",
		roadmap: [
			{
				stage: "Stage 1",
				title: "Phase 1 Speed & Accuracy",
				desc: "Quant, Reasoning, English, and High-Yield General Awareness (GA)."
			},
			{
				stage: "Stage 2",
				title: "Phase 2 Economic & Social Issues (ESI)",
				desc: "Macroeconomic policies, inflation, fiscal deficits, and growth indices."
			},
			{
				stage: "Stage 3",
				title: "Phase 2 Finance & Management (FM)",
				desc: "Corporate finance, banking regulations, leadership theories."
			},
			{
				stage: "Stage 4",
				title: "Descriptive English Writing",
				desc: "Essay, précis, and business report writing."
			},
			{
				stage: "Stage 5",
				title: "Interview",
				desc: "Panel interview at RBI Headquarters Mumbai."
			}
		],
		governmentExams: [
			"RBI Grade B",
			"SEBI Grade A",
			"NABARD Grade A",
			"UPSC CSE"
		],
		tags: [
			"RBI",
			"Banking",
			"Finance",
			"Central Bank",
			"High Salary"
		]
	},
	{
		id: "ssc-cgl-officer",
		name: "Central Inspector / ASO (SSC CGL)",
		domain: "Government & Defense",
		salary: "₹6.5 - ₹14 LPA + Govt Perks",
		minSalaryLPA: 6.5,
		maxSalaryLPA: 14,
		demand: "High",
		educationRequired: "Graduate",
		sector: "Government",
		workType: "On-Site",
		description: "Work as Income Tax Inspector, GST Inspector, Assistant Section Officer (CSS/MEA), or CBI Sub-Inspector.",
		responsibilities: [
			"Tax assessment, search & audit operations",
			"Central secretariat file management and diplomatic administration (MEA)",
			"Criminal investigation and intelligence gathering (CBI/ED)"
		],
		requiredSkills: [
			"Quantitative Aptitude",
			"Logical Reasoning",
			"English Comprehension",
			"General Knowledge"
		],
		degrees: ["Bachelor's Degree in ANY Discipline"],
		topColleges: ["Any Recognized University"],
		topRecruiters: [
			"Ministry of External Affairs",
			"Central Board of Direct Taxes (CBDT)",
			"CBIC",
			"CBI",
			"CAG"
		],
		futureScope: "Stable, powerful central government career with promotions to Group A cadre.",
		roadmap: [
			{
				stage: "Stage 1",
				title: "Tier 1 Speed Drill",
				desc: "Maths, Reasoning, English, and General Studies."
			},
			{
				stage: "Stage 2",
				title: "Tier 2 In-Depth Preparation",
				desc: "High-scoring Quantitative Abilities, English Comprehension, and Computer Knowledge."
			},
			{
				stage: "Stage 3",
				title: "Typing Test Qualification",
				desc: "Data Entry Speed Test (DEST) clearance."
			}
		],
		governmentExams: [
			"SSC CGL",
			"SSC CHSL",
			"State PSC",
			"IBPS PO"
		],
		tags: [
			"SSC CGL",
			"Income Tax",
			"GST Inspector",
			"Govt Job",
			"Stable"
		]
	},
	{
		id: "doctor-mbbs-md",
		name: "Doctor & Specialist Physician (MBBS / MD)",
		domain: "Healthcare",
		salary: "₹10 - ₹45 LPA",
		minSalaryLPA: 10,
		maxSalaryLPA: 45,
		demand: "Very High",
		educationRequired: "Graduate",
		sector: "Both",
		workType: "On-Site",
		description: "Diagnose medical ailments, prescribe treatment protocols, and perform life-saving clinical care.",
		responsibilities: [
			"Patient consultation, clinical examination, and treatment planning",
			"Emergency medical care and ICU management",
			"Medical research, surgery, or clinical trials"
		],
		requiredSkills: [
			"Clinical Diagnosis",
			"Pharmacology",
			"Empathy",
			"Surgical Precision",
			"Patient Care"
		],
		degrees: ["MBBS (5.5 Years) + MD / MS / DNB Specialization"],
		topColleges: [
			"AIIMS New Delhi",
			"CMC Vellore",
			"JIPMER",
			"KGMU Lucknow",
			"MAMC New Delhi"
		],
		topRecruiters: [
			"Apollo Hospitals",
			"Fortis Healthcare",
			"Max Healthcare",
			"Govt Medical Colleges",
			"Private Practice"
		],
		futureScope: "Universal evergreen demand with severe doctor-to-patient deficit in India.",
		roadmap: [
			{
				stage: "Stage 1",
				title: "Class 12 with PCB",
				desc: "Physics, Chemistry, Biology with strong NCERT foundation."
			},
			{
				stage: "Stage 2",
				title: "Crack NEET UG",
				desc: "Target 650+ score to secure Government Medical College MBBS seat."
			},
			{
				stage: "Stage 3",
				title: "MBBS (4.5 Years + 1 Year Internship)",
				desc: "Anatomy, Physiology, Pathology, Medicine, Surgery."
			},
			{
				stage: "Stage 4",
				title: "NEET PG / NExT Examination",
				desc: "Secure MD/MS seat in Cardiology, Neurology, Pediatrics, Orthopedics."
			},
			{
				stage: "Stage 5",
				title: "Super-Specialty (DM/MCh)",
				desc: "Advanced surgical or medical super-specialization."
			}
		],
		governmentExams: [
			"UPSC CMS (Combined Medical Services)",
			"NEET PG",
			"INI-CET",
			"State Health Services"
		],
		tags: [
			"Doctor",
			"MBBS",
			"NEET",
			"Medicine",
			"Healthcare",
			"Noble Career"
		]
	},
	{
		id: "biomedical-engineer",
		name: "Biomedical & Healthcare Tech Engineer",
		domain: "Healthcare",
		salary: "₹6 - ₹18 LPA",
		minSalaryLPA: 6,
		maxSalaryLPA: 18,
		demand: "High",
		educationRequired: "Graduate",
		sector: "Private",
		workType: "Hybrid",
		description: "Design advanced medical equipment like MRI scanners, robotic surgical arms, pacemakers, and prosthetics.",
		responsibilities: [
			"Develop medical imaging and biosensor systems",
			"Ensure clinical compliance with FDA/CDSCO medical norms",
			"Maintain ICU and diagnostic machinery"
		],
		requiredSkills: [
			"Biomechanics",
			"Medical Signal Processing",
			"Embedded C",
			"Sensor Tech",
			"CAD"
		],
		degrees: [
			"B.Tech Biomedical Engineering",
			"B.Tech Biotechnology",
			"M.Tech Medical Devices"
		],
		topColleges: [
			"IIT Bombay (Biomedical)",
			"IIT Madras",
			"Manipal",
			"Vellore Institute of Technology"
		],
		topRecruiters: [
			"GE Healthcare",
			"Siemens Healthineers",
			"Philips Healthcare",
			"Medtronic",
			"Johnson & Johnson"
		],
		futureScope: "Booming with robotic surgeries and AI diagnostic imaging.",
		roadmap: [
			{
				stage: "Stage 1",
				title: "Engineering & Biology Basics",
				desc: "Human anatomy, electronics, and sensor circuits."
			},
			{
				stage: "Stage 2",
				title: "Medical Devices & Signal Analysis",
				desc: "ECG/EEG signal processing and imaging systems."
			},
			{
				stage: "Stage 3",
				title: "Prototyping & Compliance",
				desc: "Embedded firmware, 3D printing prosthetics, and ISO 13485 standards."
			}
		],
		tags: [
			"Biomedical",
			"Healthcare Tech",
			"Medical Devices",
			"Biotech"
		]
	},
	{
		id: "clinical-psychologist",
		name: "Clinical Psychologist & Mental Health Counselor",
		domain: "Healthcare",
		salary: "₹5 - ₹16 LPA",
		minSalaryLPA: 5,
		maxSalaryLPA: 16,
		demand: "Very High",
		educationRequired: "Post Graduate",
		sector: "Both",
		workType: "Hybrid",
		description: "Conduct cognitive behavioral therapy (CBT), psycho-diagnostic assessments, and mental wellness counseling.",
		responsibilities: [
			"Individual psychotherapy and psycho-assessments",
			"Counseling for anxiety, depression, and trauma",
			"Corporate mental health workshops"
		],
		requiredSkills: [
			"Active Listening",
			"CBT",
			"Psychodiagnostics",
			"Empathy",
			"Research"
		],
		degrees: ["BA/B.Sc Psychology + MA/M.Sc Clinical Psychology + M.Phil (RCI Licensed)"],
		topColleges: [
			"NIMHANS Bangalore",
			"TISS Mumbai",
			"Delhi University",
			"Christ University"
		],
		topRecruiters: [
			"NIMHANS",
			"Max Healthcare",
			"Corporate Tech Wellness Firms",
			"Private Practice",
			"Schools/Universities"
		],
		futureScope: "Exponential surge in demand as mental health awareness grows in India.",
		roadmap: [
			{
				stage: "Stage 1",
				title: "BA/B.Sc Psychology",
				desc: "Cognitive, developmental, and abnormal psychology."
			},
			{
				stage: "Stage 2",
				title: "Master's in Clinical Psychology",
				desc: "Clinical psychometry, DSM-5 diagnostics, and hospital internships."
			},
			{
				stage: "Stage 3",
				title: "RCI License (M.Phil / Psy.D)",
				desc: "Mandatory Rehabilitation Council of India (RCI) license."
			}
		],
		tags: [
			"Psychology",
			"Mental Health",
			"Counseling",
			"CBT",
			"RCI"
		]
	},
	{
		id: "chartered-accountant",
		name: "Chartered Accountant (ICAI CA)",
		domain: "Business & Finance",
		salary: "₹9 - ₹30 LPA",
		minSalaryLPA: 9,
		maxSalaryLPA: 30,
		demand: "Very High",
		educationRequired: "Class 12",
		sector: "Both",
		workType: "Hybrid",
		description: "Manage statutory audits, corporate taxation, forensic accounting, financial reporting, and merger advisory.",
		responsibilities: [
			"Statutory and internal audits for listed corporations",
			"Direct & Indirect tax planning (GST, Corporate Tax)",
			"Financial due diligence and valuation for M&A deals"
		],
		requiredSkills: [
			"Auditing",
			"Direct & Indirect Tax",
			"Accounting Standards (Ind AS/IFRS)",
			"Financial Analysis",
			"Company Law"
		],
		degrees: ["CA Foundation -> CA Intermediate -> 2-Year Articleship -> CA Final (ICAI)"],
		topColleges: ["The Institute of Chartered Accountants of India (ICAI)"],
		topRecruiters: [
			"Big 4 (Deloitte, PwC, EY, KPMG)",
			"Goldman Sachs",
			"Reliance Industries",
			"Tata Group",
			"Private Advisory"
		],
		futureScope: "Supreme statutory authority on company audits and tax governance in India.",
		roadmap: [
			{
				stage: "Stage 1",
				title: "CA Foundation",
				desc: "Clear 4 papers after Class 12 (Accounts, Law, Math, Economics)."
			},
			{
				stage: "Stage 2",
				title: "CA Intermediate",
				desc: "Clear 6 papers in 2 groups (Advanced Accounting, Tax, Costing, Audit)."
			},
			{
				stage: "Stage 3",
				title: "2-Year Mandatory Articleship",
				desc: "Hands-on audit and tax filing experience under a practicing CA firm."
			},
			{
				stage: "Stage 4",
				title: "CA Final Exam",
				desc: "Crack CA Final (Financial Reporting, Strategic Financial Management, Advanced Auditing)."
			},
			{
				stage: "Stage 5",
				title: "ICAI Membership & Campus Placement",
				desc: "Receive license and secure Big 4 or corporate finance roles."
			}
		],
		tags: [
			"CA",
			"Chartered Accountant",
			"Finance",
			"Tax",
			"Audit",
			"Big 4"
		]
	},
	{
		id: "investment-banker",
		name: "Investment Banker & Equity Analyst",
		domain: "Business & Finance",
		salary: "₹16 - ₹55 LPA + High Bonuses",
		minSalaryLPA: 16,
		maxSalaryLPA: 55,
		demand: "High",
		educationRequired: "Graduate",
		sector: "Private",
		workType: "On-Site",
		description: "Structure Mergers & Acquisitions (M&A), manage Initial Public Offerings (IPOs), and build financial models.",
		responsibilities: [
			"Build Discounted Cash Flow (DCF) and LBO valuation models",
			"Draft IPO prospectuses and pitch decks for VC/PE funding",
			"Advise corporate clients on debt and equity capital raising"
		],
		requiredSkills: [
			"Financial Modeling",
			"Valuation (DCF/LBO)",
			"Excel Mastery",
			"PowerPoint",
			"M&A Strategy",
			"CFA Knowledge"
		],
		degrees: ["B.Com / BBA / B.Tech + MBA in Finance from Top IIMs", "CFA Charterholder"],
		topColleges: [
			"IIM Ahmedabad",
			"IIM Bangalore",
			"IIM Calcutta",
			"FMS Delhi",
			"SRCC Delhi",
			"St. Xavier's Mumbai"
		],
		topRecruiters: [
			"Goldman Sachs",
			"Morgan Stanley",
			"J.P. Morgan",
			"Avendus Capital",
			"Kotak Investment Banking",
			"Citi"
		],
		futureScope: "Highest compensating corporate career in India with global exit opportunities.",
		roadmap: [
			{
				stage: "Stage 1",
				title: "Finance & Accounting Base",
				desc: "Master financial statements, accounting principles, and Excel shortcuts."
			},
			{
				stage: "Stage 2",
				title: "CFA Level 1 & Financial Modeling",
				desc: "Build 3-statement financial models, DCF valuations, and pitch decks."
			},
			{
				stage: "Stage 3",
				title: "MBA from Top Tier-1 B-School",
				desc: "CAT 99+ Percentile -> IIM ABC / FMS -> Front-Office Investment Banking internship."
			},
			{
				stage: "Stage 4",
				title: "Analyst / Associate Role",
				desc: "Execute live deal mandates, capital structuring, and private equity deals."
			}
		],
		tags: [
			"Investment Banking",
			"Finance",
			"M&A",
			"CFA",
			"High Salary",
			"Wall Street"
		]
	},
	{
		id: "management-consultant",
		name: "Management & Strategy Consultant",
		domain: "Management",
		salary: "₹15 - ₹45 LPA",
		minSalaryLPA: 15,
		maxSalaryLPA: 45,
		demand: "High",
		educationRequired: "Graduate",
		sector: "Private",
		workType: "Hybrid",
		description: "Advise Fortune 500 CEOs on corporate restructuring, market expansion, profitability, and digital transformation.",
		responsibilities: [
			"Solve high-stakes business strategy problems using structured frameworks",
			"Conduct market sizing, competitor benchmarking, and cost optimization",
			"Deliver strategic recommendations to C-suite executives"
		],
		requiredSkills: [
			"Structured Problem Solving",
			"Case Frameworks",
			"Executive Presentation",
			"Data Synthesis",
			"Storylining"
		],
		degrees: ["B.Tech (IITs) / B.Com (SRCC) + MBA (IIMs / ISB)"],
		topColleges: [
			"IIM Ahmedabad",
			"IIM Bangalore",
			"IIM Calcutta",
			"ISB Hyderabad",
			"IIT Bombay",
			"IIT Delhi"
		],
		topRecruiters: [
			"McKinsey & Company",
			"Boston Consulting Group (BCG)",
			"Bain & Company",
			"Oliver Wyman",
			"Kearney"
		],
		futureScope: "Prestigious career track leading directly to Startup CXO roles and Venture Capital.",
		roadmap: [
			{
				stage: "Stage 1",
				title: "Case Solving Mastery",
				desc: "Practice 100+ business cases (Profitability, Market Entry, M&A, Pricing)."
			},
			{
				stage: "Stage 2",
				title: "Structured Communication",
				desc: "Master Pyramid Principle, MECE framework, and data visualization."
			},
			{
				stage: "Stage 3",
				title: "Tier-1 Campus Hiring",
				desc: "Top ranks in IITs/SRCC/IIMs -> MBB Case Interviews & Partner rounds."
			}
		],
		tags: [
			"Consulting",
			"McKinsey",
			"BCG",
			"Bain",
			"Strategy",
			"High Salary"
		]
	},
	{
		id: "product-manager",
		name: "Product Manager (Tech & SaaS)",
		domain: "Management",
		salary: "₹14 - ₹38 LPA",
		minSalaryLPA: 14,
		maxSalaryLPA: 38,
		demand: "Very High",
		educationRequired: "Graduate",
		sector: "Private",
		workType: "Hybrid",
		description: "Own the product vision, roadmap, and execution at the intersection of Tech, Business, and UX design.",
		responsibilities: [
			"Define product specifications (PRDs) and user journey wireframes",
			"Prioritize features based on ROI, user feedback, and metric impact",
			"Lead cross-functional sprints with engineers and UI/UX designers"
		],
		requiredSkills: [
			"Product Strategy",
			"User Research",
			"Agile / Scrum",
			"Data Analytics (Mixpanel/Amplitude)",
			"A/B Testing"
		],
		degrees: [
			"B.Tech CSE/IT",
			"MBA",
			"Any Degree + Strong Tech Portfolio"
		],
		topColleges: [
			"IITs",
			"IIMs",
			"BITS Pilani",
			"ISB"
		],
		topRecruiters: [
			"Google",
			"Microsoft",
			"Flipkart",
			"Razorpay",
			"CRED",
			"Swiggy",
			"Jio"
		],
		futureScope: "Crucial leadership role across every consumer internet app and enterprise software company.",
		roadmap: [
			{
				stage: "Stage 1",
				title: "Tech & UX Literacy",
				desc: "Understand system design, REST APIs, wireframing in Figma, and Agile sprints."
			},
			{
				stage: "Stage 2",
				title: "Data & Metrics",
				desc: "Track retention, CAC, LTV, churn, and conduct structured A/B tests."
			},
			{
				stage: "Stage 3",
				title: "PRD Writing & Case Studies",
				desc: "Write comprehensive Product Requirement Documents and teardowns of popular apps."
			},
			{
				stage: "Stage 4",
				title: "APM Program / Product Role",
				desc: "Join Associate Product Manager (APM) programs or transition from SDE/Analytics."
			}
		],
		tags: [
			"Product Management",
			"SaaS",
			"UX",
			"Tech Strategy",
			"High Demand"
		]
	},
	{
		id: "corporate-lawyer",
		name: "Corporate Lawyer & M&A Legal Counsel",
		domain: "Law & Policy",
		salary: "₹10 - ₹32 LPA",
		minSalaryLPA: 10,
		maxSalaryLPA: 32,
		demand: "High",
		educationRequired: "Graduate",
		sector: "Both",
		workType: "Hybrid",
		description: "Draft high-value contracts, ensure regulatory compliance, and advise corporations on mergers, IPOs, and disputes.",
		responsibilities: [
			"Draft Shareholder Agreements (SHA) and term sheets for startup funding",
			"Ensure compliance with SEBI, Competition Commission, and Companies Act",
			"Represent clients in commercial dispute arbitration and NCLT hearings"
		],
		requiredSkills: [
			"Contract Drafting",
			"Company Law",
			"Negotiation",
			"Due Diligence",
			"Legal Research (Manupatra/SCC)"
		],
		degrees: ["BA LLB / BBA LLB (5-Year Integrated) or 3-Year LLB + LLM"],
		topColleges: [
			"NLSIU Bangalore",
			"NALSAR Hyderabad",
			"WBNUJS Kolkata",
			"NLU Delhi",
			"Symbiosis Law School"
		],
		topRecruiters: [
			"Shardul Amarchand Mangaldas",
			"Cyril Amarchand Mangaldas",
			"AZB & Partners",
			"Khaitan & Co",
			"Trilegal"
		],
		futureScope: "Indispensable corporate governance demand amidst rising investments in India.",
		roadmap: [
			{
				stage: "Stage 1",
				title: "Crack CLAT Exam",
				desc: "Clear Common Law Admission Test for Top 5 National Law Universities (NLUs)."
			},
			{
				stage: "Stage 2",
				title: "Law School & Moot Courts",
				desc: "Excel in contract law, corporate law, and national moot court competitions."
			},
			{
				stage: "Stage 3",
				title: "Tier-1 Law Firm Internships",
				desc: "Complete assessment internships at top law firms during 4th & 5th year."
			},
			{
				stage: "Stage 4",
				title: "Bar Council Enrollment",
				desc: "Clear All India Bar Examination (AIBE) and join corporate law practice."
			}
		],
		governmentExams: [
			"UPSC CSE (Law Optional)",
			"Judicial Services Exam (PCS-J)",
			"SEBI Legal Officer",
			"JAG Entry (Army)"
		],
		tags: [
			"Law",
			"Corporate Law",
			"CLAT",
			"NLU",
			"High Salary",
			"Legal"
		]
	},
	{
		id: "ui-ux-product-designer",
		name: "UI/UX & Digital Product Designer",
		domain: "Arts & Design",
		salary: "₹7 - ₹24 LPA",
		minSalaryLPA: 7,
		maxSalaryLPA: 24,
		demand: "Very High",
		educationRequired: "Graduate",
		sector: "Private",
		workType: "Remote Friendly",
		description: "Create intuitive user journeys, wireframes, high-fidelity prototypes, and design systems for web & mobile apps.",
		responsibilities: [
			"Conduct user research, usability testing, and persona mapping",
			"Design modern interfaces and interactive prototypes in Figma",
			"Build scalable design systems with reusable components and tokens"
		],
		requiredSkills: [
			"Figma",
			"Design Systems",
			"User Research",
			"Wireframing",
			"Interaction Design",
			"Visual Aesthetics"
		],
		degrees: [
			"B.Des in Interaction Design",
			"B.Sc Animation & Multimedia",
			"Any Degree + Design Portfolio"
		],
		topColleges: [
			"National Institute of Design (NID)",
			"IIT Bombay (IDC)",
			"IIT Guwahati (DoD)",
			"Srishti Institute"
		],
		topRecruiters: [
			"Apple",
			"Google",
			"Microsoft",
			"Swiggy",
			"CRED",
			"Canva",
			"Top Global Startups"
		],
		futureScope: "Massive demand as design quality becomes the primary differentiator for digital SaaS products.",
		roadmap: [
			{
				stage: "Stage 1",
				title: "Design Principles & Typography",
				desc: "Color theory, visual hierarchy, typography scales, and Gestalt principles."
			},
			{
				stage: "Stage 2",
				title: "Figma Tool Mastery",
				desc: "Auto-layout, component variants, interactive prototyping, and design tokens."
			},
			{
				stage: "Stage 3",
				title: "UX Research & Case Studies",
				desc: "User interviews, empathy maps, information architecture, and usability tests."
			},
			{
				stage: "Stage 4",
				title: "Portfolio Building & Dribbble/Behance",
				desc: "Publish 3 comprehensive UX case studies with documented problem solving."
			}
		],
		tags: [
			"UI UX",
			"Figma",
			"Product Design",
			"Remote Work",
			"Creative"
		]
	},
	{
		id: "agricultural-scientist",
		name: "Agricultural Scientist & AgriTech Innovator",
		domain: "Agriculture & Environment",
		salary: "₹6 - ₹16 LPA",
		minSalaryLPA: 6,
		maxSalaryLPA: 16,
		demand: "Medium",
		educationRequired: "Graduate",
		sector: "Both",
		workType: "Field Work",
		description: "Develop climate-resilient hybrid crops, precision drone farming solutions, and sustainable soil fertilizers.",
		responsibilities: [
			"Conduct plant genetics breeding and yield enhancement trials",
			"Deploy IoT sensors and drone imagery for soil health monitoring",
			"Advise farmers and agri-businesses on sustainable crop protection"
		],
		requiredSkills: [
			"Agronomy",
			"Genetics & Plant Breeding",
			"Soil Science",
			"AgriTech IoT",
			"Data Analysis"
		],
		degrees: [
			"B.Sc Agriculture (Hons)",
			"M.Sc Agronomy / Plant Genetics",
			"Ph.D in Agriculture"
		],
		topColleges: [
			"IARI New Delhi (Pusa)",
			"GB Pant University Pantnagar",
			"PAU Ludhiana",
			"TNAU Coimbatore"
		],
		topRecruiters: [
			"ICAR Institutes",
			"Bayer CropScience",
			"Syngenta",
			"ITC Agri-Business",
			"AgriTech Startups (DeHaat, Ninjacart)"
		],
		futureScope: "High priority sector driven by climate change, food security, and AgriTech venture investments.",
		roadmap: [
			{
				stage: "Stage 1",
				title: "ICAR AIEEA / CUET Agriculture",
				desc: "Crack entrance exam for 4-year B.Sc Agriculture (Hons)."
			},
			{
				stage: "Stage 2",
				title: "Core Agronomy & Research",
				desc: "Field crop production, soil chemistry, plant pathology, and precision farming."
			},
			{
				stage: "Stage 3",
				title: "ICAR JRF / ASRB Exam",
				desc: "Qualify for Agricultural Research Service (ARS) Scientist posts."
			}
		],
		governmentExams: [
			"ASRB ARS Scientist",
			"NABARD Grade A",
			"IBPS SO (Agriculture Field Officer - AFO)"
		],
		tags: [
			"Agriculture",
			"AgriTech",
			"ICAR",
			"Farming Innovation",
			"Research"
		]
	}
];
var SCHOLARSHIPS_DATA = [
	{
		id: "nsp-csss",
		name: "Central Sector Scheme of Scholarships for College & University Students (NSP CSSS)",
		provider: "Department of Higher Education (MHRD/MoE), Govt of India",
		category: "Central Government",
		amount: "₹12,000 to ₹20,000 per year",
		annualValueINR: 2e4,
		eligibility: "Students scoring above 80th percentile in relevant stream in Class 12 board exams, pursuing regular graduation/post-graduation.",
		minEducation: "Class 12",
		eligibleStates: ["All India"],
		gender: "All",
		annualFamilyIncomeLimitINR: 45e4,
		deadline: "November 30, 2026",
		status: "Open",
		officialUrl: "https://scholarships.gov.in",
		lastUpdated: "September 2026",
		description: "Financial assistance to meritorious students from low-income families to meet day-to-day expenses while pursuing higher studies.",
		documentsRequired: [
			"Class 12 Marksheet",
			"Income Certificate (< ₹4.5 Lakhs)",
			"Aadhaar Card",
			"Bank Passbook seeded with Aadhaar",
			"College Bonafide Certificate"
		],
		selectionBasis: "Merit Based"
	},
	{
		id: "dst-inspire-fellowship",
		name: "INSPIRE Scholarship for Higher Education (SHE) - DST",
		provider: "Department of Science and Technology (DST), Govt of India",
		category: "Central Government",
		amount: "₹80,000 per year (₹60,000 cash + ₹20,000 mentorship project grant)",
		annualValueINR: 8e4,
		eligibility: "Top 1% rankers in Class 12 board exams or rankers within 10,000 in JEE/NEET pursuing B.Sc / B.S / Int. M.Sc in Natural & Basic Sciences.",
		minEducation: "Class 12",
		eligibleStates: ["All India"],
		gender: "All",
		annualFamilyIncomeLimitINR: 1e6,
		deadline: "December 31, 2026",
		status: "Open",
		officialUrl: "https://online-inspire.gov.in",
		lastUpdated: "August 2026",
		description: "Prestigious fellowship designed to attract young talent to the study of basic sciences (Physics, Chemistry, Maths, Biology, Geology).",
		documentsRequired: [
			"Class 12 Advisory Note / Top 1% Certificate",
			"College Endorsement Certificate",
			"SBI Bank Account Details",
			"Class 10/12 Marksheet"
		],
		selectionBasis: "Merit Based"
	},
	{
		id: "aicte-pragati-scholarship",
		name: "AICTE Pragati Scholarship for Girl Students (Technical Degree/Diploma)",
		provider: "All India Council for Technical Education (AICTE)",
		category: "Women in STEM",
		amount: "₹50,000 per annum (Tuition + Incidental Expenses)",
		annualValueINR: 5e4,
		eligibility: "Girl students admitted to 1st year of Degree/Diploma level AICTE-approved technical program (max 2 girls per family).",
		minEducation: "Class 12",
		eligibleStates: ["All India"],
		gender: "Female Only",
		annualFamilyIncomeLimitINR: 8e5,
		deadline: "October 31, 2026",
		status: "Closing Soon",
		officialUrl: "https://www.aicte-pragati-saksham-gov.in",
		lastUpdated: "September 2026",
		description: "Empowers girl students in engineering, architecture, pharmacy, and computer applications with comprehensive annual funding.",
		documentsRequired: [
			"Admission Allotment Letter",
			"Tuition Fee Receipt",
			"Annual Income Certificate (< ₹8 Lakhs)",
			"Family Declaration (Max 2 girls)"
		],
		selectionBasis: "Means & Merit"
	},
	{
		id: "mahadbt-ebc-freeship",
		name: "Rajarshi Chhatrapati Shahu Maharaj Shikshan Shulkh Shishyavrutti (EBC Freeship)",
		provider: "Directorate of Higher & Technical Education, Govt of Maharashtra",
		category: "State Government",
		amount: "50% to 100% Tuition Fee & Exam Fee Waiver",
		annualValueINR: 65e3,
		eligibility: "Domicile of Maharashtra enrolled in government or approved private engineering, medical, management, or degree colleges.",
		minEducation: "Class 12",
		eligibleStates: ["Maharashtra"],
		gender: "All",
		annualFamilyIncomeLimitINR: 8e5,
		deadline: "December 15, 2026",
		status: "Open",
		officialUrl: "https://mahadbt.maharashtra.gov.in",
		lastUpdated: "September 2026",
		description: "State-funded fee waiver for Economically Backward Class (EBC) students in Maharashtra across professional degree programs.",
		documentsRequired: [
			"Maharashtra Domicile Certificate",
			"Tahasildar Income Certificate",
			"CAP Allotment Letter",
			"Fee Receipts"
		],
		selectionBasis: "Means & Merit"
	},
	{
		id: "reliance-foundation-scholarship",
		name: "Reliance Foundation Undergraduate Scholarships",
		provider: "Reliance Foundation",
		category: "Corporate CSR",
		amount: "Up to ₹2,00,000 over the duration of degree",
		annualValueINR: 5e4,
		eligibility: "1st year full-time undergraduate students in any stream with min 60% in Class 12 and family income below ₹15 Lakhs.",
		minEducation: "Class 12",
		eligibleStates: ["All India"],
		gender: "All",
		annualFamilyIncomeLimitINR: 15e5,
		deadline: "October 15, 2026",
		status: "Closing Soon",
		officialUrl: "https://www.reliancefoundation.org",
		lastUpdated: "September 2026",
		description: "Supports 5,000 meritorious undergraduate students annually with financial grants, mentorship workshops, and leadership development.",
		documentsRequired: [
			"Class 12 Marksheet",
			"Income Proof",
			"College ID Card",
			"Aptitude Test Score"
		],
		selectionBasis: "Competitive Entrance"
	},
	{
		id: "tata-pankh-scholarship",
		name: "Tata Capital Pankh Scholarship Programme",
		provider: "Tata Capital CSR Foundation",
		category: "Corporate CSR",
		amount: "Up to 80% of Tuition Fees (₹12,000 to ₹50,000)",
		annualValueINR: 5e4,
		eligibility: "Students studying in Class 11, 12, or general/professional undergraduate degree courses with min 60% in previous exam.",
		minEducation: "Class 10",
		eligibleStates: ["All India"],
		gender: "All",
		annualFamilyIncomeLimitINR: 4e5,
		deadline: "November 15, 2026",
		status: "Open",
		officialUrl: "https://www.buddy4study.com/page/the-tata-capital-pankh-scholarship-programme",
		lastUpdated: "August 2026",
		description: "Aims to support economically weaker students to prevent dropout from formal school and higher professional education.",
		documentsRequired: [
			"Previous Year Marksheet",
			"Income Proof (Salary slip / Form 16 / ITR)",
			"Current Academic Fee Receipt"
		],
		selectionBasis: "Means & Merit"
	}
];
var COLLEGES_DATA = [
	{
		id: "iit-madras",
		name: "Indian Institute of Technology Madras (IIT Madras)",
		shortName: "IIT Madras",
		type: "Government / Autonomous",
		city: "Chennai",
		state: "Tamil Nadu",
		nirfRank: 1,
		coursesOffered: [
			"B.Tech",
			"Dual Degree",
			"M.Tech",
			"MS",
			"Ph.D",
			"B.Sc Data Science"
		],
		popularDegrees: [
			"Computer Science & Engg",
			"AI & Data Science",
			"Electrical Engg",
			"Aerospace"
		],
		annualFeesRange: "₹2,20,000 / year",
		avgPlacementPackageLPA: 21.5,
		highestPlacementPackageLPA: 131,
		acceptedExams: [
			"JEE Advanced",
			"GATE",
			"IITM Online Qualifier"
		],
		campusFacilities: [
			"Research Park",
			"High-Performance Computing Cluster",
			"Hyperloop Lab",
			"Olympic Sports Complex"
		],
		officialWebsite: "https://www.iitm.ac.in",
		description: "Ranked #1 Engineering & Overall institution in India by NIRF consecutively for 6+ years.",
		rating: 4.9
	},
	{
		id: "iit-bombay",
		name: "Indian Institute of Technology Bombay (IIT Bombay)",
		shortName: "IIT Bombay",
		type: "Government / Autonomous",
		city: "Mumbai",
		state: "Maharashtra",
		nirfRank: 3,
		coursesOffered: [
			"B.Tech",
			"B.Des",
			"M.Tech",
			"M.Des",
			"MBA (SJMSOM)",
			"Ph.D"
		],
		popularDegrees: [
			"Computer Science & Engg",
			"Electrical Engg",
			"Industrial Design",
			"Mechanical"
		],
		annualFeesRange: "₹2,25,000 / year",
		avgPlacementPackageLPA: 23.5,
		highestPlacementPackageLPA: 168,
		acceptedExams: [
			"JEE Advanced",
			"UCEED",
			"GATE",
			"CEED",
			"CAT"
		],
		campusFacilities: [
			"SINE Startup Incubator",
			"Nanotechnology Center",
			"Powai Lake Campus",
			"Supercomputing Lab"
		],
		officialWebsite: "https://www.iitb.ac.in",
		description: "Premier engineering and startup hub in India with top 100 JEE Advanced ranker choice.",
		rating: 4.9
	},
	{
		id: "bits-pilani",
		name: "Birla Institute of Technology and Science, Pilani (BITS Pilani)",
		shortName: "BITS Pilani",
		type: "Deemed University",
		city: "Pilani",
		state: "Rajasthan",
		nirfRank: 20,
		coursesOffered: [
			"B.E (Hons)",
			"M.Sc (Hons)",
			"M.E",
			"MBA",
			"Ph.D"
		],
		popularDegrees: [
			"B.E Computer Science",
			"B.E Electronics",
			"M.Sc Economics",
			"B.E Mechanical"
		],
		annualFeesRange: "₹5,40,000 / year",
		avgPlacementPackageLPA: 19,
		highestPlacementPackageLPA: 60,
		acceptedExams: [
			"BITSAT",
			"GATE",
			"CAT"
		],
		campusFacilities: [
			"Practice School (PS) Industry Internships",
			"No Attendance Policy",
			"Sandbox Startup Incubator"
		],
		officialWebsite: "https://www.bits-pilani.ac.in",
		description: "Top-tier private engineering and science institute known for meritocratic admissions and stellar tech alumni.",
		rating: 4.8
	},
	{
		id: "nit-trichy",
		name: "National Institute of Technology Tiruchirappalli (NIT Trichy)",
		shortName: "NIT Trichy",
		type: "Government / Autonomous",
		city: "Tiruchirappalli",
		state: "Tamil Nadu",
		nirfRank: 9,
		coursesOffered: [
			"B.Tech",
			"B.Arch",
			"M.Tech",
			"MCA",
			"MBA",
			"Ph.D"
		],
		popularDegrees: [
			"Computer Science",
			"ECE",
			"Mechanical",
			"MCA"
		],
		annualFeesRange: "₹1,50,000 / year",
		avgPlacementPackageLPA: 15.5,
		highestPlacementPackageLPA: 52,
		acceptedExams: [
			"JEE Main",
			"NIMCET",
			"GATE",
			"CAT"
		],
		campusFacilities: [
			"Siemens Center of Excellence",
			"Octagon Computer Center",
			"Central Library"
		],
		officialWebsite: "https://www.nitt.edu",
		description: "Ranked #1 among all 32 National Institutes of Technology (NITs) in India.",
		rating: 4.7
	},
	{
		id: "st-xaviers-mumbai",
		name: "St. Xavier's College (Autonomous), Mumbai",
		shortName: "St. Xavier's Mumbai",
		type: "Government / Autonomous",
		city: "Mumbai",
		state: "Maharashtra",
		nirfRank: 5,
		coursesOffered: [
			"B.Sc IT",
			"B.Sc Computer Science",
			"BMS",
			"BA",
			"B.Com"
		],
		popularDegrees: [
			"B.Sc Information Technology",
			"BMS (Management)",
			"B.Sc Biotechnology"
		],
		annualFeesRange: "₹45,000 / year",
		avgPlacementPackageLPA: 7.5,
		highestPlacementPackageLPA: 21,
		acceptedExams: ["Class 12 Merit (Maths)", "Xavier Entrance Test (XET)"],
		campusFacilities: [
			"Gothic Heritage Campus",
			"Advanced IT Labs",
			"Malhar Cultural Forum",
			"Incubation Cell"
		],
		officialWebsite: "https://xaviers.edu",
		description: "Iconic premier college in Mumbai known for academic excellence, modern B.Sc IT curriculum, and top MNC hiring.",
		rating: 4.8
	},
	{
		id: "christ-university-bangalore",
		name: "Christ (Deemed to be University), Bangalore",
		shortName: "Christ University",
		type: "Deemed University",
		city: "Bangalore",
		state: "Karnataka",
		nirfRank: 60,
		coursesOffered: [
			"BCA",
			"B.Sc Data Science",
			"B.Sc IT",
			"BBA",
			"B.Com",
			"MBA",
			"MCA"
		],
		popularDegrees: [
			"BCA",
			"BBA Finance",
			"B.Sc Data Analytics",
			"MBA"
		],
		annualFeesRange: "₹1,50,000 / year",
		avgPlacementPackageLPA: 6.8,
		highestPlacementPackageLPA: 21.5,
		acceptedExams: ["Christ University Entrance Test (CUET)", "Skill Assessment + PI"],
		campusFacilities: [
			"Modern Silicon Valley style tech labs",
			"Bloomberg Terminals",
			"Corporate Placement Center"
		],
		officialWebsite: "https://christuniversity.in",
		description: "Top-ranked institution for BCA and Commerce in Bangalore with strong corporate recruiters (Deloitte, EY, Amazon).",
		rating: 4.7
	},
	{
		id: "loyola-college-chennai",
		name: "Loyola College (Autonomous), Chennai",
		shortName: "Loyola Chennai",
		type: "Government / Autonomous",
		city: "Chennai",
		state: "Tamil Nadu",
		nirfRank: 4,
		coursesOffered: [
			"BCA",
			"B.Sc Computer Science",
			"B.Sc Visual Communication",
			"B.Com"
		],
		popularDegrees: [
			"BCA",
			"B.Sc Computer Science",
			"B.Com",
			"B.Sc VisCom"
		],
		annualFeesRange: "₹48,000 / year",
		avgPlacementPackageLPA: 6.5,
		highestPlacementPackageLPA: 18,
		acceptedExams: ["Class 12 Board Merit"],
		campusFacilities: [
			"LIVE Visual Media Labs",
			"Data Center",
			"Extensive Sports Grounds"
		],
		officialWebsite: "https://www.loyolacollege.edu",
		description: "NAAC A++ premier arts & science college with world-class computer applications and commerce faculty.",
		rating: 4.8
	},
	{
		id: "iim-ahmedabad",
		name: "Indian Institute of Management Ahmedabad (IIM-A)",
		shortName: "IIM Ahmedabad",
		type: "Government / Autonomous",
		city: "Ahmedabad",
		state: "Gujarat",
		nirfRank: 1,
		coursesOffered: [
			"MBA (PGP)",
			"MBA-FABM",
			"MBA-PGPX",
			"Ph.D"
		],
		popularDegrees: ["Post Graduate Programme in Management (MBA)"],
		annualFeesRange: "₹25,00,000 (Total 2-Year Program)",
		avgPlacementPackageLPA: 34.5,
		highestPlacementPackageLPA: 115,
		acceptedExams: ["CAT", "GMAT"],
		campusFacilities: [
			"Louis Kahn Heritage Campus",
			"CIIE Startup Incubator",
			"Vikram Sarabhai Library"
		],
		officialWebsite: "https://www.iima.ac.in",
		description: "The gold standard of management education in Asia. Top recruiter choices in Investment Banking & Strategy Consulting.",
		rating: 5
	},
	{
		id: "fms-delhi",
		name: "Faculty of Management Studies (FMS Delhi University)",
		shortName: "FMS Delhi",
		type: "Central University",
		city: "New Delhi",
		state: "Delhi",
		nirfRank: 7,
		coursesOffered: [
			"MBA Full Time",
			"Executive MBA",
			"Ph.D"
		],
		popularDegrees: ["MBA (Marketing, Finance, Strategy)"],
		annualFeesRange: "₹2,00,000 (Total 2-Year Program — Highest ROI in India!)",
		avgPlacementPackageLPA: 34.1,
		highestPlacementPackageLPA: 123,
		acceptedExams: ["CAT (99.5+ Percentile)"],
		campusFacilities: [
			"North Campus DU access",
			"Finance Lab",
			"Consulting Club"
		],
		officialWebsite: "https://fms.edu",
		description: "Legendary business school renowned for having the highest Return on Investment (ROI) in India with ₹2 Lakh total fees.",
		rating: 4.9
	},
	{
		id: "aiims-delhi",
		name: "All India Institute of Medical Sciences (AIIMS New Delhi)",
		shortName: "AIIMS New Delhi",
		type: "Government / Autonomous",
		city: "New Delhi",
		state: "Delhi",
		nirfRank: 1,
		coursesOffered: [
			"MBBS",
			"MD",
			"MS",
			"M.Ch",
			"DM",
			"B.Sc Nursing"
		],
		popularDegrees: [
			"MBBS",
			"MD Cardiology",
			"MS Neuro Surgery"
		],
		annualFeesRange: "₹1,628 / year (Heavily Subsidized by Govt of India)",
		avgPlacementPackageLPA: 18,
		highestPlacementPackageLPA: 50,
		acceptedExams: ["NEET UG (Top 50 AIR)", "INI-CET"],
		campusFacilities: [
			"Apex Trauma Center",
			"National Medical Library",
			"Robotic Surgical Theaters"
		],
		officialWebsite: "https://www.aiims.edu",
		description: "Apex medical institute and hospital in India providing highest tier clinical training and subsidized education.",
		rating: 5
	},
	{
		id: "nlsiu-bangalore",
		name: "National Law School of India University (NLSIU Bangalore)",
		shortName: "NLSIU Bangalore",
		type: "Government / Autonomous",
		city: "Bangalore",
		state: "Karnataka",
		nirfRank: 1,
		coursesOffered: [
			"B.A. LL.B (Hons)",
			"LL.M",
			"Master of Public Policy (MPP)",
			"Ph.D in Law"
		],
		popularDegrees: ["5-Year Integrated B.A. LL.B (Hons)"],
		annualFeesRange: "₹3,75,000 / year",
		avgPlacementPackageLPA: 16,
		highestPlacementPackageLPA: 45,
		acceptedExams: ["CLAT (Common Law Admission Test - Top 60 AIR)"],
		campusFacilities: [
			"Narayana Rao Melgiri National Law Library",
			"Moot Court Hall",
			"Legal Aid Clinic"
		],
		officialWebsite: "https://www.nls.ac.in",
		description: "The Harvard of Indian legal education. Undisputed #1 Law School in India for corporate law and judicial careers.",
		rating: 4.9
	}
];
//#endregion
export { COLLEGES_DATA as n, SCHOLARSHIPS_DATA as r, CAREERS_DATA as t };
