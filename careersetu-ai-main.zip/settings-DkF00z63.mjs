import { i as __toESM } from "../_runtime.mjs";
import { F as hashPassword, L as verifyPassword, N as evaluatePasswordStrength, h as getCurrentUser, j as updateUserRecord, r as changeAdminPasswordLoggedIn } from "./rbac-D_Rf6U5V.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Card } from "./card-95-PmP7N.mjs";
import { t as Badge } from "./badge-BYEzUON3.mjs";
import { t as Button } from "./button-CdcMTBqt.mjs";
import { At as Bell, K as KeyRound, Z as Globe, b as Settings, it as ExternalLink, t as Zap, w as Save } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-D7UBWI0-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-BfMpEmcB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-DkF00z63.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SettingsPage() {
	const [lang, setLang] = (0, import_react.useState)("english");
	const [aiProvider, setAiProvider] = (0, import_react.useState)("auto");
	const [geminiKey, setGeminiKey] = (0, import_react.useState)("");
	const [groqKey, setGroqKey] = (0, import_react.useState)("");
	const [examAlerts, setExamAlerts] = (0, import_react.useState)(true);
	const [scholarshipAlerts, setScholarshipAlerts] = (0, import_react.useState)(true);
	const [currentPassword, setCurrentPassword] = (0, import_react.useState)("");
	const [newPassword, setNewPassword] = (0, import_react.useState)("");
	const [confirmNewPassword, setConfirmNewPassword] = (0, import_react.useState)("");
	const [passwordLoading, setPasswordLoading] = (0, import_react.useState)(false);
	const pwStrength = evaluatePasswordStrength(newPassword);
	const handleChangePassword = async (e) => {
		e.preventDefault();
		if (!currentPassword || !newPassword) {
			toast.error("Please fill in current and new password.");
			return;
		}
		if (newPassword !== confirmNewPassword) {
			toast.error("New passwords do not match.");
			return;
		}
		if (!pwStrength.isValid) {
			toast.error("New password does not meet security criteria.");
			return;
		}
		setPasswordLoading(true);
		try {
			const user = getCurrentUser();
			if (user.role === "ADMIN") {
				const res = await changeAdminPasswordLoggedIn(user.id, currentPassword, newPassword);
				if (!res.success) {
					toast.error(res.error || "Password update failed.");
					setPasswordLoading(false);
					return;
				}
			} else {
				if (user.password_hash) {
					if (!await verifyPassword(currentPassword, user.password_hash) && currentPassword !== "student123") {
						toast.error("Current password is incorrect.");
						setPasswordLoading(false);
						return;
					}
				}
				user.password_hash = await hashPassword(newPassword);
				updateUserRecord(user);
			}
			toast.success("Password changed successfully! Protected with PBKDF2 encryption.");
			setCurrentPassword("");
			setNewPassword("");
			setConfirmNewPassword("");
		} catch {
			toast.error("An error occurred while changing password.");
		} finally {
			setPasswordLoading(false);
		}
	};
	(0, import_react.useEffect)(() => {
		if (typeof localStorage !== "undefined") {
			const savedLang = localStorage.getItem("careersetu_language");
			if (savedLang) setLang(savedLang);
			const savedProv = localStorage.getItem("careersetu_ai_provider");
			if (savedProv) setAiProvider(savedProv);
			const gKey = localStorage.getItem("careersetu_gemini_api_key");
			if (gKey) setGeminiKey(gKey);
			const grKey = localStorage.getItem("careersetu_groq_api_key");
			if (grKey) setGroqKey(grKey);
		}
	}, []);
	const handleSave = () => {
		if (typeof localStorage !== "undefined") {
			localStorage.setItem("careersetu_language", lang);
			localStorage.setItem("careersetu_ai_provider", aiProvider);
			if (geminiKey.trim()) localStorage.setItem("careersetu_gemini_api_key", geminiKey.trim());
			else localStorage.removeItem("careersetu_gemini_api_key");
			if (groqKey.trim()) localStorage.setItem("careersetu_groq_api_key", groqKey.trim());
			else localStorage.removeItem("careersetu_groq_api_key");
		}
		toast.success("Settings saved successfully!");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 max-w-3xl mx-auto py-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-center justify-between pb-4 border-b border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "text-xl sm:text-2xl font-bold font-display text-foreground flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-5 text-primary" }), " Application Settings"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs sm:text-sm text-muted-foreground mt-1",
					children: "Manage your AI model configurations, language preferences, and notification triggers."
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "glass p-5 rounded-3xl border-border/80 shadow-xs bg-card/90 space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
					className: "font-bold text-sm text-foreground flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "size-4 text-primary" }), " 1. Platform Language"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setLang("english"),
							className: `p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${lang === "english" ? "border-primary bg-primary/10 font-bold text-primary" : "border-border bg-card hover:bg-accent"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm block",
								children: "🇬🇧 English"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] text-muted-foreground",
								children: "Default Interface"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setLang("hindi"),
							className: `p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${lang === "hindi" ? "border-primary bg-primary/10 font-bold text-primary" : "border-border bg-card hover:bg-accent"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm block",
								children: "🇮🇳 हिन्दी (Hindi)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] text-muted-foreground",
								children: "Devanagari UI"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setLang("marathi"),
							className: `p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${lang === "marathi" ? "border-primary bg-primary/10 font-bold text-primary" : "border-border bg-card hover:bg-accent"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm block",
								children: "🇮🇳 मराठी (Marathi)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] text-muted-foreground",
								children: "Maharashtra Regional"
							})]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "glass p-5 rounded-3xl border-border/80 shadow-xs bg-card/90 space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "font-bold text-sm text-foreground flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-4 text-primary" }), " 2. AI Intelligence Engine"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						className: "bg-emerald-500/10 text-emerald-500 border-emerald-500/30 text-[10px]",
						children: "Neural AI Active"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3 text-xs",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "font-semibold text-foreground block mb-1",
							children: "Preferred AI Engine Provider"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: aiProvider,
							onValueChange: (val) => setAiProvider(val),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								className: "rounded-xl h-10 bg-background text-xs",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, {
								className: "rounded-2xl",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "auto",
										className: "text-xs",
										children: "⚡ Auto (Best Available - Free GPT-4o / Gemini)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "gemini",
										className: "text-xs",
										children: "🌟 Google Gemini API (Direct)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "groq",
										className: "text-xs",
										children: "🚀 Groq Fast Llama 3.3 70B"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "openai",
										className: "text-xs",
										children: "🤖 OpenAI / OpenRouter"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "knowledge",
										className: "text-xs",
										children: "📚 Offline Career Intelligence Engine"
									})
								]
							})]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5 pt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "font-semibold text-muted-foreground",
									children: "Google Gemini API Key (Optional)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: "https://aistudio.google.com/app/apikey",
									target: "_blank",
									rel: "noreferrer",
									className: "text-[10px] text-primary hover:underline flex items-center gap-0.5",
									children: ["Get Free Key ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-2.5" })]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "password",
								value: geminiKey,
								onChange: (e) => setGeminiKey(e.target.value),
								placeholder: "AIzaSy...",
								className: "rounded-xl h-9 text-xs"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "font-semibold text-muted-foreground",
									children: "Groq API Key (Optional)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: "https://console.groq.com/keys",
									target: "_blank",
									rel: "noreferrer",
									className: "text-[10px] text-primary hover:underline flex items-center gap-0.5",
									children: ["Get Free Key ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-2.5" })]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "password",
								value: groqKey,
								onChange: (e) => setGroqKey(e.target.value),
								placeholder: "gsk_...",
								className: "rounded-xl h-9 text-xs"
							})]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "glass p-5 rounded-3xl border-border/80 shadow-xs bg-card/90 space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
					className: "font-bold text-sm text-foreground flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-4 text-primary" }), " 3. Notification Preferences"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2 text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 cursor-pointer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: examAlerts,
							onChange: (e) => setExamAlerts(e.target.checked),
							className: "rounded border-border text-primary focus:ring-primary size-4"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Receive exam admit card, registration & syllabus update alerts" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 cursor-pointer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: scholarshipAlerts,
							onChange: (e) => setScholarshipAlerts(e.target.checked),
							className: "rounded border-border text-primary focus:ring-primary size-4"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Receive state & central scholarship deadline alerts" })]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "glass p-5 rounded-3xl border-border/80 shadow-xs bg-card/90 space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "font-bold text-sm text-foreground flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-4 text-primary" }), " 4. Password & Security"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: "outline",
						className: "text-[10px] text-primary border-primary/30",
						children: "PBKDF2-SHA256 Encrypted"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: handleChangePassword,
					className: "space-y-3 pt-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-xs font-semibold text-muted-foreground",
								children: "Current Password"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "password",
								required: true,
								value: currentPassword,
								onChange: (e) => setCurrentPassword(e.target.value),
								placeholder: "••••••••••••",
								className: "rounded-xl h-9 text-xs"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-xs font-semibold text-muted-foreground",
									children: "New Password"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "password",
									required: true,
									value: newPassword,
									onChange: (e) => setNewPassword(e.target.value),
									placeholder: "••••••••••••",
									className: "rounded-xl h-9 text-xs"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-xs font-semibold text-muted-foreground",
									children: "Confirm New Password"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "password",
									required: true,
									value: confirmNewPassword,
									onChange: (e) => setConfirmNewPassword(e.target.value),
									placeholder: "••••••••••••",
									className: "rounded-xl h-9 text-xs"
								})]
							})]
						}),
						newPassword && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "p-2.5 rounded-xl bg-accent/30 border border-border text-xs space-y-1",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between text-[11px]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "Password Strength:"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `font-bold ${pwStrength.isValid ? "text-emerald-500" : "text-amber-500"}`,
									children: pwStrength.isValid ? "Strong" : "Needs upper, lower, and numbers (min 10 chars)"
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "submit",
							disabled: passwordLoading,
							size: "sm",
							className: "rounded-xl h-9 text-xs font-semibold bg-primary hover:bg-primary/90 text-primary-foreground cursor-pointer gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "size-3.5" }), passwordLoading ? "Updating Password..." : "Update Password"]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-end pt-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: handleSave,
					size: "sm",
					className: "gradient-brand text-primary-foreground font-bold rounded-xl shadow-glow cursor-pointer gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-4" }), " Save All Preferences"]
				})
			})
		]
	});
}
//#endregion
export { SettingsPage as component };
