import { i as __toESM } from "../_runtime.mjs";
import { g as Link, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { I as maskEmail, N as evaluatePasswordStrength, i as completeAdminFirstSetup, v as initiateAdminFirstSetup } from "./rbac-D_Rf6U5V.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Card } from "./card-95-PmP7N.mjs";
import { t as Button } from "./button-CdcMTBqt.mjs";
import { B as LoaderCircle, K as KeyRound, Nt as ArrowLeft, g as Sparkles, v as ShieldCheck } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-D7UBWI0-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Logo } from "./Logo-CGI7av7x.mjs";
import { t as Label } from "./label-DiINKb2h.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.first-setup-Cs3coHWq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminFirstSetupPage() {
	const navigate = useNavigate();
	const [email, setEmail] = (0, import_react.useState)("tysonfire13@gmail.com");
	const [securityCode, setSecurityCode] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [confirmPassword, setConfirmPassword] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [devOtp, setDevOtp] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let stored = "";
		if (typeof sessionStorage !== "undefined") {
			stored = sessionStorage.getItem("careersetu_pending_admin_email") || "";
			const devOtpStored = sessionStorage.getItem("careersetu_dev_otp");
			if (devOtpStored) setDevOtp(devOtpStored);
		}
		if (!stored) stored = "tysonfire13@gmail.com";
		setEmail(stored);
	}, []);
	const passwordStrength = evaluatePasswordStrength(password);
	const handleSetup = async (e) => {
		e.preventDefault();
		if (!securityCode || securityCode.trim().length !== 6) {
			toast.error("Please enter the 6-digit authorization security code.");
			return;
		}
		if (!password || password !== confirmPassword) {
			toast.error("Passwords do not match.");
			return;
		}
		if (!passwordStrength.isValid) {
			toast.error("Please create a stronger password meeting security criteria.");
			return;
		}
		setLoading(true);
		try {
			const result = await completeAdminFirstSetup(email, securityCode.trim(), password);
			if (!result.success) {
				toast.error(result.error || "Setup verification failed.");
				setLoading(false);
				return;
			}
			toast.success("Administrator password established successfully! Logging you in...");
			navigate({ to: "/admin/dashboard" });
		} catch (err) {
			toast.error("An error occurred during first-time administrator setup.");
		} finally {
			setLoading(false);
		}
	};
	const handleResend = async () => {
		if ((await initiateAdminFirstSetup(email)).isDev && typeof sessionStorage !== "undefined") {
			const devRecord = sessionStorage.getItem("careersetu_latest_dev_email");
			if (devRecord) try {
				const parsed = JSON.parse(devRecord);
				setDevOtp(parsed.otpCode);
			} catch {}
		}
		toast.success("New authorization security code dispatched.");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background text-foreground relative overflow-hidden flex flex-col justify-between p-4 sm:p-8 antialiased",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gradient-soft absolute inset-0 -z-10 opacity-70" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "blueprint-grid absolute inset-0 -z-10 opacity-40" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -top-32 left-1/2 -translate-x-1/2 -z-10 size-[32rem] rounded-full bg-amber-500/10 blur-[120px] pointer-events-none" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto w-full max-w-md flex items-center justify-between pt-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "flex items-center gap-2 hover:opacity-90 transition-opacity",
					"aria-label": "CareerSetu home",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto w-full max-w-md py-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 rounded-2xl bg-amber-500/10 border border-amber-500/25 p-3.5 flex items-start gap-3 text-xs text-amber-600 dark:text-amber-300",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-5 text-amber-500 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-bold",
						children: "First-Time Administrator Setup"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-0.5 text-muted-foreground leading-relaxed text-[11px]",
						children: "Set up your personal administrator password. No permanent hardcoded password is used."
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "rounded-3xl p-6 sm:p-8 bg-card/85 border border-border/80 shadow-elegant backdrop-blur-xl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between pb-4 border-b border-border/70",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid size-10 place-items-center rounded-2xl bg-amber-500/20 text-amber-600 dark:text-amber-400 border border-amber-500/30",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "size-5" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
										className: "text-lg font-bold font-display text-foreground",
										children: "Create Admin Password"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-muted-foreground",
										children: ["Account: ", email]
									})] })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "ghost",
									size: "sm",
									onClick: () => navigate({ to: "/admin/login" }),
									className: "h-8 px-2 text-xs text-muted-foreground hover:text-foreground rounded-xl",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-3.5 mr-1" }), " Back"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-4 rounded-2xl bg-primary/5 border border-primary/20 space-y-1.5 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-muted-foreground leading-relaxed",
									children: "A one-time setup code was generated on the backend and dispatched to your administrator email:"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono font-bold text-amber-600 dark:text-amber-400 text-sm tracking-wide",
									children: maskEmail(email)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								onSubmit: handleSetup,
								className: "space-y-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between mb-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-xs text-foreground font-semibold",
											children: "6-Digit Authorization Code"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: handleResend,
											className: "text-[11px] text-amber-600 dark:text-amber-400 hover:underline cursor-pointer",
											children: "Resend Code"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "text",
										required: true,
										maxLength: 6,
										value: securityCode,
										onChange: (e) => setSecurityCode(e.target.value.replace(/[^0-9]/g, "")),
										placeholder: "• • • • • •",
										className: "rounded-xl h-11 text-center text-lg tracking-[0.4em] font-mono font-bold"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-xs text-foreground font-semibold mb-1.5 block",
										children: "New Administrator Password"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "password",
										required: true,
										value: password,
										onChange: (e) => setPassword(e.target.value),
										placeholder: "••••••••••••",
										className: "rounded-xl h-10 text-xs"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-xs text-foreground font-semibold mb-1.5 block",
										children: "Confirm Administrator Password"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "password",
										required: true,
										value: confirmPassword,
										onChange: (e) => setConfirmPassword(e.target.value),
										placeholder: "••••••••••••",
										className: "rounded-xl h-10 text-xs"
									})] }),
									password && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3 rounded-xl bg-accent/40 border border-border/80 text-xs space-y-1.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-muted-foreground text-[11px]",
													children: "Password Security:"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: `text-[11px] font-bold ${passwordStrength.isValid ? "text-emerald-500" : "text-amber-500"}`,
													children: passwordStrength.isValid ? "Strong Password" : "Requirements Pending"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "grid grid-cols-4 gap-1 h-1.5 bg-muted rounded-full overflow-hidden",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `h-full ${passwordStrength.score >= 1 ? "bg-red-500" : "bg-transparent"}` }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `h-full ${passwordStrength.score >= 2 ? "bg-amber-500" : "bg-transparent"}` }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `h-full ${passwordStrength.score >= 3 ? "bg-blue-500" : "bg-transparent"}` }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `h-full ${passwordStrength.score >= 4 ? "bg-emerald-500" : "bg-transparent"}` })
												]
											}),
											!passwordStrength.isValid && passwordStrength.feedback.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px] text-muted-foreground leading-tight",
												children: passwordStrength.feedback[0]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "pt-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											type: "submit",
											disabled: loading || !passwordStrength.isValid || securityCode.length !== 6,
											className: "w-full h-11 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-md shadow-amber-600/20 cursor-pointer disabled:opacity-50 transition-all",
											children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin mr-2" }), "Hashing Password with PBKDF2 & Activating..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 mr-2" }), "Establish Password & Open Admin Dashboard"] })
										})
									})
								]
							})
						]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "text-center text-[11px] text-muted-foreground py-3",
				children: "CareerSetu AI Platform Security System • Multi-Factor Authentication & RBAC Tier 1"
			})
		]
	});
}
//#endregion
export { AdminFirstSetupPage as component };
