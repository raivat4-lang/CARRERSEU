import processModule from "node:process";
import { Buffer } from "node:buffer";
import { createHash, createHmac, randomBytes } from "node:crypto";
//#region node_modules/.nitro/vite/services/ssr/assets/session.server-XfVCDd2_.js
function getSecretKey() {
	return (typeof processModule !== "undefined" && processModule.env ? processModule.env : {}).SESSION_SECRET || "careersetu_production_cryptographic_session_secret_2026_tier1";
}
function generate6DigitOtp() {
	const num = randomBytes(4).readUInt32BE(0) % 9e5;
	return String(1e5 + num);
}
function hashOtp(otp) {
	return createHash("sha256").update(otp.trim()).digest("hex");
}
function signChallenge(payload) {
	const secret = getSecretKey();
	const raw = Buffer.from(JSON.stringify(payload)).toString("base64url");
	return `${raw}.${createHmac("sha256", secret).update(raw).digest("base64url")}`;
}
function verifyAndDecodeChallenge(token) {
	try {
		const parts = token.split(".");
		if (parts.length !== 2) return null;
		const [raw, signature] = parts;
		if (!raw || !signature) return null;
		const secret = getSecretKey();
		if (signature !== createHmac("sha256", secret).update(raw).digest("base64url")) return null;
		const json = Buffer.from(raw, "base64url").toString("utf8");
		return JSON.parse(json);
	} catch {
		return null;
	}
}
function signSessionToken(payload) {
	const secret = getSecretKey();
	const raw = Buffer.from(JSON.stringify(payload)).toString("base64url");
	return `${raw}.${createHmac("sha256", secret).update(raw).digest("base64url")}`;
}
function verifyAndDecodeSessionToken(token) {
	try {
		const parts = token.split(".");
		if (parts.length !== 2) return null;
		const [raw, signature] = parts;
		if (!raw || !signature) return null;
		const secret = getSecretKey();
		if (signature !== createHmac("sha256", secret).update(raw).digest("base64url")) return null;
		const json = Buffer.from(raw, "base64url").toString("utf8");
		const payload = JSON.parse(json);
		if (Date.now() > payload.expiresAt) return null;
		return payload;
	} catch {
		return null;
	}
}
//#endregion
export { generate6DigitOtp, hashOtp, signChallenge, signSessionToken, verifyAndDecodeChallenge, verifyAndDecodeSessionToken };
