import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Card } from "./card-95-PmP7N.mjs";
import { t as Badge } from "./badge-BYEzUON3.mjs";
import { C as Search, F as MapPin, Ot as Bookmark, h as Star, it as ExternalLink, u as Trophy, wt as Building2 } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-D7UBWI0-.mjs";
import { a as getManagedColleges } from "./admin-content-store-CcAL24zG.mjs";
import { _ as toggleBookmark, l as isBookmarked } from "./careersetu-store-CamG1tac.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-BfMpEmcB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/colleges-CGZEwDa0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var COLLEGE_TYPES = [
	"All Types",
	"Government / Autonomous",
	"Private University",
	"Deemed University",
	"Central University"
];
function CollegesDirectoryPage() {
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [selectedType, setSelectedType] = (0, import_react.useState)("All Types");
	const [bookmarkedMap, setBookmarkedMap] = (0, import_react.useState)({});
	const [collegesList, setCollegesList] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		const live = getManagedColleges().filter((c) => c.status !== "ARCHIVED");
		setCollegesList(live);
		const bMap = {};
		live.forEach((col) => {
			bMap[col.id] = isBookmarked("colleges", col.id);
		});
		setBookmarkedMap(bMap);
	}, []);
	const handleToggleBookmark = (id) => {
		const isNow = toggleBookmark("colleges", id);
		setBookmarkedMap((prev) => ({
			...prev,
			[id]: isNow
		}));
		toast.success(isNow ? "College added to bookmarks" : "Removed from bookmarks");
	};
	const filteredColleges = (0, import_react.useMemo)(() => {
		return collegesList.filter((col) => {
			const q = searchQuery.toLowerCase().trim();
			const matchesSearch = !q || col.name.toLowerCase().includes(q) || col.city.toLowerCase().includes(q) || col.state.toLowerCase().includes(q) || col.popularDegrees && col.popularDegrees.some((deg) => deg.toLowerCase().includes(q)) || col.acceptedExams && col.acceptedExams.some((ex) => ex.toLowerCase().includes(q));
			const matchesType = selectedType === "All Types" || col.type === selectedType;
			return matchesSearch && matchesType;
		});
	}, [
		collegesList,
		searchQuery,
		selectedType
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 max-w-5xl mx-auto py-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-9 place-items-center rounded-xl bg-emerald-500/10 text-emerald-500",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-xl sm:text-2xl font-bold font-display text-foreground",
						children: "College & University Directory"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs sm:text-sm text-muted-foreground mt-1",
					children: "NIRF rankings, tuition fees, placement averages, accepted exams, and campus infrastructure."
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "glass p-4 rounded-3xl border-border/80 shadow-xs space-y-3 bg-card/80",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 gap-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-2.5 size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: searchQuery,
							onChange: (e) => setSearchQuery(e.target.value),
							placeholder: "Search by college name, city, course (B.Tech, BCA, MBA)...",
							className: "pl-9 h-10 rounded-xl bg-background border-border text-xs sm:text-sm"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: selectedType,
						onValueChange: setSelectedType,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "rounded-xl h-10 text-xs bg-background",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "University Type" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, {
							className: "rounded-2xl",
							children: COLLEGE_TYPES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: t,
								className: "text-xs",
								children: t
							}, t))
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between text-xs pt-1 text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						"Showing ",
						filteredColleges.length,
						" Top-Tier Indian Institutions"
					] }), (searchQuery || selectedType !== "All Types") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							setSearchQuery("");
							setSelectedType("All Types");
						},
						className: "text-primary hover:underline text-[11px] font-medium cursor-pointer",
						children: "Clear Filters"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 md:grid-cols-2 gap-4",
				children: filteredColleges.map((col) => {
					const isSaved = bookmarkedMap[col.id];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "glass p-5 rounded-3xl border-border/80 hover:border-emerald-500/40 transition-all shadow-xs hover:shadow-lg flex flex-col justify-between space-y-4 bg-card/90",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "outline",
										className: "text-[10px] border-emerald-500/30 text-emerald-600 dark:text-emerald-400 bg-emerald-500/5",
										children: col.type
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[10px] font-bold text-primary bg-primary/10 px-2 py-0.5 rounded-full flex items-center gap-1",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "size-3 text-amber-500" }),
												" NIRF #",
												col.nirfRank
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => handleToggleBookmark(col.id),
											className: "p-1 rounded-lg text-muted-foreground hover:text-primary transition-colors cursor-pointer",
											title: "Bookmark college",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: `size-3.5 ${isSaved ? "fill-primary text-primary" : ""}` })
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-bold text-base text-foreground leading-snug",
										children: col.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-muted-foreground mt-0.5 flex items-center gap-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3 text-primary" }),
											" ",
											col.city,
											", ",
											col.state
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground mt-1.5 line-clamp-2 leading-relaxed",
										children: col.description
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5 pt-2 border-t border-border/40 text-xs text-muted-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Average Package:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
											className: "text-emerald-500 font-bold",
											children: [
												"₹",
												col.avgPlacementPackageLPA,
												" LPA"
											]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Annual Tuition Fees:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-foreground",
											children: col.annualFeesRange
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] font-semibold text-muted-foreground block",
										children: "Popular Degrees:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex flex-wrap gap-1",
										children: col.popularDegrees.map((deg) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] px-2 py-0.5 rounded-md bg-accent text-foreground font-medium",
											children: deg
										}, deg))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] font-semibold text-muted-foreground block",
										children: "Accepted Exams:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex flex-wrap gap-1",
										children: col.acceptedExams.map((ex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] px-2 py-0.5 rounded-md bg-primary/10 text-primary font-mono font-semibold",
											children: ex
										}, ex))
									})]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2 pt-3 border-t border-border/40",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs font-semibold text-amber-500 flex items-center gap-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "size-3.5 fill-amber-500" }),
									" ",
									col.rating,
									" / 5.0"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: col.officialWebsite,
								target: "_blank",
								rel: "noreferrer",
								className: "inline-flex items-center gap-1.5 text-xs font-bold text-primary hover:underline cursor-pointer",
								children: ["Official Website ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3.5" })]
							})]
						})]
					}, col.id);
				})
			})
		]
	});
}
//#endregion
export { CollegesDirectoryPage as component };
