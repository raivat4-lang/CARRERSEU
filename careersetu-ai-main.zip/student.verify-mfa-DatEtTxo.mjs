import { i as __toESM } from "../_runtime.mjs";
import { g as Link, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { I as maskEmail, g as getUserByEmail, l as createAndDispatchMfaCode, s as completeStudentMfaLogin, u as getActiveDevOtpForEmail } from "./rbac-D_Rf6U5V.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Card } from "./card-95-PmP7N.mjs";
import { t as Button } from "./button-CdcMTBqt.mjs";
import { B as LoaderCircle, E as RefreshCw, I as Mail, Nt as ArrowLeft, g as Sparkles, ht as CircleAlert, pt as CircleCheck, v as ShieldCheck } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Logo } from "./Logo-CGI7av7x.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/student.verify-mfa-DatEtTxo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function StudentVerifyMfaPage() {
	const navigate = useNavigate();
	const [email, setEmail] = (0, import_react.useState)("");
	const [maskedDisplay, setMaskedDisplay] = (0, import_react.useState)("");
	const [devOtp, setDevOtp] = (0, import_react.useState)(null);
	const [otp, setOtp] = (0, import_react.useState)([
		"",
		"",
		"",
		"",
		"",
		""
	]);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [timeLeft, setTimeLeft] = (0, import_react.useState)(600);
	const [resendCooldown, setResendCooldown] = (0, import_react.useState)(45);
	const [errorMsg, setErrorMsg] = (0, import_react.useState)("");
	const [attempts, setAttempts] = (0, import_react.useState)(0);
	const inputRefs = (0, import_react.useRef)([]);
	(0, import_react.useEffect)(() => {
		let storedEmail = "";
		let storedMasked = "";
		if (typeof sessionStorage !== "undefined") {
			storedEmail = sessionStorage.getItem("careersetu_pending_student_email") || "";
			storedMasked = sessionStorage.getItem("careersetu_pending_student_masked") || "";
			const storedDevOtp = sessionStorage.getItem("careersetu_dev_otp") || sessionStorage.getItem("careersetu_pending_dev_otp");
			if (storedDevOtp) setDevOtp(storedDevOtp);
		}
		if (!storedEmail) {
			toast.error("No active verification session. Please sign up or log in first.");
			navigate({ to: "/student/signup" });
			return;
		}
		setEmail(storedEmail);
		setMaskedDisplay(storedMasked || maskEmail(storedEmail));
		if (!devOtp) {
			const activeCode = getActiveDevOtpForEmail(storedEmail);
			if (activeCode) setDevOtp(activeCode);
		}
		setTimeout(() => inputRefs.current[0]?.focus(), 100);
	}, [navigate]);
	(0, import_react.useEffect)(() => {
		if (timeLeft <= 0) return;
		const timer = setInterval(() => setTimeLeft((prev) => Math.max(0, prev - 1)), 1e3);
		return () => clearInterval(timer);
	}, [timeLeft]);
	(0, import_react.useEffect)(() => {
		if (resendCooldown <= 0) return;
		const timer = setInterval(() => setResendCooldown((prev) => Math.max(0, prev - 1)), 1e3);
		return () => clearInterval(timer);
	}, [resendCooldown]);
	const formatTimer = (seconds) => {
		return `${Math.floor(seconds / 60).toString().padStart(2, "0")}:${(seconds % 60).toString().padStart(2, "0")}`;
	};
	const otpValue = otp.join("");
	const handleOtpInput = (index, value) => {
		setErrorMsg("");
		if (value.length > 1) {
			const digits = value.replace(/\D/g, "").slice(0, 6).split("");
			const newOtp = Array.from({ length: 6 }, (_, i) => digits[i] || "");
			setOtp(newOtp);
			const nextFocus = Math.min(digits.length, 5);
			setTimeout(() => inputRefs.current[nextFocus]?.focus(), 20);
			return;
		}
		const digit = value.replace(/\D/g, "");
		const newOtp = [...otp];
		newOtp[index] = digit;
		setOtp(newOtp);
		if (digit && index < 5) setTimeout(() => inputRefs.current[index + 1]?.focus(), 20);
	};
	const handleOtpKeyDown = (index, e) => {
		if (e.key === "Backspace") if (!otp[index] && index > 0) {
			const newOtp = [...otp];
			newOtp[index - 1] = "";
			setOtp(newOtp);
			setTimeout(() => inputRefs.current[index - 1]?.focus(), 20);
		} else {
			const newOtp = [...otp];
			newOtp[index] = "";
			setOtp(newOtp);
		}
		else if (e.key === "ArrowLeft" && index > 0) inputRefs.current[index - 1]?.focus();
		else if (e.key === "ArrowRight" && index < 5) inputRefs.current[index + 1]?.focus();
		else if (e.key === "Enter" && otpValue.length === 6) handleVerifyOtp();
	};
	const handleOtpPaste = (e) => {
		e.preventDefault();
		const pasted = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, 6);
		if (!pasted) return;
		const digits = pasted.split("");
		const newOtp = Array.from({ length: 6 }, (_, i) => digits[i] || "");
		setOtp(newOtp);
		const nextFocus = Math.min(pasted.length, 5);
		setTimeout(() => inputRefs.current[nextFocus]?.focus(), 20);
	};
	const handleVerifyOtp = async () => {
		const code = otpValue.trim();
		if (code.length !== 6) {
			setErrorMsg("Please enter all 6 digits of the verification code.");
			const firstEmpty = otp.findIndex((d) => !d);
			if (firstEmpty >= 0) inputRefs.current[firstEmpty]?.focus();
			return;
		}
		if (timeLeft <= 0) {
			setErrorMsg("The verification code has expired. Please request a new one.");
			return;
		}
		setLoading(true);
		setErrorMsg("");
		try {
			const rbacResult = await completeStudentMfaLogin(email, code);
			if (rbacResult.success) {
				if (typeof sessionStorage !== "undefined") {
					sessionStorage.removeItem("careersetu_pending_student_email");
					sessionStorage.removeItem("careersetu_pending_student_masked");
					sessionStorage.removeItem("careersetu_dev_otp");
					sessionStorage.removeItem("careersetu_pending_dev_otp");
				}
				toast.success(`Welcome to CareerSetu, ${rbacResult.user?.name || "Student"}! 🎉`);
				navigate({ to: "/dashboard" });
				return;
			}
			setAttempts((prev) => prev + 1);
			if ((rbacResult.error || "The verification code is incorrect or expired.").toLowerCase().includes("expired")) setErrorMsg("Verification code has expired. Click 'Resend Code' to get a new one.");
			else {
				const remaining = Math.max(0, 5 - (attempts + 1));
				setErrorMsg(`Incorrect code.${remaining > 0 ? ` ${remaining} attempts remaining.` : " Please request a new code."}`);
			}
			setOtp([
				"",
				"",
				"",
				"",
				"",
				""
			]);
			setTimeout(() => inputRefs.current[0]?.focus(), 50);
		} catch (err) {
			setErrorMsg("An unexpected error occurred. Please try again.");
			console.error("[VerifyOtp] Unexpected error:", err);
		} finally {
			setLoading(false);
		}
	};
	const handleResendCode = async () => {
		if (resendCooldown > 0) return;
		setLoading(true);
		setErrorMsg("");
		setOtp([
			"",
			"",
			"",
			"",
			"",
			""
		]);
		try {
			const user = getUserByEmail(email);
			if (!user) {
				toast.error("User account not found. Please register again.");
				return;
			}
			const latestCode = (await createAndDispatchMfaCode(user, user.email_verified ? "LOGIN" : "EMAIL_VERIFICATION")).devOtp || getActiveDevOtpForEmail(email);
			if (latestCode) {
				setDevOtp(latestCode);
				if (typeof sessionStorage !== "undefined") {
					sessionStorage.setItem("careersetu_dev_otp", latestCode);
					sessionStorage.setItem("careersetu_pending_dev_otp", latestCode);
				}
			}
			setResendCooldown(45);
			setTimeLeft(600);
			setAttempts(0);
			toast.success("A fresh 6-digit verification code has been dispatched.");
			setTimeout(() => inputRefs.current[0]?.focus(), 100);
		} catch {
			toast.error("Failed to resend code. Please try again.");
		} finally {
			setLoading(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background text-foreground relative overflow-hidden flex flex-col justify-between p-4 sm:p-8 antialiased",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gradient-soft absolute inset-0 -z-10 opacity-70" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "blueprint-grid absolute inset-0 -z-10 opacity-40" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -top-32 left-1/2 -translate-x-1/2 -z-10 size-[36rem] rounded-full bg-primary/15 blur-[120px] pointer-events-none" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute bottom-0 right-0 -z-10 size-64 rounded-full bg-violet-500/10 blur-[80px] pointer-events-none" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto w-full max-w-md flex items-center justify-between pt-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "flex items-center gap-2 hover:opacity-90 transition-opacity",
					"aria-label": "CareerSetu home",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/student/login",
					className: "flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors rounded-xl px-3 py-1.5 hover:bg-accent",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-3.5" }), "Back to Login"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto w-full max-w-md py-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "rounded-3xl p-6 sm:p-8 bg-card/90 border border-border/80 shadow-elegant backdrop-blur-xl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-4 pb-4 border-b border-border/70",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid size-12 place-items-center rounded-2xl gradient-brand text-primary-foreground shadow-glow shrink-0",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "text-xl font-bold font-display text-foreground tracking-tight",
									children: "Email Verification"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground mt-0.5",
									children: "Step 2 of 2 — Enter 6-digit security code"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-4 rounded-2xl bg-primary/5 border border-primary/20 space-y-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-muted-foreground leading-relaxed flex items-start gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3.5 text-primary shrink-0 mt-0.5" }), "A single-use 6-digit code was sent to:"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-mono font-bold text-primary text-base tracking-widest pl-5",
										children: maskedDisplay || "your@email.com"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[11px] text-muted-foreground pl-5",
										children: [
											"Check your ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-foreground font-medium",
												children: "inbox and spam folder"
											}),
											" for the verification code from CareerSetu AI."
										]
									})
								]
							}),
							devOtp && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl border border-primary/40 bg-primary/10 p-4 flex items-start gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-primary text-xl leading-none mt-0.5",
									children: "⚡"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1 min-w-0",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between mb-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-bold text-primary",
												children: "Verification Code Ready"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-primary/20 text-primary font-semibold",
												children: "Instant Testing"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-mono text-2xl sm:text-3xl font-black tracking-[0.3em] text-foreground select-all cursor-pointer hover:text-primary transition-colors",
												onClick: () => {
													const digits = devOtp.slice(0, 6).split("");
													setOtp(Array.from({ length: 6 }, (_, i) => digits[i] || ""));
													toast.success("Security code auto-filled!");
													setTimeout(() => inputRefs.current[5]?.focus(), 50);
												},
												title: "Click to copy or auto-fill",
												children: devOtp
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												type: "button",
												size: "sm",
												onClick: () => {
													const digits = devOtp.slice(0, 6).split("");
													setOtp(Array.from({ length: 6 }, (_, i) => digits[i] || ""));
													toast.success("Code auto-filled!");
													setTimeout(() => inputRefs.current[5]?.focus(), 50);
												},
												className: "h-8 px-3 text-xs rounded-xl gradient-brand text-primary-foreground font-semibold shadow-xs hover:opacity-90 cursor-pointer",
												children: "Auto-fill"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[11px] text-muted-foreground mt-2 leading-relaxed",
											children: [
												"Click code or ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Auto-fill" }),
												" to verify instantly. Real emails are sent when SMTP or Brevo API is configured in ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
													className: "font-mono text-[10px] bg-muted px-1 py-0.5 rounded",
													children: ".env"
												}),
												"."
											]
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between mb-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "text-xs text-foreground font-semibold",
										children: "6-Digit Verification Code"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `text-[11px] font-mono font-medium tabular-nums ${timeLeft <= 60 ? "text-red-400" : "text-muted-foreground"}`,
										children: timeLeft > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Expires in ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: timeLeft <= 60 ? "text-red-400" : "text-amber-400",
											children: formatTimer(timeLeft)
										})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-red-400 font-semibold",
											children: "Code expired"
										})
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex gap-2 sm:gap-3 justify-center",
									onPaste: handleOtpPaste,
									children: otp.map((digit, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										ref: (el) => {
											inputRefs.current[index] = el;
										},
										type: "text",
										inputMode: "numeric",
										maxLength: 6,
										value: digit,
										disabled: loading || timeLeft <= 0,
										onChange: (e) => handleOtpInput(index, e.target.value),
										onKeyDown: (e) => handleOtpKeyDown(index, e),
										onFocus: (e) => e.target.select(),
										style: {
											width: "100%",
											maxWidth: "60px",
											aspectRatio: "1",
											borderRadius: "16px",
											border: `2px solid ${digit ? "hsl(var(--primary))" : errorMsg && !digit ? "rgba(239,68,68,0.6)" : "hsl(var(--border))"}`,
											background: digit ? "hsl(var(--primary) / 0.05)" : "hsl(var(--card) / 0.8)",
											color: "hsl(var(--foreground))",
											textAlign: "center",
											fontSize: "1.5rem",
											fontWeight: "900",
											fontFamily: "monospace",
											outline: "none",
											transition: "all 0.15s ease",
											opacity: loading || timeLeft <= 0 ? .5 : 1,
											cursor: loading || timeLeft <= 0 ? "not-allowed" : "text",
											boxShadow: digit ? "0 0 0 3px hsl(var(--primary) / 0.15)" : "none"
										},
										onFocusCapture: (e) => {
											e.currentTarget.style.borderColor = "hsl(var(--primary))";
											e.currentTarget.style.boxShadow = "0 0 0 3px hsl(var(--primary) / 0.2)";
										},
										onBlurCapture: (e) => {
											const hasValue = e.currentTarget.value;
											e.currentTarget.style.borderColor = hasValue ? "hsl(var(--primary))" : "hsl(var(--border))";
											e.currentTarget.style.boxShadow = hasValue ? "0 0 0 3px hsl(var(--primary) / 0.15)" : "none";
										},
										"aria-label": `Digit ${index + 1}`
									}, index))
								}),
								errorMsg && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 flex items-start gap-2 p-3 rounded-xl bg-red-500/10 border border-red-500/25 text-xs text-red-400",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "size-3.5 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: errorMsg })]
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								onClick: handleVerifyOtp,
								disabled: loading || otpValue.length !== 6 || timeLeft <= 0,
								className: "w-full h-12 rounded-xl gradient-brand text-primary-foreground font-bold text-sm shadow-glow hover:opacity-95 hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0 cursor-pointer transition-all disabled:opacity-50 disabled:cursor-not-allowed",
								children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin mr-2" }), "Verifying Code..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 mr-2" }), "Verify & Open Dashboard"] })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3 pt-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between text-xs text-muted-foreground",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Didn't receive the email?" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: handleResendCode,
											disabled: resendCooldown > 0 || loading,
											className: `flex items-center gap-1.5 font-semibold transition-colors ${resendCooldown > 0 || loading ? "text-muted-foreground/50 cursor-not-allowed" : "text-primary hover:underline underline-offset-2 cursor-pointer"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `size-3 ${loading ? "animate-spin" : ""}` }), resendCooldown > 0 ? `Resend in ${resendCooldown}s` : "Resend Code"]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 p-3 rounded-xl bg-accent/30 border border-border/50",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-3.5 text-muted-foreground shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] text-muted-foreground leading-tight",
											children: "This code expires in 10 minutes and can only be used once. Never share it with anyone."
										})]
									}),
									attempts >= 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[11px] text-center text-muted-foreground",
										children: [
											"Having trouble?",
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => navigate({ to: "/student/signup" }),
												className: "text-primary underline underline-offset-2 cursor-pointer",
												children: "Try registering again"
											})
										]
									})
								]
							})
						]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "text-center text-[11px] text-muted-foreground py-3",
				children: "CareerSetu AI • End-to-end Encrypted Verification"
			})
		]
	});
}
//#endregion
export { StudentVerifyMfaPage as component };
