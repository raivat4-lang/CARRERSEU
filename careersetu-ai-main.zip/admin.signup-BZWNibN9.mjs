import { i as __toESM } from "../_runtime.mjs";
import { g as Link, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { F as hashPassword, M as sendAuthenticationEmail, N as evaluatePasswordStrength, P as generateSecureOtp, c as createAdminApplication, d as getAdminApplicationByEmail, g as getUserByEmail } from "./rbac-D_Rf6U5V.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Card } from "./card-95-PmP7N.mjs";
import { t as Button } from "./button-CdcMTBqt.mjs";
import { A as Phone, B as LoaderCircle, E as RefreshCw, I as Mail, Mt as ArrowRight, Nt as ArrowLeft, _ as Shield, g as Sparkles, lt as ClipboardList, o as User, pt as CircleCheck, v as ShieldCheck, wt as Building2, y as ShieldAlert } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-D7UBWI0-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Logo } from "./Logo-CGI7av7x.mjs";
import { t as Label } from "./label-DiINKb2h.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.signup-BZWNibN9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminSignupPage() {
	const navigate = useNavigate();
	const [step, setStep] = (0, import_react.useState)("details");
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [formData, setFormData] = (0, import_react.useState)({
		fullName: "",
		email: "",
		phone: "",
		organization: "",
		reason: "",
		password: "",
		confirmPassword: ""
	});
	const [emailOtp, setEmailOtp] = (0, import_react.useState)([
		"",
		"",
		"",
		"",
		"",
		""
	]);
	const [emailOtpCode, setEmailOtpCode] = (0, import_react.useState)("");
	const [, setEmailVerified] = (0, import_react.useState)(false);
	const [emailResendCooldown, setEmailResendCooldown] = (0, import_react.useState)(0);
	const [emailTimeLeft, setEmailTimeLeft] = (0, import_react.useState)(600);
	const emailRefs = (0, import_react.useRef)([]);
	const [phoneOtp, setPhoneOtp] = (0, import_react.useState)([
		"",
		"",
		"",
		"",
		"",
		""
	]);
	const [phoneOtpCode, setPhoneOtpCode] = (0, import_react.useState)("");
	const [, setPhoneVerified] = (0, import_react.useState)(false);
	const [phoneResendCooldown, setPhoneResendCooldown] = (0, import_react.useState)(0);
	const phoneRefs = (0, import_react.useRef)([]);
	const [applicationId, setApplicationId] = (0, import_react.useState)("");
	const passwordStrength = evaluatePasswordStrength(formData.password);
	const startTimer = (setter, seconds) => {
		setter(seconds);
		const id = setInterval(() => {
			setter((prev) => {
				if (prev <= 1) {
					clearInterval(id);
					return 0;
				}
				return prev - 1;
			});
		}, 1e3);
	};
	const formatTimer = (s) => `${Math.floor(s / 60).toString().padStart(2, "0")}:${(s % 60).toString().padStart(2, "0")}`;
	const handleDetailsSubmit = async (e) => {
		e.preventDefault();
		const { fullName, email, phone, organization, reason, password, confirmPassword } = formData;
		if (!fullName || !email || !phone || !organization || !reason || !password) {
			toast.error("Please fill in all required fields.");
			return;
		}
		if (!email.includes("@")) {
			toast.error("Please enter a valid email address.");
			return;
		}
		if (phone.replace(/\D/g, "").length < 10) {
			toast.error("Please enter a valid 10-digit phone number.");
			return;
		}
		if (reason.trim().length < 30) {
			toast.error("Please provide a more detailed reason (at least 30 characters).");
			return;
		}
		if (!passwordStrength.isValid) {
			toast.error("Please choose a stronger password (min 10 chars with uppercase, lowercase, and numbers).");
			return;
		}
		if (password !== confirmPassword) {
			toast.error("Passwords do not match.");
			return;
		}
		const cleanEmail = email.trim().toLowerCase();
		const existingUser = getUserByEmail(cleanEmail);
		if (existingUser && existingUser.role === "ADMIN") {
			toast.error("An administrator account with this email already exists. Please log in.");
			return;
		}
		const existingApp = getAdminApplicationByEmail(cleanEmail);
		if (existingApp && existingApp.status === "APPROVED") {
			toast.error("This email already has an approved admin account. Please log in.");
			return;
		}
		if (existingApp && existingApp.status === "PENDING_APPROVAL") {
			toast.info("Your application is already under review. Please wait for Super Admin approval.");
			return;
		}
		setLoading(true);
		try {
			const otp = generateSecureOtp();
			setEmailOtpCode(otp);
			await sendAuthenticationEmail({
				to: cleanEmail,
				templateType: "ADMIN_FIRST_SETUP",
				recipientName: fullName.trim(),
				otpCode: otp,
				expiresInMinutes: 10
			});
			setStep("email-verify");
			startTimer(setEmailTimeLeft, 600);
			startTimer(setEmailResendCooldown, 45);
			toast.success("A 6-digit verification code has been sent to your email.");
			setTimeout(() => emailRefs.current[0]?.focus(), 150);
		} catch {
			toast.error("Failed to send verification email. Please try again.");
		} finally {
			setLoading(false);
		}
	};
	const handleEmailOtpInput = (index, value) => {
		if (value.length > 1) {
			const digits = value.replace(/\D/g, "").slice(0, 6).split("");
			const newOtp = Array.from({ length: 6 }, (_, i) => digits[i] || "");
			setEmailOtp(newOtp);
			setTimeout(() => emailRefs.current[Math.min(digits.length, 5)]?.focus(), 20);
			return;
		}
		const digit = value.replace(/\D/g, "");
		const newOtp = [...emailOtp];
		newOtp[index] = digit;
		setEmailOtp(newOtp);
		if (digit && index < 5) setTimeout(() => emailRefs.current[index + 1]?.focus(), 20);
	};
	const handleEmailOtpKeyDown = (index, e) => {
		if (e.key === "Backspace" && !emailOtp[index] && index > 0) {
			const newOtp = [...emailOtp];
			newOtp[index - 1] = "";
			setEmailOtp(newOtp);
			setTimeout(() => emailRefs.current[index - 1]?.focus(), 20);
		}
	};
	const handleVerifyEmail = async () => {
		const entered = emailOtp.join("");
		if (entered.length !== 6) {
			toast.error("Please enter all 6 digits.");
			return;
		}
		if (emailTimeLeft <= 0) {
			toast.error("The verification code has expired. Please request a new one.");
			return;
		}
		if (entered !== emailOtpCode) {
			toast.error("Incorrect code. Please try again.");
			setEmailOtp([
				"",
				"",
				"",
				"",
				"",
				""
			]);
			setTimeout(() => emailRefs.current[0]?.focus(), 50);
			return;
		}
		setEmailVerified(true);
		const pOtp = generateSecureOtp();
		setPhoneOtpCode(pOtp);
		console.log(`[ADMIN SIGNUP PHONE OTP] To: ${formData.phone} | Code: ${pOtp}`);
		toast.success("Email verified! Now verify your phone number.");
		toast.info(`[Dev Testing] Phone OTP is: ${pOtp}`);
		setStep("phone-verify");
		startTimer(setPhoneResendCooldown, 45);
		setTimeout(() => phoneRefs.current[0]?.focus(), 150);
	};
	const handleResendEmailOtp = async () => {
		if (emailResendCooldown > 0) return;
		setLoading(true);
		try {
			const otp = generateSecureOtp();
			setEmailOtpCode(otp);
			await sendAuthenticationEmail({
				to: formData.email.trim().toLowerCase(),
				templateType: "ADMIN_FIRST_SETUP",
				recipientName: formData.fullName.trim(),
				otpCode: otp,
				expiresInMinutes: 10
			});
			startTimer(setEmailTimeLeft, 600);
			startTimer(setEmailResendCooldown, 45);
			setEmailOtp([
				"",
				"",
				"",
				"",
				"",
				""
			]);
			toast.success("A new verification code has been sent.");
		} catch {
			toast.error("Failed to resend code. Please try again.");
		} finally {
			setLoading(false);
		}
	};
	const handlePhoneOtpInput = (index, value) => {
		if (value.length > 1) {
			const digits = value.replace(/\D/g, "").slice(0, 6).split("");
			const newOtp = Array.from({ length: 6 }, (_, i) => digits[i] || "");
			setPhoneOtp(newOtp);
			setTimeout(() => phoneRefs.current[Math.min(digits.length, 5)]?.focus(), 20);
			return;
		}
		const digit = value.replace(/\D/g, "");
		const newOtp = [...phoneOtp];
		newOtp[index] = digit;
		setPhoneOtp(newOtp);
		if (digit && index < 5) setTimeout(() => phoneRefs.current[index + 1]?.focus(), 20);
	};
	const handlePhoneOtpKeyDown = (index, e) => {
		if (e.key === "Backspace" && !phoneOtp[index] && index > 0) {
			const newOtp = [...phoneOtp];
			newOtp[index - 1] = "";
			setPhoneOtp(newOtp);
			setTimeout(() => phoneRefs.current[index - 1]?.focus(), 20);
		}
	};
	const handleResendPhoneOtp = () => {
		if (phoneResendCooldown > 0) return;
		const pOtp = generateSecureOtp();
		setPhoneOtpCode(pOtp);
		console.log(`[ADMIN SIGNUP PHONE OTP] To: ${formData.phone} | Code: ${pOtp}`);
		toast.info(`[Dev Testing] New Phone OTP is: ${pOtp}`);
		startTimer(setPhoneResendCooldown, 45);
		setPhoneOtp([
			"",
			"",
			"",
			"",
			"",
			""
		]);
	};
	const handleVerifyPhone = async () => {
		const entered = phoneOtp.join("");
		if (entered.length !== 6) {
			toast.error("Please enter all 6 digits.");
			return;
		}
		if (entered !== phoneOtpCode) {
			toast.error("Incorrect phone OTP. Please try again.");
			setPhoneOtp([
				"",
				"",
				"",
				"",
				"",
				""
			]);
			setTimeout(() => phoneRefs.current[0]?.focus(), 50);
			return;
		}
		setPhoneVerified(true);
		setLoading(true);
		try {
			const password_hash = await hashPassword(formData.password);
			const result = createAdminApplication({
				fullName: formData.fullName.trim(),
				email: formData.email.trim().toLowerCase(),
				phone: formData.phone.trim(),
				organization: formData.organization.trim(),
				reason: formData.reason.trim(),
				password_hash,
				emailVerified: true,
				phoneVerified: true
			});
			if (!result.success || !result.application) {
				toast.error(result.error || "Failed to submit application. Please try again.");
				return;
			}
			setApplicationId(result.application.id);
			setStep("submitted");
			toast.success("Application submitted! Awaiting Super Admin review.");
		} catch {
			toast.error("An unexpected error occurred. Please try again.");
		} finally {
			setLoading(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background text-foreground relative overflow-hidden flex flex-col justify-between p-4 sm:p-8 antialiased",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gradient-soft absolute inset-0 -z-10 opacity-70" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "blueprint-grid absolute inset-0 -z-10 opacity-40" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -top-32 left-1/2 -translate-x-1/2 -z-10 size-[36rem] rounded-full bg-amber-500/10 blur-[120px] pointer-events-none" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto w-full max-w-lg flex items-center justify-between pt-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "flex items-center gap-2 hover:opacity-90 transition-opacity",
					"aria-label": "CareerSetu home",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/admin/login",
					className: "flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors px-3 py-1.5 rounded-xl border border-border/60 hover:bg-accent",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-3.5" }), "Back to Admin Login"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto w-full max-w-lg py-6",
				children: [step !== "submitted" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center justify-center gap-2 mb-6",
					children: [
						"details",
						"email-verify",
						"phone-verify"
					].map((s, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `flex items-center justify-center size-7 rounded-full text-xs font-bold transition-all ${step === s ? "bg-amber-500 text-black shadow-[0_0_10px_rgba(245,158,11,0.5)]" : [
								"details",
								"email-verify",
								"phone-verify"
							].indexOf(step) > idx ? "bg-emerald-500/20 border border-emerald-500/50 text-emerald-400" : "bg-muted border border-border/60 text-muted-foreground"}`,
							children: [
								"details",
								"email-verify",
								"phone-verify"
							].indexOf(step) > idx ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4" }) : idx + 1
						}), idx < 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `w-8 h-0.5 rounded-full ${[
							"details",
							"email-verify",
							"phone-verify"
						].indexOf(step) > idx ? "bg-emerald-500/50" : "bg-border/50"}` })]
					}, s))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "rounded-3xl p-6 sm:p-8 bg-card/90 border border-border/80 shadow-elegant backdrop-blur-xl",
					children: [
						step === "details" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 pb-4 border-b border-border/70",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid size-11 place-items-center rounded-2xl bg-amber-500/15 border border-amber-500/30 text-amber-400 shrink-0",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "text-lg font-bold font-display text-foreground",
									children: "Request Admin Access"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground mt-0.5",
									children: "Submit your details for Super Admin authorization."
								})] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								onSubmit: handleDetailsSubmit,
								className: "space-y-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
												htmlFor: "admin-full-name",
												className: "text-xs font-semibold text-muted-foreground uppercase tracking-wide",
												children: "Full Name *"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "relative",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "absolute left-3 top-1/2 -translate-y-1/2 size-3.5 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													id: "admin-full-name",
													placeholder: "Your full name",
													value: formData.fullName,
													onChange: (e) => setFormData((p) => ({
														...p,
														fullName: e.target.value
													})),
													className: "pl-9 h-10 rounded-xl",
													required: true
												})]
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
												htmlFor: "admin-phone",
												className: "text-xs font-semibold text-muted-foreground uppercase tracking-wide",
												children: "Phone Number *"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "relative",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "absolute left-3 top-1/2 -translate-y-1/2 size-3.5 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													id: "admin-phone",
													type: "tel",
													placeholder: "+91 98765 43210",
													value: formData.phone,
													onChange: (e) => setFormData((p) => ({
														...p,
														phone: e.target.value
													})),
													className: "pl-9 h-10 rounded-xl",
													required: true
												})]
											})]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: "admin-email",
											className: "text-xs font-semibold text-muted-foreground uppercase tracking-wide",
											children: "Work Email *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "absolute left-3 top-1/2 -translate-y-1/2 size-3.5 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												id: "admin-email",
												type: "email",
												placeholder: "you@organization.com",
												value: formData.email,
												onChange: (e) => setFormData((p) => ({
													...p,
													email: e.target.value
												})),
												className: "pl-9 h-10 rounded-xl",
												required: true
											})]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: "admin-org",
											className: "text-xs font-semibold text-muted-foreground uppercase tracking-wide",
											children: "Organization / Institution *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "absolute left-3 top-1/2 -translate-y-1/2 size-3.5 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												id: "admin-org",
												placeholder: "e.g. National Career Institute",
												value: formData.organization,
												onChange: (e) => setFormData((p) => ({
													...p,
													organization: e.target.value
												})),
												className: "pl-9 h-10 rounded-xl",
												required: true
											})]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
											htmlFor: "admin-reason",
											className: "text-xs font-semibold text-muted-foreground uppercase tracking-wide",
											children: ["Reason for Admin Access *", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "ml-1 text-muted-foreground/60 normal-case font-normal",
												children: "(min 30 chars)"
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardList, { className: "absolute left-3 top-3 size-3.5 text-muted-foreground" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
													id: "admin-reason",
													placeholder: "Describe why you require administrator permissions and how you plan to manage platform content...",
													value: formData.reason,
													onChange: (e) => setFormData((p) => ({
														...p,
														reason: e.target.value
													})),
													rows: 3,
													className: "w-full pl-9 pr-3 py-2.5 text-sm rounded-xl bg-background/60 border border-border/70 text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-amber-500/60 resize-none transition-colors",
													required: true
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: `absolute bottom-2 right-3 text-[10px] ${formData.reason.length >= 30 ? "text-emerald-400" : "text-muted-foreground/50"}`,
													children: [formData.reason.length, "/30+"]
												})
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-1.5",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													htmlFor: "admin-password",
													className: "text-xs font-semibold text-muted-foreground uppercase tracking-wide",
													children: "Password *"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													id: "admin-password",
													type: "password",
													placeholder: "Min 10 chars",
													value: formData.password,
													onChange: (e) => setFormData((p) => ({
														...p,
														password: e.target.value
													})),
													className: "h-10 rounded-xl",
													required: true
												}),
												formData.password && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "flex gap-1 mt-1",
													children: [
														1,
														2,
														3,
														4,
														5
													].map((lvl) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `h-1 flex-1 rounded-full transition-colors ${passwordStrength.score >= lvl ? passwordStrength.score >= 4 ? "bg-emerald-500" : passwordStrength.score >= 3 ? "bg-amber-400" : "bg-red-500" : "bg-border/50"}` }, lvl))
												})
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
												htmlFor: "admin-confirm-password",
												className: "text-xs font-semibold text-muted-foreground uppercase tracking-wide",
												children: "Confirm Password *"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												id: "admin-confirm-password",
												type: "password",
												placeholder: "Repeat password",
												value: formData.confirmPassword,
												onChange: (e) => setFormData((p) => ({
													...p,
													confirmPassword: e.target.value
												})),
												className: `h-10 rounded-xl ${formData.confirmPassword && formData.password !== formData.confirmPassword ? "border-red-500/60" : ""}`,
												required: true
											})]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/25",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs text-amber-300/90 flex gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-4 shrink-0 mt-0.5 text-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Super Admin Review Policy:" }),
												" Accounts are marked as ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "Pending Approval" }),
												". You will only be granted access after verified Super Admin approval."
											] })]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "submit",
										disabled: loading,
										className: "w-full h-11 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold shadow-md shadow-amber-600/25 group cursor-pointer",
										children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin mr-2" }), " Sending Verification Code..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4 mr-2" }),
											"Continue to Verification",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 ml-1 group-hover:translate-x-0.5 transition-transform" })
										] })
									})
								]
							})]
						}),
						step === "email-verify" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3 pb-4 border-b border-border/70",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid size-11 place-items-center rounded-2xl bg-amber-500/15 border border-amber-500/30 text-amber-400 shrink-0",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-5" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
										className: "text-lg font-bold font-display",
										children: "Verify Email"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-muted-foreground mt-0.5",
										children: ["Enter the 6-digit code sent to ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-foreground font-medium",
											children: formData.email
										})]
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs text-muted-foreground mb-1",
										children: "Code expires in"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `text-2xl font-mono font-bold ${emailTimeLeft < 60 ? "text-red-400" : "text-foreground"}`,
										children: formatTimer(emailTimeLeft)
									})]
								}),
								emailOtpCode && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-2xl border border-amber-500/40 bg-amber-500/10 p-3.5 flex items-start gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-amber-500 text-base leading-none mt-0.5",
										children: "🔧"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex-1 min-w-0 text-left",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-bold text-amber-500 dark:text-amber-400",
												children: "Dev Mode — Security Code Generated"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-mono text-xl font-black tracking-[0.3em] text-amber-600 dark:text-amber-300 select-all cursor-pointer hover:opacity-85 transition-opacity",
												onClick: () => {
													const digits = emailOtpCode.slice(0, 6).split("");
													setEmailOtp(Array.from({ length: 6 }, (_, i) => digits[i] || ""));
													toast.success("Email verification code auto-filled!");
													setTimeout(() => emailRefs.current[5]?.focus(), 50);
												},
												title: "Click to auto-fill",
												children: emailOtpCode
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[10px] text-muted-foreground mt-0.5",
												children: [
													"Click code to auto-fill. To receive real emails, configure SMTP in ",
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
														className: "font-mono text-[9px] bg-muted px-1 py-0.5 rounded",
														children: ".env"
													}),
													"."
												]
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex justify-center gap-2.5 my-4",
									children: emailOtp.map((digit, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										ref: (el) => {
											emailRefs.current[i] = el;
										},
										type: "text",
										inputMode: "numeric",
										maxLength: 6,
										value: digit,
										onChange: (e) => handleEmailOtpInput(i, e.target.value),
										onKeyDown: (e) => handleEmailOtpKeyDown(i, e),
										className: `w-10 h-12 sm:w-12 sm:h-14 text-center text-lg font-bold rounded-xl border-2 bg-background/60 text-foreground outline-none transition-all duration-200 ${digit ? "border-amber-500 shadow-[0_0_12px_rgba(245,158,11,0.3)]" : "border-border/70 focus:border-amber-500/70"}`
									}, i))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									onClick: handleVerifyEmail,
									disabled: loading || emailOtp.join("").length !== 6,
									className: "w-full h-11 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold cursor-pointer",
									children: [loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin mr-2" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 mr-2" }), "Verify Email & Continue"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: handleResendEmailOtp,
										disabled: emailResendCooldown > 0 || loading,
										className: "text-xs text-muted-foreground hover:text-foreground transition-colors disabled:opacity-50 flex items-center gap-1.5 mx-auto cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-3" }), emailResendCooldown > 0 ? `Resend code in ${emailResendCooldown}s` : "Resend Email Code"]
									})
								})
							]
						}),
						step === "phone-verify" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3 pb-4 border-b border-border/70",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid size-11 place-items-center rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 shrink-0",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-5" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
										className: "text-lg font-bold font-display",
										children: "Verify Phone"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-muted-foreground mt-0.5",
										children: ["Enter the 6-digit code sent to ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-foreground font-medium",
											children: formData.phone
										})]
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/25 text-xs text-emerald-400",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5 inline mr-1.5 text-emerald-400" }), "Work email verified successfully."]
								}),
								phoneOtpCode && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-2xl border border-emerald-500/40 bg-emerald-500/10 p-3.5 flex items-start gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-emerald-500 text-base leading-none mt-0.5",
										children: "🔧"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex-1 min-w-0 text-left",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-bold text-emerald-500 dark:text-emerald-400",
												children: "Dev Mode — Simulated Phone OTP"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-mono text-xl font-black tracking-[0.3em] text-emerald-600 dark:text-emerald-300 select-all cursor-pointer hover:opacity-85 transition-opacity",
												onClick: () => {
													const digits = phoneOtpCode.slice(0, 6).split("");
													setPhoneOtp(Array.from({ length: 6 }, (_, i) => digits[i] || ""));
													toast.success("Phone verification code auto-filled!");
													setTimeout(() => phoneRefs.current[5]?.focus(), 50);
												},
												title: "Click to auto-fill",
												children: phoneOtpCode
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px] text-muted-foreground mt-0.5",
												children: "Click code to auto-fill simulated SMS verification code."
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex justify-center gap-2.5 my-4",
									children: phoneOtp.map((digit, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										ref: (el) => {
											phoneRefs.current[i] = el;
										},
										type: "text",
										inputMode: "numeric",
										maxLength: 6,
										value: digit,
										onChange: (e) => handlePhoneOtpInput(i, e.target.value),
										onKeyDown: (e) => handlePhoneOtpKeyDown(i, e),
										className: `w-10 h-12 sm:w-12 sm:h-14 text-center text-lg font-bold rounded-xl border-2 bg-background/60 text-foreground outline-none transition-all duration-200 ${digit ? "border-emerald-500 shadow-[0_0_12px_rgba(16,185,129,0.3)]" : "border-border/70 focus:border-emerald-500/70"}`
									}, i))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									onClick: handleVerifyPhone,
									disabled: loading || phoneOtp.join("").length !== 6,
									className: "w-full h-11 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold cursor-pointer",
									children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin mr-2" }), " Submitting Application..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 mr-2" }), " Verify Phone & Submit Application"] })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: handleResendPhoneOtp,
										disabled: phoneResendCooldown > 0,
										className: "text-xs text-muted-foreground hover:text-foreground transition-colors disabled:opacity-50 flex items-center gap-1.5 mx-auto cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-3" }), phoneResendCooldown > 0 ? `Resend in ${phoneResendCooldown}s` : "Resend Phone Code"]
									})
								})
							]
						}),
						step === "submitted" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-6 text-center py-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex justify-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-20 rounded-full bg-amber-500/15 flex items-center justify-center border border-amber-500/30 shadow-[0_0_30px_rgba(245,158,11,0.2)]",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-10 text-amber-400" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "absolute -bottom-1 -right-1 size-7 rounded-full bg-emerald-500 flex items-center justify-center border-2 border-background",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 text-white" })
										})]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "text-xl font-bold font-display text-foreground mb-1",
									children: "Application Submitted!"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-muted-foreground",
									children: [
										"Your administrator application is now",
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-amber-400 font-semibold",
											children: "Pending Super Admin Review"
										}),
										"."
									]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-background/60 border border-border/70 text-left space-y-2.5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between text-xs",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-muted-foreground",
												children: "Applicant"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-medium text-foreground",
												children: formData.fullName
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between text-xs",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-muted-foreground",
												children: "Email"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-medium text-foreground",
												children: formData.email
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between text-xs",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-muted-foreground",
												children: "Organization"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-medium text-foreground",
												children: formData.organization
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between text-xs",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-muted-foreground",
												children: "Application ID"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-mono text-[10px] text-amber-400",
												children: applicationId
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between text-xs",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-muted-foreground",
												children: "Status"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-amber-400 font-semibold flex items-center gap-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-amber-400 animate-pulse" }), "Pending Super Admin Approval"]
											})]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground leading-relaxed",
									children: [
										"Super Admin (",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-foreground font-medium",
											children: "raivats4@gmail.com"
										}),
										") has received your application. Once approved, you will be able to log in to the Management Console."
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col gap-2 pt-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										onClick: () => navigate({ to: "/admin/login" }),
										className: "w-full h-11 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold cursor-pointer",
										children: "Go to Admin Login"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/",
										className: "text-xs text-muted-foreground hover:text-foreground transition-colors mt-2",
										children: "Return to Homepage"
									})]
								})
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "text-center text-[11px] text-muted-foreground py-3",
				children: "CareerSetu AI • Super Admin Governed Access Portal • All applications reviewed server-side"
			})
		]
	});
}
//#endregion
export { AdminSignupPage as component };
