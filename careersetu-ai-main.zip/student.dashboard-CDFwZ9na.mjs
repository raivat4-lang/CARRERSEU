import { i as __toESM } from "../_runtime.mjs";
import { v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/student.dashboard-CDFwZ9na.js
var import_react = /* @__PURE__ */ __toESM(require_react());
function StudentDashboardRedirect() {
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		navigate({
			to: "/dashboard",
			replace: true
		});
	}, [navigate]);
	return null;
}
//#endregion
export { StudentDashboardRedirect as component };
