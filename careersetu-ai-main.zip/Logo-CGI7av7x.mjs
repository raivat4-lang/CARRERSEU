import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Logo-CGI7av7x.js
var import_jsx_runtime = require_jsx_runtime();
/**
* CareerSetu brand mark.
* "Setu" = bridge — a single arched span over a deck, with a guiding star above:
* the bridge from where a student is now to the career ahead.
* Drawn inline as SVG so it stays crisp at any size.
*/
function LogoMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 48 48",
		fill: "none",
		"aria-hidden": "true",
		className,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M24 3l2.1 4.7L31 9.8l-4.9 2.1L24 16.6l-2.1-4.7L17 9.8l4.9-2.1L24 3z",
				fill: "currentColor"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M6.5 36c0-9.7 7.8-17.5 17.5-17.5S41.5 26.3 41.5 36",
				stroke: "currentColor",
				strokeWidth: "4.2",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M4 36h40",
				stroke: "currentColor",
				strokeWidth: "4.2",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M24 36V23.5",
				stroke: "currentColor",
				strokeWidth: "3",
				strokeLinecap: "round",
				opacity: "0.6"
			})
		]
	});
}
function Logo({ className, size = "md" }) {
	const box = size === "lg" ? "size-12" : size === "sm" ? "size-8" : "size-10";
	const text = size === "lg" ? "text-2xl" : size === "sm" ? "text-base" : "text-lg";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: `flex min-w-0 items-center gap-2.5 ${className ?? ""}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `gradient-brand shadow-glow grid ${box} shrink-0 place-items-center rounded-[0.95rem] text-primary-foreground`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoMark, { className: "size-[78%]" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: `truncate font-display ${text} font-extrabold tracking-tight`,
			children: ["Career", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-gradient",
				children: "Setu"
			})]
		})]
	});
}
//#endregion
export { Logo as t };
