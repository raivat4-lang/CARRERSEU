//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DvkfmKyZ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/Raivat/Downloads/careersetu-ai-main/careersetu-ai-main/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/auth",
			"/admin/first-setup",
			"/admin/forgot-password",
			"/admin/login",
			"/admin/reset-password",
			"/admin/signup",
			"/admin/verify-mfa",
			"/student/login",
			"/student/signup",
			"/student/verify-mfa"
		],
		preloads: [
			"/assets/index-Bvx_0a4f.js",
			"/assets/react-SIfiwpqq.js",
			"/assets/card-BB7CDD3N.js",
			"/assets/link-00_398TT.js",
			"/assets/invariant-DEEwAagU.js",
			"/assets/useRouter-BOIK_ctv.js",
			"/assets/jsx-runtime-0vZSBttN.js",
			"/assets/dist-DaMJBOOH.js",
			"/assets/dist-6XRCsHSn.js",
			"/assets/dist-CxQLMtpZ.js",
			"/assets/dist-D02EahZX.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Bvx_0a4f.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/Raivat/Downloads/careersetu-ai-main/careersetu-ai-main/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DBgtXAN9.js",
			"/assets/arrow-right-BEPWhoGI.js",
			"/assets/bell-DgI6jO5x.js",
			"/assets/briefcase-tU36ioOU.js",
			"/assets/calendar-B3yQQbgm.js",
			"/assets/chevron-down-C_dO9U1q.js",
			"/assets/circle-question-mark-BknLfVYu.js",
			"/assets/compass-CEolWXNF.js",
			"/assets/external-link-D0we04BV.js",
			"/assets/file-text-BEbVpH8I.js",
			"/assets/flame-Dq78G3U4.js",
			"/assets/mail-CxQAHNNm.js",
			"/assets/menu-Rd8_TGju.js",
			"/assets/sun-Dk7zMYoC.js",
			"/assets/refresh-cw-CyIkjZeM.js",
			"/assets/shield-bTReFHjo.js",
			"/assets/star-BNOLLNP6.js",
			"/assets/user-plus-CcHkKspJ.js",
			"/assets/Logo-CMwvEJ8R.js"
		]
	},
	"/_authenticated": {
		filePath: "C:/Users/Raivat/Downloads/careersetu-ai-main/careersetu-ai-main/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/admin",
			"/_authenticated/assessment",
			"/_authenticated/assessment-results",
			"/_authenticated/bookmarks",
			"/_authenticated/careers",
			"/_authenticated/colleges",
			"/_authenticated/dashboard",
			"/_authenticated/exams",
			"/_authenticated/profile",
			"/_authenticated/progress",
			"/_authenticated/resources",
			"/_authenticated/resume",
			"/_authenticated/scholarships",
			"/_authenticated/settings",
			"/_authenticated/skill-gap",
			"/_authenticated/study-planner",
			"/_authenticated/student/dashboard"
		],
		preloads: [
			"/assets/route-Lxhw1QYN.js",
			"/assets/arrow-right-BEPWhoGI.js",
			"/assets/bell-DgI6jO5x.js",
			"/assets/book-open-C9DL596P.js",
			"/assets/briefcase-tU36ioOU.js",
			"/assets/building-2-BLh0mOVw.js",
			"/assets/calendar-B3yQQbgm.js",
			"/assets/select-BrfgtSk_.js",
			"/assets/external-link-D0we04BV.js",
			"/assets/file-text-BEbVpH8I.js",
			"/assets/settings-DWQVU4K3.js",
			"/assets/loader-circle-dfnGM31Q.js",
			"/assets/menu-Rd8_TGju.js",
			"/assets/sun-Dk7zMYoC.js",
			"/assets/rotate-ccw-C3TgJiXB.js",
			"/assets/shield-bTReFHjo.js",
			"/assets/trending-up-D6CurdqJ.js",
			"/assets/user-CPmcM1lX.js",
			"/assets/zap-D6yiHB6h.js",
			"/assets/admin-content-store-C8pQ1fgc.js",
			"/assets/Logo-CMwvEJ8R.js"
		]
	},
	"/auth": {
		filePath: "C:/Users/Raivat/Downloads/careersetu-ai-main/careersetu-ai-main/src/routes/auth.tsx",
		children: ["/auth/callback"],
		preloads: [
			"/assets/auth-CTwF39-2.js",
			"/assets/arrow-left-Dn5nYYJB.js",
			"/assets/arrow-right-BEPWhoGI.js",
			"/assets/select-BrfgtSk_.js",
			"/assets/circle-alert-CJDau4Dt.js",
			"/assets/loader-circle-dfnGM31Q.js",
			"/assets/lock-CbGycxOR.js",
			"/assets/mail-CxQAHNNm.js",
			"/assets/refresh-cw-CyIkjZeM.js",
			"/assets/user-check-Nd6eRP8K.js",
			"/assets/Logo-CMwvEJ8R.js",
			"/assets/label-BXcizJ9S.js"
		]
	},
	"/_authenticated/admin": {
		filePath: "C:/Users/Raivat/Downloads/careersetu-ai-main/careersetu-ai-main/src/routes/_authenticated/admin.tsx",
		children: ["/_authenticated/admin/dashboard"],
		preloads: [
			"/assets/admin-C3A2gkZB.js",
			"/assets/circle-question-mark-BknLfVYu.js",
			"/assets/clock-COcvnknD.js",
			"/assets/eye-BLih-J1n.js",
			"/assets/lock-CbGycxOR.js",
			"/assets/refresh-cw-CyIkjZeM.js",
			"/assets/shield-alert-CcfBXc2S.js",
			"/assets/user-check-Nd6eRP8K.js",
			"/assets/careersetu-store-BUGn49kH.js"
		]
	},
	"/_authenticated/assessment": {
		filePath: "C:/Users/Raivat/Downloads/careersetu-ai-main/careersetu-ai-main/src/routes/_authenticated/assessment.tsx",
		children: void 0,
		preloads: [
			"/assets/assessment-jIUWsRfN.js",
			"/assets/arrow-left-Dn5nYYJB.js",
			"/assets/assessment-questions-BB4nJHoL.js",
			"/assets/careersetu-store-BUGn49kH.js"
		]
	},
	"/_authenticated/assessment-results": {
		filePath: "C:/Users/Raivat/Downloads/careersetu-ai-main/careersetu-ai-main/src/routes/_authenticated/assessment-results.tsx",
		children: void 0,
		preloads: [
			"/assets/assessment-results-uCXU3PvU.js",
			"/assets/compass-CEolWXNF.js",
			"/assets/careersetu-store-BUGn49kH.js"
		]
	},
	"/_authenticated/bookmarks": {
		filePath: "C:/Users/Raivat/Downloads/careersetu-ai-main/careersetu-ai-main/src/routes/_authenticated/bookmarks.tsx",
		children: void 0,
		preloads: [
			"/assets/bookmarks-CKax3XV-.js",
			"/assets/colleges-data-1OIOuAi2.js",
			"/assets/exams-data-BmssMpcg.js",
			"/assets/careersetu-store-BUGn49kH.js"
		]
	},
	"/_authenticated/careers": {
		filePath: "C:/Users/Raivat/Downloads/careersetu-ai-main/careersetu-ai-main/src/routes/_authenticated/careers.tsx",
		children: void 0,
		preloads: [
			"/assets/careers-D6FA3rYU.js",
			"/assets/compass-CEolWXNF.js",
			"/assets/careersetu-store-BUGn49kH.js"
		]
	},
	"/_authenticated/colleges": {
		filePath: "C:/Users/Raivat/Downloads/careersetu-ai-main/careersetu-ai-main/src/routes/_authenticated/colleges.tsx",
		children: void 0,
		preloads: [
			"/assets/colleges-ClsdL4vH.js",
			"/assets/star-BNOLLNP6.js",
			"/assets/trophy-gTB8pQE1.js",
			"/assets/careersetu-store-BUGn49kH.js"
		]
	},
	"/_authenticated/exams": {
		filePath: "C:/Users/Raivat/Downloads/careersetu-ai-main/careersetu-ai-main/src/routes/_authenticated/exams.tsx",
		children: void 0,
		preloads: [
			"/assets/exams-CuOe5mWn.js",
			"/assets/shield-alert-CcfBXc2S.js",
			"/assets/careersetu-store-BUGn49kH.js"
		]
	},
	"/_authenticated/profile": {
		filePath: "C:/Users/Raivat/Downloads/careersetu-ai-main/careersetu-ai-main/src/routes/_authenticated/profile.tsx",
		children: void 0,
		preloads: ["/assets/profile-BQzbQfea.js", "/assets/save-Cds0NNFH.js"]
	},
	"/_authenticated/progress": {
		filePath: "C:/Users/Raivat/Downloads/careersetu-ai-main/careersetu-ai-main/src/routes/_authenticated/progress.tsx",
		children: void 0,
		preloads: [
			"/assets/progress-BVzgK7HN.js",
			"/assets/flame-Dq78G3U4.js",
			"/assets/trophy-gTB8pQE1.js",
			"/assets/careersetu-store-BUGn49kH.js"
		]
	},
	"/_authenticated/resources": {
		filePath: "C:/Users/Raivat/Downloads/careersetu-ai-main/careersetu-ai-main/src/routes/_authenticated/resources.tsx",
		children: void 0,
		preloads: [
			"/assets/resources-D0AdgYPo.js",
			"/assets/star-BNOLLNP6.js",
			"/assets/careersetu-store-BUGn49kH.js"
		]
	},
	"/_authenticated/resume": {
		filePath: "C:/Users/Raivat/Downloads/careersetu-ai-main/careersetu-ai-main/src/routes/_authenticated/resume.tsx",
		children: void 0,
		preloads: [
			"/assets/resume-CJxqivw2.js",
			"/assets/eye-BLih-J1n.js",
			"/assets/save-Cds0NNFH.js",
			"/assets/careersetu-store-BUGn49kH.js"
		]
	},
	"/_authenticated/scholarships": {
		filePath: "C:/Users/Raivat/Downloads/careersetu-ai-main/careersetu-ai-main/src/routes/_authenticated/scholarships.tsx",
		children: void 0,
		preloads: ["/assets/scholarships-h6-WKnvl.js", "/assets/careersetu-store-BUGn49kH.js"]
	},
	"/_authenticated/settings": {
		filePath: "C:/Users/Raivat/Downloads/careersetu-ai-main/careersetu-ai-main/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-DCsX1HL_.js",
			"/assets/key-round-BlZbh3FD.js",
			"/assets/save-Cds0NNFH.js"
		]
	},
	"/_authenticated/skill-gap": {
		filePath: "C:/Users/Raivat/Downloads/careersetu-ai-main/careersetu-ai-main/src/routes/_authenticated/skill-gap.tsx",
		children: void 0,
		preloads: ["/assets/skill-gap-b6WN9XCo.js", "/assets/careersetu-store-BUGn49kH.js"]
	},
	"/_authenticated/study-planner": {
		filePath: "C:/Users/Raivat/Downloads/careersetu-ai-main/careersetu-ai-main/src/routes/_authenticated/study-planner.tsx",
		children: void 0,
		preloads: [
			"/assets/study-planner--3AK0OnB.js",
			"/assets/clock-COcvnknD.js",
			"/assets/flame-Dq78G3U4.js",
			"/assets/exams-data-BmssMpcg.js",
			"/assets/careersetu-store-BUGn49kH.js"
		]
	},
	"/admin/first-setup": {
		filePath: "C:/Users/Raivat/Downloads/careersetu-ai-main/careersetu-ai-main/src/routes/admin.first-setup.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.first-setup-DyXPTA0Q.js",
			"/assets/arrow-left-Dn5nYYJB.js",
			"/assets/key-round-BlZbh3FD.js",
			"/assets/loader-circle-dfnGM31Q.js",
			"/assets/shield-check-Vfuvg4nz.js",
			"/assets/Logo-CMwvEJ8R.js",
			"/assets/label-BXcizJ9S.js"
		]
	},
	"/admin/forgot-password": {
		filePath: "C:/Users/Raivat/Downloads/careersetu-ai-main/careersetu-ai-main/src/routes/admin.forgot-password.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.forgot-password-B5pheoXF.js",
			"/assets/arrow-left-Dn5nYYJB.js",
			"/assets/arrow-right-BEPWhoGI.js",
			"/assets/key-round-BlZbh3FD.js",
			"/assets/loader-circle-dfnGM31Q.js",
			"/assets/mail-CxQAHNNm.js",
			"/assets/shield-alert-CcfBXc2S.js",
			"/assets/shield-check-Vfuvg4nz.js",
			"/assets/Logo-CMwvEJ8R.js",
			"/assets/label-BXcizJ9S.js"
		]
	},
	"/admin/login": {
		filePath: "C:/Users/Raivat/Downloads/careersetu-ai-main/careersetu-ai-main/src/routes/admin.login.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.login-BEckIw1b.js",
			"/assets/arrow-right-BEPWhoGI.js",
			"/assets/eye-off-Dc1BvVX2.js",
			"/assets/eye-BLih-J1n.js",
			"/assets/key-round-BlZbh3FD.js",
			"/assets/loader-circle-dfnGM31Q.js",
			"/assets/lock-CbGycxOR.js",
			"/assets/sun-Dk7zMYoC.js",
			"/assets/shield-alert-CcfBXc2S.js",
			"/assets/shield-check-Vfuvg4nz.js",
			"/assets/Logo-CMwvEJ8R.js",
			"/assets/label-BXcizJ9S.js"
		]
	},
	"/admin/reset-password": {
		filePath: "C:/Users/Raivat/Downloads/careersetu-ai-main/careersetu-ai-main/src/routes/admin.reset-password.tsx",
		children: void 0,
		preloads: ["/assets/admin.reset-password-nr6_IO2E.js"]
	},
	"/admin/signup": {
		filePath: "C:/Users/Raivat/Downloads/careersetu-ai-main/careersetu-ai-main/src/routes/admin.signup.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.signup-8incsPst.js",
			"/assets/arrow-left-Dn5nYYJB.js",
			"/assets/arrow-right-BEPWhoGI.js",
			"/assets/building-2-BLh0mOVw.js",
			"/assets/loader-circle-dfnGM31Q.js",
			"/assets/mail-CxQAHNNm.js",
			"/assets/refresh-cw-CyIkjZeM.js",
			"/assets/shield-alert-CcfBXc2S.js",
			"/assets/shield-check-Vfuvg4nz.js",
			"/assets/shield-bTReFHjo.js",
			"/assets/user-CPmcM1lX.js",
			"/assets/Logo-CMwvEJ8R.js",
			"/assets/label-BXcizJ9S.js"
		]
	},
	"/admin/verify-mfa": {
		filePath: "C:/Users/Raivat/Downloads/careersetu-ai-main/careersetu-ai-main/src/routes/admin.verify-mfa.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.verify-mfa-DSi5GsmW.js",
			"/assets/arrow-left-Dn5nYYJB.js",
			"/assets/circle-alert-CJDau4Dt.js",
			"/assets/loader-circle-dfnGM31Q.js",
			"/assets/mail-CxQAHNNm.js",
			"/assets/refresh-cw-CyIkjZeM.js",
			"/assets/shield-check-Vfuvg4nz.js",
			"/assets/Logo-CMwvEJ8R.js"
		]
	},
	"/auth/callback": {
		filePath: "C:/Users/Raivat/Downloads/careersetu-ai-main/careersetu-ai-main/src/routes/auth.callback.tsx",
		children: void 0,
		preloads: ["/assets/auth.callback-D5s7V1n2.js"]
	},
	"/student/login": {
		filePath: "C:/Users/Raivat/Downloads/careersetu-ai-main/careersetu-ai-main/src/routes/student.login.tsx",
		children: void 0,
		preloads: [
			"/assets/student.login-UhYpwD0Q.js",
			"/assets/arrow-right-BEPWhoGI.js",
			"/assets/eye-off-Dc1BvVX2.js",
			"/assets/eye-BLih-J1n.js",
			"/assets/key-round-BlZbh3FD.js",
			"/assets/loader-circle-dfnGM31Q.js",
			"/assets/mail-CxQAHNNm.js",
			"/assets/sun-Dk7zMYoC.js",
			"/assets/Logo-CMwvEJ8R.js",
			"/assets/label-BXcizJ9S.js"
		]
	},
	"/student/signup": {
		filePath: "C:/Users/Raivat/Downloads/careersetu-ai-main/careersetu-ai-main/src/routes/student.signup.tsx",
		children: void 0,
		preloads: [
			"/assets/student.signup-C7hiUeYb.js",
			"/assets/arrow-right-BEPWhoGI.js",
			"/assets/select-BrfgtSk_.js",
			"/assets/loader-circle-dfnGM31Q.js",
			"/assets/refresh-cw-CyIkjZeM.js",
			"/assets/user-plus-CcHkKspJ.js",
			"/assets/Logo-CMwvEJ8R.js",
			"/assets/label-BXcizJ9S.js"
		]
	},
	"/student/verify-mfa": {
		filePath: "C:/Users/Raivat/Downloads/careersetu-ai-main/careersetu-ai-main/src/routes/student.verify-mfa.tsx",
		children: void 0,
		preloads: [
			"/assets/student.verify-mfa-BBc8dgIZ.js",
			"/assets/arrow-left-Dn5nYYJB.js",
			"/assets/circle-alert-CJDau4Dt.js",
			"/assets/loader-circle-dfnGM31Q.js",
			"/assets/mail-CxQAHNNm.js",
			"/assets/refresh-cw-CyIkjZeM.js",
			"/assets/shield-check-Vfuvg4nz.js",
			"/assets/Logo-CMwvEJ8R.js"
		]
	},
	"/_authenticated/admin/dashboard": {
		filePath: "C:/Users/Raivat/Downloads/careersetu-ai-main/careersetu-ai-main/src/routes/_authenticated/admin.dashboard.tsx",
		children: void 0,
		preloads: ["/assets/admin.dashboard-O-6vdH05.js"]
	},
	"/_authenticated/student/dashboard": {
		filePath: "C:/Users/Raivat/Downloads/careersetu-ai-main/careersetu-ai-main/src/routes/_authenticated/student.dashboard.tsx",
		children: void 0,
		preloads: ["/assets/student.dashboard-B8IUsXAs.js"]
	}
} });
//#endregion
export { tsrStartManifest };
