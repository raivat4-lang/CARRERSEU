import { i as __toESM } from "../_runtime.mjs";
import { A as isRedirect, N as redirect, b as useRouter, c as HeadContent, d as createRouter, f as Outlet, g as Link, h as createRootRouteWithContext, m as createFileRoute, p as lazyRouteComponent, s as Scripts } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as createServerFn } from "./createServerFn-CIHAFgYl.mjs";
import { R as verifyAdminAccessServerFn, h as getCurrentUser, z as createSsrRpc } from "./rbac-D_Rf6U5V.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { n as cn, t as Card } from "./card-95-PmP7N.mjs";
import { t as Badge } from "./badge-BYEzUON3.mjs";
import { t as Button } from "./button-CdcMTBqt.mjs";
import { C as Search, G as Landmark, Ot as Bookmark, St as CalendarClock, X as GraduationCap, _t as ChevronRight, f as Trash2, g as Sparkles, i as Wallet, k as Plus, mt as CircleCheckBig, p as Target, pt as CircleCheck } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, n as DialogContent, o as DialogTitle, t as Dialog } from "./dialog-d9GHmrLL.mjs";
import { t as Input } from "./input-D7UBWI0-.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-mEmCUBpO.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { c as Radar, d as PolarGrid, m as Tooltip, n as RadarChart, p as ResponsiveContainer, u as PolarAngleAxis } from "../_libs/recharts+[...].mjs";
import { t as Progress } from "./progress-CNflbst_.mjs";
import { a as educationLabel } from "./options-f9ysKH3u.mjs";
import { t as supabase } from "./client-DVcAC_2T.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-BpbeoxIM.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { n as QueryClientProvider, t as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-DWN2lGJ0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useServerFn(serverFn) {
	const router = useRouter();
	return import_react.useCallback(async (...args) => {
		try {
			const res = await serverFn(...args);
			if (isRedirect(res)) throw res;
			return res;
		} catch (err) {
			if (isRedirect(err)) {
				err.options._fromLocation = router.stores.location.get();
				return router.navigate(router.resolveRedirect(err).options);
			}
			throw err;
		}
	}, [router, serverFn]);
}
var styles_default = "/assets/styles-nKVPTVeb.css";
var Toaster$1 = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
			description: "group-[.toast]:text-muted-foreground",
			actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
			cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
		} },
		...props
	});
};
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message,
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$31 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "CareerSetu — AI Career & Government Exam Guidance" },
			{
				name: "description",
				content: "AI career guidance, government exam finder and study planning for Indian students."
			},
			{
				name: "author",
				content: "CareerSetu"
			},
			{
				property: "og:title",
				content: "CareerSetu — AI Career & Government Exam Guidance"
			},
			{
				property: "og:description",
				content: "AI career guidance, government exam finder and study planning for Indian students."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap"
			},
			{
				rel: "icon",
				href: "/favicon.svg",
				type: "image/svg+xml"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("head", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
			src: "https://js.puter.com/v2/",
			async: true
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$31.useRouteContext();
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		const { data } = supabase.auth.onAuthStateChange((event) => {
			if (event !== "SIGNED_IN" && event !== "SIGNED_OUT" && event !== "USER_UPDATED") return;
			router.invalidate();
			if (event !== "SIGNED_OUT") queryClient.invalidateQueries();
		});
		return () => data.subscription.unsubscribe();
	}, [router, queryClient]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QueryClientProvider, {
		client: queryClient,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, {})]
	});
}
var $$splitComponentImporter$29 = () => import("./routes-CX8s7CHV.mjs");
var title$1 = "CareerSetu — AI Career & Government Exam Guidance";
var description$1 = "Take an AI career assessment, discover 100+ careers, find government exams, get live Indian exam news, study plans & college matches — built for Indian students.";
var Route$30 = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: title$1 },
		{
			name: "description",
			content: description$1
		},
		{
			property: "og:title",
			content: title$1
		},
		{
			property: "og:description",
			content: description$1
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$29, "component")
});
var $$splitComponentImporter$28 = () => import("./route-C-l5O7s9.mjs");
var Route$29 = createFileRoute("/_authenticated")({
	ssr: false,
	beforeLoad: async () => {
		return { user: getCurrentUser() };
	},
	component: lazyRouteComponent($$splitComponentImporter$28, "component")
});
var $$splitComponentImporter$27 = () => import("./auth-BNu5LqbP.mjs");
var title = "Sign In or Register — CareerSetu AI";
var description = "Access your CareerSetu AI career assessment, exam tracker, and customized study planner with secure multi-factor authentication.";
var Route$28 = createFileRoute("/auth")({
	validateSearch: (search) => ({ mode: search["mode"] === "signup" ? "signup" : "login" }),
	head: () => ({ meta: [
		{ title },
		{
			name: "description",
			content: description
		},
		{
			property: "og:title",
			content: title
		},
		{
			property: "og:description",
			content: description
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$27, "component")
});
var $$splitComponentImporter$26 = () => import("./admin-Ie7Np424.mjs");
var Route$27 = createFileRoute("/_authenticated/admin")({
	beforeLoad: async () => {
		let token = "";
		if (typeof localStorage !== "undefined") token = localStorage.getItem("careersetu_admin_token") || "";
		const verifyResult = await verifyAdminAccessServerFn({ data: { token } });
		if (!verifyResult.authorized) throw redirect({ to: "/admin/login" });
		return { adminUser: verifyResult.user };
	},
	head: () => ({ meta: [{ title: "CareerSetu Admin — Platform Management Console" }, {
		name: "description",
		content: "Secure administrative management console for CareerSetu AI users, careers, government exams, and platform analytics."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$26, "component")
});
var $$splitComponentImporter$25 = () => import("./assessment-D8AueDG3.mjs");
var Route$26 = createFileRoute("/_authenticated/assessment")({
	head: () => ({ meta: [{ title: "AI Career Assessment — CareerSetu" }, {
		name: "description",
		content: "Take the 50-question adaptive AI Career Assessment to discover your ideal career matches and strengths."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$25, "component")
});
var $$splitComponentImporter$24 = () => import("./assessment-results-DlQcv1Et.mjs");
var Route$25 = createFileRoute("/_authenticated/assessment-results")({
	head: () => ({ meta: [{ title: "Assessment Results — CareerSetu" }, {
		name: "description",
		content: "View your AI Career Assessment personality analysis, interest radar, and top recommended career paths."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$24, "component")
});
var $$splitComponentImporter$23 = () => import("./bookmarks-BT_Qebi9.mjs");
var Route$24 = createFileRoute("/_authenticated/bookmarks")({
	head: () => ({ meta: [{ title: "My Bookmarks — CareerSetu" }, {
		name: "description",
		content: "Access your saved careers, government exams, scholarships, and colleges in one centralized hub."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$23, "component")
});
var $$splitComponentImporter$22 = () => import("./careers-jJVDuGjG.mjs");
var Route$23 = createFileRoute("/_authenticated/careers")({
	head: () => ({ meta: [{ title: "Career Explorer — CareerSetu" }, {
		name: "description",
		content: "Explore 100+ high-growth careers across Technology, Healthcare, Civil Services, Finance, and Law."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$22, "component")
});
var $$splitComponentImporter$21 = () => import("./colleges-CGZEwDa0.mjs");
var Route$22 = createFileRoute("/_authenticated/colleges")({
	head: () => ({ meta: [{ title: "College Directory & Rankings — CareerSetu" }, {
		name: "description",
		content: "Explore top NIRF-ranked Indian universities and institutes across Engineering, Medical, IT, Management, and Law."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$21, "component")
});
function Skeleton({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("animate-pulse rounded-md bg-primary/10", className),
		...props
	});
}
var getMyProfile = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("5dbf46616266e7bfe81c82694a91090a42de6200b3efc1b9d156faf41ac3a479"));
var Route$21 = createFileRoute("/_authenticated/dashboard")({
	head: () => ({ meta: [
		{ title: "Dashboard — CareerSetu" },
		{
			name: "description",
			content: "Your personalized CareerSetu dashboard: live career match score, dynamic assessment progress, saved exams, deadlines and study plan."
		},
		{
			property: "og:title",
			content: "Dashboard — CareerSetu"
		},
		{
			property: "og:description",
			content: "Track your career match score, study progress and upcoming exam deadlines in real time."
		}
	] }),
	component: Dashboard
});
var DEFAULT_BLANK_INTERESTS = [
	{
		area: "Technology",
		score: 20
	},
	{
		area: "Science",
		score: 20
	},
	{
		area: "Management",
		score: 20
	},
	{
		area: "Commerce",
		score: 20
	},
	{
		area: "Arts",
		score: 20
	},
	{
		area: "Law",
		score: 20
	}
];
var CAREER_DATABASE = [
	{
		id: "1",
		name: "AI & Machine Learning Engineer",
		domain: "Technology",
		baseMatch: 95,
		salary: "₹12 - ₹35 LPA",
		demand: "Very High",
		description: "Design intelligent neural networks, LLMs, and computer vision systems.",
		bookmarked: true
	},
	{
		id: "2",
		name: "Cloud Architect & DevOps",
		domain: "Technology",
		baseMatch: 90,
		salary: "₹10 - ₹28 LPA",
		demand: "High",
		description: "Architect scalable multi-cloud infrastructure and automated CI/CD pipelines.",
		bookmarked: false
	},
	{
		id: "3",
		name: "Data Scientist & AI Analyst",
		domain: "Science",
		baseMatch: 88,
		salary: "₹9 - ₹24 LPA",
		demand: "High",
		description: "Extract predictive insights from massive enterprise datasets with statistics & ML.",
		bookmarked: true
	},
	{
		id: "4",
		name: "IAS / IPS Officer (Civil Services)",
		domain: "Law",
		baseMatch: 86,
		salary: "₹7 - ₹18 LPA + Perks",
		demand: "Prestigious",
		description: "Lead district administration, public policy formulation, and governance.",
		bookmarked: true
	},
	{
		id: "5",
		name: "Product & Strategy Manager",
		domain: "Management",
		baseMatch: 84,
		salary: "₹14 - ₹32 LPA",
		demand: "Very High",
		description: "Drive product vision, roadmap execution, and cross-functional leadership.",
		bookmarked: false
	},
	{
		id: "6",
		name: "Chartered Financial Analyst (CFA)",
		domain: "Commerce",
		baseMatch: 82,
		salary: "₹10 - ₹26 LPA",
		demand: "High",
		description: "Manage equity portfolios, corporate valuations, and investment funds.",
		bookmarked: false
	}
];
var INITIAL_EXAMS = [
	{
		id: "e1",
		name: "GATE CS (Computer Science)",
		window: "Feb 2027",
		category: "Engineering",
		saved: true
	},
	{
		id: "e2",
		name: "ISRO Scientist/Engineer ICRB",
		window: "Nov 2026",
		category: "Engineering",
		saved: true
	},
	{
		id: "e3",
		name: "UPSC Civil Services (Prelims)",
		window: "May 2027",
		category: "Civil Services",
		saved: true
	},
	{
		id: "e4",
		name: "JEE Advanced 2026",
		window: "May 2026",
		category: "Engineering",
		saved: false
	},
	{
		id: "e5",
		name: "NEET UG Medical 2026",
		window: "May 2026",
		category: "Medical",
		saved: false
	},
	{
		id: "e6",
		name: "SSC CGL Tier 1",
		window: "Sep 2026",
		category: "Civil Services",
		saved: false
	}
];
var ASSESSMENT_QUESTIONS = [
	{
		id: 1,
		question: "When solving a complex challenge, what is your preferred approach?",
		options: [
			{
				text: "Write code, algorithms or build automated software",
				scores: {
					Technology: 30,
					Science: 15
				}
			},
			{
				text: "Analyze financial statements, spreadsheets & trends",
				scores: {
					Commerce: 30,
					Management: 15
				}
			},
			{
				text: "Lead people, coordinate strategy & team execution",
				scores: {
					Management: 30,
					Law: 15
				}
			},
			{
				text: "Research scientific hypotheses, nature or medicine",
				scores: {
					Science: 30,
					Arts: 10
				}
			}
		]
	},
	{
		id: 2,
		question: "Which work environment excites you most?",
		options: [
			{
				text: "High-tech innovation lab / AI software startup",
				scores: { Technology: 25 }
			},
			{
				text: "Government ministry / Policy & civil administration",
				scores: {
					Law: 25,
					Management: 15
				}
			},
			{
				text: "Research laboratory / Hospital / Space agency",
				scores: { Science: 25 }
			},
			{
				text: "Investment bank / FinTech corporate boardroom",
				scores: { Commerce: 25 }
			}
		]
	},
	{
		id: 3,
		question: "What subjects did you naturally enjoy most?",
		options: [
			{
				text: "Mathematics, Programming & Computer Science",
				scores: {
					Technology: 25,
					Science: 15
				}
			},
			{
				text: "Physics, Chemistry & Biology",
				scores: { Science: 25 }
			},
			{
				text: "Economics, Accountancy & Business Studies",
				scores: {
					Commerce: 25,
					Management: 15
				}
			},
			{
				text: "Political Science, Civics, History & Law",
				scores: {
					Law: 25,
					Arts: 20
				}
			}
		]
	},
	{
		id: 4,
		question: "What long-term career impact motivates you most?",
		options: [
			{
				text: "Building groundbreaking tech used by millions worldwide",
				scores: { Technology: 25 }
			},
			{
				text: "Formulating national policies and reforming public welfare",
				scores: {
					Law: 25,
					Arts: 15
				}
			},
			{
				text: "Founding or scaling high-growth enterprises and funds",
				scores: {
					Management: 20,
					Commerce: 20
				}
			},
			{
				text: "Discovering scientific breakthroughs & healthcare solutions",
				scores: { Science: 25 }
			}
		]
	},
	{
		id: 5,
		question: "How do you prefer spending your productive work hours?",
		options: [
			{
				text: "Deep work on technical logic, architecture & system design",
				scores: { Technology: 25 }
			},
			{
				text: "Debating, negotiating, presenting and resolving disputes",
				scores: {
					Law: 20,
					Management: 15
				}
			},
			{
				text: "Conducting empirical data modeling & experimental analysis",
				scores: {
					Science: 20,
					Technology: 10
				}
			},
			{
				text: "Optimizing budgets, revenue models & market investments",
				scores: { Commerce: 25 }
			}
		]
	}
];
function Dashboard() {
	const fetchProfile = useServerFn(getMyProfile);
	const { data: serverProfile, isLoading } = useQuery({
		queryKey: ["profile"],
		queryFn: async () => {
			try {
				const timeoutPromise = new Promise((resolve) => setTimeout(() => resolve(null), 150));
				return await Promise.race([fetchProfile(), timeoutPromise]);
			} catch {
				return null;
			}
		},
		staleTime: 6e4
	});
	const demoProfile = typeof localStorage !== "undefined" ? localStorage.getItem("careersetu_demo_user") : null;
	const parsedDemo = demoProfile ? JSON.parse(demoProfile) : null;
	const profile = serverProfile || parsedDemo || {
		full_name: "Tushar Devendra",
		city: "Mumbai",
		current_education: "class_12"
	};
	const STORAGE_KEY = `careersetu_dashboard_${profile?.id || "default_user"}`;
	const [assessmentTaken, setAssessmentTaken] = (0, import_react.useState)(false);
	const [assessmentProgress, setAssessmentProgress] = (0, import_react.useState)(0);
	const [matchScore, setMatchScore] = (0, import_react.useState)(0);
	const [topRole, setTopRole] = (0, import_react.useState)("AI & Machine Learning Engineer");
	const [topDomain, setTopDomain] = (0, import_react.useState)("Technology & Engineering");
	const [interestsData, setInterestsData] = (0, import_react.useState)(DEFAULT_BLANK_INTERESTS);
	const [careersList, setCareersList] = (0, import_react.useState)(CAREER_DATABASE);
	const [savedExamsList, setSavedExamsList] = (0, import_react.useState)(INITIAL_EXAMS);
	const [examSearch, setExamSearch] = (0, import_react.useState)("");
	const [tasks, setTasks] = (0, import_react.useState)([
		{
			id: "1",
			title: "Aptitude: 20 quantitative questions",
			done: true
		},
		{
			id: "2",
			title: "Current affairs: 30 minutes reading",
			done: true
		},
		{
			id: "3",
			title: "Core syllabus revision: 1 hour",
			done: false
		},
		{
			id: "4",
			title: "Mock test Section 2 analysis",
			done: false
		}
	]);
	const [newTaskTitle, setNewTaskTitle] = (0, import_react.useState)("");
	const [isAssessmentOpen, setIsAssessmentOpen] = (0, import_react.useState)(false);
	const [assessmentStep, setAssessmentStep] = (0, import_react.useState)(0);
	const [selectedAnswers, setSelectedAnswers] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		if (typeof localStorage !== "undefined") {
			const saved = localStorage.getItem(STORAGE_KEY);
			if (saved) try {
				const data = JSON.parse(saved);
				if (data.assessmentTaken !== void 0) setAssessmentTaken(data.assessmentTaken);
				if (data.assessmentProgress !== void 0) setAssessmentProgress(data.assessmentProgress);
				if (data.matchScore !== void 0) setMatchScore(data.matchScore);
				if (data.topRole) setTopRole(data.topRole);
				if (data.topDomain) setTopDomain(data.topDomain);
				if (data.interestsData) setInterestsData(data.interestsData);
				if (data.careersList) setCareersList(data.careersList);
				if (data.savedExamsList) setSavedExamsList(data.savedExamsList);
				if (data.tasks) setTasks(data.tasks);
			} catch {}
		}
	}, [STORAGE_KEY]);
	const saveStateToStorage = (updated) => {
		if (typeof localStorage === "undefined") return;
		try {
			const current = localStorage.getItem(STORAGE_KEY);
			const merged = {
				...current ? JSON.parse(current) : {},
				assessmentTaken,
				assessmentProgress,
				matchScore,
				topRole,
				topDomain,
				interestsData,
				careersList,
				savedExamsList,
				tasks,
				...updated
			};
			localStorage.setItem(STORAGE_KEY, JSON.stringify(merged));
		} catch {}
	};
	const firstName = (profile?.full_name || "").split(" ")[0] || "Student";
	const doneTasks = tasks.filter((t) => t.done).length;
	const progressPercent = Math.round(doneTasks / (tasks.length || 1) * 100);
	const bookmarkedCareersCount = careersList.filter((c) => c.bookmarked).length;
	const trackedExamsCount = savedExamsList.filter((e) => e.saved).length;
	const toggleTask = (id) => {
		const nextTasks = tasks.map((t) => t.id === id ? {
			...t,
			done: !t.done
		} : t);
		setTasks(nextTasks);
		saveStateToStorage({ tasks: nextTasks });
	};
	const addTask = (e) => {
		e.preventDefault();
		if (!newTaskTitle.trim()) return;
		const nextTasks = [...tasks, {
			id: Date.now().toString(),
			title: newTaskTitle.trim(),
			done: false
		}];
		setTasks(nextTasks);
		setNewTaskTitle("");
		saveStateToStorage({ tasks: nextTasks });
		toast.success("Task added to Study Planner!");
	};
	const removeTask = (id) => {
		const nextTasks = tasks.filter((t) => t.id !== id);
		setTasks(nextTasks);
		saveStateToStorage({ tasks: nextTasks });
	};
	const toggleBookmarkCareer = (id) => {
		const nextCareers = careersList.map((c) => {
			if (c.id === id) {
				const nextState = !c.bookmarked;
				toast.success(nextState ? `Bookmarked ${c.name}` : `Removed ${c.name}`);
				return {
					...c,
					bookmarked: nextState
				};
			}
			return c;
		});
		setCareersList(nextCareers);
		saveStateToStorage({ careersList: nextCareers });
	};
	const toggleSaveExam = (id) => {
		const nextExams = savedExamsList.map((e) => {
			if (e.id === id) {
				const next = !e.saved;
				toast.success(next ? `Bookmarked ${e.name}` : `Removed ${e.name}`);
				return {
					...e,
					saved: next
				};
			}
			return e;
		});
		setSavedExamsList(nextExams);
		saveStateToStorage({ savedExamsList: nextExams });
	};
	const handleAssessmentOptionSelect = (optionIndex) => {
		const nextAnswers = [...selectedAnswers, optionIndex];
		setSelectedAnswers(nextAnswers);
		if (assessmentStep < ASSESSMENT_QUESTIONS.length - 1) setAssessmentStep((prev) => prev + 1);
		else {
			const rawScores = {
				Technology: 35,
				Science: 30,
				Management: 25,
				Commerce: 25,
				Arts: 20,
				Law: 20
			};
			nextAnswers.forEach((ansIdx, qIdx) => {
				const option = ASSESSMENT_QUESTIONS[qIdx]?.options[ansIdx];
				if (option?.scores) Object.entries(option.scores).forEach(([area, points]) => {
					rawScores[area] = (rawScores[area] ?? 20) + points;
				});
			});
			const updatedInterests = [
				{
					area: "Technology",
					score: Math.min(98, Math.max(30, rawScores["Technology"] ?? 35))
				},
				{
					area: "Science",
					score: Math.min(96, Math.max(25, rawScores["Science"] ?? 30))
				},
				{
					area: "Management",
					score: Math.min(95, Math.max(25, rawScores["Management"] ?? 25))
				},
				{
					area: "Commerce",
					score: Math.min(94, Math.max(25, rawScores["Commerce"] ?? 25))
				},
				{
					area: "Arts",
					score: Math.min(92, Math.max(20, rawScores["Arts"] ?? 20))
				},
				{
					area: "Law",
					score: Math.min(95, Math.max(20, rawScores["Law"] ?? 20))
				}
			];
			const sortedDomains = [...updatedInterests].sort((a, b) => b.score - a.score);
			const topArea = sortedDomains[0]?.area ?? "Technology";
			const computedMatchScore = sortedDomains[0]?.score ?? 94;
			let computedTopRole = "AI & Machine Learning Engineer";
			let domainLabel = "Technology & Engineering";
			if (topArea === "Science") {
				computedTopRole = "Data Scientist & AI Analyst";
				domainLabel = "Science & Data Analytics";
			} else if (topArea === "Management") {
				computedTopRole = "Product & Strategy Manager";
				domainLabel = "Management & Product Leadership";
			} else if (topArea === "Commerce") {
				computedTopRole = "Chartered Financial Analyst (CFA)";
				domainLabel = "Commerce & High Finance";
			} else if (topArea === "Law") {
				computedTopRole = "IAS / IPS Officer (Civil Services)";
				domainLabel = "Civil Services & Governance";
			} else if (topArea === "Arts") {
				computedTopRole = "Creative Design & UX Lead";
				domainLabel = "Creative Arts & Design";
			}
			const dynamicCareers = careersList.map((c) => {
				if (c.domain === topArea) return {
					...c,
					baseMatch: computedMatchScore
				};
				const areaScore = updatedInterests.find((i) => i.area === c.domain)?.score ?? 70;
				return {
					...c,
					baseMatch: Math.max(65, areaScore - 6)
				};
			}).sort((a, b) => b.baseMatch - a.baseMatch);
			setInterestsData(updatedInterests);
			setMatchScore(computedMatchScore);
			setTopRole(computedTopRole);
			setTopDomain(domainLabel);
			setAssessmentTaken(true);
			setAssessmentProgress(5);
			setCareersList(dynamicCareers);
			setIsAssessmentOpen(false);
			setAssessmentStep(0);
			setSelectedAnswers([]);
			saveStateToStorage({
				assessmentTaken: true,
				assessmentProgress: 5,
				matchScore: computedMatchScore,
				topRole: computedTopRole,
				topDomain: domainLabel,
				interestsData: updatedInterests,
				careersList: dynamicCareers
			});
			toast.success(`Assessment complete! Your Top Match is ${computedTopRole} (${computedMatchScore}% Match)!`);
		}
	};
	const retakeAssessment = () => {
		setAssessmentStep(0);
		setSelectedAnswers([]);
		setIsAssessmentOpen(true);
	};
	const activeQuestion = ASSESSMENT_QUESTIONS[assessmentStep] ?? {
		id: 1,
		question: "When solving a complex challenge, what is your preferred approach?",
		options: [
			{
				text: "Write code, algorithms or build automated software",
				scores: {
					Technology: 30,
					Science: 15
				}
			},
			{
				text: "Analyze financial statements, spreadsheets & trends",
				scores: {
					Commerce: 30,
					Management: 15
				}
			},
			{
				text: "Lead people, coordinate strategy & team execution",
				scores: {
					Management: 30,
					Law: 15
				}
			},
			{
				text: "Research scientific hypotheses, nature or medicine",
				scores: {
					Science: 30,
					Arts: 10
				}
			}
		]
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-7xl px-4 py-6 sm:px-6 space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "sr-only",
				children: "Your CareerSetu dashboard"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "gradient-brand shadow-elegant overflow-hidden rounded-3xl border-0 p-6 sm:p-8 text-primary-foreground",
				children: isLoading && !serverProfile && !parsedDemo ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-64 bg-primary-foreground/20" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-80 bg-primary-foreground/20" })]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-6 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 space-y-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "inline-flex items-center gap-1.5 rounded-full bg-primary-foreground/15 px-3 py-1 text-xs font-semibold backdrop-blur",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3.5" }),
									educationLabel(profile?.current_education),
									profile?.city ? ` · ${profile.city}` : ""
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "font-display text-2xl sm:text-3xl font-extrabold tracking-tight",
								children: [
									"Welcome back, ",
									firstName,
									"!"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "max-w-xl text-xs sm:text-sm text-primary-foreground/85 leading-relaxed",
								children: assessmentTaken ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
									"Your AI career analysis is ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
										className: "text-white font-bold",
										children: [matchScore, "% matched"]
									}),
									" for ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "text-white font-bold",
										children: topDomain
									}),
									" (",
									topRole,
									")."
								] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: "Take our quick 5-question AI assessment to calculate your real-time career match score, interest spectrum, and personalized exam roadmap!" })
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "lg",
						variant: "secondary",
						onClick: retakeAssessment,
						className: "h-12 rounded-xl font-bold px-6 shadow-soft shrink-0 hover:scale-[1.02] transition-transform cursor-pointer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "mr-2 size-4 text-primary" }), assessmentTaken ? "Retake AI Assessment" : "Take Quick AI Assessment"]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						icon: Target,
						label: "Top Match Score",
						value: assessmentTaken ? `${matchScore}%` : "Pending",
						hint: assessmentTaken ? topRole : "Complete quiz to unlock",
						badge: assessmentTaken ? "Live Match" : "Take Quiz"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						icon: GraduationCap,
						label: "Assessment Progress",
						value: `${assessmentProgress}/5`,
						hint: assessmentTaken ? "100% complete" : "Not started yet",
						badge: assessmentTaken ? "Completed" : "Action Needed"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						icon: Bookmark,
						label: "Bookmarked Careers",
						value: String(bookmarkedCareersCount),
						hint: "Saved career paths",
						badge: `${careersList.length} Available`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						icon: Landmark,
						label: "Tracked Govt Exams",
						value: String(trackedExamsCount),
						hint: "Active deadlines",
						badge: "Live Tracker"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
				defaultValue: "overview",
				className: "w-full space-y-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
						className: "flex w-full overflow-x-auto justify-start sm:justify-center rounded-2xl bg-card border border-border p-1.5 scrollbar-none",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "overview",
								className: "rounded-xl text-xs sm:text-sm font-medium px-4",
								children: "Overview"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "planner",
								className: "rounded-xl text-xs sm:text-sm font-medium px-4",
								children: [
									"Study Planner (",
									doneTasks,
									"/",
									tasks.length,
									")"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "exams",
								className: "rounded-xl text-xs sm:text-sm font-medium px-4",
								children: [
									"Government Exams (",
									trackedExamsCount,
									")"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "careers",
								className: "rounded-xl text-xs sm:text-sm font-medium px-4",
								children: [
									"Saved Careers (",
									bookmarkedCareersCount,
									")"
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
						value: "overview",
						className: "space-y-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-6 lg:grid-cols-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
								className: "glass rounded-2xl p-5 lg:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-semibold text-base",
										children: "Career Interest Spectrum"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: assessmentTaken ? "Computed live from your assessment responses" : "Take assessment to generate live analytics"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: assessmentTaken ? "default" : "outline",
										className: "text-xs",
										children: assessmentTaken ? "Live Analytics" : "Baseline"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-4 h-64 sm:h-72 w-full",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
										width: "100%",
										height: "100%",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(RadarChart, {
											data: interestsData,
											outerRadius: "70%",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarGrid, { stroke: "var(--border)" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarAngleAxis, {
													dataKey: "area",
													tick: {
														fill: "var(--foreground)",
														fontSize: 12
													}
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radar, {
													dataKey: "score",
													stroke: "var(--chart-1)",
													fill: "var(--chart-1)",
													fillOpacity: assessmentTaken ? .45 : .15
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
													background: "var(--popover)",
													border: "1px solid var(--border)",
													borderRadius: 12,
													color: "var(--popover-foreground)"
												} })
											]
										})
									})
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
								className: "glass rounded-2xl p-5 flex flex-col justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-semibold text-base",
											children: "Today's Study Goal"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
											variant: progressPercent === 100 ? "default" : "secondary",
											children: [progressPercent, "% Complete"]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
										value: progressPercent,
										className: "mt-4 h-2.5 rounded-full"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "mt-4 space-y-2.5",
										children: tasks.slice(0, 4).map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											onClick: () => toggleTask(t.id),
											className: "flex items-center gap-3 text-xs sm:text-sm cursor-pointer group",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `grid size-5 shrink-0 place-items-center rounded-full transition-colors ${t.done ? "bg-emerald-500 text-white" : "border border-border group-hover:border-primary"}`,
												children: t.done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5" }) : null
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: t.done ? "text-muted-foreground line-through" : "text-foreground font-medium",
												children: t.title
											})]
										}, t.id))
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									onClick: retakeAssessment,
									className: "mt-6 w-full rounded-xl gap-2 border-primary/20 text-xs font-semibold text-primary cursor-pointer hover:bg-primary/5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4" }), assessmentTaken ? "Retake Career Assessment" : "Take Career Quiz"]
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-6 sm:grid-cols-2 lg:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListCard, {
									icon: Bookmark,
									title: "Top Matched Careers",
									items: careersList.slice(0, 4).map((c) => ({
										primary: c.name,
										secondary: `${c.baseMatch}% match`
									}))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListCard, {
									icon: Landmark,
									title: "Tracked Government Exams",
									items: savedExamsList.filter((e) => e.saved).map((e) => ({
										primary: e.name,
										secondary: e.window
									}))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListCard, {
									icon: Wallet,
									title: "Matched Scholarships",
									items: [
										{
											primary: "NSP Merit Scholarship 2026",
											secondary: "₹20,000/yr"
										},
										{
											primary: "Maharashtra Freeship Scheme",
											secondary: "Full Tuition"
										},
										{
											primary: "INSPIRE DST Science Fellowship",
											secondary: "₹80,000/yr"
										}
									]
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "planner",
						className: "space-y-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "glass rounded-3xl p-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-xl font-bold font-display",
										children: "Interactive AI Study Planner"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground mt-0.5",
										children: "Manage daily study objectives and track preparation progress."
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex items-center gap-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
											variant: "outline",
											className: "text-sm px-3 py-1",
											children: [
												doneTasks,
												" of ",
												tasks.length,
												" Completed"
											]
										})
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
									value: progressPercent,
									className: "mt-4 h-3 rounded-full"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
									onSubmit: addTask,
									className: "mt-6 flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										placeholder: "Add a new study goal (e.g. Solve 30 Quant questions)...",
										value: newTaskTitle,
										onChange: (e) => setNewTaskTitle(e.target.value),
										className: "h-11 rounded-xl bg-background border-border text-sm"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										type: "submit",
										className: "gradient-brand h-11 px-5 rounded-xl text-primary-foreground font-semibold shrink-0 gap-1.5 cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " Add Task"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-6 space-y-3",
									children: tasks.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `flex items-center justify-between gap-4 p-4 rounded-2xl border transition-all ${t.done ? "bg-accent/30 border-border/40" : "bg-card border-border shadow-xs hover:border-primary/40"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											onClick: () => toggleTask(t.id),
											className: "flex items-center gap-3.5 cursor-pointer flex-1 min-w-0",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `grid size-6 shrink-0 place-items-center rounded-full transition-colors ${t.done ? "bg-emerald-500 text-white" : "border-2 border-border"}`,
												children: t.done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheckBig, { className: "size-4" }) : null
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `text-sm font-medium ${t.done ? "text-muted-foreground line-through" : "text-foreground"}`,
												children: t.title
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "ghost",
											size: "icon",
											onClick: () => removeTask(t.id),
											className: "h-8 w-8 text-muted-foreground hover:text-destructive rounded-lg cursor-pointer",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
										})]
									}, t.id))
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "exams",
						className: "space-y-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "glass rounded-3xl p-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-xl font-bold font-display",
									children: "Government & Entrance Exam Tracker"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground mt-0.5",
									children: "Discover eligibility, schedules, and bookmark exams for your target timeline."
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative w-full sm:w-64",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										placeholder: "Search exam name...",
										value: examSearch,
										onChange: (e) => setExamSearch(e.target.value),
										className: "pl-9 h-10 rounded-xl bg-background border-border text-sm"
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
								children: savedExamsList.filter((e) => e.name.toLowerCase().includes(examSearch.toLowerCase())).map((exam) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
									className: "p-5 rounded-2xl border-border/80 flex flex-col justify-between bg-card hover-lift",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												variant: "secondary",
												className: "text-[11px]",
												children: exam.category
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												variant: "ghost",
												size: "icon",
												onClick: () => toggleSaveExam(exam.id),
												className: `h-8 w-8 rounded-full cursor-pointer ${exam.saved ? "text-primary fill-primary" : "text-muted-foreground"}`,
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: `size-4 ${exam.saved ? "fill-primary text-primary" : ""}` })
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: "font-bold text-base mt-3",
											children: exam.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs text-muted-foreground mt-1 flex items-center gap-1.5",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarClock, { className: "size-3.5 text-primary" }),
												" Target: ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
													className: "text-foreground",
													children: exam.window
												})
											]
										})
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: exam.saved ? "outline" : "default",
										size: "sm",
										onClick: () => toggleSaveExam(exam.id),
										className: "mt-5 w-full rounded-xl text-xs font-semibold cursor-pointer",
										children: exam.saved ? "Bookmarked ✓" : "Track Exam"
									})]
								}, exam.id))
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "careers",
						className: "space-y-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "glass rounded-3xl p-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-xl font-bold font-display",
									children: "AI Recommended Careers"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground mt-0.5",
									children: assessmentTaken ? "Ranked according to your exact multi-discipline assessment scores." : "Complete the assessment to receive tailored real-time match rankings."
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									variant: "outline",
									className: "px-3 py-1 text-xs",
									children: [bookmarkedCareersCount, " Saved"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-6 grid gap-4 sm:grid-cols-2",
								children: careersList.map((career) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
									className: "p-5 rounded-2xl border-border bg-card hover-lift flex flex-col justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
												className: "bg-primary/10 text-primary border-primary/20",
												children: [career.baseMatch, "% Match"]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												variant: "ghost",
												size: "icon",
												onClick: () => toggleBookmarkCareer(career.id),
												className: `h-8 w-8 rounded-full cursor-pointer ${career.bookmarked ? "text-primary" : "text-muted-foreground"}`,
												title: career.bookmarked ? "Remove bookmark" : "Bookmark career",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: `size-4 ${career.bookmarked ? "fill-primary text-primary" : ""}` })
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: "font-bold text-lg mt-2",
											children: career.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-muted-foreground mt-1 leading-relaxed",
											children: career.description
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-3 flex items-center justify-between text-xs text-muted-foreground pt-2 border-t border-border/50",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Salary: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "text-foreground font-semibold",
												children: career.salary
											})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Demand: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "text-emerald-600 dark:text-emerald-400 font-semibold",
												children: career.demand
											})] })]
										})
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: career.bookmarked ? "outline" : "default",
										size: "sm",
										onClick: () => toggleBookmarkCareer(career.id),
										className: "mt-5 w-full rounded-xl text-xs font-semibold gap-1.5 cursor-pointer",
										children: career.bookmarked ? "Saved in Profile ✓" : "Bookmark Career Path"
									})]
								}, career.id))
							})]
						})
					})
				]
			}),
			isAssessmentOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: isAssessmentOpen,
				onOpenChange: setIsAssessmentOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-lg rounded-3xl p-6 sm:p-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
								variant: "outline",
								className: "text-xs text-primary border-primary/20",
								children: [
									"Question ",
									assessmentStep + 1,
									" of ",
									ASSESSMENT_QUESTIONS.length
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-muted-foreground",
								children: [Math.round((assessmentStep + 1) / ASSESSMENT_QUESTIONS.length * 100), "% Complete"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
							value: (assessmentStep + 1) / ASSESSMENT_QUESTIONS.length * 100,
							className: "h-1.5 rounded-full mb-3"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
							className: "text-base sm:text-lg font-bold font-display leading-snug",
							children: activeQuestion.question
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 space-y-2.5",
						children: activeQuestion.options.map((option, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => handleAssessmentOptionSelect(idx),
							className: "w-full text-left p-4 rounded-2xl bg-card border border-border/80 hover:border-primary hover:bg-primary/5 transition-all text-xs sm:text-sm font-medium text-foreground flex items-center justify-between group cursor-pointer shadow-2xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "pr-2",
								children: option.text
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4 shrink-0 text-muted-foreground group-hover:text-primary transition-colors" })]
						}, idx))
					})]
				})
			})
		]
	});
}
function StatCard({ icon: Icon, label, value, hint, badge }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "hover-lift glass rounded-2xl p-5 border-border/70 relative overflow-hidden",
		children: [
			badge && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				variant: "secondary",
				className: "absolute top-4 right-4 text-[10px] font-semibold py-0.5 px-2",
				children: badge
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-10 shrink-0 place-items-center rounded-xl bg-accent text-accent-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5 text-primary" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-xs text-muted-foreground font-medium",
						children: label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl font-bold text-foreground",
						children: value
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 truncate text-xs text-muted-foreground font-normal",
				children: hint
			})
		]
	});
}
function ListCard({ icon: Icon, title, items }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "glass rounded-2xl p-5 border-border/70",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 text-primary shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-semibold text-sm",
				children: title
			})]
		}), items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-xs text-muted-foreground",
			children: "Nothing saved yet."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 space-y-3",
			children: items.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-start justify-between gap-3 text-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "min-w-0 flex-1 font-medium text-foreground truncate",
					children: i.primary
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "shrink-0 text-muted-foreground font-semibold",
					children: i.secondary
				})]
			}, i.primary))
		})]
	});
}
var $$splitComponentImporter$20 = () => import("./exams-AZSYYp2I.mjs");
var Route$20 = createFileRoute("/_authenticated/exams")({
	head: () => ({ meta: [{ title: "Government & National Exams — CareerSetu" }, {
		name: "description",
		content: "Discover 20+ national entrance and government exams like UPSC, GATE, SSC CGL, RBI Grade B, and ISRO with official eligibility and syllabus."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$20, "component")
});
var $$splitComponentImporter$19 = () => import("./profile-2dHdcVm3.mjs");
var Route$19 = createFileRoute("/_authenticated/profile")({
	head: () => ({ meta: [{ title: "My Profile — CareerSetu" }, {
		name: "description",
		content: "Manage your student academic profile, current education level, target career interests, and contact details."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$19, "component")
});
var $$splitComponentImporter$18 = () => import("./progress-eD8_Gtqb.mjs");
var Route$18 = createFileRoute("/_authenticated/progress")({
	head: () => ({ meta: [{ title: "Progress & Achievements — CareerSetu" }, {
		name: "description",
		content: "Track your study streaks, assessment history, completed milestones, and unlocked achievement badges."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$18, "component")
});
var $$splitComponentImporter$17 = () => import("./resources-CaoG8GsZ.mjs");
var Route$17 = createFileRoute("/_authenticated/resources")({
	head: () => ({ meta: [{ title: "Learning Resources — CareerSetu" }, {
		name: "description",
		content: "Curated learning materials, standard textbooks, official PYQs, YouTube lecture series, and free study notes."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$17, "component")
});
var $$splitComponentImporter$16 = () => import("./resume-B3xaHj6c.mjs");
var Route$16 = createFileRoute("/_authenticated/resume")({
	head: () => ({ meta: [{ title: "AI Resume & CV Builder — CareerSetu" }, {
		name: "description",
		content: "Build professional ATS-optimized resumes with AI summary enhancement, real-time preview, and PDF export."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$16, "component")
});
var $$splitComponentImporter$15 = () => import("./scholarships-Ov1ZEOx5.mjs");
var Route$15 = createFileRoute("/_authenticated/scholarships")({
	head: () => ({ meta: [{ title: "Scholarship Finder — CareerSetu" }, {
		name: "description",
		content: "Discover verified government and CSR scholarships for Indian school and college students with active application deadlines."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$15, "component")
});
var $$splitComponentImporter$14 = () => import("./settings-DkF00z63.mjs");
var Route$14 = createFileRoute("/_authenticated/settings")({
	head: () => ({ meta: [{ title: "Settings — CareerSetu" }, {
		name: "description",
		content: "Configure language, theme, notification alerts, and custom AI provider API keys."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var $$splitComponentImporter$13 = () => import("./skill-gap-BcUOYw2x.mjs");
var Route$13 = createFileRoute("/_authenticated/skill-gap")({
	head: () => ({ meta: [{ title: "Skill Gap Analysis — CareerSetu" }, {
		name: "description",
		content: "Analyze missing skills for your target career, prioritize learning milestones, and track your technical mastery."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("./study-planner-CVgfQjHP.mjs");
var Route$12 = createFileRoute("/_authenticated/study-planner")({
	head: () => ({ meta: [{ title: "AI Study Planner — CareerSetu" }, {
		name: "description",
		content: "Generate adaptive daily schedules, weekly goals, and track your competitive exam preparation with automated missed task rescheduling."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
var $$splitComponentImporter$11 = () => import("./admin.first-setup-Cs3coHWq.mjs");
var Route$11 = createFileRoute("/admin/first-setup")({
	head: () => ({ meta: [{ title: "First-Time Administrator Setup — CareerSetu AI" }, {
		name: "description",
		content: "Establish initial administrator credentials with secure authorization."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./admin.forgot-password-CcJEXUkX.mjs");
var Route$10 = createFileRoute("/admin/forgot-password")({
	head: () => ({ meta: [{ title: "Administrator Password Recovery — CareerSetu AI" }, {
		name: "description",
		content: "Recover and reset your administrator account password using secure security code verification."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./admin.login-Fm9WthV9.mjs");
var Route$9 = createFileRoute("/admin/login")({
	head: () => ({ meta: [{ title: "Administrator Sign In — CareerSetu AI" }, {
		name: "description",
		content: "Restricted Administrative Gateway with Encrypted Database Verification and Email MFA."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./admin.reset-password-DL1Fxt0a.mjs");
var Route$8 = createFileRoute("/admin/reset-password")({
	head: () => ({ meta: [{ title: "Admin Password Reset — CareerSetu AI" }] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./admin.signup-BZWNibN9.mjs");
var Route$7 = createFileRoute("/admin/signup")({
	head: () => ({ meta: [{ title: "Request Admin Access — CareerSetu AI" }, {
		name: "description",
		content: "Apply for administrator access on CareerSetu AI. All applications require Super Admin approval."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./admin.verify-mfa-D19HN0h6.mjs");
var Route$6 = createFileRoute("/admin/verify-mfa")({
	head: () => ({ meta: [{ title: "Administrator Verification — CareerSetu AI" }, {
		name: "description",
		content: "Enter the 6-digit administrator MFA security code to access the console."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./auth.callback-DxFrFoeJ.mjs");
var Route$5 = createFileRoute("/auth/callback")({
	head: () => ({ meta: [{ title: "Signing you in… — CareerSetu AI" }] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./student.login-Ci6Yixqz.mjs");
var Route$4 = createFileRoute("/student/login")({
	head: () => ({ meta: [{ title: "Student Sign In — CareerSetu AI" }, {
		name: "description",
		content: "Sign in to your CareerSetu student account with secure Email MFA verification."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./student.signup-BOEF--sa.mjs");
var Route$3 = createFileRoute("/student/signup")({
	head: () => ({ meta: [{ title: "Student Registration — CareerSetu AI" }, {
		name: "description",
		content: "Create your CareerSetu student account and start personalized career discovery."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./student.verify-mfa-DatEtTxo.mjs");
var Route$2 = createFileRoute("/student/verify-mfa")({
	head: () => ({ meta: [{ title: "Verify Your Email — CareerSetu AI" }, {
		name: "description",
		content: "Enter the 6-digit email verification code to access your student dashboard."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./admin.dashboard-DzRKAD3F.mjs");
var Route$1 = createFileRoute("/_authenticated/admin/dashboard")({
	beforeLoad: async () => {
		let token = "";
		if (typeof localStorage !== "undefined") token = localStorage.getItem("careersetu_admin_token") || "";
		if (!(await verifyAdminAccessServerFn({ data: { token } })).authorized) throw redirect({ to: "/admin/login" });
	},
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./student.dashboard-CDFwZ9na.mjs");
var Route = createFileRoute("/_authenticated/student/dashboard")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var IndexRoute = Route$30.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$31
});
var AuthenticatedRouteRoute = Route$29.update({
	id: "/_authenticated",
	getParentRoute: () => Route$31
});
var AuthRoute = Route$28.update({
	id: "/auth",
	path: "/auth",
	getParentRoute: () => Route$31
});
var AuthenticatedAdminRoute = Route$27.update({
	id: "/admin",
	path: "/admin",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedAssessmentRoute = Route$26.update({
	id: "/assessment",
	path: "/assessment",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedAssessmentResultsRoute = Route$25.update({
	id: "/assessment-results",
	path: "/assessment-results",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedBookmarksRoute = Route$24.update({
	id: "/bookmarks",
	path: "/bookmarks",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedCareersRoute = Route$23.update({
	id: "/careers",
	path: "/careers",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedCollegesRoute = Route$22.update({
	id: "/colleges",
	path: "/colleges",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedDashboardRoute = Route$21.update({
	id: "/dashboard",
	path: "/dashboard",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedExamsRoute = Route$20.update({
	id: "/exams",
	path: "/exams",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedProfileRoute = Route$19.update({
	id: "/profile",
	path: "/profile",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedProgressRoute = Route$18.update({
	id: "/progress",
	path: "/progress",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedResourcesRoute = Route$17.update({
	id: "/resources",
	path: "/resources",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedResumeRoute = Route$16.update({
	id: "/resume",
	path: "/resume",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedScholarshipsRoute = Route$15.update({
	id: "/scholarships",
	path: "/scholarships",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedSettingsRoute = Route$14.update({
	id: "/settings",
	path: "/settings",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedSkillGapRoute = Route$13.update({
	id: "/skill-gap",
	path: "/skill-gap",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedStudyPlannerRoute = Route$12.update({
	id: "/study-planner",
	path: "/study-planner",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AdminFirstSetupRoute = Route$11.update({
	id: "/admin/first-setup",
	path: "/admin/first-setup",
	getParentRoute: () => Route$31
});
var AdminForgotPasswordRoute = Route$10.update({
	id: "/admin/forgot-password",
	path: "/admin/forgot-password",
	getParentRoute: () => Route$31
});
var AdminLoginRoute = Route$9.update({
	id: "/admin/login",
	path: "/admin/login",
	getParentRoute: () => Route$31
});
var AdminResetPasswordRoute = Route$8.update({
	id: "/admin/reset-password",
	path: "/admin/reset-password",
	getParentRoute: () => Route$31
});
var AdminSignupRoute = Route$7.update({
	id: "/admin/signup",
	path: "/admin/signup",
	getParentRoute: () => Route$31
});
var AdminVerifyMfaRoute = Route$6.update({
	id: "/admin/verify-mfa",
	path: "/admin/verify-mfa",
	getParentRoute: () => Route$31
});
var AuthCallbackRoute = Route$5.update({
	id: "/callback",
	path: "/callback",
	getParentRoute: () => AuthRoute
});
var StudentLoginRoute = Route$4.update({
	id: "/student/login",
	path: "/student/login",
	getParentRoute: () => Route$31
});
var StudentSignupRoute = Route$3.update({
	id: "/student/signup",
	path: "/student/signup",
	getParentRoute: () => Route$31
});
var StudentVerifyMfaRoute = Route$2.update({
	id: "/student/verify-mfa",
	path: "/student/verify-mfa",
	getParentRoute: () => Route$31
});
var AuthenticatedAdminDashboardRoute = Route$1.update({
	id: "/dashboard",
	path: "/dashboard",
	getParentRoute: () => AuthenticatedAdminRoute
});
var AuthenticatedStudentDashboardRoute = Route.update({
	id: "/student/dashboard",
	path: "/student/dashboard",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedAdminRouteChildren = { AuthenticatedAdminDashboardRoute };
var AuthenticatedRouteRouteChildren = {
	AuthenticatedAdminRoute: AuthenticatedAdminRoute._addFileChildren(AuthenticatedAdminRouteChildren),
	AuthenticatedAssessmentRoute,
	AuthenticatedAssessmentResultsRoute,
	AuthenticatedBookmarksRoute,
	AuthenticatedCareersRoute,
	AuthenticatedCollegesRoute,
	AuthenticatedDashboardRoute,
	AuthenticatedExamsRoute,
	AuthenticatedProfileRoute,
	AuthenticatedProgressRoute,
	AuthenticatedResourcesRoute,
	AuthenticatedResumeRoute,
	AuthenticatedScholarshipsRoute,
	AuthenticatedSettingsRoute,
	AuthenticatedSkillGapRoute,
	AuthenticatedStudyPlannerRoute,
	AuthenticatedStudentDashboardRoute
};
var AuthenticatedRouteRouteWithChildren = AuthenticatedRouteRoute._addFileChildren(AuthenticatedRouteRouteChildren);
var AuthRouteChildren = { AuthCallbackRoute };
var rootRouteChildren = {
	IndexRoute,
	AuthenticatedRouteRoute: AuthenticatedRouteRouteWithChildren,
	AuthRoute: AuthRoute._addFileChildren(AuthRouteChildren),
	AdminFirstSetupRoute,
	AdminForgotPasswordRoute,
	AdminLoginRoute,
	AdminResetPasswordRoute,
	AdminSignupRoute,
	AdminVerifyMfaRoute,
	StudentLoginRoute,
	StudentSignupRoute,
	StudentVerifyMfaRoute
};
var routeTree = Route$31._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreload: "intent",
		defaultPreloadStaleTime: 3e4
	});
};
//#endregion
export { getRouter };
