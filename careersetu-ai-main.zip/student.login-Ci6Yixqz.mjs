import { i as __toESM } from "../_runtime.mjs";
import { g as Link, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { x as initiateStudentLogin } from "./rbac-D_Rf6U5V.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Card } from "./card-95-PmP7N.mjs";
import { t as Button } from "./button-CdcMTBqt.mjs";
import { B as LoaderCircle, I as Mail, K as KeyRound, M as Moon, Mt as ArrowRight, g as Sparkles, m as Sun, nt as Eye, rt as EyeOff } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-D7UBWI0-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Logo } from "./Logo-CGI7av7x.mjs";
import { t as Label } from "./label-DiINKb2h.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/student.login-Ci6Yixqz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function StudentLoginPage() {
	const navigate = useNavigate();
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [showPassword, setShowPassword] = (0, import_react.useState)(false);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const handleStudentLogin = async (e) => {
		e.preventDefault();
		if (!email || !password) {
			toast.error("Please provide both email and password.");
			return;
		}
		setLoading(true);
		try {
			const result = await initiateStudentLogin(email, password);
			if (!result.success) {
				toast.error(result.error || "Invalid email or password.");
				setLoading(false);
				return;
			}
			if (typeof sessionStorage !== "undefined") {
				sessionStorage.setItem("careersetu_pending_student_email", email.trim().toLowerCase());
				sessionStorage.setItem("careersetu_pending_student_masked", result.maskedEmail || "");
				if (result.devOtp) {
					sessionStorage.setItem("careersetu_dev_otp", result.devOtp);
					sessionStorage.setItem("careersetu_pending_dev_otp", result.devOtp);
				}
			}
			if (result.requiresVerification) toast.info("Account pending verification — check your email for a 6-digit code.");
			else toast.success("Verification code sent — check your email.");
			navigate({ to: "/student/verify-mfa" });
		} catch (err) {
			toast.error("An unexpected error occurred during login. Please try again.");
		} finally {
			setLoading(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background text-foreground relative overflow-hidden flex flex-col justify-between p-4 sm:p-8 antialiased",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gradient-soft absolute inset-0 -z-10 opacity-70" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "blueprint-grid absolute inset-0 -z-10 opacity-40" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -top-32 left-1/2 -translate-x-1/2 -z-10 size-[32rem] rounded-full bg-primary/15 blur-[120px] pointer-events-none" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto w-full max-w-md flex items-center justify-between pt-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "flex items-center gap-2 hover:opacity-90 transition-opacity",
					"aria-label": "CareerSetu home",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "ghost",
					size: "icon",
					"aria-label": "Toggle theme",
					onClick: () => {
						document.documentElement.classList.toggle("dark");
					},
					className: "rounded-xl size-9 text-muted-foreground hover:text-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0 text-amber-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "absolute size-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100 text-sky-400" })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto w-full max-w-md py-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 rounded-2xl bg-primary/10 border border-primary/25 p-3.5 flex items-start gap-3 text-xs text-primary backdrop-blur-md shadow-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-bold",
							children: "Backend Email 2FA Enabled"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-0.5 text-muted-foreground leading-relaxed text-[11px]",
							children: "Every sign-in dispatches a single-use 6-digit security code directly to your registered email address."
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: "rounded-3xl p-6 sm:p-8 bg-card/90 border border-border/80 shadow-elegant backdrop-blur-xl",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3.5 pb-4 border-b border-border/70",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid size-12 place-items-center rounded-2xl gradient-brand text-primary-foreground shadow-glow shrink-0",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-5" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
										className: "text-xl font-bold font-display text-foreground tracking-tight",
										children: "Student Sign In"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground mt-0.5",
										children: "Step 1: Enter email & password"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
									onSubmit: handleStudentLogin,
									className: "space-y-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-xs text-foreground font-semibold mb-1.5 block",
											children: "Student Email"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "email",
											required: true,
											value: email,
											onChange: (e) => setEmail(e.target.value),
											placeholder: "student@careersetu.ai",
											className: "rounded-xl h-11 text-xs sm:text-sm"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex items-center justify-between mb-1.5",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
												className: "text-xs text-foreground font-semibold",
												children: "Password"
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												type: showPassword ? "text" : "password",
												required: true,
												value: password,
												onChange: (e) => setPassword(e.target.value),
												placeholder: "••••••••••••",
												className: "rounded-xl h-11 text-xs sm:text-sm pr-11"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setShowPassword(!showPassword),
												className: "absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground cursor-pointer p-1.5 rounded-lg hover:bg-accent/80 transition-colors",
												"aria-label": showPassword ? "Hide password" : "Show password",
												children: showPassword ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" })
											})]
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "pt-2",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												type: "submit",
												disabled: loading,
												className: "w-full h-11 rounded-xl gradient-brand text-primary-foreground font-bold text-xs sm:text-sm shadow-glow hover:opacity-95 hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0 cursor-pointer transition-all group",
												children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin mr-2" }), "Verifying & Sending Security Code..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Sign In & Request Email Code", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 ml-2 transition-transform duration-200 group-hover:translate-x-1" })] })
											})
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "pt-4 border-t border-border/70 text-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[11px] text-muted-foreground mb-2.5 font-medium",
										children: "Quick Demo Accounts:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap gap-2 justify-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											type: "button",
											variant: "outline",
											size: "sm",
											onClick: () => {
												setEmail("aditi.kulkarni@gmail.com");
												setPassword("student123");
												toast.info("Loaded Aditi Kulkarni credentials");
											},
											className: "text-[11px] font-medium rounded-xl h-8 px-3 border-border/80 bg-card/75 text-foreground hover:bg-accent/80 hover:border-primary/40 cursor-pointer transition-all active:scale-95",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "size-3 mr-1.5 text-primary" }), " Aditi (student123)"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											type: "button",
											variant: "outline",
											size: "sm",
											onClick: () => {
												setEmail("rahul.sharma@gmail.com");
												setPassword("student123");
												toast.info("Loaded Rahul Sharma credentials");
											},
											className: "text-[11px] font-medium rounded-xl h-8 px-3 border-border/80 bg-card/75 text-foreground hover:bg-accent/80 hover:border-primary/40 cursor-pointer transition-all active:scale-95",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "size-3 mr-1.5 text-primary" }), " Rahul (student123)"]
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "pt-2 text-center text-xs text-muted-foreground",
									children: [
										"Don't have a student account yet?",
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/student/signup",
											className: "text-primary font-semibold hover:underline underline-offset-2",
											children: "Create Student Account"
										})
									]
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5 text-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/admin/login",
							className: "text-xs text-muted-foreground hover:text-amber-500 transition-colors inline-flex items-center gap-1",
							children: "Looking for Administrator Gateway? Click here →"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "text-center text-[11px] text-muted-foreground py-3",
				children: "CareerSetu AI Student Portal • Protected by PBKDF2 Encryption & Email MFA"
			})
		]
	});
}
//#endregion
export { StudentLoginPage as component };
