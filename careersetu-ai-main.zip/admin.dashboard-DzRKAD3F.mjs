import { i as __toESM } from "../_runtime.mjs";
import { v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.dashboard-DzRKAD3F.js
var import_react = /* @__PURE__ */ __toESM(require_react());
function AdminDashboardRedirect() {
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		navigate({
			to: "/admin",
			replace: true
		});
	}, [navigate]);
	return null;
}
//#endregion
export { AdminDashboardRedirect as component };
